import {
    _ as x,
    u as k,
    v as g,
    g as m,
    x as y,
    y as b,
    h as $,
    r as u,
    o as c,
    i as T,
    j as C,
    c as l,
    F as H,
    a as M,
    n as L,
    z as B,
    k as v,
    p as _,
    d as f,
    w,
    A as S
} from "./index-1cb91aca.js";
import {
    u as z
} from "./uniqueId-d6099c84.js";
const N = {
        data() {
            return {
                popped: []
            }
        },
        created() {
            const t = this;
            k.global._toaster = {
                popped: t.popped,
                pop: t.pop
            }
        },
        methods: {
            pop(t) {
                const n = this,
                    o = {
                        title: "",
                        description: "",
                        duration: 5e3,
                        id: z(),
                        callback: null,
                        swiping: !1,
                        swiped: !1,
                        x: null,
                        y: null
                    },
                    e = g({ ...o,
                        ...t
                    });
                n.popped.push(e), n.$nextTick(() => {
                    const i = m(n.$refs, e.id + "[0]");
                    if (i) {
                        const {
                            distanceX: a,
                            isSwiping: d
                        } = y(i, {
                            threshold: 10,
                            onSwipe() {
                                e.swiping = !0, i.offsetWidth && (a.value < 0 ? e.x = Math.abs(a.value) + "px" : e.x = null)
                            },
                            onSwipeEnd() {
                                e.swiping = !1, e.swiped = !0;
                                const r = i.offsetWidth,
                                    p = r ? Math.abs(a.value) / r : 0;
                                a.value < 0 && p >= .33 ? n.remove(e) : e.x = null
                            }
                        })
                    }
                }), n.remove(e, e.duration)
            },
            remove(t, n) {
                const o = this;
                b(() => {
                    const e = m(o.$refs, t.id + "[0]");
                    if (e) {
                        const i = e.offsetParent.offsetHeight;
                        t.y = i - e.offsetTop - e.offsetHeight + "px"
                    }
                    t.callback && t.callback(), o.$nextTick(() => {
                        const i = o.popped.indexOf(t);
                        i > -1 && o.popped.splice(i, 1)
                    })
                }, n)
            }
        }
    },
    V = {
        key: 0,
        class: "ui-toaster_icon --ui-center"
    },
    D = {
        class: "ui-toaster_content"
    },
    E = {
        key: 0
    },
    F = ["innerHTML"],
    O = ["innerHTML"],
    W = ["onClick"];

function j(t, n, o, e, i, a) {
    const d = $("icon"),
        r = u("orphans"),
        p = u("nl2br"),
        h = u("links");
    return c(), T(S, {
        name: "ui-toaster",
        tag: "ul",
        class: "ui-toaster --app-scrollbar-offset"
    }, {
        default: C(() => [(c(!0), l(H, null, M(i.popped, s => (c(), l("li", {
            key: s.id,
            ref_for: !0,
            ref: s.id,
            class: L([{
                "--swiping": s.swiping,
                "--swiped": s.swiped
            }, "ui-toaster_item --ui-raised --ui-shadow-sm"]),
            style: B({
                "--toast-x": s.x,
                "--toast-y": s.y
            })
        }, [s.icon ? (c(), l("div", V, [v(d, {
            name: s.icon
        }, null, 8, ["name"])])) : _("", !0), f("div", D, [s.title ? (c(), l("p", E, [w(f("b", {
            class: "--type-text",
            innerHTML: s.title
        }, null, 8, F), [
            [r],
            [p],
            [h]
        ])])) : _("", !0), s.description ? w((c(), l("p", {
            key: 1,
            class: "--type-caption",
            innerHTML: s.description
        }, null, 8, O)), [
            [r],
            [p],
            [h]
        ]) : _("", !0)]), f("button", {
            class: "ui-toaster_close --input-reset --ui-icon",
            onClick: q => a.remove(s)
        }, [v(d, {
            name: "action-close"
        })], 8, W)], 6))), 128))]),
        _: 1
    })
}
const I = x(N, [
    ["render", j]
]);
export {
    I as
    default
};