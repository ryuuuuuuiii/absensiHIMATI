import {
    _ as $,
    l as B,
    e as E,
    f as b,
    s as w,
    h as a,
    r as x,
    o as t,
    i as _,
    j as o,
    c as i,
    n as m,
    F as p,
    k as n,
    d as r,
    p as d,
    a as C,
    t as g,
    w as V,
    q as D,
    T as N
} from "./index-1cb91aca.js";
const T = {
        components: {
            "svg-pomegranate-logo": B(() => E(() =>
                import ("./pomegranate-logo-a7584a2f.js"), ["assets/pomegranate-logo-a7584a2f.js", "assets/index-1cb91aca.js", "assets/index-ff101a6a.css", "assets/pomegranate-logo-b4f056ee.css"]))
        },
        computed: {
            title() {
                return this.$api.options.site_title || []
            },
            menu() {
                return this.$api.menus.main || []
            }
        },
        methods: {
            animeInit() {
                b(this.$refs.menu.querySelectorAll(".ui-button"), {
                    scale: {
                        from: .9
                    },
                    opacity: {
                        from: 0,
                        duration: 50,
                        ease: "linear"
                    },
                    duration: 700,
                    delay: w(25, {
                        start: 25
                    }),
                    ease: "outElastic(1, .8)"
                })
            }
        }
    },
    z = {
        class: "part-menu_logo-img"
    },
    I = {
        class: "part-menu_panel"
    },
    q = {
        class: "--ui-col"
    },
    A = {
        class: "part-menu_title"
    },
    F = {
        class: "part-menu_desc"
    };

function L(e, l, P, S, j, u) {
    const v = a("svg-pomegranate-logo"),
        f = a("route"),
        h = a("ui-gradient"),
        c = a("ui-button"),
        k = a("ui-scroll"),
        y = x("orphans");
    return t(), _(N, {
        name: "part-menu",
        onEnter: u.animeInit
    }, {
        default: o(() => [e.$app.menu ? (t(), i("div", {
            key: 0,
            class: m(["part-menu --ui-col --app-scrollbar-offset", {
                "--ui-x-outer --ui-px": e._is("lg")
            }]),
            onClick: l[0] || (l[0] = s => e._app.toggleMenu(!1)),
            ref: "menu"
        }, [e._isBelow("lg") ? (t(), i(p, {
            key: 0
        }, [n(f, {
            link: "/",
            class: "part-menu_logo --ui-center --ui-px"
        }, {
            default: o(() => [r("div", z, [n(v, {
                immediate: ""
            })])]),
            _: 1
        }), n(h, {
            colors: ["pom-1", "pom-3", "raised"],
            immediate: "",
            flush: ""
        })], 64)) : d("", !0), n(k, {
            class: m(["part-menu_scroll", {
                "--ui-raised": e._is("lg")
            }]),
            container: {
                class: "part-menu_list"
            },
            tag: "nav",
            active: e._isBelow("lg")
        }, {
            default: o(() => [(t(!0), i(p, null, C(u.menu, s => (t(), _(c, {
                link: s.link,
                variant: "box",
                class: "part-menu_link"
            }, {
                default: o(() => [r("div", I, [n(c, {
                    icon: s.icon,
                    variant: "seamless",
                    size: "sm",
                    nested: ""
                }, null, 8, ["icon"]), r("span", q, [r("span", A, g(s.link.text), 1), V((t(), i("span", F, [D(g(s.desc), 1)])), [
                    [y]
                ])])])]),
                _: 2
            }, 1032, ["link"]))), 256))]),
            _: 1
        }, 8, ["class", "active"])], 2)) : d("", !0)]),
        _: 1
    }, 8, ["onEnter"])
}
const O = $(T, [
    ["render", L]
]);
export {
    O as
    default
};