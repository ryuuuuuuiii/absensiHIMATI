import {
    _ as f,
    l as v,
    e as h,
    f as g,
    s as k,
    h as i,
    o as t,
    c as s,
    d as u,
    i as r,
    p as l,
    j as y,
    k as d,
    n as C
} from "./index-1cb91aca.js";
const x = {
        components: {
            "svg-pomegranate-logo": v(() => h(() =>
                import ("./pomegranate-logo-a7584a2f.js"), ["assets/pomegranate-logo-a7584a2f.js", "assets/index-1cb91aca.js", "assets/index-ff101a6a.css", "assets/pomegranate-logo-b4f056ee.css"]))
        },
        props: {
            fixed: {
                type: Boolean,
                default: !1
            }
        },
        computed: {
            title() {
                return this.$api.options.site_title || ""
            },
            invest() {
                const e = this.$api.options.invest_fab || {};
                return e.text || (e.text = "Invest today"), e.path === "/#invest" && (e.path = null), e
            }
        },
        mounted() {
            this.animeInit()
        },
        methods: {
            animeInit() {
                const e = this;
                e.fixed && g(e.$refs.header.querySelectorAll(".part-header_left, .part-header_right"), {
                    scale: ["33%", "100%"],
                    opacity: {
                        from: 0,
                        duration: 100
                    },
                    duration: 800,
                    ease: "outElastic(1, .8)",
                    delay: k(200, {
                        start: 1e3
                    })
                })
            },
            onClick() {
                const e = this;
                e.invest.path || (e._app.toggleMenu(!1), e._window.scrollTo({
                    target: "#invest",
                    centered: !0,
                    smooth: !0,
                    user: !0
                }))
            }
        }
    },
    $ = {
        class: "--ui-x-outer --ui-px"
    },
    B = {
        class: "--ui-center --ui-relative"
    },
    b = {
        key: 0,
        class: "part-header_left"
    },
    E = {
        key: 2,
        class: "part-header_right"
    };

function I(e, a, n, V, w, c) {
    const o = i("ui-button"),
        p = i("svg-pomegranate-logo"),
        _ = i("route");
    return t(), s("header", {
        class: C(["part-header --app-scrollbar-offset", {
            "--fixed": n.fixed
        }]),
        ref: "header"
    }, [u("div", $, [u("div", B, [n.fixed ? (t(), s("div", b, [e._is("lg") ? (t(), r(o, {
        key: 0,
        onClick: a[0] || (a[0] = m => e._app.toggleMenu()),
        "icon-left": e.$app.menu ? "action-close" : "action-open",
        text: e.$app.menu ? "Close menu" : "Learn more",
        variant: e.$app.menu ? "active" : null
    }, null, 8, ["icon-left", "text", "variant"])) : (t(), r(o, {
        key: 1,
        onClick: a[1] || (a[1] = m => e._app.toggleMenu()),
        icon: e.$app.menu ? "action-close" : "action-open",
        variant: e.$app.menu ? "active" : null
    }, null, 8, ["icon", "variant"]))])) : l("", !0), n.fixed ? l("", !0) : (t(), r(_, {
        key: 1,
        link: "/",
        class: "part-header_logo --motion-click"
    }, {
        default: y(() => [d(p, {
            immediate: ""
        })]),
        _: 1
    })), n.fixed ? (t(), s("div", E, [d(o, {
        link: c.invest,
        variant: "secondary",
        onClick: c.onClick
    }, null, 8, ["link", "onClick"])])) : l("", !0)])])], 2)
}
const N = f(x, [
    ["render", I]
]);
export {
    N as
    default
};