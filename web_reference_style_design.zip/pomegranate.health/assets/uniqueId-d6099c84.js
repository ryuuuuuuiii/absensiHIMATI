import {
    I as i
} from "./index-1cb91aca.js";
var n = 0;

function u(r) {
    var t = ++n;
    return i(r) + t
}
export {
    u
};