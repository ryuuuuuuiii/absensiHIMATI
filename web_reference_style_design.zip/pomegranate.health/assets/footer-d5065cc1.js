import {
    _ as L,
    l as m,
    e as h,
    h as s,
    r as c,
    o as t,
    c as o,
    k as i,
    F as p,
    d as e,
    j as D,
    w as a,
    p as T,
    a as v,
    i as y,
    t as w
} from "./index-1cb91aca.js";
const B = {
        components: {
            "svg-pomegranate-logo": m(() => h(() =>
                import ("./pomegranate-logo-a7584a2f.js"), ["assets/pomegranate-logo-a7584a2f.js", "assets/index-1cb91aca.js", "assets/index-ff101a6a.css", "assets/pomegranate-logo-b4f056ee.css"])),
            "part-phones": m(() => h(() =>
                import ("./phones-de22cf24.js"), ["assets/phones-de22cf24.js", "assets/index-1cb91aca.js", "assets/index-ff101a6a.css", "assets/phones-3f42a49d.css"]))
        },
        props: {
            compact: {
                type: Boolean,
                default: !1
            }
        },
        computed: {
            menuLeft() {
                return this.$api.menus.footer_left || []
            },
            menuRight() {
                return this.$api.menus.footer_right || []
            },
            options() {
                return this.$api.options
            },
            year() {
                return new Date().getFullYear()
            },
            phones() {
                return {
                    media_1: this.options.invest_media_1,
                    media_2: this.options.invest_media_2,
                    media_3: this.options.invest_media_3
                }
            }
        }
    },
    E = {
        class: "part-footer"
    },
    R = {
        class: "--ui-center --ui-px --ui-py-lg --ui-p--b"
    },
    V = {
        class: "--ui-x --ui-px --ui-py --ui-space"
    },
    C = ["innerHTML"],
    H = ["innerHTML"],
    M = {
        class: "--ui-center"
    },
    A = {
        class: "part-footer_phones"
    },
    F = {
        class: "--ui-x-outer --ui-px --ui-py"
    },
    I = {
        class: "part-footer_bar"
    },
    N = {
        class: "--ui-y --ui-gap-sm"
    },
    P = {
        class: "--type-caption --type-center"
    },
    z = {
        class: "--ui-y --ui-gap-sm"
    };

function O(j, S, g, Y, q, n) {
    const f = s("ui-gradient"),
        k = s("svg-pomegranate-logo"),
        _ = s("route"),
        b = s("ui-button"),
        x = s("part-phones"),
        u = c("orphans"),
        d = c("nl2br"),
        r = c("links");
    return t(), o("footer", E, [i(f, {
        colors: ["pom-2", "pom-3", "pom-4", "body"],
        size: 64,
        height: .25,
        flip: "",
        flush: ""
    }), g.compact ? T("", !0) : (t(), o(p, {
        key: 0
    }, [e("div", R, [i(_, {
        link: "/",
        class: "part-footer_logo --motion-click"
    }, {
        default: D(() => [i(k)]),
        _: 1
    })]), e("div", V, [a(e("p", {
        class: "--type-bubble --type-center --type-pretty",
        innerHTML: n.options.invest_heading
    }, null, 8, C), [
        [u],
        [d],
        [r]
    ]), a(e("p", {
        class: "--ui-x-narrow --type-opening --type-center --type-balance",
        innerHTML: n.options.invest_text
    }, null, 8, H), [
        [u],
        [d],
        [r]
    ]), e("div", M, [i(b, {
        link: n.options.invest_link,
        variant: "primary",
        type: "submit"
    }, null, 8, ["link"])]), e("div", A, [i(x, {
        content: n.phones
    }, null, 8, ["content"])])])], 64)), e("div", F, [e("div", I, [e("div", null, [a((t(), o("nav", N, [(t(!0), o(p, null, v(n.menuLeft, l => (t(), y(_, {
        link: l.link,
        class: "--type-nav"
    }, null, 8, ["link"]))), 256))])), [
        [r]
    ])]), e("div", null, [e("p", P, " © Copyright Really Intelligent LTD " + w(n.year) + ". All rights reserved. ", 1)]), e("div", null, [a((t(), o("nav", z, [(t(!0), o(p, null, v(n.menuRight, l => (t(), y(_, {
        link: l.link,
        class: "--type-nav"
    }, null, 8, ["link"]))), 256))])), [
        [r]
    ])])])])])
}
const J = L(B, [
    ["render", O]
]);
export {
    J as
    default
};