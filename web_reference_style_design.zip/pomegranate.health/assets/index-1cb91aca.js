(function() {
    const t = document.createElement("link").relList;
    if (t && t.supports && t.supports("modulepreload")) return;
    for (const i of document.querySelectorAll('link[rel="modulepreload"]')) r(i);
    new MutationObserver(i => {
        for (const s of i)
            if (s.type === "childList")
                for (const o of s.addedNodes) o.tagName === "LINK" && o.rel === "modulepreload" && r(o)
    }).observe(document, {
        childList: !0,
        subtree: !0
    });

    function n(i) {
        const s = {};
        return i.integrity && (s.integrity = i.integrity), i.referrerPolicy && (s.referrerPolicy = i.referrerPolicy), i.crossOrigin === "use-credentials" ? s.credentials = "include" : i.crossOrigin === "anonymous" ? s.credentials = "omit" : s.credentials = "same-origin", s
    }

    function r(i) {
        if (i.ep) return;
        i.ep = !0;
        const s = n(i);
        fetch(i.href, s)
    }
})();
var p0 = typeof global == "object" && global && global.Object === Object && global;
const um = p0;
var m0 = typeof self == "object" && self && self.Object === Object && self,
    g0 = um || m0 || Function("return this")();
const Xn = g0;
var _0 = Xn.Symbol;
const oi = _0;
var fm = Object.prototype,
    v0 = fm.hasOwnProperty,
    y0 = fm.toString,
    Xs = oi ? oi.toStringTag : void 0;

function b0(e) {
    var t = v0.call(e, Xs),
        n = e[Xs];
    try {
        e[Xs] = void 0;
        var r = !0
    } catch {}
    var i = y0.call(e);
    return r && (t ? e[Xs] = n : delete e[Xs]), i
}
var w0 = Object.prototype,
    S0 = w0.toString;

function T0(e) {
    return S0.call(e)
}
var C0 = "[object Null]",
    E0 = "[object Undefined]",
    Hd = oi ? oi.toStringTag : void 0;

function hi(e) {
    return e == null ? e === void 0 ? E0 : C0 : Hd && Hd in Object(e) ? b0(e) : T0(e)
}

function dr(e) {
    return e != null && typeof e == "object"
}
var A0 = "[object Symbol]";

function Bo(e) {
    return typeof e == "symbol" || dr(e) && hi(e) == A0
}

function Il(e, t) {
    for (var n = -1, r = e == null ? 0 : e.length, i = Array(r); ++n < r;) i[n] = t(e[n], n, e);
    return i
}
var x0 = Array.isArray;
const on = x0;
var O0 = 1 / 0,
    Ud = oi ? oi.prototype : void 0,
    Wd = Ud ? Ud.toString : void 0;

function $l(e) {
    if (typeof e == "string") return e;
    if (on(e)) return Il(e, $l) + "";
    if (Bo(e)) return Wd ? Wd.call(e) : "";
    var t = e + "";
    return t == "0" && 1 / e == -O0 ? "-0" : t
}
var P0 = /\s/;

function dm(e) {
    for (var t = e.length; t-- && P0.test(e.charAt(t)););
    return t
}
var M0 = /^\s+/;

function hm(e) {
    return e && e.slice(0, dm(e) + 1).replace(M0, "")
}

function qt(e) {
    var t = typeof e;
    return e != null && (t == "object" || t == "function")
}
var zd = 0 / 0,
    R0 = /^[-+]0x[0-9a-f]+$/i,
    I0 = /^0b[01]+$/i,
    $0 = /^0o[0-7]+$/i,
    k0 = parseInt;

function zc(e) {
    if (typeof e == "number") return e;
    if (Bo(e)) return zd;
    if (qt(e)) {
        var t = typeof e.valueOf == "function" ? e.valueOf() : e;
        e = qt(t) ? t + "" : t
    }
    if (typeof e != "string") return e === 0 ? e : +e;
    e = hm(e);
    var n = I0.test(e);
    return n || $0.test(e) ? k0(e.slice(2), n ? 2 : 8) : R0.test(e) ? zd : +e
}
var qd = 1 / 0,
    L0 = 17976931348623157e292;

function N0(e) {
    if (!e) return e === 0 ? e : 0;
    if (e = zc(e), e === qd || e === -qd) {
        var t = e < 0 ? -1 : 1;
        return t * L0
    }
    return e === e ? e : 0
}

function zu(e) {
    var t = N0(e),
        n = t % 1;
    return t === t ? n ? t - n : t : 0
}

function kl(e) {
    return e
}
var F0 = "[object AsyncFunction]",
    D0 = "[object Function]",
    j0 = "[object GeneratorFunction]",
    B0 = "[object Proxy]";

function qu(e) {
    if (!qt(e)) return !1;
    var t = hi(e);
    return t == D0 || t == j0 || t == F0 || t == B0
}
var V0 = Xn["__core-js_shared__"];
const yc = V0;
var Kd = function() {
    var e = /[^.]+$/.exec(yc && yc.keys && yc.keys.IE_PROTO || "");
    return e ? "Symbol(src)_1." + e : ""
}();

function H0(e) {
    return !!Kd && Kd in e
}
var U0 = Function.prototype,
    W0 = U0.toString;

function Ji(e) {
    if (e != null) {
        try {
            return W0.call(e)
        } catch {}
        try {
            return e + ""
        } catch {}
    }
    return ""
}
var z0 = /[\\^$.*+?()[\]{}|]/g,
    q0 = /^\[object .+?Constructor\]$/,
    K0 = Function.prototype,
    G0 = Object.prototype,
    Y0 = K0.toString,
    X0 = G0.hasOwnProperty,
    J0 = RegExp("^" + Y0.call(X0).replace(z0, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");

function Z0(e) {
    if (!qt(e) || H0(e)) return !1;
    var t = qu(e) ? J0 : q0;
    return t.test(Ji(e))
}

function Q0(e, t) {
    return e == null ? void 0 : e[t]
}

function Zi(e, t) {
    var n = Q0(e, t);
    return Z0(n) ? n : void 0
}
var e1 = Zi(Xn, "WeakMap");
const qc = e1;
var Gd = Object.create,
    t1 = function() {
        function e() {}
        return function(t) {
            if (!qt(t)) return {};
            if (Gd) return Gd(t);
            e.prototype = t;
            var n = new e;
            return e.prototype = void 0, n
        }
    }();
const n1 = t1;

function r1(e, t, n) {
    switch (n.length) {
        case 0:
            return e.call(t);
        case 1:
            return e.call(t, n[0]);
        case 2:
            return e.call(t, n[0], n[1]);
        case 3:
            return e.call(t, n[0], n[1], n[2])
    }
    return e.apply(t, n)
}

function i1(e, t) {
    var n = -1,
        r = e.length;
    for (t || (t = Array(r)); ++n < r;) t[n] = e[n];
    return t
}
var s1 = 800,
    o1 = 16,
    a1 = Date.now;

function l1(e) {
    var t = 0,
        n = 0;
    return function() {
        var r = a1(),
            i = o1 - (r - n);
        if (n = r, i > 0) {
            if (++t >= s1) return arguments[0]
        } else t = 0;
        return e.apply(void 0, arguments)
    }
}

function c1(e) {
    return function() {
        return e
    }
}
var u1 = function() {
    try {
        var e = Zi(Object, "defineProperty");
        return e({}, "", {}), e
    } catch {}
}();
const Qa = u1;
var f1 = Qa ? function(e, t) {
    return Qa(e, "toString", {
        configurable: !0,
        enumerable: !1,
        value: c1(t),
        writable: !0
    })
} : kl;
const d1 = f1;
var h1 = l1(d1);
const p1 = h1;

function m1(e, t) {
    for (var n = -1, r = e == null ? 0 : e.length; ++n < r && t(e[n], n, e) !== !1;);
    return e
}

function pm(e, t, n, r) {
    for (var i = e.length, s = n + (r ? 1 : -1); r ? s-- : ++s < i;)
        if (t(e[s], s, e)) return s;
    return -1
}

function g1(e) {
    return e !== e
}

function _1(e, t, n) {
    for (var r = n - 1, i = e.length; ++r < i;)
        if (e[r] === t) return r;
    return -1
}

function Ku(e, t, n) {
    return t === t ? _1(e, t, n) : pm(e, g1, n)
}
var v1 = 9007199254740991,
    y1 = /^(?:0|[1-9]\d*)$/;

function Ll(e, t) {
    var n = typeof e;
    return t = t ? ? v1, !!t && (n == "number" || n != "symbol" && y1.test(e)) && e > -1 && e % 1 == 0 && e < t
}

function Nl(e, t, n) {
    t == "__proto__" && Qa ? Qa(e, t, {
        configurable: !0,
        enumerable: !0,
        value: n,
        writable: !0
    }) : e[t] = n
}

function Vo(e, t) {
    return e === t || e !== e && t !== t
}
var b1 = Object.prototype,
    w1 = b1.hasOwnProperty;

function mm(e, t, n) {
    var r = e[t];
    (!(w1.call(e, t) && Vo(r, n)) || n === void 0 && !(t in e)) && Nl(e, t, n)
}

function S1(e, t, n, r) {
    var i = !n;
    n || (n = {});
    for (var s = -1, o = t.length; ++s < o;) {
        var a = t[s],
            l = r ? r(n[a], e[a], a, n, e) : void 0;
        l === void 0 && (l = e[a]), i ? Nl(n, a, l) : mm(n, a, l)
    }
    return n
}
var Yd = Math.max;

function T1(e, t, n) {
    return t = Yd(t === void 0 ? e.length - 1 : t, 0),
        function() {
            for (var r = arguments, i = -1, s = Yd(r.length - t, 0), o = Array(s); ++i < s;) o[i] = r[t + i];
            i = -1;
            for (var a = Array(t + 1); ++i < t;) a[i] = r[i];
            return a[t] = n(o), r1(e, this, a)
        }
}

function C1(e, t) {
    return p1(T1(e, t, kl), e + "")
}
var E1 = 9007199254740991;

function Gu(e) {
    return typeof e == "number" && e > -1 && e % 1 == 0 && e <= E1
}

function Rr(e) {
    return e != null && Gu(e.length) && !qu(e)
}

function A1(e, t, n) {
    if (!qt(n)) return !1;
    var r = typeof t;
    return (r == "number" ? Rr(n) && Ll(t, n.length) : r == "string" && t in n) ? Vo(n[t], e) : !1
}

function x1(e) {
    return C1(function(t, n) {
        var r = -1,
            i = n.length,
            s = i > 1 ? n[i - 1] : void 0,
            o = i > 2 ? n[2] : void 0;
        for (s = e.length > 3 && typeof s == "function" ? (i--, s) : void 0, o && A1(n[0], n[1], o) && (s = i < 3 ? void 0 : s, i = 1), t = Object(t); ++r < i;) {
            var a = n[r];
            a && e(t, a, r, s)
        }
        return t
    })
}
var O1 = Object.prototype;

function Yu(e) {
    var t = e && e.constructor,
        n = typeof t == "function" && t.prototype || O1;
    return e === n
}

function gm(e, t) {
    for (var n = -1, r = Array(e); ++n < e;) r[n] = t(n);
    return r
}
var P1 = "[object Arguments]";

function Xd(e) {
    return dr(e) && hi(e) == P1
}
var _m = Object.prototype,
    M1 = _m.hasOwnProperty,
    R1 = _m.propertyIsEnumerable,
    I1 = Xd(function() {
        return arguments
    }()) ? Xd : function(e) {
        return dr(e) && M1.call(e, "callee") && !R1.call(e, "callee")
    };
const el = I1;

function $1() {
    return !1
}
var vm = typeof exports == "object" && exports && !exports.nodeType && exports,
    Jd = vm && typeof module == "object" && module && !module.nodeType && module,
    k1 = Jd && Jd.exports === vm,
    Zd = k1 ? Xn.Buffer : void 0,
    L1 = Zd ? Zd.isBuffer : void 0,
    N1 = L1 || $1;
const tl = N1;
var F1 = "[object Arguments]",
    D1 = "[object Array]",
    j1 = "[object Boolean]",
    B1 = "[object Date]",
    V1 = "[object Error]",
    H1 = "[object Function]",
    U1 = "[object Map]",
    W1 = "[object Number]",
    z1 = "[object Object]",
    q1 = "[object RegExp]",
    K1 = "[object Set]",
    G1 = "[object String]",
    Y1 = "[object WeakMap]",
    X1 = "[object ArrayBuffer]",
    J1 = "[object DataView]",
    Z1 = "[object Float32Array]",
    Q1 = "[object Float64Array]",
    eb = "[object Int8Array]",
    tb = "[object Int16Array]",
    nb = "[object Int32Array]",
    rb = "[object Uint8Array]",
    ib = "[object Uint8ClampedArray]",
    sb = "[object Uint16Array]",
    ob = "[object Uint32Array]",
    xt = {};
xt[Z1] = xt[Q1] = xt[eb] = xt[tb] = xt[nb] = xt[rb] = xt[ib] = xt[sb] = xt[ob] = !0;
xt[F1] = xt[D1] = xt[X1] = xt[j1] = xt[J1] = xt[B1] = xt[V1] = xt[H1] = xt[U1] = xt[W1] = xt[z1] = xt[q1] = xt[K1] = xt[G1] = xt[Y1] = !1;

function ab(e) {
    return dr(e) && Gu(e.length) && !!xt[hi(e)]
}

function lb(e) {
    return function(t) {
        return e(t)
    }
}
var ym = typeof exports == "object" && exports && !exports.nodeType && exports,
    io = ym && typeof module == "object" && module && !module.nodeType && module,
    cb = io && io.exports === ym,
    bc = cb && um.process,
    ub = function() {
        try {
            var e = io && io.require && io.require("util").types;
            return e || bc && bc.binding && bc.binding("util")
        } catch {}
    }();
const Qd = ub;
var eh = Qd && Qd.isTypedArray,
    fb = eh ? lb(eh) : ab;
const Xu = fb;
var db = Object.prototype,
    hb = db.hasOwnProperty;

function bm(e, t) {
    var n = on(e),
        r = !n && el(e),
        i = !n && !r && tl(e),
        s = !n && !r && !i && Xu(e),
        o = n || r || i || s,
        a = o ? gm(e.length, String) : [],
        l = a.length;
    for (var u in e)(t || hb.call(e, u)) && !(o && (u == "length" || i && (u == "offset" || u == "parent") || s && (u == "buffer" || u == "byteLength" || u == "byteOffset") || Ll(u, l))) && a.push(u);
    return a
}

function wm(e, t) {
    return function(n) {
        return e(t(n))
    }
}
var pb = wm(Object.keys, Object);
const mb = pb;
var gb = Object.prototype,
    _b = gb.hasOwnProperty;

function Sm(e) {
    if (!Yu(e)) return mb(e);
    var t = [];
    for (var n in Object(e)) _b.call(e, n) && n != "constructor" && t.push(n);
    return t
}

function Ho(e) {
    return Rr(e) ? bm(e) : Sm(e)
}

function vb(e) {
    var t = [];
    if (e != null)
        for (var n in Object(e)) t.push(n);
    return t
}
var yb = Object.prototype,
    bb = yb.hasOwnProperty;

function wb(e) {
    if (!qt(e)) return vb(e);
    var t = Yu(e),
        n = [];
    for (var r in e) r == "constructor" && (t || !bb.call(e, r)) || n.push(r);
    return n
}

function Ju(e) {
    return Rr(e) ? bm(e, !0) : wb(e)
}
var Sb = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,
    Tb = /^\w*$/;

function Zu(e, t) {
    if (on(e)) return !1;
    var n = typeof e;
    return n == "number" || n == "symbol" || n == "boolean" || e == null || Bo(e) ? !0 : Tb.test(e) || !Sb.test(e) || t != null && e in Object(t)
}
var Cb = Zi(Object, "create");
const yo = Cb;

function Eb() {
    this.__data__ = yo ? yo(null) : {}, this.size = 0
}

function Ab(e) {
    var t = this.has(e) && delete this.__data__[e];
    return this.size -= t ? 1 : 0, t
}
var xb = "__lodash_hash_undefined__",
    Ob = Object.prototype,
    Pb = Ob.hasOwnProperty;

function Mb(e) {
    var t = this.__data__;
    if (yo) {
        var n = t[e];
        return n === xb ? void 0 : n
    }
    return Pb.call(t, e) ? t[e] : void 0
}
var Rb = Object.prototype,
    Ib = Rb.hasOwnProperty;

function $b(e) {
    var t = this.__data__;
    return yo ? t[e] !== void 0 : Ib.call(t, e)
}
var kb = "__lodash_hash_undefined__";

function Lb(e, t) {
    var n = this.__data__;
    return this.size += this.has(e) ? 0 : 1, n[e] = yo && t === void 0 ? kb : t, this
}

function Vi(e) {
    var t = -1,
        n = e == null ? 0 : e.length;
    for (this.clear(); ++t < n;) {
        var r = e[t];
        this.set(r[0], r[1])
    }
}
Vi.prototype.clear = Eb;
Vi.prototype.delete = Ab;
Vi.prototype.get = Mb;
Vi.prototype.has = $b;
Vi.prototype.set = Lb;

function Nb() {
    this.__data__ = [], this.size = 0
}

function Fl(e, t) {
    for (var n = e.length; n--;)
        if (Vo(e[n][0], t)) return n;
    return -1
}
var Fb = Array.prototype,
    Db = Fb.splice;

function jb(e) {
    var t = this.__data__,
        n = Fl(t, e);
    if (n < 0) return !1;
    var r = t.length - 1;
    return n == r ? t.pop() : Db.call(t, n, 1), --this.size, !0
}

function Bb(e) {
    var t = this.__data__,
        n = Fl(t, e);
    return n < 0 ? void 0 : t[n][1]
}

function Vb(e) {
    return Fl(this.__data__, e) > -1
}

function Hb(e, t) {
    var n = this.__data__,
        r = Fl(n, e);
    return r < 0 ? (++this.size, n.push([e, t])) : n[r][1] = t, this
}

function Ir(e) {
    var t = -1,
        n = e == null ? 0 : e.length;
    for (this.clear(); ++t < n;) {
        var r = e[t];
        this.set(r[0], r[1])
    }
}
Ir.prototype.clear = Nb;
Ir.prototype.delete = jb;
Ir.prototype.get = Bb;
Ir.prototype.has = Vb;
Ir.prototype.set = Hb;
var Ub = Zi(Xn, "Map");
const bo = Ub;

function Wb() {
    this.size = 0, this.__data__ = {
        hash: new Vi,
        map: new(bo || Ir),
        string: new Vi
    }
}

function zb(e) {
    var t = typeof e;
    return t == "string" || t == "number" || t == "symbol" || t == "boolean" ? e !== "__proto__" : e === null
}

function Dl(e, t) {
    var n = e.__data__;
    return zb(t) ? n[typeof t == "string" ? "string" : "hash"] : n.map
}

function qb(e) {
    var t = Dl(this, e).delete(e);
    return this.size -= t ? 1 : 0, t
}

function Kb(e) {
    return Dl(this, e).get(e)
}

function Gb(e) {
    return Dl(this, e).has(e)
}

function Yb(e, t) {
    var n = Dl(this, e),
        r = n.size;
    return n.set(e, t), this.size += n.size == r ? 0 : 1, this
}

function $r(e) {
    var t = -1,
        n = e == null ? 0 : e.length;
    for (this.clear(); ++t < n;) {
        var r = e[t];
        this.set(r[0], r[1])
    }
}
$r.prototype.clear = Wb;
$r.prototype.delete = qb;
$r.prototype.get = Kb;
$r.prototype.has = Gb;
$r.prototype.set = Yb;
var Xb = "Expected a function";

function Qu(e, t) {
    if (typeof e != "function" || t != null && typeof t != "function") throw new TypeError(Xb);
    var n = function() {
        var r = arguments,
            i = t ? t.apply(this, r) : r[0],
            s = n.cache;
        if (s.has(i)) return s.get(i);
        var o = e.apply(this, r);
        return n.cache = s.set(i, o) || s, o
    };
    return n.cache = new(Qu.Cache || $r), n
}
Qu.Cache = $r;
var Jb = 500;

function Zb(e) {
    var t = Qu(e, function(r) {
            return n.size === Jb && n.clear(), r
        }),
        n = t.cache;
    return t
}
var Qb = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g,
    e2 = /\\(\\)?/g,
    t2 = Zb(function(e) {
        var t = [];
        return e.charCodeAt(0) === 46 && t.push(""), e.replace(Qb, function(n, r, i, s) {
            t.push(i ? s.replace(e2, "$1") : r || n)
        }), t
    });
const n2 = t2;

function ef(e) {
    return e == null ? "" : $l(e)
}

function jl(e, t) {
    return on(e) ? e : Zu(e, t) ? [e] : n2(ef(e))
}
var r2 = 1 / 0;

function Uo(e) {
    if (typeof e == "string" || Bo(e)) return e;
    var t = e + "";
    return t == "0" && 1 / e == -r2 ? "-0" : t
}

function tf(e, t) {
    t = jl(t, e);
    for (var n = 0, r = t.length; e != null && n < r;) e = e[Uo(t[n++])];
    return n && n == r ? e : void 0
}

function gt(e, t, n) {
    var r = e == null ? void 0 : tf(e, t);
    return r === void 0 ? n : r
}

function Tm(e, t) {
    for (var n = -1, r = t.length, i = e.length; ++n < r;) e[i + n] = t[n];
    return e
}
var i2 = wm(Object.getPrototypeOf, Object);
const nf = i2;
var s2 = "[object Object]",
    o2 = Function.prototype,
    a2 = Object.prototype,
    Cm = o2.toString,
    l2 = a2.hasOwnProperty,
    c2 = Cm.call(Object);

function Em(e) {
    if (!dr(e) || hi(e) != s2) return !1;
    var t = nf(e);
    if (t === null) return !0;
    var n = l2.call(t, "constructor") && t.constructor;
    return typeof n == "function" && n instanceof n && Cm.call(n) == c2
}

function u2(e, t, n) {
    var r = -1,
        i = e.length;
    t < 0 && (t = -t > i ? 0 : i + t), n = n > i ? i : n, n < 0 && (n += i), i = t > n ? 0 : n - t >>> 0, t >>>= 0;
    for (var s = Array(i); ++r < i;) s[r] = e[r + t];
    return s
}

function Am(e, t, n) {
    var r = e.length;
    return n = n === void 0 ? r : n, !t && n >= r ? e : u2(e, t, n)
}
var f2 = "\\ud800-\\udfff",
    d2 = "\\u0300-\\u036f",
    h2 = "\\ufe20-\\ufe2f",
    p2 = "\\u20d0-\\u20ff",
    m2 = d2 + h2 + p2,
    g2 = "\\ufe0e\\ufe0f",
    _2 = "\\u200d",
    v2 = RegExp("[" + _2 + f2 + m2 + g2 + "]");

function xm(e) {
    return v2.test(e)
}

function y2(e) {
    return e.split("")
}
var Om = "\\ud800-\\udfff",
    b2 = "\\u0300-\\u036f",
    w2 = "\\ufe20-\\ufe2f",
    S2 = "\\u20d0-\\u20ff",
    T2 = b2 + w2 + S2,
    C2 = "\\ufe0e\\ufe0f",
    E2 = "[" + Om + "]",
    Kc = "[" + T2 + "]",
    Gc = "\\ud83c[\\udffb-\\udfff]",
    A2 = "(?:" + Kc + "|" + Gc + ")",
    Pm = "[^" + Om + "]",
    Mm = "(?:\\ud83c[\\udde6-\\uddff]){2}",
    Rm = "[\\ud800-\\udbff][\\udc00-\\udfff]",
    x2 = "\\u200d",
    Im = A2 + "?",
    $m = "[" + C2 + "]?",
    O2 = "(?:" + x2 + "(?:" + [Pm, Mm, Rm].join("|") + ")" + $m + Im + ")*",
    P2 = $m + Im + O2,
    M2 = "(?:" + [Pm + Kc + "?", Kc, Mm, Rm, E2].join("|") + ")",
    R2 = RegExp(Gc + "(?=" + Gc + ")|" + M2 + P2, "g");

function I2(e) {
    return e.match(R2) || []
}

function nl(e) {
    return xm(e) ? I2(e) : y2(e)
}

function $2() {
    this.__data__ = new Ir, this.size = 0
}

function k2(e) {
    var t = this.__data__,
        n = t.delete(e);
    return this.size = t.size, n
}

function L2(e) {
    return this.__data__.get(e)
}

function N2(e) {
    return this.__data__.has(e)
}
var F2 = 200;

function D2(e, t) {
    var n = this.__data__;
    if (n instanceof Ir) {
        var r = n.__data__;
        if (!bo || r.length < F2 - 1) return r.push([e, t]), this.size = ++n.size, this;
        n = this.__data__ = new $r(r)
    }
    return n.set(e, t), this.size = n.size, this
}

function ur(e) {
    var t = this.__data__ = new Ir(e);
    this.size = t.size
}
ur.prototype.clear = $2;
ur.prototype.delete = k2;
ur.prototype.get = L2;
ur.prototype.has = N2;
ur.prototype.set = D2;
var km = typeof exports == "object" && exports && !exports.nodeType && exports,
    th = km && typeof module == "object" && module && !module.nodeType && module,
    j2 = th && th.exports === km,
    nh = j2 ? Xn.Buffer : void 0,
    rh = nh ? nh.allocUnsafe : void 0;

function B2(e, t) {
    if (t) return e.slice();
    var n = e.length,
        r = rh ? rh(n) : new e.constructor(n);
    return e.copy(r), r
}

function Lm(e, t) {
    for (var n = -1, r = e == null ? 0 : e.length, i = 0, s = []; ++n < r;) {
        var o = e[n];
        t(o, n, e) && (s[i++] = o)
    }
    return s
}

function Nm() {
    return []
}
var V2 = Object.prototype,
    H2 = V2.propertyIsEnumerable,
    ih = Object.getOwnPropertySymbols,
    U2 = ih ? function(e) {
        return e == null ? [] : (e = Object(e), Lm(ih(e), function(t) {
            return H2.call(e, t)
        }))
    } : Nm;
const Fm = U2;
var W2 = Object.getOwnPropertySymbols,
    z2 = W2 ? function(e) {
        for (var t = []; e;) Tm(t, Fm(e)), e = nf(e);
        return t
    } : Nm;
const q2 = z2;

function Dm(e, t, n) {
    var r = t(e);
    return on(e) ? r : Tm(r, n(e))
}

function sh(e) {
    return Dm(e, Ho, Fm)
}

function K2(e) {
    return Dm(e, Ju, q2)
}
var G2 = Zi(Xn, "DataView");
const Yc = G2;
var Y2 = Zi(Xn, "Promise");
const Xc = Y2;
var X2 = Zi(Xn, "Set");
const Jc = X2;
var oh = "[object Map]",
    J2 = "[object Object]",
    ah = "[object Promise]",
    lh = "[object Set]",
    ch = "[object WeakMap]",
    uh = "[object DataView]",
    Z2 = Ji(Yc),
    Q2 = Ji(bo),
    ew = Ji(Xc),
    tw = Ji(Jc),
    nw = Ji(qc),
    Si = hi;
(Yc && Si(new Yc(new ArrayBuffer(1))) != uh || bo && Si(new bo) != oh || Xc && Si(Xc.resolve()) != ah || Jc && Si(new Jc) != lh || qc && Si(new qc) != ch) && (Si = function(e) {
    var t = hi(e),
        n = t == J2 ? e.constructor : void 0,
        r = n ? Ji(n) : "";
    if (r) switch (r) {
        case Z2:
            return uh;
        case Q2:
            return oh;
        case ew:
            return ah;
        case tw:
            return lh;
        case nw:
            return ch
    }
    return t
});
const Zc = Si;
var rw = Xn.Uint8Array;
const rl = rw;

function iw(e) {
    var t = new e.constructor(e.byteLength);
    return new rl(t).set(new rl(e)), t
}

function sw(e, t) {
    var n = t ? iw(e.buffer) : e.buffer;
    return new e.constructor(n, e.byteOffset, e.length)
}

function ow(e) {
    return typeof e.constructor == "function" && !Yu(e) ? n1(nf(e)) : {}
}
var aw = "__lodash_hash_undefined__";

function lw(e) {
    return this.__data__.set(e, aw), this
}

function cw(e) {
    return this.__data__.has(e)
}

function il(e) {
    var t = -1,
        n = e == null ? 0 : e.length;
    for (this.__data__ = new $r; ++t < n;) this.add(e[t])
}
il.prototype.add = il.prototype.push = lw;
il.prototype.has = cw;

function uw(e, t) {
    for (var n = -1, r = e == null ? 0 : e.length; ++n < r;)
        if (t(e[n], n, e)) return !0;
    return !1
}

function fw(e, t) {
    return e.has(t)
}
var dw = 1,
    hw = 2;

function jm(e, t, n, r, i, s) {
    var o = n & dw,
        a = e.length,
        l = t.length;
    if (a != l && !(o && l > a)) return !1;
    var u = s.get(e),
        f = s.get(t);
    if (u && f) return u == t && f == e;
    var h = -1,
        _ = !0,
        m = n & hw ? new il : void 0;
    for (s.set(e, t), s.set(t, e); ++h < a;) {
        var T = e[h],
            R = t[h];
        if (r) var B = o ? r(R, T, h, t, e, s) : r(T, R, h, e, t, s);
        if (B !== void 0) {
            if (B) continue;
            _ = !1;
            break
        }
        if (m) {
            if (!uw(t, function(I, A) {
                    if (!fw(m, A) && (T === I || i(T, I, n, r, s))) return m.push(A)
                })) {
                _ = !1;
                break
            }
        } else if (!(T === R || i(T, R, n, r, s))) {
            _ = !1;
            break
        }
    }
    return s.delete(e), s.delete(t), _
}

function pw(e) {
    var t = -1,
        n = Array(e.size);
    return e.forEach(function(r, i) {
        n[++t] = [i, r]
    }), n
}

function mw(e) {
    var t = -1,
        n = Array(e.size);
    return e.forEach(function(r) {
        n[++t] = r
    }), n
}
var gw = 1,
    _w = 2,
    vw = "[object Boolean]",
    yw = "[object Date]",
    bw = "[object Error]",
    ww = "[object Map]",
    Sw = "[object Number]",
    Tw = "[object RegExp]",
    Cw = "[object Set]",
    Ew = "[object String]",
    Aw = "[object Symbol]",
    xw = "[object ArrayBuffer]",
    Ow = "[object DataView]",
    fh = oi ? oi.prototype : void 0,
    wc = fh ? fh.valueOf : void 0;

function Pw(e, t, n, r, i, s, o) {
    switch (n) {
        case Ow:
            if (e.byteLength != t.byteLength || e.byteOffset != t.byteOffset) return !1;
            e = e.buffer, t = t.buffer;
        case xw:
            return !(e.byteLength != t.byteLength || !s(new rl(e), new rl(t)));
        case vw:
        case yw:
        case Sw:
            return Vo(+e, +t);
        case bw:
            return e.name == t.name && e.message == t.message;
        case Tw:
        case Ew:
            return e == t + "";
        case ww:
            var a = pw;
        case Cw:
            var l = r & gw;
            if (a || (a = mw), e.size != t.size && !l) return !1;
            var u = o.get(e);
            if (u) return u == t;
            r |= _w, o.set(e, t);
            var f = jm(a(e), a(t), r, i, s, o);
            return o.delete(e), f;
        case Aw:
            if (wc) return wc.call(e) == wc.call(t)
    }
    return !1
}
var Mw = 1,
    Rw = Object.prototype,
    Iw = Rw.hasOwnProperty;

function $w(e, t, n, r, i, s) {
    var o = n & Mw,
        a = sh(e),
        l = a.length,
        u = sh(t),
        f = u.length;
    if (l != f && !o) return !1;
    for (var h = l; h--;) {
        var _ = a[h];
        if (!(o ? _ in t : Iw.call(t, _))) return !1
    }
    var m = s.get(e),
        T = s.get(t);
    if (m && T) return m == t && T == e;
    var R = !0;
    s.set(e, t), s.set(t, e);
    for (var B = o; ++h < l;) {
        _ = a[h];
        var I = e[_],
            A = t[_];
        if (r) var E = o ? r(A, I, _, t, e, s) : r(I, A, _, e, t, s);
        if (!(E === void 0 ? I === A || i(I, A, n, r, s) : E)) {
            R = !1;
            break
        }
        B || (B = _ == "constructor")
    }
    if (R && !B) {
        var O = e.constructor,
            P = t.constructor;
        O != P && "constructor" in e && "constructor" in t && !(typeof O == "function" && O instanceof O && typeof P == "function" && P instanceof P) && (R = !1)
    }
    return s.delete(e), s.delete(t), R
}
var kw = 1,
    dh = "[object Arguments]",
    hh = "[object Array]",
    _a = "[object Object]",
    Lw = Object.prototype,
    ph = Lw.hasOwnProperty;

function Nw(e, t, n, r, i, s) {
    var o = on(e),
        a = on(t),
        l = o ? hh : Zc(e),
        u = a ? hh : Zc(t);
    l = l == dh ? _a : l, u = u == dh ? _a : u;
    var f = l == _a,
        h = u == _a,
        _ = l == u;
    if (_ && tl(e)) {
        if (!tl(t)) return !1;
        o = !0, f = !1
    }
    if (_ && !f) return s || (s = new ur), o || Xu(e) ? jm(e, t, n, r, i, s) : Pw(e, t, l, n, r, i, s);
    if (!(n & kw)) {
        var m = f && ph.call(e, "__wrapped__"),
            T = h && ph.call(t, "__wrapped__");
        if (m || T) {
            var R = m ? e.value() : e,
                B = T ? t.value() : t;
            return s || (s = new ur), i(R, B, n, r, s)
        }
    }
    return _ ? (s || (s = new ur), $w(e, t, n, r, i, s)) : !1
}

function rf(e, t, n, r, i) {
    return e === t ? !0 : e == null || t == null || !dr(e) && !dr(t) ? e !== e && t !== t : Nw(e, t, n, r, rf, i)
}
var Fw = 1,
    Dw = 2;

function jw(e, t, n, r) {
    var i = n.length,
        s = i,
        o = !r;
    if (e == null) return !s;
    for (e = Object(e); i--;) {
        var a = n[i];
        if (o && a[2] ? a[1] !== e[a[0]] : !(a[0] in e)) return !1
    }
    for (; ++i < s;) {
        a = n[i];
        var l = a[0],
            u = e[l],
            f = a[1];
        if (o && a[2]) {
            if (u === void 0 && !(l in e)) return !1
        } else {
            var h = new ur;
            if (r) var _ = r(u, f, l, e, t, h);
            if (!(_ === void 0 ? rf(f, u, Fw | Dw, r, h) : _)) return !1
        }
    }
    return !0
}

function Bm(e) {
    return e === e && !qt(e)
}

function Bw(e) {
    for (var t = Ho(e), n = t.length; n--;) {
        var r = t[n],
            i = e[r];
        t[n] = [r, i, Bm(i)]
    }
    return t
}

function Vm(e, t) {
    return function(n) {
        return n == null ? !1 : n[e] === t && (t !== void 0 || e in Object(n))
    }
}

function Vw(e) {
    var t = Bw(e);
    return t.length == 1 && t[0][2] ? Vm(t[0][0], t[0][1]) : function(n) {
        return n === e || jw(n, e, t)
    }
}

function Hw(e, t) {
    return e != null && t in Object(e)
}

function Hm(e, t, n) {
    t = jl(t, e);
    for (var r = -1, i = t.length, s = !1; ++r < i;) {
        var o = Uo(t[r]);
        if (!(s = e != null && n(e, o))) break;
        e = e[o]
    }
    return s || ++r != i ? s : (i = e == null ? 0 : e.length, !!i && Gu(i) && Ll(o, i) && (on(e) || el(e)))
}

function Uw(e, t) {
    return e != null && Hm(e, t, Hw)
}
var Ww = 1,
    zw = 2;

function qw(e, t) {
    return Zu(e) && Bm(t) ? Vm(Uo(e), t) : function(n) {
        var r = gt(n, e);
        return r === void 0 && r === t ? Uw(n, e) : rf(t, r, Ww | zw)
    }
}

function Um(e) {
    return function(t) {
        return t == null ? void 0 : t[e]
    }
}

function Kw(e) {
    return function(t) {
        return tf(t, e)
    }
}

function Gw(e) {
    return Zu(e) ? Um(Uo(e)) : Kw(e)
}

function pi(e) {
    return typeof e == "function" ? e : e == null ? kl : typeof e == "object" ? on(e) ? qw(e[0], e[1]) : Vw(e) : Gw(e)
}

function Yw(e) {
    return function(t, n, r) {
        for (var i = -1, s = Object(t), o = r(t), a = o.length; a--;) {
            var l = o[e ? a : ++i];
            if (n(s[l], l, s) === !1) break
        }
        return t
    }
}
var Xw = Yw();
const Wm = Xw;

function sf(e, t) {
    return e && Wm(e, t, Ho)
}

function Jw(e, t) {
    return function(n, r) {
        if (n == null) return n;
        if (!Rr(n)) return e(n, r);
        for (var i = n.length, s = t ? i : -1, o = Object(n);
            (t ? s-- : ++s < i) && r(o[s], s, o) !== !1;);
        return n
    }
}
var Zw = Jw(sf);
const of = Zw;
var Qw = function() {
    return Xn.Date.now()
};
const Sc = Qw;
var eS = "Expected a function",
    tS = Math.max,
    nS = Math.min;

function rS(e, t, n) {
    var r, i, s, o, a, l, u = 0,
        f = !1,
        h = !1,
        _ = !0;
    if (typeof e != "function") throw new TypeError(eS);
    t = zc(t) || 0, qt(n) && (f = !!n.leading, h = "maxWait" in n, s = h ? tS(zc(n.maxWait) || 0, t) : s, _ = "trailing" in n ? !!n.trailing : _);

    function m($) {
        var H = r,
            F = i;
        return r = i = void 0, u = $, o = e.apply(F, H), o
    }

    function T($) {
        return u = $, a = setTimeout(I, t), f ? m($) : o
    }

    function R($) {
        var H = $ - l,
            F = $ - u,
            V = t - H;
        return h ? nS(V, s - F) : V
    }

    function B($) {
        var H = $ - l,
            F = $ - u;
        return l === void 0 || H >= t || H < 0 || h && F >= s
    }

    function I() {
        var $ = Sc();
        if (B($)) return A($);
        a = setTimeout(I, R($))
    }

    function A($) {
        return a = void 0, _ && r ? m($) : (r = i = void 0, o)
    }

    function E() {
        a !== void 0 && clearTimeout(a), u = 0, r = l = i = a = void 0
    }

    function O() {
        return a === void 0 ? o : A(Sc())
    }

    function P() {
        var $ = Sc(),
            H = B($);
        if (r = arguments, i = this, l = $, H) {
            if (a === void 0) return T(l);
            if (h) return clearTimeout(a), a = setTimeout(I, t), m(l)
        }
        return a === void 0 && (a = setTimeout(I, t)), o
    }
    return P.cancel = E, P.flush = O, P
}

function Qc(e, t, n) {
    (n !== void 0 && !Vo(e[t], n) || n === void 0 && !(t in e)) && Nl(e, t, n)
}

function iS(e) {
    return dr(e) && Rr(e)
}

function eu(e, t) {
    if (!(t === "constructor" && typeof e[t] == "function") && t != "__proto__") return e[t]
}

function sS(e) {
    return S1(e, Ju(e))
}

function oS(e, t, n, r, i, s, o) {
    var a = eu(e, n),
        l = eu(t, n),
        u = o.get(l);
    if (u) {
        Qc(e, n, u);
        return
    }
    var f = s ? s(a, l, n + "", e, t, o) : void 0,
        h = f === void 0;
    if (h) {
        var _ = on(l),
            m = !_ && tl(l),
            T = !_ && !m && Xu(l);
        f = l, _ || m || T ? on(a) ? f = a : iS(a) ? f = i1(a) : m ? (h = !1, f = B2(l, !0)) : T ? (h = !1, f = sw(l, !0)) : f = [] : Em(l) || el(l) ? (f = a, el(a) ? f = sS(a) : (!qt(a) || qu(a)) && (f = ow(l))) : h = !1
    }
    h && (o.set(l, f), i(f, l, r, s, o), o.delete(l)), Qc(e, n, f)
}

function zm(e, t, n, r, i) {
    e !== t && Wm(t, function(s, o) {
        if (i || (i = new ur), qt(s)) oS(e, t, o, n, zm, r, i);
        else {
            var a = r ? r(eu(e, o), s, o + "", e, t, i) : void 0;
            a === void 0 && (a = s), Qc(e, o, a)
        }
    }, Ju)
}

function qm(e) {
    return typeof e == "function" ? e : kl
}

function lr(e, t) {
    var n = on(e) ? m1 : of ;
    return n(e, qm(t))
}

function aS(e, t) {
    var n = [];
    return of(e, function(r, i, s) {
        t(r, i, s) && n.push(r)
    }), n
}

function lS(e, t) {
    var n = on(e) ? Lm : aS;
    return n(e, pi(t))
}

function cS(e) {
    return function(t, n, r) {
        var i = Object(t);
        if (!Rr(t)) {
            var s = pi(n);
            t = Ho(t), n = function(a) {
                return s(i[a], a, i)
            }
        }
        var o = e(t, n, r);
        return o > -1 ? i[s ? t[o] : o] : void 0
    }
}
var uS = Math.max;

function fS(e, t, n) {
    var r = e == null ? 0 : e.length;
    if (!r) return -1;
    var i = n == null ? 0 : zu(n);
    return i < 0 && (i = uS(r + i, 0)), pm(e, pi(t), i)
}
var dS = cS(fS);
const Km = dS;

function hS(e, t, n) {
    var r;
    return n(e, function(i, s, o) {
        if (t(i, s, o)) return r = s, !1
    }), r
}

function pS(e, t) {
    return hS(e, pi(t), sf)
}

function mS(e) {
    return e && e.length ? e[0] : void 0
}

function gS(e, t) {
    var n = -1,
        r = Rr(e) ? Array(e.length) : [];
    return of(e, function(i, s, o) {
        r[++n] = t(i, s, o)
    }), r
}

function af(e, t) {
    var n = on(e) ? Il : gS;
    return n(e, pi(t))
}

function _S(e, t) {
    return e > t
}
var vS = Object.prototype,
    yS = vS.hasOwnProperty;

function bS(e, t) {
    return e != null && yS.call(e, t)
}

function mh(e, t) {
    return e != null && Hm(e, t, bS)
}
var wS = "[object String]";

function Wo(e) {
    return typeof e == "string" || !on(e) && dr(e) && hi(e) == wS
}

function SS(e, t) {
    return Il(t, function(n) {
        return e[n]
    })
}

function TS(e) {
    return e == null ? [] : SS(e, Ho(e))
}
var CS = Math.max;

function lf(e, t, n, r) {
    e = Rr(e) ? e : TS(e), n = n && !r ? zu(n) : 0;
    var i = e.length;
    return n < 0 && (n = CS(i + n, 0)), Wo(e) ? n <= i && e.indexOf(t, n) > -1 : !!i && Ku(e, t, n) > -1
}

function ES(e) {
    return dr(e) && e.nodeType === 1 && !Em(e)
}

function AS(e, t) {
    var n = {};
    return t = pi(t), sf(e, function(r, i, s) {
        Nl(n, i, t(r, i, s))
    }), n
}

function xS(e, t, n) {
    for (var r = -1, i = e.length; ++r < i;) {
        var s = e[r],
            o = t(s);
        if (o != null && (a === void 0 ? o === o && !Bo(o) : n(o, a))) var a = o,
            l = s
    }
    return l
}

function OS(e, t) {
    return e && e.length ? xS(e, pi(t), _S) : void 0
}
var PS = x1(function(e, t, n) {
    zm(e, t, n)
});
const gh = PS;

function Gm(e, t, n, r) {
    if (!qt(e)) return e;
    t = jl(t, e);
    for (var i = -1, s = t.length, o = s - 1, a = e; a != null && ++i < s;) {
        var l = Uo(t[i]),
            u = n;
        if (l === "__proto__" || l === "constructor" || l === "prototype") return e;
        if (i != o) {
            var f = a[l];
            u = r ? r(f, l, a) : void 0, u === void 0 && (u = qt(f) ? f : Ll(t[i + 1]) ? [] : {})
        }
        mm(a, l, u), a = a[l]
    }
    return e
}

function MS(e, t, n) {
    for (var r = -1, i = t.length, s = {}; ++r < i;) {
        var o = t[r],
            a = tf(e, o);
        n(a, o) && Gm(s, jl(o, e), a)
    }
    return s
}

function RS(e, t) {
    if (e == null) return {};
    var n = Il(K2(e), function(r) {
        return [r]
    });
    return t = pi(t), MS(e, n, function(r, i) {
        return t(r, i[0])
    })
}
var IS = Um("length");
const $S = IS;
var Ym = "\\ud800-\\udfff",
    kS = "\\u0300-\\u036f",
    LS = "\\ufe20-\\ufe2f",
    NS = "\\u20d0-\\u20ff",
    FS = kS + LS + NS,
    DS = "\\ufe0e\\ufe0f",
    jS = "[" + Ym + "]",
    tu = "[" + FS + "]",
    nu = "\\ud83c[\\udffb-\\udfff]",
    BS = "(?:" + tu + "|" + nu + ")",
    Xm = "[^" + Ym + "]",
    Jm = "(?:\\ud83c[\\udde6-\\uddff]){2}",
    Zm = "[\\ud800-\\udbff][\\udc00-\\udfff]",
    VS = "\\u200d",
    Qm = BS + "?",
    eg = "[" + DS + "]?",
    HS = "(?:" + VS + "(?:" + [Xm, Jm, Zm].join("|") + ")" + eg + Qm + ")*",
    US = eg + Qm + HS,
    WS = "(?:" + [Xm + tu + "?", tu, Jm, Zm, jS].join("|") + ")",
    _h = RegExp(nu + "(?=" + nu + ")|" + WS + US, "g");

function zS(e) {
    for (var t = _h.lastIndex = 0; _h.test(e);) ++t;
    return t
}

function qS(e) {
    return xm(e) ? zS(e) : $S(e)
}

function KS(e, t, n) {
    return e == null ? e : Gm(e, t, n)
}
var GS = "[object Map]",
    YS = "[object Set]";

function XS(e) {
    if (e == null) return 0;
    if (Rr(e)) return Wo(e) ? qS(e) : e.length;
    var t = Zc(e);
    return t == GS || t == YS ? e.size : Sm(e).length
}
var JS = "Expected a function";

function vh(e, t, n) {
    var r = !0,
        i = !0;
    if (typeof e != "function") throw new TypeError(JS);
    return qt(n) && (r = "leading" in n ? !!n.leading : r, i = "trailing" in n ? !!n.trailing : i), rS(e, t, {
        leading: r,
        maxWait: t,
        trailing: i
    })
}
var ZS = 9007199254740991,
    Tc = 4294967295,
    QS = Math.min;

function eT(e, t) {
    if (e = zu(e), e < 1 || e > ZS) return [];
    var n = Tc,
        r = QS(e, Tc);
    t = qm(t), e -= Tc;
    for (var i = gm(r, t); ++n < e;) t(n);
    return i
}

function tg(e, t) {
    for (var n = e.length; n-- && Ku(t, e[n], 0) > -1;);
    return n
}

function tT(e, t) {
    for (var n = -1, r = e.length; ++n < r && Ku(t, e[n], 0) > -1;);
    return n
}

function nT(e, t, n) {
    if (e = ef(e), e && (n || t === void 0)) return hm(e);
    if (!e || !(t = $l(t))) return e;
    var r = nl(e),
        i = nl(t),
        s = tT(r, i),
        o = tg(r, i) + 1;
    return Am(r, s, o).join("")
}

function yh(e, t, n) {
    if (e = ef(e), e && (n || t === void 0)) return e.slice(0, dm(e) + 1);
    if (!e || !(t = $l(t))) return e;
    var r = nl(e),
        i = tg(r, nl(t)) + 1;
    return Am(r, 0, i).join("")
}
/**
 * @vue/shared v3.4.27
 * (c) 2018-present Yuxi (Evan) You and Vue contributors
 * @license MIT
 **/
/*! #__NO_SIDE_EFFECTS__ */
function In(e, t) {
    const n = new Set(e.split(","));
    return t ? r => n.has(r.toLowerCase()) : r => n.has(r)
}
const ft = {},
    ys = [],
    Ut = () => {},
    Ba = () => !1,
    Qi = e => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && (e.charCodeAt(2) > 122 || e.charCodeAt(2) < 97),
    cf = e => e.startsWith("onUpdate:"),
    rt = Object.assign,
    uf = (e, t) => {
        const n = e.indexOf(t);
        n > -1 && e.splice(n, 1)
    },
    rT = Object.prototype.hasOwnProperty,
    ct = (e, t) => rT.call(e, t),
    we = Array.isArray,
    bs = e => Us(e) === "[object Map]",
    es = e => Us(e) === "[object Set]",
    bh = e => Us(e) === "[object Date]",
    iT = e => Us(e) === "[object RegExp]",
    Re = e => typeof e == "function",
    He = e => typeof e == "string",
    Vn = e => typeof e == "symbol",
    yt = e => e !== null && typeof e == "object",
    ff = e => (yt(e) || Re(e)) && Re(e.then) && Re(e.catch),
    ng = Object.prototype.toString,
    Us = e => ng.call(e),
    sT = e => Us(e).slice(8, -1),
    rg = e => Us(e) === "[object Object]",
    df = e => He(e) && e !== "NaN" && e[0] !== "-" && "" + parseInt(e, 10) === e,
    ti = In(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),
    oT = In("bind,cloak,else-if,else,for,html,if,model,on,once,pre,show,slot,text,memo"),
    Bl = e => {
        const t = Object.create(null);
        return n => t[n] || (t[n] = e(n))
    },
    aT = /-(\w)/g,
    kt = Bl(e => e.replace(aT, (t, n) => n ? n.toUpperCase() : "")),
    lT = /\B([A-Z])/g,
    Pn = Bl(e => e.replace(lT, "-$1").toLowerCase()),
    ts = Bl(e => e.charAt(0).toUpperCase() + e.slice(1)),
    ws = Bl(e => e ? `on${ts(e)}` : ""),
    Gn = (e, t) => !Object.is(e, t),
    Ss = (e, t) => {
        for (let n = 0; n < e.length; n++) e[n](t)
    },
    ig = (e, t, n, r = !1) => {
        Object.defineProperty(e, t, {
            configurable: !0,
            enumerable: !1,
            writable: r,
            value: n
        })
    },
    sl = e => {
        const t = parseFloat(e);
        return isNaN(t) ? e : t
    },
    ol = e => {
        const t = He(e) ? Number(e) : NaN;
        return isNaN(t) ? e : t
    };
let wh;
const sg = () => wh || (wh = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : typeof global < "u" ? global : {}),
    cT = "Infinity,undefined,NaN,isFinite,isNaN,parseFloat,parseInt,decodeURI,decodeURIComponent,encodeURI,encodeURIComponent,Math,Number,Date,Array,Object,Boolean,String,RegExp,Map,Set,JSON,Intl,BigInt,console,Error",
    uT = In(cT);

function ns(e) {
    if (we(e)) {
        const t = {};
        for (let n = 0; n < e.length; n++) {
            const r = e[n],
                i = He(r) ? og(r) : ns(r);
            if (i)
                for (const s in i) t[s] = i[s]
        }
        return t
    } else if (He(e) || yt(e)) return e
}
const fT = /;(?![^(]*\))/g,
    dT = /:([^]+)/,
    hT = /\/\*[^]*?\*\//g;

function og(e) {
    const t = {};
    return e.replace(hT, "").split(fT).forEach(n => {
        if (n) {
            const r = n.split(dT);
            r.length > 1 && (t[r[0].trim()] = r[1].trim())
        }
    }), t
}

function Ot(e) {
    let t = "";
    if (He(e)) t = e;
    else if (we(e))
        for (let n = 0; n < e.length; n++) {
            const r = Ot(e[n]);
            r && (t += r + " ")
        } else if (yt(e))
            for (const n in e) e[n] && (t += n + " ");
    return t.trim()
}

function ag(e) {
    if (!e) return null;
    let {
        class: t,
        style: n
    } = e;
    return t && !He(t) && (e.class = Ot(t)), n && (e.style = ns(n)), e
}
const pT = "html,body,base,head,link,meta,style,title,address,article,aside,footer,header,hgroup,h1,h2,h3,h4,h5,h6,nav,section,div,dd,dl,dt,figcaption,figure,picture,hr,img,li,main,ol,p,pre,ul,a,b,abbr,bdi,bdo,br,cite,code,data,dfn,em,i,kbd,mark,q,rp,rt,ruby,s,samp,small,span,strong,sub,sup,time,u,var,wbr,area,audio,map,track,video,embed,object,param,source,canvas,script,noscript,del,ins,caption,col,colgroup,table,thead,tbody,td,th,tr,button,datalist,fieldset,form,input,label,legend,meter,optgroup,option,output,progress,select,textarea,details,dialog,menu,summary,template,blockquote,iframe,tfoot",
    mT = "svg,animate,animateMotion,animateTransform,circle,clipPath,color-profile,defs,desc,discard,ellipse,feBlend,feColorMatrix,feComponentTransfer,feComposite,feConvolveMatrix,feDiffuseLighting,feDisplacementMap,feDistantLight,feDropShadow,feFlood,feFuncA,feFuncB,feFuncG,feFuncR,feGaussianBlur,feImage,feMerge,feMergeNode,feMorphology,feOffset,fePointLight,feSpecularLighting,feSpotLight,feTile,feTurbulence,filter,foreignObject,g,hatch,hatchpath,image,line,linearGradient,marker,mask,mesh,meshgradient,meshpatch,meshrow,metadata,mpath,path,pattern,polygon,polyline,radialGradient,rect,set,solidcolor,stop,switch,symbol,text,textPath,title,tspan,unknown,use,view",
    gT = "annotation,annotation-xml,maction,maligngroup,malignmark,math,menclose,merror,mfenced,mfrac,mfraction,mglyph,mi,mlabeledtr,mlongdiv,mmultiscripts,mn,mo,mover,mpadded,mphantom,mprescripts,mroot,mrow,ms,mscarries,mscarry,msgroup,msline,mspace,msqrt,msrow,mstack,mstyle,msub,msubsup,msup,mtable,mtd,mtext,mtr,munder,munderover,none,semantics",
    _T = "area,base,br,col,embed,hr,img,input,link,meta,param,source,track,wbr",
    vT = In(pT),
    yT = In(mT),
    bT = In(gT),
    wT = In(_T),
    ST = "itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",
    TT = In(ST);

function lg(e) {
    return !!e || e === ""
}

function CT(e, t) {
    if (e.length !== t.length) return !1;
    let n = !0;
    for (let r = 0; n && r < e.length; r++) n = ai(e[r], t[r]);
    return n
}

function ai(e, t) {
    if (e === t) return !0;
    let n = bh(e),
        r = bh(t);
    if (n || r) return n && r ? e.getTime() === t.getTime() : !1;
    if (n = Vn(e), r = Vn(t), n || r) return e === t;
    if (n = we(e), r = we(t), n || r) return n && r ? CT(e, t) : !1;
    if (n = yt(e), r = yt(t), n || r) {
        if (!n || !r) return !1;
        const i = Object.keys(e).length,
            s = Object.keys(t).length;
        if (i !== s) return !1;
        for (const o in e) {
            const a = e.hasOwnProperty(o),
                l = t.hasOwnProperty(o);
            if (a && !l || !a && l || !ai(e[o], t[o])) return !1
        }
    }
    return String(e) === String(t)
}

function Vl(e, t) {
    return e.findIndex(n => ai(n, t))
}
const Hi = e => He(e) ? e : e == null ? "" : we(e) || yt(e) && (e.toString === ng || !Re(e.toString)) ? JSON.stringify(e, cg, 2) : String(e),
    cg = (e, t) => t && t.__v_isRef ? cg(e, t.value) : bs(t) ? {
        [`Map(${t.size})`]: [...t.entries()].reduce((n, [r, i], s) => (n[Cc(r, s) + " =>"] = i, n), {})
    } : es(t) ? {
        [`Set(${t.size})`]: [...t.values()].map(n => Cc(n))
    } : Vn(t) ? Cc(t) : yt(t) && !we(t) && !rg(t) ? String(t) : t,
    Cc = (e, t = "") => {
        var n;
        return Vn(e) ? `Symbol(${(n=e.description)!=null?n:t})` : e
    };
/**
 * @vue/reactivity v3.4.27
 * (c) 2018-present Yuxi (Evan) You and Vue contributors
 * @license MIT
 **/
let An;
class hf {
    constructor(t = !1) {
        this.detached = t, this._active = !0, this.effects = [], this.cleanups = [], this.parent = An, !t && An && (this.index = (An.scopes || (An.scopes = [])).push(this) - 1)
    }
    get active() {
        return this._active
    }
    run(t) {
        if (this._active) {
            const n = An;
            try {
                return An = this, t()
            } finally {
                An = n
            }
        }
    }
    on() {
        An = this
    }
    off() {
        An = this.parent
    }
    stop(t) {
        if (this._active) {
            let n, r;
            for (n = 0, r = this.effects.length; n < r; n++) this.effects[n].stop();
            for (n = 0, r = this.cleanups.length; n < r; n++) this.cleanups[n]();
            if (this.scopes)
                for (n = 0, r = this.scopes.length; n < r; n++) this.scopes[n].stop(!0);
            if (!this.detached && this.parent && !t) {
                const i = this.parent.scopes.pop();
                i && i !== this && (this.parent.scopes[this.index] = i, i.index = this.index)
            }
            this.parent = void 0, this._active = !1
        }
    }
}

function ET(e) {
    return new hf(e)
}

function ug(e, t = An) {
    t && t.active && t.effects.push(e)
}

function pf() {
    return An
}

function fg(e) {
    An && An.cleanups.push(e)
}
let $i;
class Ms {
    constructor(t, n, r, i) {
        this.fn = t, this.trigger = n, this.scheduler = r, this.active = !0, this.deps = [], this._dirtyLevel = 4, this._trackId = 0, this._runnings = 0, this._shouldSchedule = !1, this._depsLength = 0, ug(this, i)
    }
    get dirty() {
        if (this._dirtyLevel === 2 || this._dirtyLevel === 3) {
            this._dirtyLevel = 1, mi();
            for (let t = 0; t < this._depsLength; t++) {
                const n = this.deps[t];
                if (n.computed && (AT(n.computed), this._dirtyLevel >= 4)) break
            }
            this._dirtyLevel === 1 && (this._dirtyLevel = 0), gi()
        }
        return this._dirtyLevel >= 4
    }
    set dirty(t) {
        this._dirtyLevel = t ? 4 : 0
    }
    run() {
        if (this._dirtyLevel = 0, !this.active) return this.fn();
        let t = ni,
            n = $i;
        try {
            return ni = !0, $i = this, this._runnings++, Sh(this), this.fn()
        } finally {
            Th(this), this._runnings--, $i = n, ni = t
        }
    }
    stop() {
        this.active && (Sh(this), Th(this), this.onStop && this.onStop(), this.active = !1)
    }
}

function AT(e) {
    return e.value
}

function Sh(e) {
    e._trackId++, e._depsLength = 0
}

function Th(e) {
    if (e.deps.length > e._depsLength) {
        for (let t = e._depsLength; t < e.deps.length; t++) dg(e.deps[t], e);
        e.deps.length = e._depsLength
    }
}

function dg(e, t) {
    const n = e.get(t);
    n !== void 0 && t._trackId !== n && (e.delete(t), e.size === 0 && e.cleanup())
}

function xT(e, t) {
    e.effect instanceof Ms && (e = e.effect.fn);
    const n = new Ms(e, Ut, () => {
        n.dirty && n.run()
    });
    t && (rt(n, t), t.scope && ug(n, t.scope)), (!t || !t.lazy) && n.run();
    const r = n.run.bind(n);
    return r.effect = n, r
}

function OT(e) {
    e.effect.stop()
}
let ni = !0,
    ru = 0;
const hg = [];

function mi() {
    hg.push(ni), ni = !1
}

function gi() {
    const e = hg.pop();
    ni = e === void 0 ? !0 : e
}

function mf() {
    ru++
}

function gf() {
    for (ru--; !ru && iu.length;) iu.shift()()
}

function pg(e, t, n) {
    if (t.get(e) !== e._trackId) {
        t.set(e, e._trackId);
        const r = e.deps[e._depsLength];
        r !== t ? (r && dg(r, e), e.deps[e._depsLength++] = t) : e._depsLength++
    }
}
const iu = [];

function mg(e, t, n) {
    mf();
    for (const r of e.keys()) {
        let i;
        r._dirtyLevel < t && (i ? ? (i = e.get(r) === r._trackId)) && (r._shouldSchedule || (r._shouldSchedule = r._dirtyLevel === 0), r._dirtyLevel = t), r._shouldSchedule && (i ? ? (i = e.get(r) === r._trackId)) && (r.trigger(), (!r._runnings || r.allowRecurse) && r._dirtyLevel !== 2 && (r._shouldSchedule = !1, r.scheduler && iu.push(r.scheduler)))
    }
    gf()
}
const gg = (e, t) => {
        const n = new Map;
        return n.cleanup = e, n.computed = t, n
    },
    al = new WeakMap,
    ki = Symbol(""),
    su = Symbol("");

function Cn(e, t, n) {
    if (ni && $i) {
        let r = al.get(e);
        r || al.set(e, r = new Map);
        let i = r.get(n);
        i || r.set(n, i = gg(() => r.delete(n))), pg($i, i)
    }
}

function Er(e, t, n, r, i, s) {
    const o = al.get(e);
    if (!o) return;
    let a = [];
    if (t === "clear") a = [...o.values()];
    else if (n === "length" && we(e)) {
        const l = Number(r);
        o.forEach((u, f) => {
            (f === "length" || !Vn(f) && f >= l) && a.push(u)
        })
    } else switch (n !== void 0 && a.push(o.get(n)), t) {
        case "add":
            we(e) ? df(n) && a.push(o.get("length")) : (a.push(o.get(ki)), bs(e) && a.push(o.get(su)));
            break;
        case "delete":
            we(e) || (a.push(o.get(ki)), bs(e) && a.push(o.get(su)));
            break;
        case "set":
            bs(e) && a.push(o.get(ki));
            break
    }
    mf();
    for (const l of a) l && mg(l, 4);
    gf()
}

function PT(e, t) {
    const n = al.get(e);
    return n && n.get(t)
}
const MT = In("__proto__,__v_isRef,__isVue"),
    _g = new Set(Object.getOwnPropertyNames(Symbol).filter(e => e !== "arguments" && e !== "caller").map(e => Symbol[e]).filter(Vn)),
    Ch = RT();

function RT() {
    const e = {};
    return ["includes", "indexOf", "lastIndexOf"].forEach(t => {
        e[t] = function(...n) {
            const r = it(this);
            for (let s = 0, o = this.length; s < o; s++) Cn(r, "get", s + "");
            const i = r[t](...n);
            return i === -1 || i === !1 ? r[t](...n.map(it)) : i
        }
    }), ["push", "pop", "shift", "unshift", "splice"].forEach(t => {
        e[t] = function(...n) {
            mi(), mf();
            const r = it(this)[t].apply(this, n);
            return gf(), gi(), r
        }
    }), e
}

function IT(e) {
    Vn(e) || (e = String(e));
    const t = it(this);
    return Cn(t, "has", e), t.hasOwnProperty(e)
}
class vg {
    constructor(t = !1, n = !1) {
        this._isReadonly = t, this._isShallow = n
    }
    get(t, n, r) {
        const i = this._isReadonly,
            s = this._isShallow;
        if (n === "__v_isReactive") return !i;
        if (n === "__v_isReadonly") return i;
        if (n === "__v_isShallow") return s;
        if (n === "__v_raw") return r === (i ? s ? Cg : Tg : s ? Sg : wg).get(t) || Object.getPrototypeOf(t) === Object.getPrototypeOf(r) ? t : void 0;
        const o = we(t);
        if (!i) {
            if (o && ct(Ch, n)) return Reflect.get(Ch, n, r);
            if (n === "hasOwnProperty") return IT
        }
        const a = Reflect.get(t, n, r);
        return (Vn(n) ? _g.has(n) : MT(n)) || (i || Cn(t, "get", n), s) ? a : an(a) ? o && df(n) ? a : a.value : yt(a) ? i ? Cr(a) : li(a) : a
    }
}
class yg extends vg {
    constructor(t = !1) {
        super(!1, t)
    }
    set(t, n, r, i) {
        let s = t[n];
        if (!this._isShallow) {
            const l = Rs(s);
            if (!wo(r) && !Rs(r) && (s = it(s), r = it(r)), !we(t) && an(s) && !an(r)) return l ? !1 : (s.value = r, !0)
        }
        const o = we(t) && df(n) ? Number(n) < t.length : ct(t, n),
            a = Reflect.set(t, n, r, i);
        return t === it(i) && (o ? Gn(r, s) && Er(t, "set", n, r) : Er(t, "add", n, r)), a
    }
    deleteProperty(t, n) {
        const r = ct(t, n);
        t[n];
        const i = Reflect.deleteProperty(t, n);
        return i && r && Er(t, "delete", n, void 0), i
    }
    has(t, n) {
        const r = Reflect.has(t, n);
        return (!Vn(n) || !_g.has(n)) && Cn(t, "has", n), r
    }
    ownKeys(t) {
        return Cn(t, "iterate", we(t) ? "length" : ki), Reflect.ownKeys(t)
    }
}
class bg extends vg {
    constructor(t = !1) {
        super(!0, t)
    }
    set(t, n) {
        return !0
    }
    deleteProperty(t, n) {
        return !0
    }
}
const $T = new yg,
    kT = new bg,
    LT = new yg(!0),
    NT = new bg(!0),
    _f = e => e,
    Hl = e => Reflect.getPrototypeOf(e);

function va(e, t, n = !1, r = !1) {
    e = e.__v_raw;
    const i = it(e),
        s = it(t);
    n || (Gn(t, s) && Cn(i, "get", t), Cn(i, "get", s));
    const {
        has: o
    } = Hl(i), a = r ? _f : n ? bf : So;
    if (o.call(i, t)) return a(e.get(t));
    if (o.call(i, s)) return a(e.get(s));
    e !== i && e.get(t)
}

function ya(e, t = !1) {
    const n = this.__v_raw,
        r = it(n),
        i = it(e);
    return t || (Gn(e, i) && Cn(r, "has", e), Cn(r, "has", i)), e === i ? n.has(e) : n.has(e) || n.has(i)
}

function ba(e, t = !1) {
    return e = e.__v_raw, !t && Cn(it(e), "iterate", ki), Reflect.get(e, "size", e)
}

function Eh(e) {
    e = it(e);
    const t = it(this);
    return Hl(t).has.call(t, e) || (t.add(e), Er(t, "add", e, e)), this
}

function Ah(e, t) {
    t = it(t);
    const n = it(this),
        {
            has: r,
            get: i
        } = Hl(n);
    let s = r.call(n, e);
    s || (e = it(e), s = r.call(n, e));
    const o = i.call(n, e);
    return n.set(e, t), s ? Gn(t, o) && Er(n, "set", e, t) : Er(n, "add", e, t), this
}

function xh(e) {
    const t = it(this),
        {
            has: n,
            get: r
        } = Hl(t);
    let i = n.call(t, e);
    i || (e = it(e), i = n.call(t, e)), r && r.call(t, e);
    const s = t.delete(e);
    return i && Er(t, "delete", e, void 0), s
}

function Oh() {
    const e = it(this),
        t = e.size !== 0,
        n = e.clear();
    return t && Er(e, "clear", void 0, void 0), n
}

function wa(e, t) {
    return function(r, i) {
        const s = this,
            o = s.__v_raw,
            a = it(o),
            l = t ? _f : e ? bf : So;
        return !e && Cn(a, "iterate", ki), o.forEach((u, f) => r.call(i, l(u), l(f), s))
    }
}

function Sa(e, t, n) {
    return function(...r) {
        const i = this.__v_raw,
            s = it(i),
            o = bs(s),
            a = e === "entries" || e === Symbol.iterator && o,
            l = e === "keys" && o,
            u = i[e](...r),
            f = n ? _f : t ? bf : So;
        return !t && Cn(s, "iterate", l ? su : ki), {
            next() {
                const {
                    value: h,
                    done: _
                } = u.next();
                return _ ? {
                    value: h,
                    done: _
                } : {
                    value: a ? [f(h[0]), f(h[1])] : f(h),
                    done: _
                }
            },
            [Symbol.iterator]() {
                return this
            }
        }
    }
}

function Dr(e) {
    return function(...t) {
        return e === "delete" ? !1 : e === "clear" ? void 0 : this
    }
}

function FT() {
    const e = {
            get(s) {
                return va(this, s)
            },
            get size() {
                return ba(this)
            },
            has: ya,
            add: Eh,
            set: Ah,
            delete: xh,
            clear: Oh,
            forEach: wa(!1, !1)
        },
        t = {
            get(s) {
                return va(this, s, !1, !0)
            },
            get size() {
                return ba(this)
            },
            has: ya,
            add: Eh,
            set: Ah,
            delete: xh,
            clear: Oh,
            forEach: wa(!1, !0)
        },
        n = {
            get(s) {
                return va(this, s, !0)
            },
            get size() {
                return ba(this, !0)
            },
            has(s) {
                return ya.call(this, s, !0)
            },
            add: Dr("add"),
            set: Dr("set"),
            delete: Dr("delete"),
            clear: Dr("clear"),
            forEach: wa(!0, !1)
        },
        r = {
            get(s) {
                return va(this, s, !0, !0)
            },
            get size() {
                return ba(this, !0)
            },
            has(s) {
                return ya.call(this, s, !0)
            },
            add: Dr("add"),
            set: Dr("set"),
            delete: Dr("delete"),
            clear: Dr("clear"),
            forEach: wa(!0, !0)
        };
    return ["keys", "values", "entries", Symbol.iterator].forEach(s => {
        e[s] = Sa(s, !1, !1), n[s] = Sa(s, !0, !1), t[s] = Sa(s, !1, !0), r[s] = Sa(s, !0, !0)
    }), [e, n, t, r]
}
const [DT, jT, BT, VT] = FT();

function Ul(e, t) {
    const n = t ? e ? VT : BT : e ? jT : DT;
    return (r, i, s) => i === "__v_isReactive" ? !e : i === "__v_isReadonly" ? e : i === "__v_raw" ? r : Reflect.get(ct(n, i) && i in r ? n : r, i, s)
}
const HT = {
        get: Ul(!1, !1)
    },
    UT = {
        get: Ul(!1, !0)
    },
    WT = {
        get: Ul(!0, !1)
    },
    zT = {
        get: Ul(!0, !0)
    },
    wg = new WeakMap,
    Sg = new WeakMap,
    Tg = new WeakMap,
    Cg = new WeakMap;

function qT(e) {
    switch (e) {
        case "Object":
        case "Array":
            return 1;
        case "Map":
        case "Set":
        case "WeakMap":
        case "WeakSet":
            return 2;
        default:
            return 0
    }
}

function KT(e) {
    return e.__v_skip || !Object.isExtensible(e) ? 0 : qT(sT(e))
}

function li(e) {
    return Rs(e) ? e : Wl(e, !1, $T, HT, wg)
}

function vf(e) {
    return Wl(e, !1, LT, UT, Sg)
}

function Cr(e) {
    return Wl(e, !0, kT, WT, Tg)
}

function GT(e) {
    return Wl(e, !0, NT, zT, Cg)
}

function Wl(e, t, n, r, i) {
    if (!yt(e) || e.__v_raw && !(t && e.__v_isReactive)) return e;
    const s = i.get(e);
    if (s) return s;
    const o = KT(e);
    if (o === 0) return e;
    const a = new Proxy(e, o === 2 ? r : n);
    return i.set(e, a), a
}

function Ts(e) {
    return Rs(e) ? Ts(e.__v_raw) : !!(e && e.__v_isReactive)
}

function Rs(e) {
    return !!(e && e.__v_isReadonly)
}

function wo(e) {
    return !!(e && e.__v_isShallow)
}

function yf(e) {
    return e ? !!e.__v_raw : !1
}

function it(e) {
    const t = e && e.__v_raw;
    return t ? it(t) : e
}

function Eg(e) {
    return Object.isExtensible(e) && ig(e, "__v_skip", !0), e
}
const So = e => yt(e) ? li(e) : e,
    bf = e => yt(e) ? Cr(e) : e;
class Ag {
    constructor(t, n, r, i) {
        this.getter = t, this._setter = n, this.dep = void 0, this.__v_isRef = !0, this.__v_isReadonly = !1, this.effect = new Ms(() => t(this._value), () => Cs(this, this.effect._dirtyLevel === 2 ? 2 : 3)), this.effect.computed = this, this.effect.active = this._cacheable = !i, this.__v_isReadonly = r
    }
    get value() {
        const t = it(this);
        return (!t._cacheable || t.effect.dirty) && Gn(t._value, t._value = t.effect.run()) && Cs(t, 4), wf(t), t.effect._dirtyLevel >= 2 && Cs(t, 2), t._value
    }
    set value(t) {
        this._setter(t)
    }
    get _dirty() {
        return this.effect.dirty
    }
    set _dirty(t) {
        this.effect.dirty = t
    }
}

function YT(e, t, n = !1) {
    let r, i;
    const s = Re(e);
    return s ? (r = e, i = Ut) : (r = e.get, i = e.set), new Ag(r, i, s || !i, n)
}

function wf(e) {
    var t;
    ni && $i && (e = it(e), pg($i, (t = e.dep) != null ? t : e.dep = gg(() => e.dep = void 0, e instanceof Ag ? e : void 0)))
}

function Cs(e, t = 4, n) {
    e = it(e);
    const r = e.dep;
    r && mg(r, t)
}

function an(e) {
    return !!(e && e.__v_isRef === !0)
}

function Tn(e) {
    return Og(e, !1)
}

function xg(e) {
    return Og(e, !0)
}

function Og(e, t) {
    return an(e) ? e : new XT(e, t)
}
class XT {
    constructor(t, n) {
        this.__v_isShallow = n, this.dep = void 0, this.__v_isRef = !0, this._rawValue = n ? t : it(t), this._value = n ? t : So(t)
    }
    get value() {
        return wf(this), this._value
    }
    set value(t) {
        const n = this.__v_isShallow || wo(t) || Rs(t);
        t = n ? t : it(t), Gn(t, this._rawValue) && (this._rawValue = t, this._value = n ? t : So(t), Cs(this, 4))
    }
}

function JT(e) {
    Cs(e, 4)
}

function Ar(e) {
    return an(e) ? e.value : e
}

function ZT(e) {
    return Re(e) ? e() : Ar(e)
}
const QT = {
    get: (e, t, n) => Ar(Reflect.get(e, t, n)),
    set: (e, t, n, r) => {
        const i = e[t];
        return an(i) && !an(n) ? (i.value = n, !0) : Reflect.set(e, t, n, r)
    }
};

function Sf(e) {
    return Ts(e) ? e : new Proxy(e, QT)
}
class eC {
    constructor(t) {
        this.dep = void 0, this.__v_isRef = !0;
        const {
            get: n,
            set: r
        } = t(() => wf(this), () => Cs(this));
        this._get = n, this._set = r
    }
    get value() {
        return this._get()
    }
    set value(t) {
        this._set(t)
    }
}

function Tf(e) {
    return new eC(e)
}

function tC(e) {
    const t = we(e) ? new Array(e.length) : {};
    for (const n in e) t[n] = Mg(e, n);
    return t
}
class nC {
    constructor(t, n, r) {
        this._object = t, this._key = n, this._defaultValue = r, this.__v_isRef = !0
    }
    get value() {
        const t = this._object[this._key];
        return t === void 0 ? this._defaultValue : t
    }
    set value(t) {
        this._object[this._key] = t
    }
    get dep() {
        return PT(it(this._object), this._key)
    }
}
class rC {
    constructor(t) {
        this._getter = t, this.__v_isRef = !0, this.__v_isReadonly = !0
    }
    get value() {
        return this._getter()
    }
}

function Pg(e, t, n) {
    return an(e) ? e : Re(e) ? new rC(e) : yt(e) && arguments.length > 1 ? Mg(e, t, n) : Tn(e)
}

function Mg(e, t, n) {
    const r = e[t];
    return an(r) ? r : new nC(e, t, n)
}
const iC = {
        GET: "get",
        HAS: "has",
        ITERATE: "iterate"
    },
    sC = {
        SET: "set",
        ADD: "add",
        DELETE: "delete",
        CLEAR: "clear"
    };
/**
 * @vue/runtime-core v3.4.27
 * (c) 2018-present Yuxi (Evan) You and Vue contributors
 * @license MIT
 **/
function oC(e, t) {}
const aC = {
        SETUP_FUNCTION: 0,
        0: "SETUP_FUNCTION",
        RENDER_FUNCTION: 1,
        1: "RENDER_FUNCTION",
        WATCH_GETTER: 2,
        2: "WATCH_GETTER",
        WATCH_CALLBACK: 3,
        3: "WATCH_CALLBACK",
        WATCH_CLEANUP: 4,
        4: "WATCH_CLEANUP",
        NATIVE_EVENT_HANDLER: 5,
        5: "NATIVE_EVENT_HANDLER",
        COMPONENT_EVENT_HANDLER: 6,
        6: "COMPONENT_EVENT_HANDLER",
        VNODE_HOOK: 7,
        7: "VNODE_HOOK",
        DIRECTIVE_HOOK: 8,
        8: "DIRECTIVE_HOOK",
        TRANSITION_HOOK: 9,
        9: "TRANSITION_HOOK",
        APP_ERROR_HANDLER: 10,
        10: "APP_ERROR_HANDLER",
        APP_WARN_HANDLER: 11,
        11: "APP_WARN_HANDLER",
        FUNCTION_REF: 12,
        12: "FUNCTION_REF",
        ASYNC_COMPONENT_LOADER: 13,
        13: "ASYNC_COMPONENT_LOADER",
        SCHEDULER: 14,
        14: "SCHEDULER"
    },
    lC = {
        sp: "serverPrefetch hook",
        bc: "beforeCreate hook",
        c: "created hook",
        bm: "beforeMount hook",
        m: "mounted hook",
        bu: "beforeUpdate hook",
        u: "updated",
        bum: "beforeUnmount hook",
        um: "unmounted hook",
        a: "activated hook",
        da: "deactivated hook",
        ec: "errorCaptured hook",
        rtc: "renderTracked hook",
        rtg: "renderTriggered hook",
        0: "setup function",
        1: "render function",
        2: "watcher getter",
        3: "watcher callback",
        4: "watcher cleanup function",
        5: "native event handler",
        6: "component event handler",
        7: "vnode hook",
        8: "directive hook",
        9: "transition hook",
        10: "app errorHandler",
        11: "app warnHandler",
        12: "ref function",
        13: "async component loader",
        14: "scheduler flush. This is likely a Vue internals bug. Please open an issue at https://github.com/vuejs/core ."
    };

function xr(e, t, n, r) {
    try {
        return r ? e(...r) : e()
    } catch (i) {
        rs(i, t, n)
    }
}

function Rn(e, t, n, r) {
    if (Re(e)) {
        const i = xr(e, t, n, r);
        return i && ff(i) && i.catch(s => {
            rs(s, t, n)
        }), i
    }
    if (we(e)) {
        const i = [];
        for (let s = 0; s < e.length; s++) i.push(Rn(e[s], t, n, r));
        return i
    }
}

function rs(e, t, n, r = !0) {
    const i = t ? t.vnode : null;
    if (t) {
        let s = t.parent;
        const o = t.proxy,
            a = `https://vuejs.org/error-reference/#runtime-${n}`;
        for (; s;) {
            const u = s.ec;
            if (u) {
                for (let f = 0; f < u.length; f++)
                    if (u[f](e, o, a) === !1) return
            }
            s = s.parent
        }
        const l = t.appContext.config.errorHandler;
        if (l) {
            mi(), xr(l, null, 10, [e, o, a]), gi();
            return
        }
    }
    cC(e, n, i, r)
}

function cC(e, t, n, r = !0) {
    console.error(e)
}
let To = !1,
    ou = !1;
const fn = [];
let ar = 0;
const Es = [];
let Kr = null,
    Ci = 0;
const Rg = Promise.resolve();
let Cf = null;

function Ws(e) {
    const t = Cf || Rg;
    return e ? t.then(this ? e.bind(this) : e) : t
}

function uC(e) {
    let t = ar + 1,
        n = fn.length;
    for (; t < n;) {
        const r = t + n >>> 1,
            i = fn[r],
            s = Co(i);
        s < e || s === e && i.pre ? t = r + 1 : n = r
    }
    return t
}

function zl(e) {
    (!fn.length || !fn.includes(e, To && e.allowRecurse ? ar + 1 : ar)) && (e.id == null ? fn.push(e) : fn.splice(uC(e.id), 0, e), Ig())
}

function Ig() {
    !To && !ou && (ou = !0, Cf = Rg.then($g))
}

function fC(e) {
    const t = fn.indexOf(e);
    t > ar && fn.splice(t, 1)
}

function ll(e) {
    we(e) ? Es.push(...e) : (!Kr || !Kr.includes(e, e.allowRecurse ? Ci + 1 : Ci)) && Es.push(e), Ig()
}

function Ph(e, t, n = To ? ar + 1 : 0) {
    for (; n < fn.length; n++) {
        const r = fn[n];
        if (r && r.pre) {
            if (e && r.id !== e.uid) continue;
            fn.splice(n, 1), n--, r()
        }
    }
}

function cl(e) {
    if (Es.length) {
        const t = [...new Set(Es)].sort((n, r) => Co(n) - Co(r));
        if (Es.length = 0, Kr) {
            Kr.push(...t);
            return
        }
        for (Kr = t, Ci = 0; Ci < Kr.length; Ci++) Kr[Ci]();
        Kr = null, Ci = 0
    }
}
const Co = e => e.id == null ? 1 / 0 : e.id,
    dC = (e, t) => {
        const n = Co(e) - Co(t);
        if (n === 0) {
            if (e.pre && !t.pre) return -1;
            if (t.pre && !e.pre) return 1
        }
        return n
    };

function $g(e) {
    ou = !1, To = !0, fn.sort(dC);
    const t = Ut;
    try {
        for (ar = 0; ar < fn.length; ar++) {
            const n = fn[ar];
            n && n.active !== !1 && xr(n, null, 14)
        }
    } finally {
        ar = 0, fn.length = 0, cl(), To = !1, Cf = null, (fn.length || Es.length) && $g()
    }
}
let ds, Ta = [];

function kg(e, t) {
    var n, r;
    ds = e, ds ? (ds.enabled = !0, Ta.forEach(({
        event: i,
        args: s
    }) => ds.emit(i, ...s)), Ta = []) : typeof window < "u" && window.HTMLElement && !((r = (n = window.navigator) == null ? void 0 : n.userAgent) != null && r.includes("jsdom")) ? ((t.__VUE_DEVTOOLS_HOOK_REPLAY__ = t.__VUE_DEVTOOLS_HOOK_REPLAY__ || []).push(s => {
        kg(s, t)
    }), setTimeout(() => {
        ds || (t.__VUE_DEVTOOLS_HOOK_REPLAY__ = null, Ta = [])
    }, 3e3)) : Ta = []
}

function hC(e, t, ...n) {
    if (e.isUnmounted) return;
    const r = e.vnode.props || ft;
    let i = n;
    const s = t.startsWith("update:"),
        o = s && t.slice(7);
    if (o && o in r) {
        const f = `${o==="modelValue"?"model":o}Modifiers`,
            {
                number: h,
                trim: _
            } = r[f] || ft;
        _ && (i = n.map(m => He(m) ? m.trim() : m)), h && (i = n.map(sl))
    }
    let a, l = r[a = ws(t)] || r[a = ws(kt(t))];
    !l && s && (l = r[a = ws(Pn(t))]), l && Rn(l, e, 6, i);
    const u = r[a + "Once"];
    if (u) {
        if (!e.emitted) e.emitted = {};
        else if (e.emitted[a]) return;
        e.emitted[a] = !0, Rn(u, e, 6, i)
    }
}

function Lg(e, t, n = !1) {
    const r = t.emitsCache,
        i = r.get(e);
    if (i !== void 0) return i;
    const s = e.emits;
    let o = {},
        a = !1;
    if (!Re(e)) {
        const l = u => {
            const f = Lg(u, t, !0);
            f && (a = !0, rt(o, f))
        };
        !n && t.mixins.length && t.mixins.forEach(l), e.extends && l(e.extends), e.mixins && e.mixins.forEach(l)
    }
    return !s && !a ? (yt(e) && r.set(e, null), null) : (we(s) ? s.forEach(l => o[l] = null) : rt(o, s), yt(e) && r.set(e, o), o)
}

function ql(e, t) {
    return !e || !Qi(t) ? !1 : (t = t.slice(2).replace(/Once$/, ""), ct(e, t[0].toLowerCase() + t.slice(1)) || ct(e, Pn(t)) || ct(e, t))
}
let Wt = null,
    Kl = null;

function Eo(e) {
    const t = Wt;
    return Wt = e, Kl = e && e.type.__scopeId || null, t
}

function pC(e) {
    Kl = e
}

function mC() {
    Kl = null
}
const gC = e => Ct;

function Ct(e, t = Wt, n) {
    if (!t || e._n) return e;
    const r = (...i) => {
        r._d && pu(-1);
        const s = Eo(t);
        let o;
        try {
            o = e(...i)
        } finally {
            Eo(s), r._d && pu(1)
        }
        return o
    };
    return r._n = !0, r._c = !0, r._d = !0, r
}

function Va(e) {
    const {
        type: t,
        vnode: n,
        proxy: r,
        withProxy: i,
        propsOptions: [s],
        slots: o,
        attrs: a,
        emit: l,
        render: u,
        renderCache: f,
        props: h,
        data: _,
        setupState: m,
        ctx: T,
        inheritAttrs: R
    } = e, B = Eo(e);
    let I, A;
    try {
        if (n.shapeFlag & 4) {
            const O = i || r,
                P = O;
            I = On(u.call(P, O, f, h, m, _, T)), A = a
        } else {
            const O = t;
            I = On(O.length > 1 ? O(h, {
                attrs: a,
                slots: o,
                emit: l
            }) : O(h, null)), A = t.props ? a : vC(a)
        }
    } catch (O) {
        lo.length = 0, rs(O, e, 1), I = Pe(sn)
    }
    let E = I;
    if (A && R !== !1) {
        const O = Object.keys(A),
            {
                shapeFlag: P
            } = E;
        O.length && P & 7 && (s && O.some(cf) && (A = yC(A, s)), E = hr(E, A, !1, !0))
    }
    return n.dirs && (E = hr(E, null, !1, !0), E.dirs = E.dirs ? E.dirs.concat(n.dirs) : n.dirs), n.transition && (E.transition = n.transition), I = E, Eo(B), I
}

function _C(e, t = !0) {
    let n;
    for (let r = 0; r < e.length; r++) {
        const i = e[r];
        if (ci(i)) {
            if (i.type !== sn || i.children === "v-if") {
                if (n) return;
                n = i
            }
        } else return
    }
    return n
}
const vC = e => {
        let t;
        for (const n in e)(n === "class" || n === "style" || Qi(n)) && ((t || (t = {}))[n] = e[n]);
        return t
    },
    yC = (e, t) => {
        const n = {};
        for (const r in e)(!cf(r) || !(r.slice(9) in t)) && (n[r] = e[r]);
        return n
    };

function bC(e, t, n) {
    const {
        props: r,
        children: i,
        component: s
    } = e, {
        props: o,
        children: a,
        patchFlag: l
    } = t, u = s.emitsOptions;
    if (t.dirs || t.transition) return !0;
    if (n && l >= 0) {
        if (l & 1024) return !0;
        if (l & 16) return r ? Mh(r, o, u) : !!o;
        if (l & 8) {
            const f = t.dynamicProps;
            for (let h = 0; h < f.length; h++) {
                const _ = f[h];
                if (o[_] !== r[_] && !ql(u, _)) return !0
            }
        }
    } else return (i || a) && (!a || !a.$stable) ? !0 : r === o ? !1 : r ? o ? Mh(r, o, u) : !0 : !!o;
    return !1
}

function Mh(e, t, n) {
    const r = Object.keys(t);
    if (r.length !== Object.keys(e).length) return !0;
    for (let i = 0; i < r.length; i++) {
        const s = r[i];
        if (t[s] !== e[s] && !ql(n, s)) return !0
    }
    return !1
}

function Ef({
    vnode: e,
    parent: t
}, n) {
    for (; t;) {
        const r = t.subTree;
        if (r.suspense && r.suspense.activeBranch === e && (r.el = e.el), r === e)(e = t.vnode).el = n, t = t.parent;
        else break
    }
}
const Af = "components",
    wC = "directives";

function vt(e, t) {
    return xf(Af, e, !0, t) || e
}
const Ng = Symbol.for("v-ndc");

function kr(e) {
    return He(e) ? xf(Af, e, !1) || e : e || Ng
}

function pt(e) {
    return xf(wC, e)
}

function xf(e, t, n = !0, r = !1) {
    const i = Wt || Jt;
    if (i) {
        const s = i.type;
        if (e === Af) {
            const a = yu(s, !1);
            if (a && (a === t || a === kt(t) || a === ts(kt(t)))) return s
        }
        const o = Rh(i[e] || s[e], t) || Rh(i.appContext[e], t);
        return !o && r ? s : o
    }
}

function Rh(e, t) {
    return e && (e[t] || e[kt(t)] || e[ts(kt(t))])
}
const Fg = e => e.__isSuspense;
let au = 0;
const SC = {
        name: "Suspense",
        __isSuspense: !0,
        process(e, t, n, r, i, s, o, a, l, u) {
            if (e == null) TC(t, n, r, i, s, o, a, l, u);
            else {
                if (s && s.deps > 0 && !e.suspense.isInFallback) {
                    t.suspense = e.suspense, t.suspense.vnode = t, t.el = e.el;
                    return
                }
                CC(e, t, n, r, i, o, a, l, u)
            }
        },
        hydrate: EC,
        create: Of,
        normalize: AC
    },
    Dg = SC;

function Ao(e, t) {
    const n = e.props && e.props[t];
    Re(n) && n()
}

function TC(e, t, n, r, i, s, o, a, l) {
    const {
        p: u,
        o: {
            createElement: f
        }
    } = l, h = f("div"), _ = e.suspense = Of(e, i, r, t, h, n, s, o, a, l);
    u(null, _.pendingBranch = e.ssContent, h, null, r, _, s, o), _.deps > 0 ? (Ao(e, "onPending"), Ao(e, "onFallback"), u(null, e.ssFallback, t, n, r, null, s, o), As(_, e.ssFallback)) : _.resolve(!1, !0)
}

function CC(e, t, n, r, i, s, o, a, {
    p: l,
    um: u,
    o: {
        createElement: f
    }
}) {
    const h = t.suspense = e.suspense;
    h.vnode = t, t.el = e.el;
    const _ = t.ssContent,
        m = t.ssFallback,
        {
            activeBranch: T,
            pendingBranch: R,
            isInFallback: B,
            isHydrating: I
        } = h;
    if (R) h.pendingBranch = _, Wn(_, R) ? (l(R, _, h.hiddenContainer, null, i, h, s, o, a), h.deps <= 0 ? h.resolve() : B && (I || (l(T, m, n, r, i, null, s, o, a), As(h, m)))) : (h.pendingId = au++, I ? (h.isHydrating = !1, h.activeBranch = R) : u(R, i, h), h.deps = 0, h.effects.length = 0, h.hiddenContainer = f("div"), B ? (l(null, _, h.hiddenContainer, null, i, h, s, o, a), h.deps <= 0 ? h.resolve() : (l(T, m, n, r, i, null, s, o, a), As(h, m))) : T && Wn(_, T) ? (l(T, _, n, r, i, h, s, o, a), h.resolve(!0)) : (l(null, _, h.hiddenContainer, null, i, h, s, o, a), h.deps <= 0 && h.resolve()));
    else if (T && Wn(_, T)) l(T, _, n, r, i, h, s, o, a), As(h, _);
    else if (Ao(t, "onPending"), h.pendingBranch = _, _.shapeFlag & 512 ? h.pendingId = _.component.suspenseId : h.pendingId = au++, l(null, _, h.hiddenContainer, null, i, h, s, o, a), h.deps <= 0) h.resolve();
    else {
        const {
            timeout: A,
            pendingId: E
        } = h;
        A > 0 ? setTimeout(() => {
            h.pendingId === E && h.fallback(m)
        }, A) : A === 0 && h.fallback(m)
    }
}

function Of(e, t, n, r, i, s, o, a, l, u, f = !1) {
    const {
        p: h,
        m: _,
        um: m,
        n: T,
        o: {
            parentNode: R,
            remove: B
        }
    } = u;
    let I;
    const A = xC(e);
    A && t && t.pendingBranch && (I = t.pendingId, t.deps++);
    const E = e.props ? ol(e.props.timeout) : void 0,
        O = s,
        P = {
            vnode: e,
            parent: t,
            parentComponent: n,
            namespace: o,
            container: r,
            hiddenContainer: i,
            deps: 0,
            pendingId: au++,
            timeout: typeof E == "number" ? E : -1,
            activeBranch: null,
            pendingBranch: null,
            isInFallback: !f,
            isHydrating: f,
            isUnmounted: !1,
            effects: [],
            resolve($ = !1, H = !1) {
                const {
                    vnode: F,
                    activeBranch: V,
                    pendingBranch: k,
                    pendingId: Y,
                    effects: L,
                    parentComponent: te,
                    container: ie
                } = P;
                let _e = !1;
                P.isHydrating ? P.isHydrating = !1 : $ || (_e = V && k.transition && k.transition.mode === "out-in", _e && (V.transition.afterLeave = () => {
                    Y === P.pendingId && (_(k, ie, s === O ? T(V) : s, 0), ll(L))
                }), V && (R(V.el) !== P.hiddenContainer && (s = T(V)), m(V, te, P, !0)), _e || _(k, ie, s, 0)), As(P, k), P.pendingBranch = null, P.isInFallback = !1;
                let X = P.parent,
                    le = !1;
                for (; X;) {
                    if (X.pendingBranch) {
                        X.effects.push(...L), le = !0;
                        break
                    }
                    X = X.parent
                }!le && !_e && ll(L), P.effects = [], A && t && t.pendingBranch && I === t.pendingId && (t.deps--, t.deps === 0 && !H && t.resolve()), Ao(F, "onResolve")
            },
            fallback($) {
                if (!P.pendingBranch) return;
                const {
                    vnode: H,
                    activeBranch: F,
                    parentComponent: V,
                    container: k,
                    namespace: Y
                } = P;
                Ao(H, "onFallback");
                const L = T(F),
                    te = () => {
                        P.isInFallback && (h(null, $, k, L, V, null, Y, a, l), As(P, $))
                    },
                    ie = $.transition && $.transition.mode === "out-in";
                ie && (F.transition.afterLeave = te), P.isInFallback = !0, m(F, V, null, !0), ie || te()
            },
            move($, H, F) {
                P.activeBranch && _(P.activeBranch, $, H, F), P.container = $
            },
            next() {
                return P.activeBranch && T(P.activeBranch)
            },
            registerDep($, H) {
                const F = !!P.pendingBranch;
                F && P.deps++;
                const V = $.vnode.el;
                $.asyncDep.catch(k => {
                    rs(k, $, 0)
                }).then(k => {
                    if ($.isUnmounted || P.isUnmounted || P.pendingId !== $.suspenseId) return;
                    $.asyncResolved = !0;
                    const {
                        vnode: Y
                    } = $;
                    _u($, k, !1), V && (Y.el = V);
                    const L = !V && $.subTree.el;
                    H($, Y, R(V || $.subTree.el), V ? null : T($.subTree), P, o, l), L && B(L), Ef($, Y.el), F && --P.deps === 0 && P.resolve()
                })
            },
            unmount($, H) {
                P.isUnmounted = !0, P.activeBranch && m(P.activeBranch, n, $, H), P.pendingBranch && m(P.pendingBranch, n, $, H)
            }
        };
    return P
}

function EC(e, t, n, r, i, s, o, a, l) {
    const u = t.suspense = Of(t, r, n, e.parentNode, document.createElement("div"), null, i, s, o, a, !0),
        f = l(e, u.pendingBranch = t.ssContent, n, u, s, o);
    return u.deps === 0 && u.resolve(!1, !0), f
}

function AC(e) {
    const {
        shapeFlag: t,
        children: n
    } = e, r = t & 32;
    e.ssContent = Ih(r ? n.default : n), e.ssFallback = r ? Ih(n.fallback) : Pe(sn)
}

function Ih(e) {
    let t;
    if (Re(e)) {
        const n = qi && e._c;
        n && (e._d = !1, Q()), e = e(), n && (e._d = !0, t = wn, w_())
    }
    return we(e) && (e = _C(e)), e = On(e), t && !e.dynamicChildren && (e.dynamicChildren = t.filter(n => n !== e)), e
}

function jg(e, t) {
    t && t.pendingBranch ? we(e) ? t.effects.push(...e) : t.effects.push(e) : ll(e)
}

function As(e, t) {
    e.activeBranch = t;
    const {
        vnode: n,
        parentComponent: r
    } = e;
    let i = t.el;
    for (; !i && t.component;) t = t.component.subTree, i = t.el;
    n.el = i, r && r.subTree === n && (r.vnode.el = i, Ef(r, i))
}

function xC(e) {
    const t = e.props && e.props.suspensible;
    return t != null && t !== !1
}
const Bg = Symbol.for("v-scx"),
    Vg = () => fr(Bg);

function OC(e, t) {
    return zo(e, null, t)
}

function Hg(e, t) {
    return zo(e, null, {
        flush: "post"
    })
}

function Ug(e, t) {
    return zo(e, null, {
        flush: "sync"
    })
}
const Ca = {};

function zn(e, t, n) {
    return zo(e, t, n)
}

function zo(e, t, {
    immediate: n,
    deep: r,
    flush: i,
    once: s,
    onTrack: o,
    onTrigger: a
} = ft) {
    if (t && s) {
        const $ = t;
        t = (...H) => {
            $(...H), P()
        }
    }
    const l = Jt,
        u = $ => r === !0 ? $ : Ei($, r === !1 ? 1 : void 0);
    let f, h = !1,
        _ = !1;
    if (an(e) ? (f = () => e.value, h = wo(e)) : Ts(e) ? (f = () => u(e), h = !0) : we(e) ? (_ = !0, h = e.some($ => Ts($) || wo($)), f = () => e.map($ => {
            if (an($)) return $.value;
            if (Ts($)) return u($);
            if (Re($)) return xr($, l, 2)
        })) : Re(e) ? t ? f = () => xr(e, l, 2) : f = () => (m && m(), Rn(e, l, 3, [T])) : f = Ut, t && r) {
        const $ = f;
        f = () => Ei($())
    }
    let m, T = $ => {
            m = E.onStop = () => {
                xr($, l, 4), m = E.onStop = void 0
            }
        },
        R;
    if (Go)
        if (T = Ut, t ? n && Rn(t, l, 3, [f(), _ ? [] : void 0, T]) : f(), i === "sync") {
            const $ = Vg();
            R = $.__watcherHandles || ($.__watcherHandles = [])
        } else return Ut;
    let B = _ ? new Array(e.length).fill(Ca) : Ca;
    const I = () => {
        if (!(!E.active || !E.dirty))
            if (t) {
                const $ = E.run();
                (r || h || (_ ? $.some((H, F) => Gn(H, B[F])) : Gn($, B))) && (m && m(), Rn(t, l, 3, [$, B === Ca ? void 0 : _ && B[0] === Ca ? [] : B, T]), B = $)
            } else E.run()
    };
    I.allowRecurse = !!t;
    let A;
    i === "sync" ? A = I : i === "post" ? A = () => nn(I, l && l.suspense) : (I.pre = !0, l && (I.id = l.uid), A = () => zl(I));
    const E = new Ms(f, Ut, A),
        O = pf(),
        P = () => {
            E.stop(), O && uf(O.effects, E)
        };
    return t ? n ? I() : B = E.run() : i === "post" ? nn(E.run.bind(E), l && l.suspense) : E.run(), R && R.push(P), P
}

function PC(e, t, n) {
    const r = this.proxy,
        i = He(e) ? e.includes(".") ? Wg(r, e) : () => r[e] : e.bind(r, r);
    let s;
    Re(t) ? s = t : (s = t.handler, n = t);
    const o = Ki(this),
        a = zo(i, s.bind(r), n);
    return o(), a
}

function Wg(e, t) {
    const n = t.split(".");
    return () => {
        let r = e;
        for (let i = 0; i < n.length && r; i++) r = r[n[i]];
        return r
    }
}

function Ei(e, t = 1 / 0, n) {
    if (t <= 0 || !yt(e) || e.__v_skip || (n = n || new Set, n.has(e))) return e;
    if (n.add(e), t--, an(e)) Ei(e.value, t, n);
    else if (we(e))
        for (let r = 0; r < e.length; r++) Ei(e[r], t, n);
    else if (es(e) || bs(e)) e.forEach(r => {
        Ei(r, t, n)
    });
    else if (rg(e))
        for (const r in e) Ei(e[r], t, n);
    return e
}

function zt(e, t) {
    if (Wt === null) return e;
    const n = Ql(Wt) || Wt.proxy,
        r = e.dirs || (e.dirs = []);
    for (let i = 0; i < t.length; i++) {
        let [s, o, a, l = ft] = t[i];
        s && (Re(s) && (s = {
            mounted: s,
            updated: s
        }), s.deep && Ei(o), r.push({
            dir: s,
            instance: n,
            value: o,
            oldValue: void 0,
            arg: a,
            modifiers: l
        }))
    }
    return e
}

function or(e, t, n, r) {
    const i = e.dirs,
        s = t && t.dirs;
    for (let o = 0; o < i.length; o++) {
        const a = i[o];
        s && (a.oldValue = s[o].value);
        let l = a.dir[r];
        l && (mi(), Rn(l, n, 8, [e.el, a, e, t]), gi())
    }
}
const Gr = Symbol("_leaveCb"),
    Ea = Symbol("_enterCb");

function Pf() {
    const e = {
        isMounted: !1,
        isLeaving: !1,
        isUnmounting: !1,
        leavingVNodes: new Map
    };
    return is(() => {
        e.isMounted = !0
    }), Jl(() => {
        e.isUnmounting = !0
    }), e
}
const Ln = [Function, Array],
    Mf = {
        mode: String,
        appear: Boolean,
        persisted: Boolean,
        onBeforeEnter: Ln,
        onEnter: Ln,
        onAfterEnter: Ln,
        onEnterCancelled: Ln,
        onBeforeLeave: Ln,
        onLeave: Ln,
        onAfterLeave: Ln,
        onLeaveCancelled: Ln,
        onBeforeAppear: Ln,
        onAppear: Ln,
        onAfterAppear: Ln,
        onAppearCancelled: Ln
    },
    MC = {
        name: "BaseTransition",
        props: Mf,
        setup(e, {
            slots: t
        }) {
            const n = Jn(),
                r = Pf();
            return () => {
                const i = t.default && Gl(t.default(), !0);
                if (!i || !i.length) return;
                let s = i[0];
                if (i.length > 1) {
                    for (const _ of i)
                        if (_.type !== sn) {
                            s = _;
                            break
                        }
                }
                const o = it(e),
                    {
                        mode: a
                    } = o;
                if (r.isLeaving) return Ec(s);
                const l = $h(s);
                if (!l) return Ec(s);
                const u = Is(l, o, r, n);
                Ui(l, u);
                const f = n.subTree,
                    h = f && $h(f);
                if (h && h.type !== sn && !Wn(l, h)) {
                    const _ = Is(h, o, r, n);
                    if (Ui(h, _), a === "out-in" && l.type !== sn) return r.isLeaving = !0, _.afterLeave = () => {
                        r.isLeaving = !1, n.update.active !== !1 && (n.effect.dirty = !0, n.update())
                    }, Ec(s);
                    a === "in-out" && l.type !== sn && (_.delayLeave = (m, T, R) => {
                        const B = qg(r, h);
                        B[String(h.key)] = h, m[Gr] = () => {
                            T(), m[Gr] = void 0, delete u.delayedLeave
                        }, u.delayedLeave = R
                    })
                }
                return s
            }
        }
    },
    zg = MC;

function qg(e, t) {
    const {
        leavingVNodes: n
    } = e;
    let r = n.get(t.type);
    return r || (r = Object.create(null), n.set(t.type, r)), r
}

function Is(e, t, n, r) {
    const {
        appear: i,
        mode: s,
        persisted: o = !1,
        onBeforeEnter: a,
        onEnter: l,
        onAfterEnter: u,
        onEnterCancelled: f,
        onBeforeLeave: h,
        onLeave: _,
        onAfterLeave: m,
        onLeaveCancelled: T,
        onBeforeAppear: R,
        onAppear: B,
        onAfterAppear: I,
        onAppearCancelled: A
    } = t, E = String(e.key), O = qg(n, e), P = (F, V) => {
        F && Rn(F, r, 9, V)
    }, $ = (F, V) => {
        const k = V[1];
        P(F, V), we(F) ? F.every(Y => Y.length <= 1) && k() : F.length <= 1 && k()
    }, H = {
        mode: s,
        persisted: o,
        beforeEnter(F) {
            let V = a;
            if (!n.isMounted)
                if (i) V = R || a;
                else return;
            F[Gr] && F[Gr](!0);
            const k = O[E];
            k && Wn(e, k) && k.el[Gr] && k.el[Gr](), P(V, [F])
        },
        enter(F) {
            let V = l,
                k = u,
                Y = f;
            if (!n.isMounted)
                if (i) V = B || l, k = I || u, Y = A || f;
                else return;
            let L = !1;
            const te = F[Ea] = ie => {
                L || (L = !0, ie ? P(Y, [F]) : P(k, [F]), H.delayedLeave && H.delayedLeave(), F[Ea] = void 0)
            };
            V ? $(V, [F, te]) : te()
        },
        leave(F, V) {
            const k = String(e.key);
            if (F[Ea] && F[Ea](!0), n.isUnmounting) return V();
            P(h, [F]);
            let Y = !1;
            const L = F[Gr] = te => {
                Y || (Y = !0, V(), te ? P(T, [F]) : P(m, [F]), F[Gr] = void 0, O[k] === e && delete O[k])
            };
            O[k] = e, _ ? $(_, [F, L]) : L()
        },
        clone(F) {
            return Is(F, t, n, r)
        }
    };
    return H
}

function Ec(e) {
    if (Ko(e)) return e = hr(e), e.children = null, e
}

function $h(e) {
    if (!Ko(e)) return e;
    const {
        shapeFlag: t,
        children: n
    } = e;
    if (n) {
        if (t & 16) return n[0];
        if (t & 32 && Re(n.default)) return n.default()
    }
}

function Ui(e, t) {
    e.shapeFlag & 6 && e.component ? Ui(e.component.subTree, t) : e.shapeFlag & 128 ? (e.ssContent.transition = t.clone(e.ssContent), e.ssFallback.transition = t.clone(e.ssFallback)) : e.transition = t
}

function Gl(e, t = !1, n) {
    let r = [],
        i = 0;
    for (let s = 0; s < e.length; s++) {
        let o = e[s];
        const a = n == null ? o.key : String(n) + String(o.key != null ? o.key : s);
        o.type === nt ? (o.patchFlag & 128 && i++, r = r.concat(Gl(o.children, t, a))) : (t || o.type !== sn) && r.push(a != null ? hr(o, {
            key: a
        }) : o)
    }
    if (i > 1)
        for (let s = 0; s < r.length; s++) r[s].patchFlag = -2;
    return r
} /*! #__NO_SIDE_EFFECTS__ */
function qo(e, t) {
    return Re(e) ? (() => rt({
        name: e.name
    }, t, {
        setup: e
    }))() : e
}
const Li = e => !!e.type.__asyncLoader; /*! #__NO_SIDE_EFFECTS__ */
function Kg(e) {
    Re(e) && (e = {
        loader: e
    });
    const {
        loader: t,
        loadingComponent: n,
        errorComponent: r,
        delay: i = 200,
        timeout: s,
        suspensible: o = !0,
        onError: a
    } = e;
    let l = null,
        u, f = 0;
    const h = () => (f++, l = null, _()),
        _ = () => {
            let m;
            return l || (m = l = t().catch(T => {
                if (T = T instanceof Error ? T : new Error(String(T)), a) return new Promise((R, B) => {
                    a(T, () => R(h()), () => B(T), f + 1)
                });
                throw T
            }).then(T => m !== l && l ? l : (T && (T.__esModule || T[Symbol.toStringTag] === "Module") && (T = T.default), u = T, T)))
        };
    return qo({
        name: "AsyncComponentWrapper",
        __asyncLoader: _,
        get __asyncResolved() {
            return u
        },
        setup() {
            const m = Jt;
            if (u) return () => Ac(u, m);
            const T = A => {
                l = null, rs(A, m, 13, !r)
            };
            if (o && m.suspense || Go) return _().then(A => () => Ac(A, m)).catch(A => (T(A), () => r ? Pe(r, {
                error: A
            }) : null));
            const R = Tn(!1),
                B = Tn(),
                I = Tn(!!i);
            return i && setTimeout(() => {
                I.value = !1
            }, i), s != null && setTimeout(() => {
                if (!R.value && !B.value) {
                    const A = new Error(`Async component timed out after ${s}ms.`);
                    T(A), B.value = A
                }
            }, s), _().then(() => {
                R.value = !0, m.parent && Ko(m.parent.vnode) && (m.parent.effect.dirty = !0, zl(m.parent.update))
            }).catch(A => {
                T(A), B.value = A
            }), () => {
                if (R.value && u) return Ac(u, m);
                if (B.value && r) return Pe(r, {
                    error: B.value
                });
                if (n && !I.value) return Pe(n)
            }
        }
    })
}

function Ac(e, t) {
    const {
        ref: n,
        props: r,
        children: i,
        ce: s
    } = t.vnode, o = Pe(e, r, i);
    return o.ref = n, o.ce = s, delete t.vnode.ce, o
}
const Ko = e => e.type.__isKeepAlive,
    RC = {
        name: "KeepAlive",
        __isKeepAlive: !0,
        props: {
            include: [String, RegExp, Array],
            exclude: [String, RegExp, Array],
            max: [String, Number]
        },
        setup(e, {
            slots: t
        }) {
            const n = Jn(),
                r = n.ctx;
            if (!r.renderer) return () => {
                const A = t.default && t.default();
                return A && A.length === 1 ? A[0] : A
            };
            const i = new Map,
                s = new Set;
            let o = null;
            const a = n.suspense,
                {
                    renderer: {
                        p: l,
                        m: u,
                        um: f,
                        o: {
                            createElement: h
                        }
                    }
                } = r,
                _ = h("div");
            r.activate = (A, E, O, P, $) => {
                const H = A.component;
                u(A, E, O, 0, a), l(H.vnode, A, E, O, H, a, P, A.slotScopeIds, $), nn(() => {
                    H.isDeactivated = !1, H.a && Ss(H.a);
                    const F = A.props && A.props.onVnodeMounted;
                    F && vn(F, H.parent, A)
                }, a)
            }, r.deactivate = A => {
                const E = A.component;
                u(A, _, null, 1, a), nn(() => {
                    E.da && Ss(E.da);
                    const O = A.props && A.props.onVnodeUnmounted;
                    O && vn(O, E.parent, A), E.isDeactivated = !0
                }, a)
            };

            function m(A) {
                xc(A), f(A, n, a, !0)
            }

            function T(A) {
                i.forEach((E, O) => {
                    const P = yu(E.type);
                    P && (!A || !A(P)) && R(O)
                })
            }

            function R(A) {
                const E = i.get(A);
                !o || !Wn(E, o) ? m(E) : o && xc(o), i.delete(A), s.delete(A)
            }
            zn(() => [e.include, e.exclude], ([A, E]) => {
                A && T(O => no(A, O)), E && T(O => !no(E, O))
            }, {
                flush: "post",
                deep: !0
            });
            let B = null;
            const I = () => {
                B != null && i.set(B, Oc(n.subTree))
            };
            return is(I), Xl(I), Jl(() => {
                i.forEach(A => {
                    const {
                        subTree: E,
                        suspense: O
                    } = n, P = Oc(E);
                    if (A.type === P.type && A.key === P.key) {
                        xc(P);
                        const $ = P.component.da;
                        $ && nn($, O);
                        return
                    }
                    m(A)
                })
            }), () => {
                if (B = null, !t.default) return null;
                const A = t.default(),
                    E = A[0];
                if (A.length > 1) return o = null, A;
                if (!ci(E) || !(E.shapeFlag & 4) && !(E.shapeFlag & 128)) return o = null, E;
                let O = Oc(E);
                const P = O.type,
                    $ = yu(Li(O) ? O.type.__asyncResolved || {} : P),
                    {
                        include: H,
                        exclude: F,
                        max: V
                    } = e;
                if (H && (!$ || !no(H, $)) || F && $ && no(F, $)) return o = O, E;
                const k = O.key == null ? P : O.key,
                    Y = i.get(k);
                return O.el && (O = hr(O), E.shapeFlag & 128 && (E.ssContent = O)), B = k, Y ? (O.el = Y.el, O.component = Y.component, O.transition && Ui(O, O.transition), O.shapeFlag |= 512, s.delete(k), s.add(k)) : (s.add(k), V && s.size > parseInt(V, 10) && R(s.values().next().value)), O.shapeFlag |= 256, o = O, Fg(E.type) ? E : O
            }
        }
    },
    IC = RC;

function no(e, t) {
    return we(e) ? e.some(n => no(n, t)) : He(e) ? e.split(",").includes(t) : iT(e) ? e.test(t) : !1
}

function Gg(e, t) {
    Xg(e, "a", t)
}

function Yg(e, t) {
    Xg(e, "da", t)
}

function Xg(e, t, n = Jt) {
    const r = e.__wdc || (e.__wdc = () => {
        let i = n;
        for (; i;) {
            if (i.isDeactivated) return;
            i = i.parent
        }
        return e()
    });
    if (Yl(t, r, n), n) {
        let i = n.parent;
        for (; i && i.parent;) Ko(i.parent.vnode) && $C(r, t, n, i), i = i.parent
    }
}

function $C(e, t, n, r) {
    const i = Yl(t, e, r, !0);
    Zl(() => {
        uf(r[t], i)
    }, n)
}

function xc(e) {
    e.shapeFlag &= -257, e.shapeFlag &= -513
}

function Oc(e) {
    return e.shapeFlag & 128 ? e.ssContent : e
}

function Yl(e, t, n = Jt, r = !1) {
    if (n) {
        const i = n[e] || (n[e] = []),
            s = t.__weh || (t.__weh = (...o) => {
                if (n.isUnmounted) return;
                mi();
                const a = Ki(n),
                    l = Rn(t, n, e, o);
                return a(), gi(), l
            });
        return r ? i.unshift(s) : i.push(s), s
    }
}
const Lr = e => (t, n = Jt) => (!Go || e === "sp") && Yl(e, (...r) => t(...r), n),
    Jg = Lr("bm"),
    is = Lr("m"),
    Zg = Lr("bu"),
    Xl = Lr("u"),
    Jl = Lr("bum"),
    Zl = Lr("um"),
    Qg = Lr("sp"),
    e_ = Lr("rtg"),
    t_ = Lr("rtc");

function n_(e, t = Jt) {
    Yl("ec", e, t)
}

function Wi(e, t, n, r) {
    let i;
    const s = n && n[r];
    if (we(e) || He(e)) {
        i = new Array(e.length);
        for (let o = 0, a = e.length; o < a; o++) i[o] = t(e[o], o, void 0, s && s[o])
    } else if (typeof e == "number") {
        i = new Array(e);
        for (let o = 0; o < e; o++) i[o] = t(o + 1, o, void 0, s && s[o])
    } else if (yt(e))
        if (e[Symbol.iterator]) i = Array.from(e, (o, a) => t(o, a, void 0, s && s[a]));
        else {
            const o = Object.keys(e);
            i = new Array(o.length);
            for (let a = 0, l = o.length; a < l; a++) {
                const u = o[a];
                i[a] = t(e[u], u, a, s && s[a])
            }
        }
    else i = [];
    return n && (n[r] = i), i
}

function kC(e, t) {
    for (let n = 0; n < t.length; n++) {
        const r = t[n];
        if (we(r))
            for (let i = 0; i < r.length; i++) e[r[i].name] = r[i].fn;
        else r && (e[r.name] = r.key ? (...i) => {
            const s = r.fn(...i);
            return s && (s.key = r.key), s
        } : r.fn)
    }
    return e
}

function Mt(e, t, n = {}, r, i) {
    if (Wt.isCE || Wt.parent && Li(Wt.parent) && Wt.parent.isCE) return t !== "default" && (n.name = t), Pe("slot", n, r && r());
    let s = e[t];
    s && s._c && (s._d = !1), Q();
    const o = s && r_(s(n)),
        a = Et(nt, {
            key: n.key || o && o.key || `_${t}`
        }, o || (r ? r() : []), o && e._ === 1 ? 64 : -2);
    return !i && a.scopeId && (a.slotScopeIds = [a.scopeId + "-s"]), s && s._c && (s._d = !0), a
}

function r_(e) {
    return e.some(t => ci(t) ? !(t.type === sn || t.type === nt && !r_(t.children)) : !0) ? e : null
}

function LC(e, t) {
    const n = {};
    for (const r in e) n[t && /[A-Z]/.test(r) ? `on:${r}` : ws(r)] = e[r];
    return n
}
const lu = e => e ? A_(e) ? Ql(e) || e.proxy : lu(e.parent) : null,
    so = rt(Object.create(null), {
        $: e => e,
        $el: e => e.vnode.el,
        $data: e => e.data,
        $props: e => e.props,
        $attrs: e => e.attrs,
        $slots: e => e.slots,
        $refs: e => e.refs,
        $parent: e => lu(e.parent),
        $root: e => lu(e.root),
        $emit: e => e.emit,
        $options: e => Rf(e),
        $forceUpdate: e => e.f || (e.f = () => {
            e.effect.dirty = !0, zl(e.update)
        }),
        $nextTick: e => e.n || (e.n = Ws.bind(e.proxy)),
        $watch: e => PC.bind(e)
    }),
    Pc = (e, t) => e !== ft && !e.__isScriptSetup && ct(e, t),
    cu = {
        get({
            _: e
        }, t) {
            if (t === "__v_skip") return !0;
            const {
                ctx: n,
                setupState: r,
                data: i,
                props: s,
                accessCache: o,
                type: a,
                appContext: l
            } = e;
            let u;
            if (t[0] !== "$") {
                const m = o[t];
                if (m !== void 0) switch (m) {
                    case 1:
                        return r[t];
                    case 2:
                        return i[t];
                    case 4:
                        return n[t];
                    case 3:
                        return s[t]
                } else {
                    if (Pc(r, t)) return o[t] = 1, r[t];
                    if (i !== ft && ct(i, t)) return o[t] = 2, i[t];
                    if ((u = e.propsOptions[0]) && ct(u, t)) return o[t] = 3, s[t];
                    if (n !== ft && ct(n, t)) return o[t] = 4, n[t];
                    uu && (o[t] = 0)
                }
            }
            const f = so[t];
            let h, _;
            if (f) return t === "$attrs" && Cn(e.attrs, "get", ""), f(e);
            if ((h = a.__cssModules) && (h = h[t])) return h;
            if (n !== ft && ct(n, t)) return o[t] = 4, n[t];
            if (_ = l.config.globalProperties, ct(_, t)) return _[t]
        },
        set({
            _: e
        }, t, n) {
            const {
                data: r,
                setupState: i,
                ctx: s
            } = e;
            return Pc(i, t) ? (i[t] = n, !0) : r !== ft && ct(r, t) ? (r[t] = n, !0) : ct(e.props, t) || t[0] === "$" && t.slice(1) in e ? !1 : (s[t] = n, !0)
        },
        has({
            _: {
                data: e,
                setupState: t,
                accessCache: n,
                ctx: r,
                appContext: i,
                propsOptions: s
            }
        }, o) {
            let a;
            return !!n[o] || e !== ft && ct(e, o) || Pc(t, o) || (a = s[0]) && ct(a, o) || ct(r, o) || ct(so, o) || ct(i.config.globalProperties, o)
        },
        defineProperty(e, t, n) {
            return n.get != null ? e._.accessCache[t] = 0 : ct(n, "value") && this.set(e, t, n.value, null), Reflect.defineProperty(e, t, n)
        }
    },
    NC = rt({}, cu, {
        get(e, t) {
            if (t !== Symbol.unscopables) return cu.get(e, t, e)
        },
        has(e, t) {
            return t[0] !== "_" && !uT(t)
        }
    });

function FC() {
    return null
}

function DC() {
    return null
}

function jC(e) {}

function BC(e) {}

function VC() {
    return null
}

function HC() {}

function UC(e, t) {
    return null
}

function WC() {
    return i_().slots
}

function zC() {
    return i_().attrs
}

function i_() {
    const e = Jn();
    return e.setupContext || (e.setupContext = M_(e))
}

function xo(e) {
    return we(e) ? e.reduce((t, n) => (t[n] = null, t), {}) : e
}

function qC(e, t) {
    const n = xo(e);
    for (const r in t) {
        if (r.startsWith("__skip")) continue;
        let i = n[r];
        i ? we(i) || Re(i) ? i = n[r] = {
            type: i,
            default: t[r]
        } : i.default = t[r] : i === null && (i = n[r] = {
            default: t[r]
        }), i && t[`__skip_${r}`] && (i.skipFactory = !0)
    }
    return n
}

function KC(e, t) {
    return !e || !t ? e || t : we(e) && we(t) ? e.concat(t) : rt({}, xo(e), xo(t))
}

function GC(e, t) {
    const n = {};
    for (const r in e) t.includes(r) || Object.defineProperty(n, r, {
        enumerable: !0,
        get: () => e[r]
    });
    return n
}

function YC(e) {
    const t = Jn();
    let n = e();
    return gu(), ff(n) && (n = n.catch(r => {
        throw Ki(t), r
    })), [n, () => Ki(t)]
}
let uu = !0;

function XC(e) {
    const t = Rf(e),
        n = e.proxy,
        r = e.ctx;
    uu = !1, t.beforeCreate && kh(t.beforeCreate, e, "bc");
    const {
        data: i,
        computed: s,
        methods: o,
        watch: a,
        provide: l,
        inject: u,
        created: f,
        beforeMount: h,
        mounted: _,
        beforeUpdate: m,
        updated: T,
        activated: R,
        deactivated: B,
        beforeDestroy: I,
        beforeUnmount: A,
        destroyed: E,
        unmounted: O,
        render: P,
        renderTracked: $,
        renderTriggered: H,
        errorCaptured: F,
        serverPrefetch: V,
        expose: k,
        inheritAttrs: Y,
        components: L,
        directives: te,
        filters: ie
    } = t;
    if (u && JC(u, r, null), o)
        for (const le in o) {
            const ce = o[le];
            Re(ce) && (r[le] = ce.bind(n))
        }
    if (i) {
        const le = i.call(n, n);
        yt(le) && (e.data = li(le))
    }
    if (uu = !0, s)
        for (const le in s) {
            const ce = s[le],
                ue = Re(ce) ? ce.bind(n, n) : Re(ce.get) ? ce.get.bind(n, n) : Ut,
                Oe = !Re(ce) && Re(ce.set) ? ce.set.bind(n) : Ut,
                ke = Ht({
                    get: ue,
                    set: Oe
                });
            Object.defineProperty(r, le, {
                enumerable: !0,
                configurable: !0,
                get: () => ke.value,
                set: Ze => ke.value = Ze
            })
        }
    if (a)
        for (const le in a) s_(a[le], r, n, le);
    if (l) {
        const le = Re(l) ? l.call(n) : l;
        Reflect.ownKeys(le).forEach(ce => {
            oo(ce, le[ce])
        })
    }
    f && kh(f, e, "c");

    function X(le, ce) {
        we(ce) ? ce.forEach(ue => le(ue.bind(n))) : ce && le(ce.bind(n))
    }
    if (X(Jg, h), X(is, _), X(Zg, m), X(Xl, T), X(Gg, R), X(Yg, B), X(n_, F), X(t_, $), X(e_, H), X(Jl, A), X(Zl, O), X(Qg, V), we(k))
        if (k.length) {
            const le = e.exposed || (e.exposed = {});
            k.forEach(ce => {
                Object.defineProperty(le, ce, {
                    get: () => n[ce],
                    set: ue => n[ce] = ue
                })
            })
        } else e.exposed || (e.exposed = {});
    P && e.render === Ut && (e.render = P), Y != null && (e.inheritAttrs = Y), L && (e.components = L), te && (e.directives = te)
}

function JC(e, t, n = Ut) {
    we(e) && (e = fu(e));
    for (const r in e) {
        const i = e[r];
        let s;
        yt(i) ? "default" in i ? s = fr(i.from || r, i.default, !0) : s = fr(i.from || r) : s = fr(i), an(s) ? Object.defineProperty(t, r, {
            enumerable: !0,
            configurable: !0,
            get: () => s.value,
            set: o => s.value = o
        }) : t[r] = s
    }
}

function kh(e, t, n) {
    Rn(we(e) ? e.map(r => r.bind(t.proxy)) : e.bind(t.proxy), t, n)
}

function s_(e, t, n, r) {
    const i = r.includes(".") ? Wg(n, r) : () => n[r];
    if (He(e)) {
        const s = t[e];
        Re(s) && zn(i, s)
    } else if (Re(e)) zn(i, e.bind(n));
    else if (yt(e))
        if (we(e)) e.forEach(s => s_(s, t, n, r));
        else {
            const s = Re(e.handler) ? e.handler.bind(n) : t[e.handler];
            Re(s) && zn(i, s, e)
        }
}

function Rf(e) {
    const t = e.type,
        {
            mixins: n,
            extends: r
        } = t,
        {
            mixins: i,
            optionsCache: s,
            config: {
                optionMergeStrategies: o
            }
        } = e.appContext,
        a = s.get(t);
    let l;
    return a ? l = a : !i.length && !n && !r ? l = t : (l = {}, i.length && i.forEach(u => ul(l, u, o, !0)), ul(l, t, o)), yt(t) && s.set(t, l), l
}

function ul(e, t, n, r = !1) {
    const {
        mixins: i,
        extends: s
    } = t;
    s && ul(e, s, n, !0), i && i.forEach(o => ul(e, o, n, !0));
    for (const o in t)
        if (!(r && o === "expose")) {
            const a = ZC[o] || n && n[o];
            e[o] = a ? a(e[o], t[o]) : t[o]
        }
    return e
}
const ZC = {
    data: Lh,
    props: Nh,
    emits: Nh,
    methods: ro,
    computed: ro,
    beforeCreate: hn,
    created: hn,
    beforeMount: hn,
    mounted: hn,
    beforeUpdate: hn,
    updated: hn,
    beforeDestroy: hn,
    beforeUnmount: hn,
    destroyed: hn,
    unmounted: hn,
    activated: hn,
    deactivated: hn,
    errorCaptured: hn,
    serverPrefetch: hn,
    components: ro,
    directives: ro,
    watch: eE,
    provide: Lh,
    inject: QC
};

function Lh(e, t) {
    return t ? e ? function() {
        return rt(Re(e) ? e.call(this, this) : e, Re(t) ? t.call(this, this) : t)
    } : t : e
}

function QC(e, t) {
    return ro(fu(e), fu(t))
}

function fu(e) {
    if (we(e)) {
        const t = {};
        for (let n = 0; n < e.length; n++) t[e[n]] = e[n];
        return t
    }
    return e
}

function hn(e, t) {
    return e ? [...new Set([].concat(e, t))] : t
}

function ro(e, t) {
    return e ? rt(Object.create(null), e, t) : t
}

function Nh(e, t) {
    return e ? we(e) && we(t) ? [...new Set([...e, ...t])] : rt(Object.create(null), xo(e), xo(t ? ? {})) : t
}

function eE(e, t) {
    if (!e) return t;
    if (!t) return e;
    const n = rt(Object.create(null), e);
    for (const r in t) n[r] = hn(e[r], t[r]);
    return n
}

function o_() {
    return {
        app: null,
        config: {
            isNativeTag: Ba,
            performance: !1,
            globalProperties: {},
            optionMergeStrategies: {},
            errorHandler: void 0,
            warnHandler: void 0,
            compilerOptions: {}
        },
        mixins: [],
        components: {},
        directives: {},
        provides: Object.create(null),
        optionsCache: new WeakMap,
        propsCache: new WeakMap,
        emitsCache: new WeakMap
    }
}
let tE = 0;

function nE(e, t) {
    return function(r, i = null) {
        Re(r) || (r = rt({}, r)), i != null && !yt(i) && (i = null);
        const s = o_(),
            o = new WeakSet;
        let a = !1;
        const l = s.app = {
            _uid: tE++,
            _component: r,
            _props: i,
            _container: null,
            _context: s,
            _instance: null,
            version: I_,
            get config() {
                return s.config
            },
            set config(u) {},
            use(u, ...f) {
                return o.has(u) || (u && Re(u.install) ? (o.add(u), u.install(l, ...f)) : Re(u) && (o.add(u), u(l, ...f))), l
            },
            mixin(u) {
                return s.mixins.includes(u) || s.mixins.push(u), l
            },
            component(u, f) {
                return f ? (s.components[u] = f, l) : s.components[u]
            },
            directive(u, f) {
                return f ? (s.directives[u] = f, l) : s.directives[u]
            },
            mount(u, f, h) {
                if (!a) {
                    const _ = Pe(r, i);
                    return _.appContext = s, h === !0 ? h = "svg" : h === !1 && (h = void 0), f && t ? t(_, u) : e(_, u, h), a = !0, l._container = u, u.__vue_app__ = l, Ql(_.component) || _.component.proxy
                }
            },
            unmount() {
                a && (e(null, l._container), delete l._container.__vue_app__)
            },
            provide(u, f) {
                return s.provides[u] = f, l
            },
            runWithContext(u) {
                const f = xs;
                xs = l;
                try {
                    return u()
                } finally {
                    xs = f
                }
            }
        };
        return l
    }
}
let xs = null;

function oo(e, t) {
    if (Jt) {
        let n = Jt.provides;
        const r = Jt.parent && Jt.parent.provides;
        r === n && (n = Jt.provides = Object.create(r)), n[e] = t
    }
}

function fr(e, t, n = !1) {
    const r = Jt || Wt;
    if (r || xs) {
        const i = r ? r.parent == null ? r.vnode.appContext && r.vnode.appContext.provides : r.parent.provides : xs._context.provides;
        if (i && e in i) return i[e];
        if (arguments.length > 1) return n && Re(t) ? t.call(r && r.proxy) : t
    }
}

function rE() {
    return !!(Jt || Wt || xs)
}
const a_ = {},
    l_ = () => Object.create(a_),
    c_ = e => Object.getPrototypeOf(e) === a_;

function iE(e, t, n, r = !1) {
    const i = {},
        s = l_();
    e.propsDefaults = Object.create(null), u_(e, t, i, s);
    for (const o in e.propsOptions[0]) o in i || (i[o] = void 0);
    n ? e.props = r ? i : vf(i) : e.type.props ? e.props = i : e.props = s, e.attrs = s
}

function sE(e, t, n, r) {
    const {
        props: i,
        attrs: s,
        vnode: {
            patchFlag: o
        }
    } = e, a = it(i), [l] = e.propsOptions;
    let u = !1;
    if ((r || o > 0) && !(o & 16)) {
        if (o & 8) {
            const f = e.vnode.dynamicProps;
            for (let h = 0; h < f.length; h++) {
                let _ = f[h];
                if (ql(e.emitsOptions, _)) continue;
                const m = t[_];
                if (l)
                    if (ct(s, _)) m !== s[_] && (s[_] = m, u = !0);
                    else {
                        const T = kt(_);
                        i[T] = du(l, a, T, m, e, !1)
                    }
                else m !== s[_] && (s[_] = m, u = !0)
            }
        }
    } else {
        u_(e, t, i, s) && (u = !0);
        let f;
        for (const h in a)(!t || !ct(t, h) && ((f = Pn(h)) === h || !ct(t, f))) && (l ? n && (n[h] !== void 0 || n[f] !== void 0) && (i[h] = du(l, a, h, void 0, e, !0)) : delete i[h]);
        if (s !== a)
            for (const h in s)(!t || !ct(t, h)) && (delete s[h], u = !0)
    }
    u && Er(e.attrs, "set", "")
}

function u_(e, t, n, r) {
    const [i, s] = e.propsOptions;
    let o = !1,
        a;
    if (t)
        for (let l in t) {
            if (ti(l)) continue;
            const u = t[l];
            let f;
            i && ct(i, f = kt(l)) ? !s || !s.includes(f) ? n[f] = u : (a || (a = {}))[f] = u : ql(e.emitsOptions, l) || (!(l in r) || u !== r[l]) && (r[l] = u, o = !0)
        }
    if (s) {
        const l = it(n),
            u = a || ft;
        for (let f = 0; f < s.length; f++) {
            const h = s[f];
            n[h] = du(i, l, h, u[h], e, !ct(u, h))
        }
    }
    return o
}

function du(e, t, n, r, i, s) {
    const o = e[n];
    if (o != null) {
        const a = ct(o, "default");
        if (a && r === void 0) {
            const l = o.default;
            if (o.type !== Function && !o.skipFactory && Re(l)) {
                const {
                    propsDefaults: u
                } = i;
                if (n in u) r = u[n];
                else {
                    const f = Ki(i);
                    r = u[n] = l.call(null, t), f()
                }
            } else r = l
        }
        o[0] && (s && !a ? r = !1 : o[1] && (r === "" || r === Pn(n)) && (r = !0))
    }
    return r
}

function f_(e, t, n = !1) {
    const r = t.propsCache,
        i = r.get(e);
    if (i) return i;
    const s = e.props,
        o = {},
        a = [];
    let l = !1;
    if (!Re(e)) {
        const f = h => {
            l = !0;
            const [_, m] = f_(h, t, !0);
            rt(o, _), m && a.push(...m)
        };
        !n && t.mixins.length && t.mixins.forEach(f), e.extends && f(e.extends), e.mixins && e.mixins.forEach(f)
    }
    if (!s && !l) return yt(e) && r.set(e, ys), ys;
    if (we(s))
        for (let f = 0; f < s.length; f++) {
            const h = kt(s[f]);
            Fh(h) && (o[h] = ft)
        } else if (s)
            for (const f in s) {
                const h = kt(f);
                if (Fh(h)) {
                    const _ = s[f],
                        m = o[h] = we(_) || Re(_) ? {
                            type: _
                        } : rt({}, _);
                    if (m) {
                        const T = Bh(Boolean, m.type),
                            R = Bh(String, m.type);
                        m[0] = T > -1, m[1] = R < 0 || T < R, (T > -1 || ct(m, "default")) && a.push(h)
                    }
                }
            }
    const u = [o, a];
    return yt(e) && r.set(e, u), u
}

function Fh(e) {
    return e[0] !== "$" && !ti(e)
}

function Dh(e) {
    return e === null ? "null" : typeof e == "function" ? e.name || "" : typeof e == "object" && e.constructor && e.constructor.name || ""
}

function jh(e, t) {
    return Dh(e) === Dh(t)
}

function Bh(e, t) {
    return we(t) ? t.findIndex(n => jh(n, e)) : Re(t) && jh(t, e) ? 0 : -1
}
const d_ = e => e[0] === "_" || e === "$stable",
    If = e => we(e) ? e.map(On) : [On(e)],
    oE = (e, t, n) => {
        if (t._n) return t;
        const r = Ct((...i) => If(t(...i)), n);
        return r._c = !1, r
    },
    h_ = (e, t, n) => {
        const r = e._ctx;
        for (const i in e) {
            if (d_(i)) continue;
            const s = e[i];
            if (Re(s)) t[i] = oE(i, s, r);
            else if (s != null) {
                const o = If(s);
                t[i] = () => o
            }
        }
    },
    p_ = (e, t) => {
        const n = If(t);
        e.slots.default = () => n
    },
    aE = (e, t) => {
        const n = e.slots = l_();
        if (e.vnode.shapeFlag & 32) {
            const r = t._;
            r ? (rt(n, t), ig(n, "_", r, !0)) : h_(t, n)
        } else t && p_(e, t)
    },
    lE = (e, t, n) => {
        const {
            vnode: r,
            slots: i
        } = e;
        let s = !0,
            o = ft;
        if (r.shapeFlag & 32) {
            const a = t._;
            a ? n && a === 1 ? s = !1 : (rt(i, t), !n && a === 1 && delete i._) : (s = !t.$stable, h_(t, i)), o = t
        } else t && (p_(e, t), o = {
            default: 1
        });
        if (s)
            for (const a in i) !d_(a) && o[a] == null && delete i[a]
    };

function fl(e, t, n, r, i = !1) {
    if (we(e)) {
        e.forEach((_, m) => fl(_, t && (we(t) ? t[m] : t), n, r, i));
        return
    }
    if (Li(r) && !i) return;
    const s = r.shapeFlag & 4 ? Ql(r.component) || r.component.proxy : r.el,
        o = i ? null : s,
        {
            i: a,
            r: l
        } = e,
        u = t && t.r,
        f = a.refs === ft ? a.refs = {} : a.refs,
        h = a.setupState;
    if (u != null && u !== l && (He(u) ? (f[u] = null, ct(h, u) && (h[u] = null)) : an(u) && (u.value = null)), Re(l)) xr(l, a, 12, [o, f]);
    else {
        const _ = He(l),
            m = an(l);
        if (_ || m) {
            const T = () => {
                if (e.f) {
                    const R = _ ? ct(h, l) ? h[l] : f[l] : l.value;
                    i ? we(R) && uf(R, s) : we(R) ? R.includes(s) || R.push(s) : _ ? (f[l] = [s], ct(h, l) && (h[l] = f[l])) : (l.value = [s], e.k && (f[e.k] = l.value))
                } else _ ? (f[l] = o, ct(h, l) && (h[l] = o)) : m && (l.value = o, e.k && (f[e.k] = o))
            };
            o ? (T.id = -1, nn(T, n)) : T()
        }
    }
}
let jr = !1;
const cE = e => e.namespaceURI.includes("svg") && e.tagName !== "foreignObject",
    uE = e => e.namespaceURI.includes("MathML"),
    Aa = e => {
        if (cE(e)) return "svg";
        if (uE(e)) return "mathml"
    },
    xa = e => e.nodeType === 8;

function fE(e) {
    const {
        mt: t,
        p: n,
        o: {
            patchProp: r,
            createText: i,
            nextSibling: s,
            parentNode: o,
            remove: a,
            insert: l,
            createComment: u
        }
    } = e, f = (E, O) => {
        if (!O.hasChildNodes()) {
            n(null, E, O), cl(), O._vnode = E;
            return
        }
        jr = !1, h(O.firstChild, E, null, null, null), cl(), O._vnode = E, jr && console.error("Hydration completed but contains mismatches.")
    }, h = (E, O, P, $, H, F = !1) => {
        F = F || !!O.dynamicChildren;
        const V = xa(E) && E.data === "[",
            k = () => R(E, O, P, $, H, V),
            {
                type: Y,
                ref: L,
                shapeFlag: te,
                patchFlag: ie
            } = O;
        let _e = E.nodeType;
        O.el = E, ie === -2 && (F = !1, O.dynamicChildren = null);
        let X = null;
        switch (Y) {
            case zi:
                _e !== 3 ? O.children === "" ? (l(O.el = i(""), o(E), E), X = E) : X = k() : (E.data !== O.children && (jr = !0, E.data = O.children), X = s(E));
                break;
            case sn:
                A(E) ? (X = s(E), I(O.el = E.content.firstChild, E, P)) : _e !== 8 || V ? X = k() : X = s(E);
                break;
            case Ni:
                if (V && (E = s(E), _e = E.nodeType), _e === 1 || _e === 3) {
                    X = E;
                    const le = !O.children.length;
                    for (let ce = 0; ce < O.staticCount; ce++) le && (O.children += X.nodeType === 1 ? X.outerHTML : X.data), ce === O.staticCount - 1 && (O.anchor = X), X = s(X);
                    return V ? s(X) : X
                } else k();
                break;
            case nt:
                V ? X = T(E, O, P, $, H, F) : X = k();
                break;
            default:
                if (te & 1)(_e !== 1 || O.type.toLowerCase() !== E.tagName.toLowerCase()) && !A(E) ? X = k() : X = _(E, O, P, $, H, F);
                else if (te & 6) {
                    O.slotScopeIds = H;
                    const le = o(E);
                    if (V ? X = B(E) : xa(E) && E.data === "teleport start" ? X = B(E, E.data, "teleport end") : X = s(E), t(O, le, null, P, $, Aa(le), F), Li(O)) {
                        let ce;
                        V ? (ce = Pe(nt), ce.anchor = X ? X.previousSibling : le.lastChild) : ce = E.nodeType === 3 ? Pr("") : Pe("div"), ce.el = E, O.component.subTree = ce
                    }
                } else te & 64 ? _e !== 8 ? X = k() : X = O.type.hydrate(E, O, P, $, H, F, e, m) : te & 128 && (X = O.type.hydrate(E, O, P, $, Aa(o(E)), H, F, e, h))
        }
        return L != null && fl(L, null, $, O), X
    }, _ = (E, O, P, $, H, F) => {
        F = F || !!O.dynamicChildren;
        const {
            type: V,
            props: k,
            patchFlag: Y,
            shapeFlag: L,
            dirs: te,
            transition: ie
        } = O, _e = V === "input" || V === "option";
        if (_e || Y !== -1) {
            te && or(O, null, P, "created");
            let X = !1;
            if (A(E)) {
                X = v_($, ie) && P && P.vnode.props && P.vnode.props.appear;
                const ce = E.content.firstChild;
                X && ie.beforeEnter(ce), I(ce, E, P), O.el = E = ce
            }
            if (L & 16 && !(k && (k.innerHTML || k.textContent))) {
                let ce = m(E.firstChild, O, E, P, $, H, F);
                for (; ce;) {
                    jr = !0;
                    const ue = ce;
                    ce = ce.nextSibling, a(ue)
                }
            } else L & 8 && E.textContent !== O.children && (jr = !0, E.textContent = O.children);
            if (k)
                if (_e || !F || Y & 48)
                    for (const ce in k)(_e && (ce.endsWith("value") || ce === "indeterminate") || Qi(ce) && !ti(ce) || ce[0] === ".") && r(E, ce, null, k[ce], void 0, void 0, P);
                else k.onClick && r(E, "onClick", null, k.onClick, void 0, void 0, P);
            let le;
            (le = k && k.onVnodeBeforeMount) && vn(le, P, O), te && or(O, null, P, "beforeMount"), ((le = k && k.onVnodeMounted) || te || X) && jg(() => {
                le && vn(le, P, O), X && ie.enter(E), te && or(O, null, P, "mounted")
            }, $)
        }
        return E.nextSibling
    }, m = (E, O, P, $, H, F, V) => {
        V = V || !!O.dynamicChildren;
        const k = O.children,
            Y = k.length;
        for (let L = 0; L < Y; L++) {
            const te = V ? k[L] : k[L] = On(k[L]);
            if (E) E = h(E, te, $, H, F, V);
            else {
                if (te.type === zi && !te.children) continue;
                jr = !0, n(null, te, P, null, $, H, Aa(P), F)
            }
        }
        return E
    }, T = (E, O, P, $, H, F) => {
        const {
            slotScopeIds: V
        } = O;
        V && (H = H ? H.concat(V) : V);
        const k = o(E),
            Y = m(s(E), O, k, P, $, H, F);
        return Y && xa(Y) && Y.data === "]" ? s(O.anchor = Y) : (jr = !0, l(O.anchor = u("]"), k, Y), Y)
    }, R = (E, O, P, $, H, F) => {
        if (jr = !0, O.el = null, F) {
            const Y = B(E);
            for (;;) {
                const L = s(E);
                if (L && L !== Y) a(L);
                else break
            }
        }
        const V = s(E),
            k = o(E);
        return a(E), n(null, O, k, V, P, $, Aa(k), H), V
    }, B = (E, O = "[", P = "]") => {
        let $ = 0;
        for (; E;)
            if (E = s(E), E && xa(E) && (E.data === O && $++, E.data === P)) {
                if ($ === 0) return s(E);
                $--
            }
        return E
    }, I = (E, O, P) => {
        const $ = O.parentNode;
        $ && $.replaceChild(E, O);
        let H = P;
        for (; H;) H.vnode.el === O && (H.vnode.el = H.subTree.el = E), H = H.parent
    }, A = E => E.nodeType === 1 && E.tagName.toLowerCase() === "template";
    return [f, h]
}
const nn = jg;

function m_(e) {
    return __(e)
}

function g_(e) {
    return __(e, fE)
}

function __(e, t) {
    const n = sg();
    n.__VUE__ = !0;
    const {
        insert: r,
        remove: i,
        patchProp: s,
        createElement: o,
        createText: a,
        createComment: l,
        setText: u,
        setElementText: f,
        parentNode: h,
        nextSibling: _,
        setScopeId: m = Ut,
        insertStaticContent: T
    } = e, R = (S, C, U, K = null, z = null, ae = null, me = void 0, re = null, v = !!C.dynamicChildren) => {
        if (S === C) return;
        S && !Wn(S, C) && (K = W(S), Ze(S, z, ae, !0), S = null), C.patchFlag === -2 && (v = !1, C.dynamicChildren = null);
        const {
            type: c,
            ref: d,
            shapeFlag: b
        } = C;
        switch (c) {
            case zi:
                B(S, C, U, K);
                break;
            case sn:
                I(S, C, U, K);
                break;
            case Ni:
                S == null && A(C, U, K, me);
                break;
            case nt:
                L(S, C, U, K, z, ae, me, re, v);
                break;
            default:
                b & 1 ? P(S, C, U, K, z, ae, me, re, v) : b & 6 ? te(S, C, U, K, z, ae, me, re, v) : (b & 64 || b & 128) && c.process(S, C, U, K, z, ae, me, re, v, ye)
        }
        d != null && z && fl(d, S && S.ref, ae, C || S, !C)
    }, B = (S, C, U, K) => {
        if (S == null) r(C.el = a(C.children), U, K);
        else {
            const z = C.el = S.el;
            C.children !== S.children && u(z, C.children)
        }
    }, I = (S, C, U, K) => {
        S == null ? r(C.el = l(C.children || ""), U, K) : C.el = S.el
    }, A = (S, C, U, K) => {
        [S.el, S.anchor] = T(S.children, C, U, K, S.el, S.anchor)
    }, E = ({
        el: S,
        anchor: C
    }, U, K) => {
        let z;
        for (; S && S !== C;) z = _(S), r(S, U, K), S = z;
        r(C, U, K)
    }, O = ({
        el: S,
        anchor: C
    }) => {
        let U;
        for (; S && S !== C;) U = _(S), i(S), S = U;
        i(C)
    }, P = (S, C, U, K, z, ae, me, re, v) => {
        C.type === "svg" ? me = "svg" : C.type === "math" && (me = "mathml"), S == null ? $(C, U, K, z, ae, me, re, v) : V(S, C, z, ae, me, re, v)
    }, $ = (S, C, U, K, z, ae, me, re) => {
        let v, c;
        const {
            props: d,
            shapeFlag: b,
            transition: x,
            dirs: j
        } = S;
        if (v = S.el = o(S.type, ae, d && d.is, d), b & 8 ? f(v, S.children) : b & 16 && F(S.children, v, null, K, z, Mc(S, ae), me, re), j && or(S, null, K, "created"), H(v, S, S.scopeId, me, K), d) {
            for (const oe in d) oe !== "value" && !ti(oe) && s(v, oe, null, d[oe], ae, S.children, K, z, Ne);
            "value" in d && s(v, "value", null, d.value, ae), (c = d.onVnodeBeforeMount) && vn(c, K, S)
        }
        j && or(S, null, K, "beforeMount");
        const q = v_(z, x);
        q && x.beforeEnter(v), r(v, C, U), ((c = d && d.onVnodeMounted) || q || j) && nn(() => {
            c && vn(c, K, S), q && x.enter(v), j && or(S, null, K, "mounted")
        }, z)
    }, H = (S, C, U, K, z) => {
        if (U && m(S, U), K)
            for (let ae = 0; ae < K.length; ae++) m(S, K[ae]);
        if (z) {
            let ae = z.subTree;
            if (C === ae) {
                const me = z.vnode;
                H(S, me, me.scopeId, me.slotScopeIds, z.parent)
            }
        }
    }, F = (S, C, U, K, z, ae, me, re, v = 0) => {
        for (let c = v; c < S.length; c++) {
            const d = S[c] = re ? Yr(S[c]) : On(S[c]);
            R(null, d, C, U, K, z, ae, me, re)
        }
    }, V = (S, C, U, K, z, ae, me) => {
        const re = C.el = S.el;
        let {
            patchFlag: v,
            dynamicChildren: c,
            dirs: d
        } = C;
        v |= S.patchFlag & 16;
        const b = S.props || ft,
            x = C.props || ft;
        let j;
        if (U && bi(U, !1), (j = x.onVnodeBeforeUpdate) && vn(j, U, C, S), d && or(C, S, U, "beforeUpdate"), U && bi(U, !0), c ? k(S.dynamicChildren, c, re, U, K, Mc(C, z), ae) : me || ce(S, C, re, null, U, K, Mc(C, z), ae, !1), v > 0) {
            if (v & 16) Y(re, C, b, x, U, K, z);
            else if (v & 2 && b.class !== x.class && s(re, "class", null, x.class, z), v & 4 && s(re, "style", b.style, x.style, z), v & 8) {
                const q = C.dynamicProps;
                for (let oe = 0; oe < q.length; oe++) {
                    const ne = q[oe],
                        de = b[ne],
                        Ae = x[ne];
                    (Ae !== de || ne === "value") && s(re, ne, de, Ae, z, S.children, U, K, Ne)
                }
            }
            v & 1 && S.children !== C.children && f(re, C.children)
        } else !me && c == null && Y(re, C, b, x, U, K, z);
        ((j = x.onVnodeUpdated) || d) && nn(() => {
            j && vn(j, U, C, S), d && or(C, S, U, "updated")
        }, K)
    }, k = (S, C, U, K, z, ae, me) => {
        for (let re = 0; re < C.length; re++) {
            const v = S[re],
                c = C[re],
                d = v.el && (v.type === nt || !Wn(v, c) || v.shapeFlag & 70) ? h(v.el) : U;
            R(v, c, d, null, K, z, ae, me, !0)
        }
    }, Y = (S, C, U, K, z, ae, me) => {
        if (U !== K) {
            if (U !== ft)
                for (const re in U) !ti(re) && !(re in K) && s(S, re, U[re], null, me, C.children, z, ae, Ne);
            for (const re in K) {
                if (ti(re)) continue;
                const v = K[re],
                    c = U[re];
                v !== c && re !== "value" && s(S, re, c, v, me, C.children, z, ae, Ne)
            }
            "value" in K && s(S, "value", U.value, K.value, me)
        }
    }, L = (S, C, U, K, z, ae, me, re, v) => {
        const c = C.el = S ? S.el : a(""),
            d = C.anchor = S ? S.anchor : a("");
        let {
            patchFlag: b,
            dynamicChildren: x,
            slotScopeIds: j
        } = C;
        j && (re = re ? re.concat(j) : j), S == null ? (r(c, U, K), r(d, U, K), F(C.children || [], U, d, z, ae, me, re, v)) : b > 0 && b & 64 && x && S.dynamicChildren ? (k(S.dynamicChildren, x, U, z, ae, me, re), (C.key != null || z && C === z.subTree) && $f(S, C, !0)) : ce(S, C, U, d, z, ae, me, re, v)
    }, te = (S, C, U, K, z, ae, me, re, v) => {
        C.slotScopeIds = re, S == null ? C.shapeFlag & 512 ? z.ctx.activate(C, U, K, me, v) : ie(C, U, K, z, ae, me, v) : _e(S, C, v)
    }, ie = (S, C, U, K, z, ae, me) => {
        const re = S.component = E_(S, K, z);
        if (Ko(S) && (re.ctx.renderer = ye), x_(re), re.asyncDep) {
            if (z && z.registerDep(re, X), !S.el) {
                const v = re.subTree = Pe(sn);
                I(null, v, C, U)
            }
        } else X(re, S, C, U, z, ae, me)
    }, _e = (S, C, U) => {
        const K = C.component = S.component;
        if (bC(S, C, U))
            if (K.asyncDep && !K.asyncResolved) {
                le(K, C, U);
                return
            } else K.next = C, fC(K.update), K.effect.dirty = !0, K.update();
        else C.el = S.el, K.vnode = C
    }, X = (S, C, U, K, z, ae, me) => {
        const re = () => {
                if (S.isMounted) {
                    let {
                        next: d,
                        bu: b,
                        u: x,
                        parent: j,
                        vnode: q
                    } = S; {
                        const Ge = y_(S);
                        if (Ge) {
                            d && (d.el = q.el, le(S, d, me)), Ge.asyncDep.then(() => {
                                S.isUnmounted || re()
                            });
                            return
                        }
                    }
                    let oe = d,
                        ne;
                    bi(S, !1), d ? (d.el = q.el, le(S, d, me)) : d = q, b && Ss(b), (ne = d.props && d.props.onVnodeBeforeUpdate) && vn(ne, j, d, q), bi(S, !0);
                    const de = Va(S),
                        Ae = S.subTree;
                    S.subTree = de, R(Ae, de, h(Ae.el), W(Ae), S, z, ae), d.el = de.el, oe === null && Ef(S, de.el), x && nn(x, z), (ne = d.props && d.props.onVnodeUpdated) && nn(() => vn(ne, j, d, q), z)
                } else {
                    let d;
                    const {
                        el: b,
                        props: x
                    } = C, {
                        bm: j,
                        m: q,
                        parent: oe
                    } = S, ne = Li(C);
                    if (bi(S, !1), j && Ss(j), !ne && (d = x && x.onVnodeBeforeMount) && vn(d, oe, C), bi(S, !0), b && Be) {
                        const de = () => {
                            S.subTree = Va(S), Be(b, S.subTree, S, z, null)
                        };
                        ne ? C.type.__asyncLoader().then(() => !S.isUnmounted && de()) : de()
                    } else {
                        const de = S.subTree = Va(S);
                        R(null, de, U, K, S, z, ae), C.el = de.el
                    }
                    if (q && nn(q, z), !ne && (d = x && x.onVnodeMounted)) {
                        const de = C;
                        nn(() => vn(d, oe, de), z)
                    }(C.shapeFlag & 256 || oe && Li(oe.vnode) && oe.vnode.shapeFlag & 256) && S.a && nn(S.a, z), S.isMounted = !0, C = U = K = null
                }
            },
            v = S.effect = new Ms(re, Ut, () => zl(c), S.scope),
            c = S.update = () => {
                v.dirty && v.run()
            };
        c.id = S.uid, bi(S, !0), c()
    }, le = (S, C, U) => {
        C.component = S;
        const K = S.vnode.props;
        S.vnode = C, S.next = null, sE(S, C.props, K, U), lE(S, C.children, U), mi(), Ph(S), gi()
    }, ce = (S, C, U, K, z, ae, me, re, v = !1) => {
        const c = S && S.children,
            d = S ? S.shapeFlag : 0,
            b = C.children,
            {
                patchFlag: x,
                shapeFlag: j
            } = C;
        if (x > 0) {
            if (x & 128) {
                Oe(c, b, U, K, z, ae, me, re, v);
                return
            } else if (x & 256) {
                ue(c, b, U, K, z, ae, me, re, v);
                return
            }
        }
        j & 8 ? (d & 16 && Ne(c, z, ae), b !== c && f(U, b)) : d & 16 ? j & 16 ? Oe(c, b, U, K, z, ae, me, re, v) : Ne(c, z, ae, !0) : (d & 8 && f(U, ""), j & 16 && F(b, U, K, z, ae, me, re, v))
    }, ue = (S, C, U, K, z, ae, me, re, v) => {
        S = S || ys, C = C || ys;
        const c = S.length,
            d = C.length,
            b = Math.min(c, d);
        let x;
        for (x = 0; x < b; x++) {
            const j = C[x] = v ? Yr(C[x]) : On(C[x]);
            R(S[x], j, U, null, z, ae, me, re, v)
        }
        c > d ? Ne(S, z, ae, !0, !1, b) : F(C, U, K, z, ae, me, re, v, b)
    }, Oe = (S, C, U, K, z, ae, me, re, v) => {
        let c = 0;
        const d = C.length;
        let b = S.length - 1,
            x = d - 1;
        for (; c <= b && c <= x;) {
            const j = S[c],
                q = C[c] = v ? Yr(C[c]) : On(C[c]);
            if (Wn(j, q)) R(j, q, U, null, z, ae, me, re, v);
            else break;
            c++
        }
        for (; c <= b && c <= x;) {
            const j = S[b],
                q = C[x] = v ? Yr(C[x]) : On(C[x]);
            if (Wn(j, q)) R(j, q, U, null, z, ae, me, re, v);
            else break;
            b--, x--
        }
        if (c > b) {
            if (c <= x) {
                const j = x + 1,
                    q = j < d ? C[j].el : K;
                for (; c <= x;) R(null, C[c] = v ? Yr(C[c]) : On(C[c]), U, q, z, ae, me, re, v), c++
            }
        } else if (c > x)
            for (; c <= b;) Ze(S[c], z, ae, !0), c++;
        else {
            const j = c,
                q = c,
                oe = new Map;
            for (c = q; c <= x; c++) {
                const xe = C[c] = v ? Yr(C[c]) : On(C[c]);
                xe.key != null && oe.set(xe.key, c)
            }
            let ne, de = 0;
            const Ae = x - q + 1;
            let Ge = !1,
                st = 0;
            const Qe = new Array(Ae);
            for (c = 0; c < Ae; c++) Qe[c] = 0;
            for (c = j; c <= b; c++) {
                const xe = S[c];
                if (de >= Ae) {
                    Ze(xe, z, ae, !0);
                    continue
                }
                let De;
                if (xe.key != null) De = oe.get(xe.key);
                else
                    for (ne = q; ne <= x; ne++)
                        if (Qe[ne - q] === 0 && Wn(xe, C[ne])) {
                            De = ne;
                            break
                        }
                De === void 0 ? Ze(xe, z, ae, !0) : (Qe[De - q] = c + 1, De >= st ? st = De : Ge = !0, R(xe, C[De], U, null, z, ae, me, re, v), de++)
            }
            const ze = Ge ? dE(Qe) : ys;
            for (ne = ze.length - 1, c = Ae - 1; c >= 0; c--) {
                const xe = q + c,
                    De = C[xe],
                    Dt = xe + 1 < d ? C[xe + 1].el : K;
                Qe[c] === 0 ? R(null, De, U, Dt, z, ae, me, re, v) : Ge && (ne < 0 || c !== ze[ne] ? ke(De, U, Dt, 2) : ne--)
            }
        }
    }, ke = (S, C, U, K, z = null) => {
        const {
            el: ae,
            type: me,
            transition: re,
            children: v,
            shapeFlag: c
        } = S;
        if (c & 6) {
            ke(S.component.subTree, C, U, K);
            return
        }
        if (c & 128) {
            S.suspense.move(C, U, K);
            return
        }
        if (c & 64) {
            me.move(S, C, U, ye);
            return
        }
        if (me === nt) {
            r(ae, C, U);
            for (let b = 0; b < v.length; b++) ke(v[b], C, U, K);
            r(S.anchor, C, U);
            return
        }
        if (me === Ni) {
            E(S, C, U);
            return
        }
        if (K !== 2 && c & 1 && re)
            if (K === 0) re.beforeEnter(ae), r(ae, C, U), nn(() => re.enter(ae), z);
            else {
                const {
                    leave: b,
                    delayLeave: x,
                    afterLeave: j
                } = re, q = () => r(ae, C, U), oe = () => {
                    b(ae, () => {
                        q(), j && j()
                    })
                };
                x ? x(ae, q, oe) : oe()
            }
        else r(ae, C, U)
    }, Ze = (S, C, U, K = !1, z = !1) => {
        const {
            type: ae,
            props: me,
            ref: re,
            children: v,
            dynamicChildren: c,
            shapeFlag: d,
            patchFlag: b,
            dirs: x
        } = S;
        if (re != null && fl(re, null, U, S, !0), d & 256) {
            C.ctx.deactivate(S);
            return
        }
        const j = d & 1 && x,
            q = !Li(S);
        let oe;
        if (q && (oe = me && me.onVnodeBeforeUnmount) && vn(oe, C, S), d & 6) Le(S.component, U, K);
        else {
            if (d & 128) {
                S.suspense.unmount(U, K);
                return
            }
            j && or(S, null, C, "beforeUnmount"), d & 64 ? S.type.remove(S, C, U, z, ye, K) : c && (ae !== nt || b > 0 && b & 64) ? Ne(c, C, U, !1, !0) : (ae === nt && b & 384 || !z && d & 16) && Ne(v, C, U), K && Fe(S)
        }(q && (oe = me && me.onVnodeUnmounted) || j) && nn(() => {
            oe && vn(oe, C, S), j && or(S, null, C, "unmounted")
        }, U)
    }, Fe = S => {
        const {
            type: C,
            el: U,
            anchor: K,
            transition: z
        } = S;
        if (C === nt) {
            Ie(U, K);
            return
        }
        if (C === Ni) {
            O(S);
            return
        }
        const ae = () => {
            i(U), z && !z.persisted && z.afterLeave && z.afterLeave()
        };
        if (S.shapeFlag & 1 && z && !z.persisted) {
            const {
                leave: me,
                delayLeave: re
            } = z, v = () => me(U, ae);
            re ? re(S.el, ae, v) : v()
        } else ae()
    }, Ie = (S, C) => {
        let U;
        for (; S !== C;) U = _(S), i(S), S = U;
        i(C)
    }, Le = (S, C, U) => {
        const {
            bum: K,
            scope: z,
            update: ae,
            subTree: me,
            um: re
        } = S;
        K && Ss(K), z.stop(), ae && (ae.active = !1, Ze(me, S, C, U)), re && nn(re, C), nn(() => {
            S.isUnmounted = !0
        }, C), C && C.pendingBranch && !C.isUnmounted && S.asyncDep && !S.asyncResolved && S.suspenseId === C.pendingId && (C.deps--, C.deps === 0 && C.resolve())
    }, Ne = (S, C, U, K = !1, z = !1, ae = 0) => {
        for (let me = ae; me < S.length; me++) Ze(S[me], C, U, K, z)
    }, W = S => S.shapeFlag & 6 ? W(S.component.subTree) : S.shapeFlag & 128 ? S.suspense.next() : _(S.anchor || S.el);
    let ge = !1;
    const fe = (S, C, U) => {
            S == null ? C._vnode && Ze(C._vnode, null, null, !0) : R(C._vnode || null, S, C, null, null, null, U), ge || (ge = !0, Ph(), cl(), ge = !1), C._vnode = S
        },
        ye = {
            p: R,
            um: Ze,
            m: ke,
            r: Fe,
            mt: ie,
            mc: F,
            pc: ce,
            pbc: k,
            n: W,
            o: e
        };
    let Me, Be;
    return t && ([Me, Be] = t(ye)), {
        render: fe,
        hydrate: Me,
        createApp: nE(fe, Me)
    }
}

function Mc({
    type: e,
    props: t
}, n) {
    return n === "svg" && e === "foreignObject" || n === "mathml" && e === "annotation-xml" && t && t.encoding && t.encoding.includes("html") ? void 0 : n
}

function bi({
    effect: e,
    update: t
}, n) {
    e.allowRecurse = t.allowRecurse = n
}

function v_(e, t) {
    return (!e || e && !e.pendingBranch) && t && !t.persisted
}

function $f(e, t, n = !1) {
    const r = e.children,
        i = t.children;
    if (we(r) && we(i))
        for (let s = 0; s < r.length; s++) {
            const o = r[s];
            let a = i[s];
            a.shapeFlag & 1 && !a.dynamicChildren && ((a.patchFlag <= 0 || a.patchFlag === 32) && (a = i[s] = Yr(i[s]), a.el = o.el), n || $f(o, a)), a.type === zi && (a.el = o.el)
        }
}

function dE(e) {
    const t = e.slice(),
        n = [0];
    let r, i, s, o, a;
    const l = e.length;
    for (r = 0; r < l; r++) {
        const u = e[r];
        if (u !== 0) {
            if (i = n[n.length - 1], e[i] < u) {
                t[r] = i, n.push(r);
                continue
            }
            for (s = 0, o = n.length - 1; s < o;) a = s + o >> 1, e[n[a]] < u ? s = a + 1 : o = a;
            u < e[n[s]] && (s > 0 && (t[r] = n[s - 1]), n[s] = r)
        }
    }
    for (s = n.length, o = n[s - 1]; s-- > 0;) n[s] = o, o = t[o];
    return n
}

function y_(e) {
    const t = e.subTree.component;
    if (t) return t.asyncDep && !t.asyncResolved ? t : y_(t)
}
const hE = e => e.__isTeleport,
    ao = e => e && (e.disabled || e.disabled === ""),
    Vh = e => typeof SVGElement < "u" && e instanceof SVGElement,
    Hh = e => typeof MathMLElement == "function" && e instanceof MathMLElement,
    hu = (e, t) => {
        const n = e && e.to;
        return He(n) ? t ? t(n) : null : n
    },
    pE = {
        name: "Teleport",
        __isTeleport: !0,
        process(e, t, n, r, i, s, o, a, l, u) {
            const {
                mc: f,
                pc: h,
                pbc: _,
                o: {
                    insert: m,
                    querySelector: T,
                    createText: R,
                    createComment: B
                }
            } = u, I = ao(t.props);
            let {
                shapeFlag: A,
                children: E,
                dynamicChildren: O
            } = t;
            if (e == null) {
                const P = t.el = R(""),
                    $ = t.anchor = R("");
                m(P, n, r), m($, n, r);
                const H = t.target = hu(t.props, T),
                    F = t.targetAnchor = R("");
                H && (m(F, H), o === "svg" || Vh(H) ? o = "svg" : (o === "mathml" || Hh(H)) && (o = "mathml"));
                const V = (k, Y) => {
                    A & 16 && f(E, k, Y, i, s, o, a, l)
                };
                I ? V(n, $) : H && V(H, F)
            } else {
                t.el = e.el;
                const P = t.anchor = e.anchor,
                    $ = t.target = e.target,
                    H = t.targetAnchor = e.targetAnchor,
                    F = ao(e.props),
                    V = F ? n : $,
                    k = F ? P : H;
                if (o === "svg" || Vh($) ? o = "svg" : (o === "mathml" || Hh($)) && (o = "mathml"), O ? (_(e.dynamicChildren, O, V, i, s, o, a), $f(e, t, !0)) : l || h(e, t, V, k, i, s, o, a, !1), I) F ? t.props && e.props && t.props.to !== e.props.to && (t.props.to = e.props.to) : Oa(t, n, P, u, 1);
                else if ((t.props && t.props.to) !== (e.props && e.props.to)) {
                    const Y = t.target = hu(t.props, T);
                    Y && Oa(t, Y, null, u, 0)
                } else F && Oa(t, $, H, u, 1)
            }
            b_(t)
        },
        remove(e, t, n, r, {
            um: i,
            o: {
                remove: s
            }
        }, o) {
            const {
                shapeFlag: a,
                children: l,
                anchor: u,
                targetAnchor: f,
                target: h,
                props: _
            } = e;
            if (h && s(f), o && s(u), a & 16) {
                const m = o || !ao(_);
                for (let T = 0; T < l.length; T++) {
                    const R = l[T];
                    i(R, t, n, m, !!R.dynamicChildren)
                }
            }
        },
        move: Oa,
        hydrate: mE
    };

function Oa(e, t, n, {
    o: {
        insert: r
    },
    m: i
}, s = 2) {
    s === 0 && r(e.targetAnchor, t, n);
    const {
        el: o,
        anchor: a,
        shapeFlag: l,
        children: u,
        props: f
    } = e, h = s === 2;
    if (h && r(o, t, n), (!h || ao(f)) && l & 16)
        for (let _ = 0; _ < u.length; _++) i(u[_], t, n, 2);
    h && r(a, t, n)
}

function mE(e, t, n, r, i, s, {
    o: {
        nextSibling: o,
        parentNode: a,
        querySelector: l
    }
}, u) {
    const f = t.target = hu(t.props, l);
    if (f) {
        const h = f._lpa || f.firstChild;
        if (t.shapeFlag & 16)
            if (ao(t.props)) t.anchor = u(o(e), t, a(e), n, r, i, s), t.targetAnchor = h;
            else {
                t.anchor = o(e);
                let _ = h;
                for (; _;)
                    if (_ = o(_), _ && _.nodeType === 8 && _.data === "teleport anchor") {
                        t.targetAnchor = _, f._lpa = t.targetAnchor && o(t.targetAnchor);
                        break
                    }
                u(h, t, f, n, r, i, s)
            }
        b_(t)
    }
    return t.anchor && o(t.anchor)
}
const gE = pE;

function b_(e) {
    const t = e.ctx;
    if (t && t.ut) {
        let n = e.children[0].el;
        for (; n && n !== e.targetAnchor;) n.nodeType === 1 && n.setAttribute("data-v-owner", t.uid), n = n.nextSibling;
        t.ut()
    }
}
const nt = Symbol.for("v-fgt"),
    zi = Symbol.for("v-txt"),
    sn = Symbol.for("v-cmt"),
    Ni = Symbol.for("v-stc"),
    lo = [];
let wn = null;

function Q(e = !1) {
    lo.push(wn = e ? null : [])
}

function w_() {
    lo.pop(), wn = lo[lo.length - 1] || null
}
let qi = 1;

function pu(e) {
    qi += e
}

function S_(e) {
    return e.dynamicChildren = qi > 0 ? wn || ys : null, w_(), qi > 0 && wn && wn.push(e), e
}

function pe(e, t, n, r, i, s) {
    return S_(qe(e, t, n, r, i, s, !0))
}

function Et(e, t, n, r, i) {
    return S_(Pe(e, t, n, r, i, !0))
}

function ci(e) {
    return e ? e.__v_isVNode === !0 : !1
}

function Wn(e, t) {
    return e.type === t.type && e.key === t.key
}

function _E(e) {}
const T_ = ({
        key: e
    }) => e ? ? null,
    Ha = ({
        ref: e,
        ref_key: t,
        ref_for: n
    }) => (typeof e == "number" && (e = "" + e), e != null ? He(e) || an(e) || Re(e) ? {
        i: Wt,
        r: e,
        k: t,
        f: !!n
    } : e : null);

function qe(e, t = null, n = null, r = 0, i = null, s = e === nt ? 0 : 1, o = !1, a = !1) {
    const l = {
        __v_isVNode: !0,
        __v_skip: !0,
        type: e,
        props: t,
        key: t && T_(t),
        ref: t && Ha(t),
        scopeId: Kl,
        slotScopeIds: null,
        children: n,
        component: null,
        suspense: null,
        ssContent: null,
        ssFallback: null,
        dirs: null,
        transition: null,
        el: null,
        anchor: null,
        target: null,
        targetAnchor: null,
        staticCount: 0,
        shapeFlag: s,
        patchFlag: r,
        dynamicProps: i,
        dynamicChildren: null,
        appContext: null,
        ctx: Wt
    };
    return a ? (kf(l, n), s & 128 && e.normalize(l)) : n && (l.shapeFlag |= He(n) ? 8 : 16), qi > 0 && !o && wn && (l.patchFlag > 0 || s & 6) && l.patchFlag !== 32 && wn.push(l), l
}
const Pe = vE;

function vE(e, t = null, n = null, r = 0, i = null, s = !1) {
    if ((!e || e === Ng) && (e = sn), ci(e)) {
        const a = hr(e, t, !0);
        return n && kf(a, n), qi > 0 && !s && wn && (a.shapeFlag & 6 ? wn[wn.indexOf(e)] = a : wn.push(a)), a.patchFlag |= -2, a
    }
    if (EE(e) && (e = e.__vccOpts), t) {
        t = C_(t);
        let {
            class: a,
            style: l
        } = t;
        a && !He(a) && (t.class = Ot(a)), yt(l) && (yf(l) && !we(l) && (l = rt({}, l)), t.style = ns(l))
    }
    const o = He(e) ? 1 : Fg(e) ? 128 : hE(e) ? 64 : yt(e) ? 4 : Re(e) ? 2 : 0;
    return qe(e, t, n, r, i, o, s, !0)
}

function C_(e) {
    return e ? yf(e) || c_(e) ? rt({}, e) : e : null
}

function hr(e, t, n = !1, r = !1) {
    const {
        props: i,
        ref: s,
        patchFlag: o,
        children: a,
        transition: l
    } = e, u = t ? ui(i || {}, t) : i, f = {
        __v_isVNode: !0,
        __v_skip: !0,
        type: e.type,
        props: u,
        key: u && T_(u),
        ref: t && t.ref ? n && s ? we(s) ? s.concat(Ha(t)) : [s, Ha(t)] : Ha(t) : s,
        scopeId: e.scopeId,
        slotScopeIds: e.slotScopeIds,
        children: a,
        target: e.target,
        targetAnchor: e.targetAnchor,
        staticCount: e.staticCount,
        shapeFlag: e.shapeFlag,
        patchFlag: t && e.type !== nt ? o === -1 ? 16 : o | 16 : o,
        dynamicProps: e.dynamicProps,
        dynamicChildren: e.dynamicChildren,
        appContext: e.appContext,
        dirs: e.dirs,
        transition: l,
        component: e.component,
        suspense: e.suspense,
        ssContent: e.ssContent && hr(e.ssContent),
        ssFallback: e.ssFallback && hr(e.ssFallback),
        el: e.el,
        anchor: e.anchor,
        ctx: e.ctx,
        ce: e.ce
    };
    return l && r && (f.transition = l.clone(f)), f
}

function Pr(e = " ", t = 0) {
    return Pe(zi, null, e, t)
}

function yE(e, t) {
    const n = Pe(Ni, null, e);
    return n.staticCount = t, n
}

function dt(e = "", t = !1) {
    return t ? (Q(), Et(sn, null, e)) : Pe(sn, null, e)
}

function On(e) {
    return e == null || typeof e == "boolean" ? Pe(sn) : we(e) ? Pe(nt, null, e.slice()) : typeof e == "object" ? Yr(e) : Pe(zi, null, String(e))
}

function Yr(e) {
    return e.el === null && e.patchFlag !== -1 || e.memo ? e : hr(e)
}

function kf(e, t) {
    let n = 0;
    const {
        shapeFlag: r
    } = e;
    if (t == null) t = null;
    else if (we(t)) n = 16;
    else if (typeof t == "object")
        if (r & 65) {
            const i = t.default;
            i && (i._c && (i._d = !1), kf(e, i()), i._c && (i._d = !0));
            return
        } else {
            n = 32;
            const i = t._;
            !i && !c_(t) ? t._ctx = Wt : i === 3 && Wt && (Wt.slots._ === 1 ? t._ = 1 : (t._ = 2, e.patchFlag |= 1024))
        }
    else Re(t) ? (t = {
        default: t,
        _ctx: Wt
    }, n = 32) : (t = String(t), r & 64 ? (n = 16, t = [Pr(t)]) : n = 8);
    e.children = t, e.shapeFlag |= n
}

function ui(...e) {
    const t = {};
    for (let n = 0; n < e.length; n++) {
        const r = e[n];
        for (const i in r)
            if (i === "class") t.class !== r.class && (t.class = Ot([t.class, r.class]));
            else if (i === "style") t.style = ns([t.style, r.style]);
        else if (Qi(i)) {
            const s = t[i],
                o = r[i];
            o && s !== o && !(we(s) && s.includes(o)) && (t[i] = s ? [].concat(s, o) : o)
        } else i !== "" && (t[i] = r[i])
    }
    return t
}

function vn(e, t, n, r = null) {
    Rn(e, t, 7, [n, r])
}
const bE = o_();
let wE = 0;

function E_(e, t, n) {
    const r = e.type,
        i = (t ? t.appContext : e.appContext) || bE,
        s = {
            uid: wE++,
            vnode: e,
            type: r,
            parent: t,
            appContext: i,
            root: null,
            next: null,
            subTree: null,
            effect: null,
            update: null,
            scope: new hf(!0),
            render: null,
            proxy: null,
            exposed: null,
            exposeProxy: null,
            withProxy: null,
            provides: t ? t.provides : Object.create(i.provides),
            accessCache: null,
            renderCache: [],
            components: null,
            directives: null,
            propsOptions: f_(r, i),
            emitsOptions: Lg(r, i),
            emit: null,
            emitted: null,
            propsDefaults: ft,
            inheritAttrs: r.inheritAttrs,
            ctx: ft,
            data: ft,
            props: ft,
            attrs: ft,
            slots: ft,
            refs: ft,
            setupState: ft,
            setupContext: null,
            attrsProxy: null,
            slotsProxy: null,
            suspense: n,
            suspenseId: n ? n.pendingId : 0,
            asyncDep: null,
            asyncResolved: !1,
            isMounted: !1,
            isUnmounted: !1,
            isDeactivated: !1,
            bc: null,
            c: null,
            bm: null,
            m: null,
            bu: null,
            u: null,
            um: null,
            bum: null,
            da: null,
            a: null,
            rtg: null,
            rtc: null,
            ec: null,
            sp: null
        };
    return s.ctx = {
        _: s
    }, s.root = t ? t.root : s, s.emit = hC.bind(null, s), e.ce && e.ce(s), s
}
let Jt = null;
const Jn = () => Jt || Wt;
let dl, mu; {
    const e = sg(),
        t = (n, r) => {
            let i;
            return (i = e[n]) || (i = e[n] = []), i.push(r), s => {
                i.length > 1 ? i.forEach(o => o(s)) : i[0](s)
            }
        };
    dl = t("__VUE_INSTANCE_SETTERS__", n => Jt = n), mu = t("__VUE_SSR_SETTERS__", n => Go = n)
}
const Ki = e => {
        const t = Jt;
        return dl(e), e.scope.on(), () => {
            e.scope.off(), dl(t)
        }
    },
    gu = () => {
        Jt && Jt.scope.off(), dl(null)
    };

function A_(e) {
    return e.vnode.shapeFlag & 4
}
let Go = !1;

function x_(e, t = !1) {
    t && mu(t);
    const {
        props: n,
        children: r
    } = e.vnode, i = A_(e);
    iE(e, n, i, t), aE(e, r);
    const s = i ? SE(e, t) : void 0;
    return t && mu(!1), s
}

function SE(e, t) {
    const n = e.type;
    e.accessCache = Object.create(null), e.proxy = new Proxy(e.ctx, cu);
    const {
        setup: r
    } = n;
    if (r) {
        const i = e.setupContext = r.length > 1 ? M_(e) : null,
            s = Ki(e);
        mi();
        const o = xr(r, e, 0, [e.props, i]);
        if (gi(), s(), ff(o)) {
            if (o.then(gu, gu), t) return o.then(a => {
                _u(e, a, t)
            }).catch(a => {
                rs(a, e, 0)
            });
            e.asyncDep = o
        } else _u(e, o, t)
    } else P_(e, t)
}

function _u(e, t, n) {
    Re(t) ? e.type.__ssrInlineRender ? e.ssrRender = t : e.render = t : yt(t) && (e.setupState = Sf(t)), P_(e, n)
}
let hl, vu;

function O_(e) {
    hl = e, vu = t => {
        t.render._rc && (t.withProxy = new Proxy(t.ctx, NC))
    }
}
const TE = () => !hl;

function P_(e, t, n) {
    const r = e.type;
    if (!e.render) {
        if (!t && hl && !r.render) {
            const i = r.template || Rf(e).template;
            if (i) {
                const {
                    isCustomElement: s,
                    compilerOptions: o
                } = e.appContext.config, {
                    delimiters: a,
                    compilerOptions: l
                } = r, u = rt(rt({
                    isCustomElement: s,
                    delimiters: a
                }, o), l);
                r.render = hl(i, u)
            }
        }
        e.render = r.render || Ut, vu && vu(e)
    } {
        const i = Ki(e);
        mi();
        try {
            XC(e)
        } finally {
            gi(), i()
        }
    }
}
const CE = {
    get(e, t) {
        return Cn(e, "get", ""), e[t]
    }
};

function M_(e) {
    const t = n => {
        e.exposed = n || {}
    };
    return {
        attrs: new Proxy(e.attrs, CE),
        slots: e.slots,
        emit: e.emit,
        expose: t
    }
}

function Ql(e) {
    if (e.exposed) return e.exposeProxy || (e.exposeProxy = new Proxy(Sf(Eg(e.exposed)), {
        get(t, n) {
            if (n in t) return t[n];
            if (n in so) return so[n](e)
        },
        has(t, n) {
            return n in t || n in so
        }
    }))
}

function yu(e, t = !0) {
    return Re(e) ? e.displayName || e.name : e.name || t && e.__name
}

function EE(e) {
    return Re(e) && "__vccOpts" in e
}
const Ht = (e, t) => YT(e, t, Go);

function AE(e, t, n = ft) {
    const r = Jn(),
        i = kt(t),
        s = Pn(t),
        o = Tf((l, u) => {
            let f;
            return Ug(() => {
                const h = e[t];
                Gn(f, h) && (f = h, u())
            }), {
                get() {
                    return l(), n.get ? n.get(f) : f
                },
                set(h) {
                    const _ = r.vnode.props;
                    !(_ && (t in _ || i in _ || s in _) && (`onUpdate:${t}` in _ || `onUpdate:${i}` in _ || `onUpdate:${s}` in _)) && Gn(h, f) && (f = h, u()), r.emit(`update:${t}`, n.set ? n.set(h) : h)
                }
            }
        }),
        a = t === "modelValue" ? "modelModifiers" : `${t}Modifiers`;
    return o[Symbol.iterator] = () => {
        let l = 0;
        return {
            next() {
                return l < 2 ? {
                    value: l++ ? e[a] || {} : o,
                    done: !1
                } : {
                    done: !0
                }
            }
        }
    }, o
}

function ec(e, t, n) {
    const r = arguments.length;
    return r === 2 ? yt(t) && !we(t) ? ci(t) ? Pe(e, null, [t]) : Pe(e, t) : Pe(e, null, t) : (r > 3 ? n = Array.prototype.slice.call(arguments, 2) : r === 3 && ci(n) && (n = [n]), Pe(e, t, n))
}

function xE() {}

function OE(e, t, n, r) {
    const i = n[r];
    if (i && R_(i, e)) return i;
    const s = t();
    return s.memo = e.slice(), n[r] = s
}

function R_(e, t) {
    const n = e.memo;
    if (n.length != t.length) return !1;
    for (let r = 0; r < n.length; r++)
        if (Gn(n[r], t[r])) return !1;
    return qi > 0 && wn && wn.push(e), !0
}
const I_ = "3.4.27",
    PE = Ut,
    ME = lC,
    RE = ds,
    IE = kg,
    $E = {
        createComponentInstance: E_,
        setupComponent: x_,
        renderComponentRoot: Va,
        setCurrentRenderingInstance: Eo,
        isVNode: ci,
        normalizeVNode: On
    },
    kE = $E,
    LE = null,
    NE = null,
    FE = null;
/**
 * @vue/runtime-dom v3.4.27
 * (c) 2018-present Yuxi (Evan) You and Vue contributors
 * @license MIT
 **/
const DE = "http://www.w3.org/2000/svg",
    jE = "http://www.w3.org/1998/Math/MathML",
    Xr = typeof document < "u" ? document : null,
    Uh = Xr && Xr.createElement("template"),
    BE = {
        insert: (e, t, n) => {
            t.insertBefore(e, n || null)
        },
        remove: e => {
            const t = e.parentNode;
            t && t.removeChild(e)
        },
        createElement: (e, t, n, r) => {
            const i = t === "svg" ? Xr.createElementNS(DE, e) : t === "mathml" ? Xr.createElementNS(jE, e) : Xr.createElement(e, n ? {
                is: n
            } : void 0);
            return e === "select" && r && r.multiple != null && i.setAttribute("multiple", r.multiple), i
        },
        createText: e => Xr.createTextNode(e),
        createComment: e => Xr.createComment(e),
        setText: (e, t) => {
            e.nodeValue = t
        },
        setElementText: (e, t) => {
            e.textContent = t
        },
        parentNode: e => e.parentNode,
        nextSibling: e => e.nextSibling,
        querySelector: e => Xr.querySelector(e),
        setScopeId(e, t) {
            e.setAttribute(t, "")
        },
        insertStaticContent(e, t, n, r, i, s) {
            const o = n ? n.previousSibling : t.lastChild;
            if (i && (i === s || i.nextSibling))
                for (; t.insertBefore(i.cloneNode(!0), n), !(i === s || !(i = i.nextSibling)););
            else {
                Uh.innerHTML = r === "svg" ? `<svg>${e}</svg>` : r === "mathml" ? `<math>${e}</math>` : e;
                const a = Uh.content;
                if (r === "svg" || r === "mathml") {
                    const l = a.firstChild;
                    for (; l.firstChild;) a.appendChild(l.firstChild);
                    a.removeChild(l)
                }
                t.insertBefore(a, n)
            }
            return [o ? o.nextSibling : t.firstChild, n ? n.previousSibling : t.lastChild]
        }
    },
    Br = "transition",
    Js = "animation",
    $s = Symbol("_vtc"),
    Mr = (e, {
        slots: t
    }) => ec(zg, k_(e), t);
Mr.displayName = "Transition";
const $_ = {
        name: String,
        type: String,
        css: {
            type: Boolean,
            default: !0
        },
        duration: [String, Number, Object],
        enterFromClass: String,
        enterActiveClass: String,
        enterToClass: String,
        appearFromClass: String,
        appearActiveClass: String,
        appearToClass: String,
        leaveFromClass: String,
        leaveActiveClass: String,
        leaveToClass: String
    },
    VE = Mr.props = rt({}, Mf, $_),
    wi = (e, t = []) => {
        we(e) ? e.forEach(n => n(...t)) : e && e(...t)
    },
    Wh = e => e ? we(e) ? e.some(t => t.length > 1) : e.length > 1 : !1;

function k_(e) {
    const t = {};
    for (const L in e) L in $_ || (t[L] = e[L]);
    if (e.css === !1) return t;
    const {
        name: n = "v",
        type: r,
        duration: i,
        enterFromClass: s = `${n}-enter-from`,
        enterActiveClass: o = `${n}-enter-active`,
        enterToClass: a = `${n}-enter-to`,
        appearFromClass: l = s,
        appearActiveClass: u = o,
        appearToClass: f = a,
        leaveFromClass: h = `${n}-leave-from`,
        leaveActiveClass: _ = `${n}-leave-active`,
        leaveToClass: m = `${n}-leave-to`
    } = e, T = HE(i), R = T && T[0], B = T && T[1], {
        onBeforeEnter: I,
        onEnter: A,
        onEnterCancelled: E,
        onLeave: O,
        onLeaveCancelled: P,
        onBeforeAppear: $ = I,
        onAppear: H = A,
        onAppearCancelled: F = E
    } = t, V = (L, te, ie) => {
        zr(L, te ? f : a), zr(L, te ? u : o), ie && ie()
    }, k = (L, te) => {
        L._isLeaving = !1, zr(L, h), zr(L, m), zr(L, _), te && te()
    }, Y = L => (te, ie) => {
        const _e = L ? H : A,
            X = () => V(te, L, ie);
        wi(_e, [te, X]), zh(() => {
            zr(te, L ? l : s), br(te, L ? f : a), Wh(_e) || qh(te, r, R, X)
        })
    };
    return rt(t, {
        onBeforeEnter(L) {
            wi(I, [L]), br(L, s), br(L, o)
        },
        onBeforeAppear(L) {
            wi($, [L]), br(L, l), br(L, u)
        },
        onEnter: Y(!1),
        onAppear: Y(!0),
        onLeave(L, te) {
            L._isLeaving = !0;
            const ie = () => k(L, te);
            br(L, h), br(L, _), N_(), zh(() => {
                L._isLeaving && (zr(L, h), br(L, m), Wh(O) || qh(L, r, B, ie))
            }), wi(O, [L, ie])
        },
        onEnterCancelled(L) {
            V(L, !1), wi(E, [L])
        },
        onAppearCancelled(L) {
            V(L, !0), wi(F, [L])
        },
        onLeaveCancelled(L) {
            k(L), wi(P, [L])
        }
    })
}

function HE(e) {
    if (e == null) return null;
    if (yt(e)) return [Rc(e.enter), Rc(e.leave)]; {
        const t = Rc(e);
        return [t, t]
    }
}

function Rc(e) {
    return ol(e)
}

function br(e, t) {
    t.split(/\s+/).forEach(n => n && e.classList.add(n)), (e[$s] || (e[$s] = new Set)).add(t)
}

function zr(e, t) {
    t.split(/\s+/).forEach(r => r && e.classList.remove(r));
    const n = e[$s];
    n && (n.delete(t), n.size || (e[$s] = void 0))
}

function zh(e) {
    requestAnimationFrame(() => {
        requestAnimationFrame(e)
    })
}
let UE = 0;

function qh(e, t, n, r) {
    const i = e._endId = ++UE,
        s = () => {
            i === e._endId && r()
        };
    if (n) return setTimeout(s, n);
    const {
        type: o,
        timeout: a,
        propCount: l
    } = L_(e, t);
    if (!o) return r();
    const u = o + "end";
    let f = 0;
    const h = () => {
            e.removeEventListener(u, _), s()
        },
        _ = m => {
            m.target === e && ++f >= l && h()
        };
    setTimeout(() => {
        f < l && h()
    }, a + 1), e.addEventListener(u, _)
}

function L_(e, t) {
    const n = window.getComputedStyle(e),
        r = T => (n[T] || "").split(", "),
        i = r(`${Br}Delay`),
        s = r(`${Br}Duration`),
        o = Kh(i, s),
        a = r(`${Js}Delay`),
        l = r(`${Js}Duration`),
        u = Kh(a, l);
    let f = null,
        h = 0,
        _ = 0;
    t === Br ? o > 0 && (f = Br, h = o, _ = s.length) : t === Js ? u > 0 && (f = Js, h = u, _ = l.length) : (h = Math.max(o, u), f = h > 0 ? o > u ? Br : Js : null, _ = f ? f === Br ? s.length : l.length : 0);
    const m = f === Br && /\b(transform|all)(,|$)/.test(r(`${Br}Property`).toString());
    return {
        type: f,
        timeout: h,
        propCount: _,
        hasTransform: m
    }
}

function Kh(e, t) {
    for (; e.length < t.length;) e = e.concat(e);
    return Math.max(...t.map((n, r) => Gh(n) + Gh(e[r])))
}

function Gh(e) {
    return e === "auto" ? 0 : Number(e.slice(0, -1).replace(",", ".")) * 1e3
}

function N_() {
    return document.body.offsetHeight
}

function WE(e, t, n) {
    const r = e[$s];
    r && (t = (t ? [t, ...r] : [...r]).join(" ")), t == null ? e.removeAttribute("class") : n ? e.setAttribute("class", t) : e.className = t
}
const pl = Symbol("_vod"),
    F_ = Symbol("_vsh"),
    Oo = {
        beforeMount(e, {
            value: t
        }, {
            transition: n
        }) {
            e[pl] = e.style.display === "none" ? "" : e.style.display, n && t ? n.beforeEnter(e) : Zs(e, t)
        },
        mounted(e, {
            value: t
        }, {
            transition: n
        }) {
            n && t && n.enter(e)
        },
        updated(e, {
            value: t,
            oldValue: n
        }, {
            transition: r
        }) {
            !t != !n && (r ? t ? (r.beforeEnter(e), Zs(e, !0), r.enter(e)) : r.leave(e, () => {
                Zs(e, !1)
            }) : Zs(e, t))
        },
        beforeUnmount(e, {
            value: t
        }) {
            Zs(e, t)
        }
    };

function Zs(e, t) {
    e.style.display = t ? e[pl] : "none", e[F_] = !t
}

function zE() {
    Oo.getSSRProps = ({
        value: e
    }) => {
        if (!e) return {
            style: {
                display: "none"
            }
        }
    }
}
const D_ = Symbol("");

function qE(e) {
    const t = Jn();
    if (!t) return;
    const n = t.ut = (i = e(t.proxy)) => {
            Array.from(document.querySelectorAll(`[data-v-owner="${t.uid}"]`)).forEach(s => wu(s, i))
        },
        r = () => {
            const i = e(t.proxy);
            bu(t.subTree, i), n(i)
        };
    is(() => {
        Hg(r);
        const i = new MutationObserver(r);
        i.observe(t.subTree.el.parentNode, {
            childList: !0
        }), Zl(() => i.disconnect())
    })
}

function bu(e, t) {
    if (e.shapeFlag & 128) {
        const n = e.suspense;
        e = n.activeBranch, n.pendingBranch && !n.isHydrating && n.effects.push(() => {
            bu(n.activeBranch, t)
        })
    }
    for (; e.component;) e = e.component.subTree;
    if (e.shapeFlag & 1 && e.el) wu(e.el, t);
    else if (e.type === nt) e.children.forEach(n => bu(n, t));
    else if (e.type === Ni) {
        let {
            el: n,
            anchor: r
        } = e;
        for (; n && (wu(n, t), n !== r);) n = n.nextSibling
    }
}

function wu(e, t) {
    if (e.nodeType === 1) {
        const n = e.style;
        let r = "";
        for (const i in t) n.setProperty(`--${i}`, t[i]), r += `--${i}: ${t[i]};`;
        n[D_] = r
    }
}
const KE = /(^|;)\s*display\s*:/;

function GE(e, t, n) {
    const r = e.style,
        i = He(n);
    let s = !1;
    if (n && !i) {
        if (t)
            if (He(t))
                for (const o of t.split(";")) {
                    const a = o.slice(0, o.indexOf(":")).trim();
                    n[a] == null && Ua(r, a, "")
                } else
                    for (const o in t) n[o] == null && Ua(r, o, "");
        for (const o in n) o === "display" && (s = !0), Ua(r, o, n[o])
    } else if (i) {
        if (t !== n) {
            const o = r[D_];
            o && (n += ";" + o), r.cssText = n, s = KE.test(n)
        }
    } else t && e.removeAttribute("style");
    pl in e && (e[pl] = s ? r.display : "", e[F_] && (r.display = "none"))
}
const Yh = /\s*!important$/;

function Ua(e, t, n) {
    if (we(n)) n.forEach(r => Ua(e, t, r));
    else if (n == null && (n = ""), t.startsWith("--")) e.setProperty(t, n);
    else {
        const r = YE(e, t);
        Yh.test(n) ? e.setProperty(Pn(r), n.replace(Yh, ""), "important") : e[r] = n
    }
}
const Xh = ["Webkit", "Moz", "ms"],
    Ic = {};

function YE(e, t) {
    const n = Ic[t];
    if (n) return n;
    let r = kt(t);
    if (r !== "filter" && r in e) return Ic[t] = r;
    r = ts(r);
    for (let i = 0; i < Xh.length; i++) {
        const s = Xh[i] + r;
        if (s in e) return Ic[t] = s
    }
    return t
}
const Jh = "http://www.w3.org/1999/xlink";

function XE(e, t, n, r, i) {
    if (r && t.startsWith("xlink:")) n == null ? e.removeAttributeNS(Jh, t.slice(6, t.length)) : e.setAttributeNS(Jh, t, n);
    else {
        const s = TT(t);
        n == null || s && !lg(n) ? e.removeAttribute(t) : e.setAttribute(t, s ? "" : n)
    }
}

function JE(e, t, n, r, i, s, o) {
    if (t === "innerHTML" || t === "textContent") {
        r && o(r, i, s), e[t] = n ? ? "";
        return
    }
    const a = e.tagName;
    if (t === "value" && a !== "PROGRESS" && !a.includes("-")) {
        const u = a === "OPTION" ? e.getAttribute("value") || "" : e.value,
            f = n ? ? "";
        (u !== f || !("_value" in e)) && (e.value = f), n == null && e.removeAttribute(t), e._value = n;
        return
    }
    let l = !1;
    if (n === "" || n == null) {
        const u = typeof e[t];
        u === "boolean" ? n = lg(n) : n == null && u === "string" ? (n = "", l = !0) : u === "number" && (n = 0, l = !0)
    }
    try {
        e[t] = n
    } catch {}
    l && e.removeAttribute(t)
}

function Tr(e, t, n, r) {
    e.addEventListener(t, n, r)
}

function ZE(e, t, n, r) {
    e.removeEventListener(t, n, r)
}
const Zh = Symbol("_vei");

function QE(e, t, n, r, i = null) {
    const s = e[Zh] || (e[Zh] = {}),
        o = s[t];
    if (r && o) o.value = r;
    else {
        const [a, l] = eA(t);
        if (r) {
            const u = s[t] = rA(r, i);
            Tr(e, a, u, l)
        } else o && (ZE(e, a, o, l), s[t] = void 0)
    }
}
const Qh = /(?:Once|Passive|Capture)$/;

function eA(e) {
    let t;
    if (Qh.test(e)) {
        t = {};
        let r;
        for (; r = e.match(Qh);) e = e.slice(0, e.length - r[0].length), t[r[0].toLowerCase()] = !0
    }
    return [e[2] === ":" ? e.slice(3) : Pn(e.slice(2)), t]
}
let $c = 0;
const tA = Promise.resolve(),
    nA = () => $c || (tA.then(() => $c = 0), $c = Date.now());

function rA(e, t) {
    const n = r => {
        if (!r._vts) r._vts = Date.now();
        else if (r._vts <= n.attached) return;
        Rn(iA(r, n.value), t, 5, [r])
    };
    return n.value = e, n.attached = nA(), n
}

function iA(e, t) {
    if (we(t)) {
        const n = e.stopImmediatePropagation;
        return e.stopImmediatePropagation = () => {
            n.call(e), e._stopped = !0
        }, t.map(r => i => !i._stopped && r && r(i))
    } else return t
}
const ep = e => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && e.charCodeAt(2) > 96 && e.charCodeAt(2) < 123,
    sA = (e, t, n, r, i, s, o, a, l) => {
        const u = i === "svg";
        t === "class" ? WE(e, r, u) : t === "style" ? GE(e, n, r) : Qi(t) ? cf(t) || QE(e, t, n, r, o) : (t[0] === "." ? (t = t.slice(1), !0) : t[0] === "^" ? (t = t.slice(1), !1) : oA(e, t, r, u)) ? JE(e, t, r, s, o, a, l) : (t === "true-value" ? e._trueValue = r : t === "false-value" && (e._falseValue = r), XE(e, t, r, u))
    };

function oA(e, t, n, r) {
    if (r) return !!(t === "innerHTML" || t === "textContent" || t in e && ep(t) && Re(n));
    if (t === "spellcheck" || t === "draggable" || t === "translate" || t === "form" || t === "list" && e.tagName === "INPUT" || t === "type" && e.tagName === "TEXTAREA") return !1;
    if (t === "width" || t === "height") {
        const i = e.tagName;
        if (i === "IMG" || i === "VIDEO" || i === "CANVAS" || i === "SOURCE") return !1
    }
    return ep(t) && He(n) ? !1 : t in e
} /*! #__NO_SIDE_EFFECTS__ */
function j_(e, t) {
    const n = qo(e);
    class r extends tc {
        constructor(s) {
            super(n, s, t)
        }
    }
    return r.def = n, r
} /*! #__NO_SIDE_EFFECTS__ */
const aA = e => j_(e, J_),
    lA = typeof HTMLElement < "u" ? HTMLElement : class {};
class tc extends lA {
    constructor(t, n = {}, r) {
        super(), this._def = t, this._props = n, this._instance = null, this._connected = !1, this._resolved = !1, this._numberProps = null, this._ob = null, this.shadowRoot && r ? r(this._createVNode(), this.shadowRoot) : (this.attachShadow({
            mode: "open"
        }), this._def.__asyncLoader || this._resolveProps(this._def))
    }
    connectedCallback() {
        this._connected = !0, this._instance || (this._resolved ? this._update() : this._resolveDef())
    }
    disconnectedCallback() {
        this._connected = !1, this._ob && (this._ob.disconnect(), this._ob = null), Ws(() => {
            this._connected || (Su(null, this.shadowRoot), this._instance = null)
        })
    }
    _resolveDef() {
        this._resolved = !0;
        for (let r = 0; r < this.attributes.length; r++) this._setAttr(this.attributes[r].name);
        this._ob = new MutationObserver(r => {
            for (const i of r) this._setAttr(i.attributeName)
        }), this._ob.observe(this, {
            attributes: !0
        });
        const t = (r, i = !1) => {
                const {
                    props: s,
                    styles: o
                } = r;
                let a;
                if (s && !we(s))
                    for (const l in s) {
                        const u = s[l];
                        (u === Number || u && u.type === Number) && (l in this._props && (this._props[l] = ol(this._props[l])), (a || (a = Object.create(null)))[kt(l)] = !0)
                    }
                this._numberProps = a, i && this._resolveProps(r), this._applyStyles(o), this._update()
            },
            n = this._def.__asyncLoader;
        n ? n().then(r => t(r, !0)) : t(this._def)
    }
    _resolveProps(t) {
        const {
            props: n
        } = t, r = we(n) ? n : Object.keys(n || {});
        for (const i of Object.keys(this)) i[0] !== "_" && r.includes(i) && this._setProp(i, this[i], !0, !1);
        for (const i of r.map(kt)) Object.defineProperty(this, i, {
            get() {
                return this._getProp(i)
            },
            set(s) {
                this._setProp(i, s)
            }
        })
    }
    _setAttr(t) {
        let n = this.hasAttribute(t) ? this.getAttribute(t) : void 0;
        const r = kt(t);
        this._numberProps && this._numberProps[r] && (n = ol(n)), this._setProp(r, n, !1)
    }
    _getProp(t) {
        return this._props[t]
    }
    _setProp(t, n, r = !0, i = !0) {
        n !== this._props[t] && (this._props[t] = n, i && this._instance && this._update(), r && (n === !0 ? this.setAttribute(Pn(t), "") : typeof n == "string" || typeof n == "number" ? this.setAttribute(Pn(t), n + "") : n || this.removeAttribute(Pn(t))))
    }
    _update() {
        Su(this._createVNode(), this.shadowRoot)
    }
    _createVNode() {
        const t = Pe(this._def, rt({}, this._props));
        return this._instance || (t.ce = n => {
            this._instance = n, n.isCE = !0;
            const r = (s, o) => {
                this.dispatchEvent(new CustomEvent(s, {
                    detail: o
                }))
            };
            n.emit = (s, ...o) => {
                r(s, o), Pn(s) !== s && r(Pn(s), o)
            };
            let i = this;
            for (; i = i && (i.parentNode || i.host);)
                if (i instanceof tc) {
                    n.parent = i._instance, n.provides = i._instance.provides;
                    break
                }
        }), t
    }
    _applyStyles(t) {
        t && t.forEach(n => {
            const r = document.createElement("style");
            r.textContent = n, this.shadowRoot.appendChild(r)
        })
    }
}

function cA(e = "$style") {
    {
        const t = Jn();
        if (!t) return ft;
        const n = t.type.__cssModules;
        if (!n) return ft;
        const r = n[e];
        return r || ft
    }
}
const B_ = new WeakMap,
    V_ = new WeakMap,
    ml = Symbol("_moveCb"),
    tp = Symbol("_enterCb"),
    H_ = {
        name: "TransitionGroup",
        props: rt({}, VE, {
            tag: String,
            moveClass: String
        }),
        setup(e, {
            slots: t
        }) {
            const n = Jn(),
                r = Pf();
            let i, s;
            return Xl(() => {
                if (!i.length) return;
                const o = e.moveClass || `${e.name||"v"}-move`;
                if (!pA(i[0].el, n.vnode.el, o)) return;
                i.forEach(fA), i.forEach(dA);
                const a = i.filter(hA);
                N_(), a.forEach(l => {
                    const u = l.el,
                        f = u.style;
                    br(u, o), f.transform = f.webkitTransform = f.transitionDuration = "";
                    const h = u[ml] = _ => {
                        _ && _.target !== u || (!_ || /transform$/.test(_.propertyName)) && (u.removeEventListener("transitionend", h), u[ml] = null, zr(u, o))
                    };
                    u.addEventListener("transitionend", h)
                })
            }), () => {
                const o = it(e),
                    a = k_(o);
                let l = o.tag || nt;
                if (i = [], s)
                    for (let u = 0; u < s.length; u++) {
                        const f = s[u];
                        f.el && f.el instanceof Element && (i.push(f), Ui(f, Is(f, a, r, n)), B_.set(f, f.el.getBoundingClientRect()))
                    }
                s = t.default ? Gl(t.default()) : [];
                for (let u = 0; u < s.length; u++) {
                    const f = s[u];
                    f.key != null && Ui(f, Is(f, a, r, n))
                }
                return Pe(l, null, s)
            }
        }
    },
    uA = e => delete e.mode;
H_.props;
const U_ = H_;

function fA(e) {
    const t = e.el;
    t[ml] && t[ml](), t[tp] && t[tp]()
}

function dA(e) {
    V_.set(e, e.el.getBoundingClientRect())
}

function hA(e) {
    const t = B_.get(e),
        n = V_.get(e),
        r = t.left - n.left,
        i = t.top - n.top;
    if (r || i) {
        const s = e.el.style;
        return s.transform = s.webkitTransform = `translate(${r}px,${i}px)`, s.transitionDuration = "0s", e
    }
}

function pA(e, t, n) {
    const r = e.cloneNode(),
        i = e[$s];
    i && i.forEach(a => {
        a.split(/\s+/).forEach(l => l && r.classList.remove(l))
    }), n.split(/\s+/).forEach(a => a && r.classList.add(a)), r.style.display = "none";
    const s = t.nodeType === 1 ? t : t.parentNode;
    s.appendChild(r);
    const {
        hasTransform: o
    } = L_(r);
    return s.removeChild(r), o
}
const fi = e => {
    const t = e.props["onUpdate:modelValue"] || !1;
    return we(t) ? n => Ss(t, n) : t
};

function mA(e) {
    e.target.composing = !0
}

function np(e) {
    const t = e.target;
    t.composing && (t.composing = !1, t.dispatchEvent(new Event("input")))
}
const Bn = Symbol("_assign"),
    gl = {
        created(e, {
            modifiers: {
                lazy: t,
                trim: n,
                number: r
            }
        }, i) {
            e[Bn] = fi(i);
            const s = r || i.props && i.props.type === "number";
            Tr(e, t ? "change" : "input", o => {
                if (o.target.composing) return;
                let a = e.value;
                n && (a = a.trim()), s && (a = sl(a)), e[Bn](a)
            }), n && Tr(e, "change", () => {
                e.value = e.value.trim()
            }), t || (Tr(e, "compositionstart", mA), Tr(e, "compositionend", np), Tr(e, "change", np))
        },
        mounted(e, {
            value: t
        }) {
            e.value = t ? ? ""
        },
        beforeUpdate(e, {
            value: t,
            modifiers: {
                lazy: n,
                trim: r,
                number: i
            }
        }, s) {
            if (e[Bn] = fi(s), e.composing) return;
            const o = (i || e.type === "number") && !/^0\d/.test(e.value) ? sl(e.value) : e.value,
                a = t ? ? "";
            o !== a && (document.activeElement === e && e.type !== "range" && (n || r && e.value.trim() === a) || (e.value = a))
        }
    },
    Lf = {
        deep: !0,
        created(e, t, n) {
            e[Bn] = fi(n), Tr(e, "change", () => {
                const r = e._modelValue,
                    i = ks(e),
                    s = e.checked,
                    o = e[Bn];
                if (we(r)) {
                    const a = Vl(r, i),
                        l = a !== -1;
                    if (s && !l) o(r.concat(i));
                    else if (!s && l) {
                        const u = [...r];
                        u.splice(a, 1), o(u)
                    }
                } else if (es(r)) {
                    const a = new Set(r);
                    s ? a.add(i) : a.delete(i), o(a)
                } else o(z_(e, s))
            })
        },
        mounted: rp,
        beforeUpdate(e, t, n) {
            e[Bn] = fi(n), rp(e, t, n)
        }
    };

function rp(e, {
    value: t,
    oldValue: n
}, r) {
    e._modelValue = t, we(t) ? e.checked = Vl(t, r.props.value) > -1 : es(t) ? e.checked = t.has(r.props.value) : t !== n && (e.checked = ai(t, z_(e, !0)))
}
const Nf = {
        created(e, {
            value: t
        }, n) {
            e.checked = ai(t, n.props.value), e[Bn] = fi(n), Tr(e, "change", () => {
                e[Bn](ks(e))
            })
        },
        beforeUpdate(e, {
            value: t,
            oldValue: n
        }, r) {
            e[Bn] = fi(r), t !== n && (e.checked = ai(t, r.props.value))
        }
    },
    W_ = {
        deep: !0,
        created(e, {
            value: t,
            modifiers: {
                number: n
            }
        }, r) {
            const i = es(t);
            Tr(e, "change", () => {
                const s = Array.prototype.filter.call(e.options, o => o.selected).map(o => n ? sl(ks(o)) : ks(o));
                e[Bn](e.multiple ? i ? new Set(s) : s : s[0]), e._assigning = !0, Ws(() => {
                    e._assigning = !1
                })
            }), e[Bn] = fi(r)
        },
        mounted(e, {
            value: t,
            modifiers: {
                number: n
            }
        }) {
            ip(e, t)
        },
        beforeUpdate(e, t, n) {
            e[Bn] = fi(n)
        },
        updated(e, {
            value: t,
            modifiers: {
                number: n
            }
        }) {
            e._assigning || ip(e, t)
        }
    };

function ip(e, t, n) {
    const r = e.multiple,
        i = we(t);
    if (!(r && !i && !es(t))) {
        for (let s = 0, o = e.options.length; s < o; s++) {
            const a = e.options[s],
                l = ks(a);
            if (r)
                if (i) {
                    const u = typeof l;
                    u === "string" || u === "number" ? a.selected = t.some(f => String(f) === String(l)) : a.selected = Vl(t, l) > -1
                } else a.selected = t.has(l);
            else if (ai(ks(a), t)) {
                e.selectedIndex !== s && (e.selectedIndex = s);
                return
            }
        }!r && e.selectedIndex !== -1 && (e.selectedIndex = -1)
    }
}

function ks(e) {
    return "_value" in e ? e._value : e.value
}

function z_(e, t) {
    const n = t ? "_trueValue" : "_falseValue";
    return n in e ? e[n] : t
}
const q_ = {
    created(e, t, n) {
        Pa(e, t, n, null, "created")
    },
    mounted(e, t, n) {
        Pa(e, t, n, null, "mounted")
    },
    beforeUpdate(e, t, n, r) {
        Pa(e, t, n, r, "beforeUpdate")
    },
    updated(e, t, n, r) {
        Pa(e, t, n, r, "updated")
    }
};

function K_(e, t) {
    switch (e) {
        case "SELECT":
            return W_;
        case "TEXTAREA":
            return gl;
        default:
            switch (t) {
                case "checkbox":
                    return Lf;
                case "radio":
                    return Nf;
                default:
                    return gl
            }
    }
}

function Pa(e, t, n, r, i) {
    const o = K_(e.tagName, n.props && n.props.type)[i];
    o && o(e, t, n, r)
}

function gA() {
    gl.getSSRProps = ({
        value: e
    }) => ({
        value: e
    }), Nf.getSSRProps = ({
        value: e
    }, t) => {
        if (t.props && ai(t.props.value, e)) return {
            checked: !0
        }
    }, Lf.getSSRProps = ({
        value: e
    }, t) => {
        if (we(e)) {
            if (t.props && Vl(e, t.props.value) > -1) return {
                checked: !0
            }
        } else if (es(e)) {
            if (t.props && e.has(t.props.value)) return {
                checked: !0
            }
        } else if (e) return {
            checked: !0
        }
    }, q_.getSSRProps = (e, t) => {
        if (typeof t.type != "string") return;
        const n = K_(t.type.toUpperCase(), t.props && t.props.type);
        if (n.getSSRProps) return n.getSSRProps(e, t)
    }
}
const _A = ["ctrl", "shift", "alt", "meta"],
    vA = {
        stop: e => e.stopPropagation(),
        prevent: e => e.preventDefault(),
        self: e => e.target !== e.currentTarget,
        ctrl: e => !e.ctrlKey,
        shift: e => !e.shiftKey,
        alt: e => !e.altKey,
        meta: e => !e.metaKey,
        left: e => "button" in e && e.button !== 0,
        middle: e => "button" in e && e.button !== 1,
        right: e => "button" in e && e.button !== 2,
        exact: (e, t) => _A.some(n => e[`${n}Key`] && !t.includes(n))
    },
    yA = (e, t) => {
        const n = e._withMods || (e._withMods = {}),
            r = t.join(".");
        return n[r] || (n[r] = (i, ...s) => {
            for (let o = 0; o < t.length; o++) {
                const a = vA[t[o]];
                if (a && a(i, t)) return
            }
            return e(i, ...s)
        })
    },
    bA = {
        esc: "escape",
        space: " ",
        up: "arrow-up",
        left: "arrow-left",
        right: "arrow-right",
        down: "arrow-down",
        delete: "backspace"
    },
    wA = (e, t) => {
        const n = e._withKeys || (e._withKeys = {}),
            r = t.join(".");
        return n[r] || (n[r] = i => {
            if (!("key" in i)) return;
            const s = Pn(i.key);
            if (t.some(o => o === s || bA[o] === s)) return e(i)
        })
    },
    G_ = rt({
        patchProp: sA
    }, BE);
let co, sp = !1;

function Y_() {
    return co || (co = m_(G_))
}

function X_() {
    return co = sp ? co : g_(G_), sp = !0, co
}
const Su = (...e) => {
        Y_().render(...e)
    },
    J_ = (...e) => {
        X_().hydrate(...e)
    },
    Z_ = (...e) => {
        const t = Y_().createApp(...e),
            {
                mount: n
            } = t;
        return t.mount = r => {
            const i = ev(r);
            if (!i) return;
            const s = t._component;
            !Re(s) && !s.render && !s.template && (s.template = i.innerHTML), i.innerHTML = "";
            const o = n(i, !1, Q_(i));
            return i instanceof Element && (i.removeAttribute("v-cloak"), i.setAttribute("data-v-app", "")), o
        }, t
    },
    SA = (...e) => {
        const t = X_().createApp(...e),
            {
                mount: n
            } = t;
        return t.mount = r => {
            const i = ev(r);
            if (i) return n(i, !0, Q_(i))
        }, t
    };

function Q_(e) {
    if (e instanceof SVGElement) return "svg";
    if (typeof MathMLElement == "function" && e instanceof MathMLElement) return "mathml"
}

function ev(e) {
    return He(e) ? document.querySelector(e) : e
}
let op = !1;
const TA = () => {
        op || (op = !0, gA(), zE())
    },
    CA = Object.freeze(Object.defineProperty({
        __proto__: null,
        BaseTransition: zg,
        BaseTransitionPropsValidators: Mf,
        Comment: sn,
        DeprecationTypes: FE,
        EffectScope: hf,
        ErrorCodes: aC,
        ErrorTypeStrings: ME,
        Fragment: nt,
        KeepAlive: IC,
        ReactiveEffect: Ms,
        Static: Ni,
        Suspense: Dg,
        Teleport: gE,
        Text: zi,
        TrackOpTypes: iC,
        Transition: Mr,
        TransitionGroup: U_,
        TriggerOpTypes: sC,
        VueElement: tc,
        assertNumber: oC,
        callWithAsyncErrorHandling: Rn,
        callWithErrorHandling: xr,
        camelize: kt,
        capitalize: ts,
        cloneVNode: hr,
        compatUtils: NE,
        computed: Ht,
        createApp: Z_,
        createBlock: Et,
        createCommentVNode: dt,
        createElementBlock: pe,
        createElementVNode: qe,
        createHydrationRenderer: g_,
        createPropsRestProxy: GC,
        createRenderer: m_,
        createSSRApp: SA,
        createSlots: kC,
        createStaticVNode: yE,
        createTextVNode: Pr,
        createVNode: Pe,
        customRef: Tf,
        defineAsyncComponent: Kg,
        defineComponent: qo,
        defineCustomElement: j_,
        defineEmits: DC,
        defineExpose: jC,
        defineModel: HC,
        defineOptions: BC,
        defineProps: FC,
        defineSSRCustomElement: aA,
        defineSlots: VC,
        devtools: RE,
        effect: xT,
        effectScope: ET,
        getCurrentInstance: Jn,
        getCurrentScope: pf,
        getTransitionRawChildren: Gl,
        guardReactiveProps: C_,
        h: ec,
        handleError: rs,
        hasInjectionContext: rE,
        hydrate: J_,
        initCustomFormatter: xE,
        initDirectivesForSSR: TA,
        inject: fr,
        isMemoSame: R_,
        isProxy: yf,
        isReactive: Ts,
        isReadonly: Rs,
        isRef: an,
        isRuntimeOnly: TE,
        isShallow: wo,
        isVNode: ci,
        markRaw: Eg,
        mergeDefaults: qC,
        mergeModels: KC,
        mergeProps: ui,
        nextTick: Ws,
        normalizeClass: Ot,
        normalizeProps: ag,
        normalizeStyle: ns,
        onActivated: Gg,
        onBeforeMount: Jg,
        onBeforeUnmount: Jl,
        onBeforeUpdate: Zg,
        onDeactivated: Yg,
        onErrorCaptured: n_,
        onMounted: is,
        onRenderTracked: t_,
        onRenderTriggered: e_,
        onScopeDispose: fg,
        onServerPrefetch: Qg,
        onUnmounted: Zl,
        onUpdated: Xl,
        openBlock: Q,
        popScopeId: mC,
        provide: oo,
        proxyRefs: Sf,
        pushScopeId: pC,
        queuePostFlushCb: ll,
        reactive: li,
        readonly: Cr,
        ref: Tn,
        registerRuntimeCompiler: O_,
        render: Su,
        renderList: Wi,
        renderSlot: Mt,
        resolveComponent: vt,
        resolveDirective: pt,
        resolveDynamicComponent: kr,
        resolveFilter: LE,
        resolveTransitionHooks: Is,
        setBlockTracking: pu,
        setDevtoolsHook: IE,
        setTransitionHooks: Ui,
        shallowReactive: vf,
        shallowReadonly: GT,
        shallowRef: xg,
        ssrContextKey: Bg,
        ssrUtils: kE,
        stop: OT,
        toDisplayString: Hi,
        toHandlerKey: ws,
        toHandlers: LC,
        toRaw: it,
        toRef: Pg,
        toRefs: tC,
        toValue: ZT,
        transformVNodeArgs: _E,
        triggerRef: JT,
        unref: Ar,
        useAttrs: zC,
        useCssModule: cA,
        useCssVars: qE,
        useModel: AE,
        useSSRContext: Vg,
        useSlots: WC,
        useTransitionState: Pf,
        vModelCheckbox: Lf,
        vModelDynamic: q_,
        vModelRadio: Nf,
        vModelSelect: W_,
        vModelText: gl,
        vShow: Oo,
        version: I_,
        warn: PE,
        watch: zn,
        watchEffect: OC,
        watchPostEffect: Hg,
        watchSyncEffect: Ug,
        withAsyncContext: YC,
        withCtx: Ct,
        withDefaults: UC,
        withDirectives: zt,
        withKeys: wA,
        withMemo: OE,
        withModifiers: yA,
        withScopeId: gC
    }, Symbol.toStringTag, {
        value: "Module"
    }));
/**
 * @vue/compiler-core v3.4.27
 * (c) 2018-present Yuxi (Evan) You and Vue contributors
 * @license MIT
 **/
const Po = Symbol(""),
    uo = Symbol(""),
    Ff = Symbol(""),
    _l = Symbol(""),
    tv = Symbol(""),
    Gi = Symbol(""),
    nv = Symbol(""),
    rv = Symbol(""),
    Df = Symbol(""),
    jf = Symbol(""),
    Yo = Symbol(""),
    Bf = Symbol(""),
    iv = Symbol(""),
    Vf = Symbol(""),
    Hf = Symbol(""),
    Uf = Symbol(""),
    Wf = Symbol(""),
    zf = Symbol(""),
    qf = Symbol(""),
    sv = Symbol(""),
    ov = Symbol(""),
    nc = Symbol(""),
    vl = Symbol(""),
    Kf = Symbol(""),
    Gf = Symbol(""),
    Mo = Symbol(""),
    Xo = Symbol(""),
    Yf = Symbol(""),
    Tu = Symbol(""),
    EA = Symbol(""),
    Cu = Symbol(""),
    yl = Symbol(""),
    AA = Symbol(""),
    xA = Symbol(""),
    Xf = Symbol(""),
    OA = Symbol(""),
    PA = Symbol(""),
    Jf = Symbol(""),
    av = Symbol(""),
    Ls = {
        [Po]: "Fragment",
        [uo]: "Teleport",
        [Ff]: "Suspense",
        [_l]: "KeepAlive",
        [tv]: "BaseTransition",
        [Gi]: "openBlock",
        [nv]: "createBlock",
        [rv]: "createElementBlock",
        [Df]: "createVNode",
        [jf]: "createElementVNode",
        [Yo]: "createCommentVNode",
        [Bf]: "createTextVNode",
        [iv]: "createStaticVNode",
        [Vf]: "resolveComponent",
        [Hf]: "resolveDynamicComponent",
        [Uf]: "resolveDirective",
        [Wf]: "resolveFilter",
        [zf]: "withDirectives",
        [qf]: "renderList",
        [sv]: "renderSlot",
        [ov]: "createSlots",
        [nc]: "toDisplayString",
        [vl]: "mergeProps",
        [Kf]: "normalizeClass",
        [Gf]: "normalizeStyle",
        [Mo]: "normalizeProps",
        [Xo]: "guardReactiveProps",
        [Yf]: "toHandlers",
        [Tu]: "camelize",
        [EA]: "capitalize",
        [Cu]: "toHandlerKey",
        [yl]: "setBlockTracking",
        [AA]: "pushScopeId",
        [xA]: "popScopeId",
        [Xf]: "withCtx",
        [OA]: "unref",
        [PA]: "isRef",
        [Jf]: "withMemo",
        [av]: "isMemoSame"
    };

function MA(e) {
    Object.getOwnPropertySymbols(e).forEach(t => {
        Ls[t] = e[t]
    })
}
const $n = {
    start: {
        line: 1,
        column: 1,
        offset: 0
    },
    end: {
        line: 1,
        column: 1,
        offset: 0
    },
    source: ""
};

function RA(e, t = "") {
    return {
        type: 0,
        source: t,
        children: e,
        helpers: new Set,
        components: [],
        directives: [],
        hoists: [],
        imports: [],
        cached: 0,
        temps: 0,
        codegenNode: void 0,
        loc: $n
    }
}

function Ro(e, t, n, r, i, s, o, a = !1, l = !1, u = !1, f = $n) {
    return e && (a ? (e.helper(Gi), e.helper(Ds(e.inSSR, u))) : e.helper(Fs(e.inSSR, u)), o && e.helper(zf)), {
        type: 13,
        tag: t,
        props: n,
        children: r,
        patchFlag: i,
        dynamicProps: s,
        directives: o,
        isBlock: a,
        disableTracking: l,
        isComponent: u,
        loc: f
    }
}

function Jo(e, t = $n) {
    return {
        type: 17,
        loc: t,
        elements: e
    }
}

function Dn(e, t = $n) {
    return {
        type: 15,
        loc: t,
        properties: e
    }
}

function Bt(e, t) {
    return {
        type: 16,
        loc: $n,
        key: He(e) ? We(e, !0) : e,
        value: t
    }
}

function We(e, t = !1, n = $n, r = 0) {
    return {
        type: 4,
        loc: n,
        content: e,
        isStatic: t,
        constType: t ? 3 : r
    }
}

function qn(e, t = $n) {
    return {
        type: 8,
        loc: t,
        children: e
    }
}

function Xt(e, t = [], n = $n) {
    return {
        type: 14,
        loc: n,
        callee: e,
        arguments: t
    }
}

function Ns(e, t = void 0, n = !1, r = !1, i = $n) {
    return {
        type: 18,
        params: e,
        returns: t,
        newline: n,
        isSlot: r,
        loc: i
    }
}

function Eu(e, t, n, r = !0) {
    return {
        type: 19,
        test: e,
        consequent: t,
        alternate: n,
        newline: r,
        loc: $n
    }
}

function IA(e, t, n = !1) {
    return {
        type: 20,
        index: e,
        value: t,
        isVNode: n,
        loc: $n
    }
}

function $A(e) {
    return {
        type: 21,
        body: e,
        loc: $n
    }
}

function Fs(e, t) {
    return e || t ? Df : jf
}

function Ds(e, t) {
    return e || t ? nv : rv
}

function Zf(e, {
    helper: t,
    removeHelper: n,
    inSSR: r
}) {
    e.isBlock || (e.isBlock = !0, n(Fs(r, e.isComponent)), t(Gi), t(Ds(r, e.isComponent)))
}
const ap = new Uint8Array([123, 123]),
    lp = new Uint8Array([125, 125]);

function cp(e) {
    return e >= 97 && e <= 122 || e >= 65 && e <= 90
}

function xn(e) {
    return e === 32 || e === 10 || e === 9 || e === 12 || e === 13
}

function Vr(e) {
    return e === 47 || e === 62 || xn(e)
}

function bl(e) {
    const t = new Uint8Array(e.length);
    for (let n = 0; n < e.length; n++) t[n] = e.charCodeAt(n);
    return t
}
const cn = {
    Cdata: new Uint8Array([67, 68, 65, 84, 65, 91]),
    CdataEnd: new Uint8Array([93, 93, 62]),
    CommentEnd: new Uint8Array([45, 45, 62]),
    ScriptEnd: new Uint8Array([60, 47, 115, 99, 114, 105, 112, 116]),
    StyleEnd: new Uint8Array([60, 47, 115, 116, 121, 108, 101]),
    TitleEnd: new Uint8Array([60, 47, 116, 105, 116, 108, 101]),
    TextareaEnd: new Uint8Array([60, 47, 116, 101, 120, 116, 97, 114, 101, 97])
};
class kA {
    constructor(t, n) {
        this.stack = t, this.cbs = n, this.state = 1, this.buffer = "", this.sectionStart = 0, this.index = 0, this.entityStart = 0, this.baseState = 1, this.inRCDATA = !1, this.inXML = !1, this.inVPre = !1, this.newlines = [], this.mode = 0, this.delimiterOpen = ap, this.delimiterClose = lp, this.delimiterIndex = -1, this.currentSequence = void 0, this.sequenceIndex = 0
    }
    get inSFCRoot() {
        return this.mode === 2 && this.stack.length === 0
    }
    reset() {
        this.state = 1, this.mode = 0, this.buffer = "", this.sectionStart = 0, this.index = 0, this.baseState = 1, this.inRCDATA = !1, this.currentSequence = void 0, this.newlines.length = 0, this.delimiterOpen = ap, this.delimiterClose = lp
    }
    getPos(t) {
        let n = 1,
            r = t + 1;
        for (let i = this.newlines.length - 1; i >= 0; i--) {
            const s = this.newlines[i];
            if (t > s) {
                n = i + 2, r = t - s;
                break
            }
        }
        return {
            column: r,
            line: n,
            offset: t
        }
    }
    peek() {
        return this.buffer.charCodeAt(this.index + 1)
    }
    stateText(t) {
        t === 60 ? (this.index > this.sectionStart && this.cbs.ontext(this.sectionStart, this.index), this.state = 5, this.sectionStart = this.index) : !this.inVPre && t === this.delimiterOpen[0] && (this.state = 2, this.delimiterIndex = 0, this.stateInterpolationOpen(t))
    }
    stateInterpolationOpen(t) {
        if (t === this.delimiterOpen[this.delimiterIndex])
            if (this.delimiterIndex === this.delimiterOpen.length - 1) {
                const n = this.index + 1 - this.delimiterOpen.length;
                n > this.sectionStart && this.cbs.ontext(this.sectionStart, n), this.state = 3, this.sectionStart = n
            } else this.delimiterIndex++;
        else this.inRCDATA ? (this.state = 32, this.stateInRCDATA(t)) : (this.state = 1, this.stateText(t))
    }
    stateInterpolation(t) {
        t === this.delimiterClose[0] && (this.state = 4, this.delimiterIndex = 0, this.stateInterpolationClose(t))
    }
    stateInterpolationClose(t) {
        t === this.delimiterClose[this.delimiterIndex] ? this.delimiterIndex === this.delimiterClose.length - 1 ? (this.cbs.oninterpolation(this.sectionStart, this.index + 1), this.inRCDATA ? this.state = 32 : this.state = 1, this.sectionStart = this.index + 1) : this.delimiterIndex++ : (this.state = 3, this.stateInterpolation(t))
    }
    stateSpecialStartSequence(t) {
        const n = this.sequenceIndex === this.currentSequence.length;
        if (!(n ? Vr(t) : (t | 32) === this.currentSequence[this.sequenceIndex])) this.inRCDATA = !1;
        else if (!n) {
            this.sequenceIndex++;
            return
        }
        this.sequenceIndex = 0, this.state = 6, this.stateInTagName(t)
    }
    stateInRCDATA(t) {
        if (this.sequenceIndex === this.currentSequence.length) {
            if (t === 62 || xn(t)) {
                const n = this.index - this.currentSequence.length;
                if (this.sectionStart < n) {
                    const r = this.index;
                    this.index = n, this.cbs.ontext(this.sectionStart, n), this.index = r
                }
                this.sectionStart = n + 2, this.stateInClosingTagName(t), this.inRCDATA = !1;
                return
            }
            this.sequenceIndex = 0
        }(t | 32) === this.currentSequence[this.sequenceIndex] ? this.sequenceIndex += 1 : this.sequenceIndex === 0 ? this.currentSequence === cn.TitleEnd || this.currentSequence === cn.TextareaEnd && !this.inSFCRoot ? t === this.delimiterOpen[0] && (this.state = 2, this.delimiterIndex = 0, this.stateInterpolationOpen(t)) : this.fastForwardTo(60) && (this.sequenceIndex = 1) : this.sequenceIndex = +(t === 60)
    }
    stateCDATASequence(t) {
        t === cn.Cdata[this.sequenceIndex] ? ++this.sequenceIndex === cn.Cdata.length && (this.state = 28, this.currentSequence = cn.CdataEnd, this.sequenceIndex = 0, this.sectionStart = this.index + 1) : (this.sequenceIndex = 0, this.state = 23, this.stateInDeclaration(t))
    }
    fastForwardTo(t) {
        for (; ++this.index < this.buffer.length;) {
            const n = this.buffer.charCodeAt(this.index);
            if (n === 10 && this.newlines.push(this.index), n === t) return !0
        }
        return this.index = this.buffer.length - 1, !1
    }
    stateInCommentLike(t) {
        t === this.currentSequence[this.sequenceIndex] ? ++this.sequenceIndex === this.currentSequence.length && (this.currentSequence === cn.CdataEnd ? this.cbs.oncdata(this.sectionStart, this.index - 2) : this.cbs.oncomment(this.sectionStart, this.index - 2), this.sequenceIndex = 0, this.sectionStart = this.index + 1, this.state = 1) : this.sequenceIndex === 0 ? this.fastForwardTo(this.currentSequence[0]) && (this.sequenceIndex = 1) : t !== this.currentSequence[this.sequenceIndex - 1] && (this.sequenceIndex = 0)
    }
    startSpecial(t, n) {
        this.enterRCDATA(t, n), this.state = 31
    }
    enterRCDATA(t, n) {
        this.inRCDATA = !0, this.currentSequence = t, this.sequenceIndex = n
    }
    stateBeforeTagName(t) {
        t === 33 ? (this.state = 22, this.sectionStart = this.index + 1) : t === 63 ? (this.state = 24, this.sectionStart = this.index + 1) : cp(t) ? (this.sectionStart = this.index, this.mode === 0 ? this.state = 6 : this.inSFCRoot ? this.state = 34 : this.inXML ? this.state = 6 : t === 116 ? this.state = 30 : this.state = t === 115 ? 29 : 6) : t === 47 ? this.state = 8 : (this.state = 1, this.stateText(t))
    }
    stateInTagName(t) {
        Vr(t) && this.handleTagName(t)
    }
    stateInSFCRootTagName(t) {
        if (Vr(t)) {
            const n = this.buffer.slice(this.sectionStart, this.index);
            n !== "template" && this.enterRCDATA(bl("</" + n), 0), this.handleTagName(t)
        }
    }
    handleTagName(t) {
        this.cbs.onopentagname(this.sectionStart, this.index), this.sectionStart = -1, this.state = 11, this.stateBeforeAttrName(t)
    }
    stateBeforeClosingTagName(t) {
        xn(t) || (t === 62 ? (this.state = 1, this.sectionStart = this.index + 1) : (this.state = cp(t) ? 9 : 27, this.sectionStart = this.index))
    }
    stateInClosingTagName(t) {
        (t === 62 || xn(t)) && (this.cbs.onclosetag(this.sectionStart, this.index), this.sectionStart = -1, this.state = 10, this.stateAfterClosingTagName(t))
    }
    stateAfterClosingTagName(t) {
        t === 62 && (this.state = 1, this.sectionStart = this.index + 1)
    }
    stateBeforeAttrName(t) {
        t === 62 ? (this.cbs.onopentagend(this.index), this.inRCDATA ? this.state = 32 : this.state = 1, this.sectionStart = this.index + 1) : t === 47 ? this.state = 7 : t === 60 && this.peek() === 47 ? (this.cbs.onopentagend(this.index), this.state = 5, this.sectionStart = this.index) : xn(t) || this.handleAttrStart(t)
    }
    handleAttrStart(t) {
        t === 118 && this.peek() === 45 ? (this.state = 13, this.sectionStart = this.index) : t === 46 || t === 58 || t === 64 || t === 35 ? (this.cbs.ondirname(this.index, this.index + 1), this.state = 14, this.sectionStart = this.index + 1) : (this.state = 12, this.sectionStart = this.index)
    }
    stateInSelfClosingTag(t) {
        t === 62 ? (this.cbs.onselfclosingtag(this.index), this.state = 1, this.sectionStart = this.index + 1, this.inRCDATA = !1) : xn(t) || (this.state = 11, this.stateBeforeAttrName(t))
    }
    stateInAttrName(t) {
        (t === 61 || Vr(t)) && (this.cbs.onattribname(this.sectionStart, this.index), this.handleAttrNameEnd(t))
    }
    stateInDirName(t) {
        t === 61 || Vr(t) ? (this.cbs.ondirname(this.sectionStart, this.index), this.handleAttrNameEnd(t)) : t === 58 ? (this.cbs.ondirname(this.sectionStart, this.index), this.state = 14, this.sectionStart = this.index + 1) : t === 46 && (this.cbs.ondirname(this.sectionStart, this.index), this.state = 16, this.sectionStart = this.index + 1)
    }
    stateInDirArg(t) {
        t === 61 || Vr(t) ? (this.cbs.ondirarg(this.sectionStart, this.index), this.handleAttrNameEnd(t)) : t === 91 ? this.state = 15 : t === 46 && (this.cbs.ondirarg(this.sectionStart, this.index), this.state = 16, this.sectionStart = this.index + 1)
    }
    stateInDynamicDirArg(t) {
        t === 93 ? this.state = 14 : (t === 61 || Vr(t)) && (this.cbs.ondirarg(this.sectionStart, this.index + 1), this.handleAttrNameEnd(t))
    }
    stateInDirModifier(t) {
        t === 61 || Vr(t) ? (this.cbs.ondirmodifier(this.sectionStart, this.index), this.handleAttrNameEnd(t)) : t === 46 && (this.cbs.ondirmodifier(this.sectionStart, this.index), this.sectionStart = this.index + 1)
    }
    handleAttrNameEnd(t) {
        this.sectionStart = this.index, this.state = 17, this.cbs.onattribnameend(this.index), this.stateAfterAttrName(t)
    }
    stateAfterAttrName(t) {
        t === 61 ? this.state = 18 : t === 47 || t === 62 ? (this.cbs.onattribend(0, this.sectionStart), this.sectionStart = -1, this.state = 11, this.stateBeforeAttrName(t)) : xn(t) || (this.cbs.onattribend(0, this.sectionStart), this.handleAttrStart(t))
    }
    stateBeforeAttrValue(t) {
        t === 34 ? (this.state = 19, this.sectionStart = this.index + 1) : t === 39 ? (this.state = 20, this.sectionStart = this.index + 1) : xn(t) || (this.sectionStart = this.index, this.state = 21, this.stateInAttrValueNoQuotes(t))
    }
    handleInAttrValue(t, n) {
        (t === n || this.fastForwardTo(n)) && (this.cbs.onattribdata(this.sectionStart, this.index), this.sectionStart = -1, this.cbs.onattribend(n === 34 ? 3 : 2, this.index + 1), this.state = 11)
    }
    stateInAttrValueDoubleQuotes(t) {
        this.handleInAttrValue(t, 34)
    }
    stateInAttrValueSingleQuotes(t) {
        this.handleInAttrValue(t, 39)
    }
    stateInAttrValueNoQuotes(t) {
        xn(t) || t === 62 ? (this.cbs.onattribdata(this.sectionStart, this.index), this.sectionStart = -1, this.cbs.onattribend(1, this.index), this.state = 11, this.stateBeforeAttrName(t)) : (t === 39 || t === 60 || t === 61 || t === 96) && this.cbs.onerr(18, this.index)
    }
    stateBeforeDeclaration(t) {
        t === 91 ? (this.state = 26, this.sequenceIndex = 0) : this.state = t === 45 ? 25 : 23
    }
    stateInDeclaration(t) {
        (t === 62 || this.fastForwardTo(62)) && (this.state = 1, this.sectionStart = this.index + 1)
    }
    stateInProcessingInstruction(t) {
        (t === 62 || this.fastForwardTo(62)) && (this.cbs.onprocessinginstruction(this.sectionStart, this.index), this.state = 1, this.sectionStart = this.index + 1)
    }
    stateBeforeComment(t) {
        t === 45 ? (this.state = 28, this.currentSequence = cn.CommentEnd, this.sequenceIndex = 2, this.sectionStart = this.index + 1) : this.state = 23
    }
    stateInSpecialComment(t) {
        (t === 62 || this.fastForwardTo(62)) && (this.cbs.oncomment(this.sectionStart, this.index), this.state = 1, this.sectionStart = this.index + 1)
    }
    stateBeforeSpecialS(t) {
        t === cn.ScriptEnd[3] ? this.startSpecial(cn.ScriptEnd, 4) : t === cn.StyleEnd[3] ? this.startSpecial(cn.StyleEnd, 4) : (this.state = 6, this.stateInTagName(t))
    }
    stateBeforeSpecialT(t) {
        t === cn.TitleEnd[3] ? this.startSpecial(cn.TitleEnd, 4) : t === cn.TextareaEnd[3] ? this.startSpecial(cn.TextareaEnd, 4) : (this.state = 6, this.stateInTagName(t))
    }
    startEntity() {}
    stateInEntity() {}
    parse(t) {
        for (this.buffer = t; this.index < this.buffer.length;) {
            const n = this.buffer.charCodeAt(this.index);
            switch (n === 10 && this.newlines.push(this.index), this.state) {
                case 1:
                    {
                        this.stateText(n);
                        break
                    }
                case 2:
                    {
                        this.stateInterpolationOpen(n);
                        break
                    }
                case 3:
                    {
                        this.stateInterpolation(n);
                        break
                    }
                case 4:
                    {
                        this.stateInterpolationClose(n);
                        break
                    }
                case 31:
                    {
                        this.stateSpecialStartSequence(n);
                        break
                    }
                case 32:
                    {
                        this.stateInRCDATA(n);
                        break
                    }
                case 26:
                    {
                        this.stateCDATASequence(n);
                        break
                    }
                case 19:
                    {
                        this.stateInAttrValueDoubleQuotes(n);
                        break
                    }
                case 12:
                    {
                        this.stateInAttrName(n);
                        break
                    }
                case 13:
                    {
                        this.stateInDirName(n);
                        break
                    }
                case 14:
                    {
                        this.stateInDirArg(n);
                        break
                    }
                case 15:
                    {
                        this.stateInDynamicDirArg(n);
                        break
                    }
                case 16:
                    {
                        this.stateInDirModifier(n);
                        break
                    }
                case 28:
                    {
                        this.stateInCommentLike(n);
                        break
                    }
                case 27:
                    {
                        this.stateInSpecialComment(n);
                        break
                    }
                case 11:
                    {
                        this.stateBeforeAttrName(n);
                        break
                    }
                case 6:
                    {
                        this.stateInTagName(n);
                        break
                    }
                case 34:
                    {
                        this.stateInSFCRootTagName(n);
                        break
                    }
                case 9:
                    {
                        this.stateInClosingTagName(n);
                        break
                    }
                case 5:
                    {
                        this.stateBeforeTagName(n);
                        break
                    }
                case 17:
                    {
                        this.stateAfterAttrName(n);
                        break
                    }
                case 20:
                    {
                        this.stateInAttrValueSingleQuotes(n);
                        break
                    }
                case 18:
                    {
                        this.stateBeforeAttrValue(n);
                        break
                    }
                case 8:
                    {
                        this.stateBeforeClosingTagName(n);
                        break
                    }
                case 10:
                    {
                        this.stateAfterClosingTagName(n);
                        break
                    }
                case 29:
                    {
                        this.stateBeforeSpecialS(n);
                        break
                    }
                case 30:
                    {
                        this.stateBeforeSpecialT(n);
                        break
                    }
                case 21:
                    {
                        this.stateInAttrValueNoQuotes(n);
                        break
                    }
                case 7:
                    {
                        this.stateInSelfClosingTag(n);
                        break
                    }
                case 23:
                    {
                        this.stateInDeclaration(n);
                        break
                    }
                case 22:
                    {
                        this.stateBeforeDeclaration(n);
                        break
                    }
                case 25:
                    {
                        this.stateBeforeComment(n);
                        break
                    }
                case 24:
                    {
                        this.stateInProcessingInstruction(n);
                        break
                    }
                case 33:
                    {
                        this.stateInEntity();
                        break
                    }
            }
            this.index++
        }
        this.cleanup(), this.finish()
    }
    cleanup() {
        this.sectionStart !== this.index && (this.state === 1 || this.state === 32 && this.sequenceIndex === 0 ? (this.cbs.ontext(this.sectionStart, this.index), this.sectionStart = this.index) : (this.state === 19 || this.state === 20 || this.state === 21) && (this.cbs.onattribdata(this.sectionStart, this.index), this.sectionStart = this.index))
    }
    finish() {
        this.handleTrailingData(), this.cbs.onend()
    }
    handleTrailingData() {
        const t = this.buffer.length;
        this.sectionStart >= t || (this.state === 28 ? this.currentSequence === cn.CdataEnd ? this.cbs.oncdata(this.sectionStart, t) : this.cbs.oncomment(this.sectionStart, t) : this.state === 6 || this.state === 11 || this.state === 18 || this.state === 17 || this.state === 12 || this.state === 13 || this.state === 14 || this.state === 15 || this.state === 16 || this.state === 20 || this.state === 19 || this.state === 21 || this.state === 9 || this.cbs.ontext(this.sectionStart, t))
    }
    emitCodePoint(t, n) {}
}

function up(e, {
    compatConfig: t
}) {
    const n = t && t[e];
    return e === "MODE" ? n || 3 : n
}

function Fi(e, t) {
    const n = up("MODE", t),
        r = up(e, t);
    return n === 3 ? r === !0 : r !== !1
}

function Io(e, t, n, ...r) {
    return Fi(e, t)
}

function Qf(e) {
    throw e
}

function lv(e) {}

function It(e, t, n, r) {
    const i = `https://vuejs.org/error-reference/#compiler-${e}`,
        s = new SyntaxError(String(i));
    return s.code = e, s.loc = t, s
}
const Sn = e => e.type === 4 && e.isStatic;

function cv(e) {
    switch (e) {
        case "Teleport":
        case "teleport":
            return uo;
        case "Suspense":
        case "suspense":
            return Ff;
        case "KeepAlive":
        case "keep-alive":
            return _l;
        case "BaseTransition":
        case "base-transition":
            return tv
    }
}
const LA = /^\d|[^\$\w]/,
    ed = e => !LA.test(e),
    NA = /[A-Za-z_$\xA0-\uFFFF]/,
    FA = /[\.\?\w$\xA0-\uFFFF]/,
    DA = /\s+[.[]\s*|\s*[.[]\s+/g,
    jA = e => {
        e = e.trim().replace(DA, o => o.trim());
        let t = 0,
            n = [],
            r = 0,
            i = 0,
            s = null;
        for (let o = 0; o < e.length; o++) {
            const a = e.charAt(o);
            switch (t) {
                case 0:
                    if (a === "[") n.push(t), t = 1, r++;
                    else if (a === "(") n.push(t), t = 2, i++;
                    else if (!(o === 0 ? NA : FA).test(a)) return !1;
                    break;
                case 1:
                    a === "'" || a === '"' || a === "`" ? (n.push(t), t = 3, s = a) : a === "[" ? r++ : a === "]" && (--r || (t = n.pop()));
                    break;
                case 2:
                    if (a === "'" || a === '"' || a === "`") n.push(t), t = 3, s = a;
                    else if (a === "(") i++;
                    else if (a === ")") {
                        if (o === e.length - 1) return !1;
                        --i || (t = n.pop())
                    }
                    break;
                case 3:
                    a === s && (t = n.pop(), s = null);
                    break
            }
        }
        return !r && !i
    },
    uv = jA;

function Un(e, t, n = !1) {
    for (let r = 0; r < e.props.length; r++) {
        const i = e.props[r];
        if (i.type === 7 && (n || i.exp) && (He(t) ? i.name === t : t.test(i.name))) return i
    }
}

function rc(e, t, n = !1, r = !1) {
    for (let i = 0; i < e.props.length; i++) {
        const s = e.props[i];
        if (s.type === 6) {
            if (n) continue;
            if (s.name === t && (s.value || r)) return s
        } else if (s.name === "bind" && (s.exp || r) && Ai(s.arg, t)) return s
    }
}

function Ai(e, t) {
    return !!(e && Sn(e) && e.content === t)
}

function BA(e) {
    return e.props.some(t => t.type === 7 && t.name === "bind" && (!t.arg || t.arg.type !== 4 || !t.arg.isStatic))
}

function kc(e) {
    return e.type === 5 || e.type === 2
}

function VA(e) {
    return e.type === 7 && e.name === "slot"
}

function wl(e) {
    return e.type === 1 && e.tagType === 3
}

function Sl(e) {
    return e.type === 1 && e.tagType === 2
}
const HA = new Set([Mo, Xo]);

function fv(e, t = []) {
    if (e && !He(e) && e.type === 14) {
        const n = e.callee;
        if (!He(n) && HA.has(n)) return fv(e.arguments[0], t.concat(e))
    }
    return [e, t]
}

function Tl(e, t, n) {
    let r, i = e.type === 13 ? e.props : e.arguments[2],
        s = [],
        o;
    if (i && !He(i) && i.type === 14) {
        const a = fv(i);
        i = a[0], s = a[1], o = s[s.length - 1]
    }
    if (i == null || He(i)) r = Dn([t]);
    else if (i.type === 14) {
        const a = i.arguments[0];
        !He(a) && a.type === 15 ? fp(t, a) || a.properties.unshift(t) : i.callee === Yf ? r = Xt(n.helper(vl), [Dn([t]), i]) : i.arguments.unshift(Dn([t])), !r && (r = i)
    } else i.type === 15 ? (fp(t, i) || i.properties.unshift(t), r = i) : (r = Xt(n.helper(vl), [Dn([t]), i]), o && o.callee === Xo && (o = s[s.length - 2]));
    e.type === 13 ? o ? o.arguments[0] = r : e.props = r : o ? o.arguments[0] = r : e.arguments[2] = r
}

function fp(e, t) {
    let n = !1;
    if (e.key.type === 4) {
        const r = e.key.content;
        n = t.properties.some(i => i.key.type === 4 && i.key.content === r)
    }
    return n
}

function $o(e, t) {
    return `_${t}_${e.replace(/[^\w]/g,(n,r)=>n==="-"?"_":e.charCodeAt(r).toString())}`
}

function UA(e) {
    return e.type === 14 && e.callee === Jf ? e.arguments[1].returns : e
}
const WA = /([\s\S]*?)\s+(?:in|of)\s+([\s\S]*)/,
    dv = {
        parseMode: "base",
        ns: 0,
        delimiters: ["{{", "}}"],
        getNamespace: () => 0,
        isVoidTag: Ba,
        isPreTag: Ba,
        isCustomElement: Ba,
        onError: Qf,
        onWarn: lv,
        comments: !1,
        prefixIdentifiers: !1
    };
let ht = dv,
    ko = null,
    Or = "",
    un = null,
    tt = null,
    _n = "",
    wr = -1,
    Ti = -1,
    Cl = 0,
    Jr = !1,
    Au = null;
const Pt = [],
    Ft = new kA(Pt, {
        onerr: vr,
        ontext(e, t) {
            Ma(tn(e, t), e, t)
        },
        ontextentity(e, t, n) {
            Ma(e, t, n)
        },
        oninterpolation(e, t) {
            if (Jr) return Ma(tn(e, t), e, t);
            let n = e + Ft.delimiterOpen.length,
                r = t - Ft.delimiterClose.length;
            for (; xn(Or.charCodeAt(n));) n++;
            for (; xn(Or.charCodeAt(r - 1));) r--;
            let i = tn(n, r);
            i.includes("&") && (i = ht.decodeEntities(i, !1)), xu({
                type: 5,
                content: za(i, !1, Gt(n, r)),
                loc: Gt(e, t)
            })
        },
        onopentagname(e, t) {
            const n = tn(e, t);
            un = {
                type: 1,
                tag: n,
                ns: ht.getNamespace(n, Pt[0], ht.ns),
                tagType: 0,
                props: [],
                children: [],
                loc: Gt(e - 1, t),
                codegenNode: void 0
            }
        },
        onopentagend(e) {
            hp(e)
        },
        onclosetag(e, t) {
            const n = tn(e, t);
            if (!ht.isVoidTag(n)) {
                let r = !1;
                for (let i = 0; i < Pt.length; i++)
                    if (Pt[i].tag.toLowerCase() === n.toLowerCase()) {
                        r = !0, i > 0 && vr(24, Pt[0].loc.start.offset);
                        for (let o = 0; o <= i; o++) {
                            const a = Pt.shift();
                            Wa(a, t, o < i)
                        }
                        break
                    }
                r || vr(23, hv(e, 60))
            }
        },
        onselfclosingtag(e) {
            const t = un.tag;
            un.isSelfClosing = !0, hp(e), Pt[0] && Pt[0].tag === t && Wa(Pt.shift(), e)
        },
        onattribname(e, t) {
            tt = {
                type: 6,
                name: tn(e, t),
                nameLoc: Gt(e, t),
                value: void 0,
                loc: Gt(e)
            }
        },
        ondirname(e, t) {
            const n = tn(e, t),
                r = n === "." || n === ":" ? "bind" : n === "@" ? "on" : n === "#" ? "slot" : n.slice(2);
            if (!Jr && r === "" && vr(26, e), Jr || r === "") tt = {
                type: 6,
                name: n,
                nameLoc: Gt(e, t),
                value: void 0,
                loc: Gt(e)
            };
            else if (tt = {
                    type: 7,
                    name: r,
                    rawName: n,
                    exp: void 0,
                    arg: void 0,
                    modifiers: n === "." ? ["prop"] : [],
                    loc: Gt(e)
                }, r === "pre") {
                Jr = Ft.inVPre = !0, Au = un;
                const i = un.props;
                for (let s = 0; s < i.length; s++) i[s].type === 7 && (i[s] = e3(i[s]))
            }
        },
        ondirarg(e, t) {
            if (e === t) return;
            const n = tn(e, t);
            if (Jr) tt.name += n, xi(tt.nameLoc, t);
            else {
                const r = n[0] !== "[";
                tt.arg = za(r ? n : n.slice(1, -1), r, Gt(e, t), r ? 3 : 0)
            }
        },
        ondirmodifier(e, t) {
            const n = tn(e, t);
            if (Jr) tt.name += "." + n, xi(tt.nameLoc, t);
            else if (tt.name === "slot") {
                const r = tt.arg;
                r && (r.content += "." + n, xi(r.loc, t))
            } else tt.modifiers.push(n)
        },
        onattribdata(e, t) {
            _n += tn(e, t), wr < 0 && (wr = e), Ti = t
        },
        onattribentity(e, t, n) {
            _n += e, wr < 0 && (wr = t), Ti = n
        },
        onattribnameend(e) {
            const t = tt.loc.start.offset,
                n = tn(t, e);
            tt.type === 7 && (tt.rawName = n), un.props.some(r => (r.type === 7 ? r.rawName : r.name) === n) && vr(2, t)
        },
        onattribend(e, t) {
            if (un && tt) {
                if (xi(tt.loc, t), e !== 0)
                    if (_n.includes("&") && (_n = ht.decodeEntities(_n, !0)), tt.type === 6) tt.name === "class" && (_n = mv(_n).trim()), e === 1 && !_n && vr(13, t), tt.value = {
                        type: 2,
                        content: _n,
                        loc: e === 1 ? Gt(wr, Ti) : Gt(wr - 1, Ti + 1)
                    }, Ft.inSFCRoot && un.tag === "template" && tt.name === "lang" && _n && _n !== "html" && Ft.enterRCDATA(bl("</template"), 0);
                    else {
                        let n = 0;
                        tt.exp = za(_n, !1, Gt(wr, Ti), 0, n), tt.name === "for" && (tt.forParseResult = qA(tt.exp));
                        let r = -1;
                        tt.name === "bind" && (r = tt.modifiers.indexOf("sync")) > -1 && Io("COMPILER_V_BIND_SYNC", ht, tt.loc, tt.rawName) && (tt.name = "model", tt.modifiers.splice(r, 1))
                    }(tt.type !== 7 || tt.name !== "pre") && un.props.push(tt)
            }
            _n = "", wr = Ti = -1
        },
        oncomment(e, t) {
            ht.comments && xu({
                type: 3,
                content: tn(e, t),
                loc: Gt(e - 4, t + 3)
            })
        },
        onend() {
            const e = Or.length;
            for (let t = 0; t < Pt.length; t++) Wa(Pt[t], e - 1), vr(24, Pt[t].loc.start.offset)
        },
        oncdata(e, t) {
            Pt[0].ns !== 0 ? Ma(tn(e, t), e, t) : vr(1, e - 9)
        },
        onprocessinginstruction(e) {
            (Pt[0] ? Pt[0].ns : ht.ns) === 0 && vr(21, e - 1)
        }
    }),
    dp = /,([^,\}\]]*)(?:,([^,\}\]]*))?$/,
    zA = /^\(|\)$/g;

function qA(e) {
    const t = e.loc,
        n = e.content,
        r = n.match(WA);
    if (!r) return;
    const [, i, s] = r, o = (h, _, m = !1) => {
        const T = t.start.offset + _,
            R = T + h.length;
        return za(h, !1, Gt(T, R), 0, m ? 1 : 0)
    }, a = {
        source: o(s.trim(), n.indexOf(s, i.length)),
        value: void 0,
        key: void 0,
        index: void 0,
        finalized: !1
    };
    let l = i.trim().replace(zA, "").trim();
    const u = i.indexOf(l),
        f = l.match(dp);
    if (f) {
        l = l.replace(dp, "").trim();
        const h = f[1].trim();
        let _;
        if (h && (_ = n.indexOf(h, u + l.length), a.key = o(h, _, !0)), f[2]) {
            const m = f[2].trim();
            m && (a.index = o(m, n.indexOf(m, a.key ? _ + h.length : u + l.length), !0))
        }
    }
    return l && (a.value = o(l, u, !0)), a
}

function tn(e, t) {
    return Or.slice(e, t)
}

function hp(e) {
    Ft.inSFCRoot && (un.innerLoc = Gt(e + 1, e + 1)), xu(un);
    const {
        tag: t,
        ns: n
    } = un;
    n === 0 && ht.isPreTag(t) && Cl++, ht.isVoidTag(t) ? Wa(un, e) : (Pt.unshift(un), (n === 1 || n === 2) && (Ft.inXML = !0)), un = null
}

function Ma(e, t, n) {
    {
        const s = Pt[0] && Pt[0].tag;
        s !== "script" && s !== "style" && e.includes("&") && (e = ht.decodeEntities(e, !1))
    }
    const r = Pt[0] || ko,
        i = r.children[r.children.length - 1];
    i && i.type === 2 ? (i.content += e, xi(i.loc, n)) : r.children.push({
        type: 2,
        content: e,
        loc: Gt(t, n)
    })
}

function Wa(e, t, n = !1) {
    n ? xi(e.loc, hv(t, 60)) : xi(e.loc, KA(t, 62) + 1), Ft.inSFCRoot && (e.children.length ? e.innerLoc.end = rt({}, e.children[e.children.length - 1].loc.end) : e.innerLoc.end = rt({}, e.innerLoc.start), e.innerLoc.source = tn(e.innerLoc.start.offset, e.innerLoc.end.offset));
    const {
        tag: r,
        ns: i
    } = e;
    Jr || (r === "slot" ? e.tagType = 2 : pp(e) ? e.tagType = 3 : YA(e) && (e.tagType = 1)), Ft.inRCDATA || (e.children = pv(e.children, e.tag)), i === 0 && ht.isPreTag(r) && Cl--, Au === e && (Jr = Ft.inVPre = !1, Au = null), Ft.inXML && (Pt[0] ? Pt[0].ns : ht.ns) === 0 && (Ft.inXML = !1); {
        const s = e.props;
        if (!Ft.inSFCRoot && Fi("COMPILER_NATIVE_TEMPLATE", ht) && e.tag === "template" && !pp(e)) {
            const a = Pt[0] || ko,
                l = a.children.indexOf(e);
            a.children.splice(l, 1, ...e.children)
        }
        const o = s.find(a => a.type === 6 && a.name === "inline-template");
        o && Io("COMPILER_INLINE_TEMPLATE", ht, o.loc) && e.children.length && (o.value = {
            type: 2,
            content: tn(e.children[0].loc.start.offset, e.children[e.children.length - 1].loc.end.offset),
            loc: o.loc
        })
    }
}

function KA(e, t) {
    let n = e;
    for (; Or.charCodeAt(n) !== t && n < Or.length - 1;) n++;
    return n
}

function hv(e, t) {
    let n = e;
    for (; Or.charCodeAt(n) !== t && n >= 0;) n--;
    return n
}
const GA = new Set(["if", "else", "else-if", "for", "slot"]);

function pp({
    tag: e,
    props: t
}) {
    if (e === "template") {
        for (let n = 0; n < t.length; n++)
            if (t[n].type === 7 && GA.has(t[n].name)) return !0
    }
    return !1
}

function YA({
    tag: e,
    props: t
}) {
    if (ht.isCustomElement(e)) return !1;
    if (e === "component" || XA(e.charCodeAt(0)) || cv(e) || ht.isBuiltInComponent && ht.isBuiltInComponent(e) || ht.isNativeTag && !ht.isNativeTag(e)) return !0;
    for (let n = 0; n < t.length; n++) {
        const r = t[n];
        if (r.type === 6) {
            if (r.name === "is" && r.value) {
                if (r.value.content.startsWith("vue:")) return !0;
                if (Io("COMPILER_IS_ON_ELEMENT", ht, r.loc)) return !0
            }
        } else if (r.name === "bind" && Ai(r.arg, "is") && Io("COMPILER_IS_ON_ELEMENT", ht, r.loc)) return !0
    }
    return !1
}

function XA(e) {
    return e > 64 && e < 91
}
const JA = /\r\n/g;

function pv(e, t) {
    const n = ht.whitespace !== "preserve";
    let r = !1;
    for (let i = 0; i < e.length; i++) {
        const s = e[i];
        if (s.type === 2)
            if (Cl) s.content = s.content.replace(JA, `
`);
            else if (ZA(s.content)) {
            const o = e[i - 1] && e[i - 1].type,
                a = e[i + 1] && e[i + 1].type;
            !o || !a || n && (o === 3 && (a === 3 || a === 1) || o === 1 && (a === 3 || a === 1 && QA(s.content))) ? (r = !0, e[i] = null) : s.content = " "
        } else n && (s.content = mv(s.content))
    }
    if (Cl && t && ht.isPreTag(t)) {
        const i = e[0];
        i && i.type === 2 && (i.content = i.content.replace(/^\r?\n/, ""))
    }
    return r ? e.filter(Boolean) : e
}

function ZA(e) {
    for (let t = 0; t < e.length; t++)
        if (!xn(e.charCodeAt(t))) return !1;
    return !0
}

function QA(e) {
    for (let t = 0; t < e.length; t++) {
        const n = e.charCodeAt(t);
        if (n === 10 || n === 13) return !0
    }
    return !1
}

function mv(e) {
    let t = "",
        n = !1;
    for (let r = 0; r < e.length; r++) xn(e.charCodeAt(r)) ? n || (t += " ", n = !0) : (t += e[r], n = !1);
    return t
}

function xu(e) {
    (Pt[0] || ko).children.push(e)
}

function Gt(e, t) {
    return {
        start: Ft.getPos(e),
        end: t == null ? t : Ft.getPos(t),
        source: t == null ? t : tn(e, t)
    }
}

function xi(e, t) {
    e.end = Ft.getPos(t), e.source = tn(e.start.offset, t)
}

function e3(e) {
    const t = {
        type: 6,
        name: e.rawName,
        nameLoc: Gt(e.loc.start.offset, e.loc.start.offset + e.rawName.length),
        value: void 0,
        loc: e.loc
    };
    if (e.exp) {
        const n = e.exp.loc;
        n.end.offset < e.loc.end.offset && (n.start.offset--, n.start.column--, n.end.offset++, n.end.column++), t.value = {
            type: 2,
            content: e.exp.content,
            loc: n
        }
    }
    return t
}

function za(e, t = !1, n, r = 0, i = 0) {
    return We(e, t, n, r)
}

function vr(e, t, n) {
    ht.onError(It(e, Gt(t, t)))
}

function t3() {
    Ft.reset(), un = null, tt = null, _n = "", wr = -1, Ti = -1, Pt.length = 0
}

function n3(e, t) {
    if (t3(), Or = e, ht = rt({}, dv), t) {
        let i;
        for (i in t) t[i] != null && (ht[i] = t[i])
    }
    Ft.mode = ht.parseMode === "html" ? 1 : ht.parseMode === "sfc" ? 2 : 0, Ft.inXML = ht.ns === 1 || ht.ns === 2;
    const n = t && t.delimiters;
    n && (Ft.delimiterOpen = bl(n[0]), Ft.delimiterClose = bl(n[1]));
    const r = ko = RA([], e);
    return Ft.parse(Or), r.loc = Gt(0, e.length), r.children = pv(r.children), ko = null, r
}

function r3(e, t) {
    qa(e, t, gv(e, e.children[0]))
}

function gv(e, t) {
    const {
        children: n
    } = e;
    return n.length === 1 && t.type === 1 && !Sl(t)
}

function qa(e, t, n = !1) {
    const {
        children: r
    } = e, i = r.length;
    let s = 0;
    for (let o = 0; o < r.length; o++) {
        const a = r[o];
        if (a.type === 1 && a.tagType === 0) {
            const l = n ? 0 : jn(a, t);
            if (l > 0) {
                if (l >= 2) {
                    a.codegenNode.patchFlag = "-1", a.codegenNode = t.hoist(a.codegenNode), s++;
                    continue
                }
            } else {
                const u = a.codegenNode;
                if (u.type === 13) {
                    const f = bv(u);
                    if ((!f || f === 512 || f === 1) && vv(a, t) >= 2) {
                        const h = yv(a);
                        h && (u.props = t.hoist(h))
                    }
                    u.dynamicProps && (u.dynamicProps = t.hoist(u.dynamicProps))
                }
            }
        }
        if (a.type === 1) {
            const l = a.tagType === 1;
            l && t.scopes.vSlot++, qa(a, t), l && t.scopes.vSlot--
        } else if (a.type === 11) qa(a, t, a.children.length === 1);
        else if (a.type === 9)
            for (let l = 0; l < a.branches.length; l++) qa(a.branches[l], t, a.branches[l].children.length === 1)
    }
    if (s && t.transformHoist && t.transformHoist(r, t, e), s && s === i && e.type === 1 && e.tagType === 0 && e.codegenNode && e.codegenNode.type === 13 && we(e.codegenNode.children)) {
        const o = t.hoist(Jo(e.codegenNode.children));
        t.hmr && (o.content = `[...${o.content}]`), e.codegenNode.children = o
    }
}

function jn(e, t) {
    const {
        constantCache: n
    } = t;
    switch (e.type) {
        case 1:
            if (e.tagType !== 0) return 0;
            const r = n.get(e);
            if (r !== void 0) return r;
            const i = e.codegenNode;
            if (i.type !== 13 || i.isBlock && e.tag !== "svg" && e.tag !== "foreignObject") return 0;
            if (bv(i)) return n.set(e, 0), 0; {
                let a = 3;
                const l = vv(e, t);
                if (l === 0) return n.set(e, 0), 0;
                l < a && (a = l);
                for (let u = 0; u < e.children.length; u++) {
                    const f = jn(e.children[u], t);
                    if (f === 0) return n.set(e, 0), 0;
                    f < a && (a = f)
                }
                if (a > 1)
                    for (let u = 0; u < e.props.length; u++) {
                        const f = e.props[u];
                        if (f.type === 7 && f.name === "bind" && f.exp) {
                            const h = jn(f.exp, t);
                            if (h === 0) return n.set(e, 0), 0;
                            h < a && (a = h)
                        }
                    }
                if (i.isBlock) {
                    for (let u = 0; u < e.props.length; u++)
                        if (e.props[u].type === 7) return n.set(e, 0), 0;
                    t.removeHelper(Gi), t.removeHelper(Ds(t.inSSR, i.isComponent)), i.isBlock = !1, t.helper(Fs(t.inSSR, i.isComponent))
                }
                return n.set(e, a), a
            }
        case 2:
        case 3:
            return 3;
        case 9:
        case 11:
        case 10:
            return 0;
        case 5:
        case 12:
            return jn(e.content, t);
        case 4:
            return e.constType;
        case 8:
            let o = 3;
            for (let a = 0; a < e.children.length; a++) {
                const l = e.children[a];
                if (He(l) || Vn(l)) continue;
                const u = jn(l, t);
                if (u === 0) return 0;
                u < o && (o = u)
            }
            return o;
        default:
            return 0
    }
}
const i3 = new Set([Kf, Gf, Mo, Xo]);

function _v(e, t) {
    if (e.type === 14 && !He(e.callee) && i3.has(e.callee)) {
        const n = e.arguments[0];
        if (n.type === 4) return jn(n, t);
        if (n.type === 14) return _v(n, t)
    }
    return 0
}

function vv(e, t) {
    let n = 3;
    const r = yv(e);
    if (r && r.type === 15) {
        const {
            properties: i
        } = r;
        for (let s = 0; s < i.length; s++) {
            const {
                key: o,
                value: a
            } = i[s], l = jn(o, t);
            if (l === 0) return l;
            l < n && (n = l);
            let u;
            if (a.type === 4 ? u = jn(a, t) : a.type === 14 ? u = _v(a, t) : u = 0, u === 0) return u;
            u < n && (n = u)
        }
    }
    return n
}

function yv(e) {
    const t = e.codegenNode;
    if (t.type === 13) return t.props
}

function bv(e) {
    const t = e.patchFlag;
    return t ? parseInt(t, 10) : void 0
}

function s3(e, {
    filename: t = "",
    prefixIdentifiers: n = !1,
    hoistStatic: r = !1,
    hmr: i = !1,
    cacheHandlers: s = !1,
    nodeTransforms: o = [],
    directiveTransforms: a = {},
    transformHoist: l = null,
    isBuiltInComponent: u = Ut,
    isCustomElement: f = Ut,
    expressionPlugins: h = [],
    scopeId: _ = null,
    slotted: m = !0,
    ssr: T = !1,
    inSSR: R = !1,
    ssrCssVars: B = "",
    bindingMetadata: I = ft,
    inline: A = !1,
    isTS: E = !1,
    onError: O = Qf,
    onWarn: P = lv,
    compatConfig: $
}) {
    const H = t.replace(/\?.*$/, "").match(/([^/\\]+)\.\w+$/),
        F = {
            filename: t,
            selfName: H && ts(kt(H[1])),
            prefixIdentifiers: n,
            hoistStatic: r,
            hmr: i,
            cacheHandlers: s,
            nodeTransforms: o,
            directiveTransforms: a,
            transformHoist: l,
            isBuiltInComponent: u,
            isCustomElement: f,
            expressionPlugins: h,
            scopeId: _,
            slotted: m,
            ssr: T,
            inSSR: R,
            ssrCssVars: B,
            bindingMetadata: I,
            inline: A,
            isTS: E,
            onError: O,
            onWarn: P,
            compatConfig: $,
            root: e,
            helpers: new Map,
            components: new Set,
            directives: new Set,
            hoists: [],
            imports: [],
            constantCache: new WeakMap,
            temps: 0,
            cached: 0,
            identifiers: Object.create(null),
            scopes: {
                vFor: 0,
                vSlot: 0,
                vPre: 0,
                vOnce: 0
            },
            parent: null,
            grandParent: null,
            currentNode: e,
            childIndex: 0,
            inVOnce: !1,
            helper(V) {
                const k = F.helpers.get(V) || 0;
                return F.helpers.set(V, k + 1), V
            },
            removeHelper(V) {
                const k = F.helpers.get(V);
                if (k) {
                    const Y = k - 1;
                    Y ? F.helpers.set(V, Y) : F.helpers.delete(V)
                }
            },
            helperString(V) {
                return `_${Ls[F.helper(V)]}`
            },
            replaceNode(V) {
                F.parent.children[F.childIndex] = F.currentNode = V
            },
            removeNode(V) {
                const k = F.parent.children,
                    Y = V ? k.indexOf(V) : F.currentNode ? F.childIndex : -1;
                !V || V === F.currentNode ? (F.currentNode = null, F.onNodeRemoved()) : F.childIndex > Y && (F.childIndex--, F.onNodeRemoved()), F.parent.children.splice(Y, 1)
            },
            onNodeRemoved: Ut,
            addIdentifiers(V) {},
            removeIdentifiers(V) {},
            hoist(V) {
                He(V) && (V = We(V)), F.hoists.push(V);
                const k = We(`_hoisted_${F.hoists.length}`, !1, V.loc, 2);
                return k.hoisted = V, k
            },
            cache(V, k = !1) {
                return IA(F.cached++, V, k)
            }
        };
    return F.filters = new Set, F
}

function o3(e, t) {
    const n = s3(e, t);
    ic(e, n), t.hoistStatic && r3(e, n), t.ssr || a3(e, n), e.helpers = new Set([...n.helpers.keys()]), e.components = [...n.components], e.directives = [...n.directives], e.imports = n.imports, e.hoists = n.hoists, e.temps = n.temps, e.cached = n.cached, e.transformed = !0, e.filters = [...n.filters]
}

function a3(e, t) {
    const {
        helper: n
    } = t, {
        children: r
    } = e;
    if (r.length === 1) {
        const i = r[0];
        if (gv(e, i) && i.codegenNode) {
            const s = i.codegenNode;
            s.type === 13 && Zf(s, t), e.codegenNode = s
        } else e.codegenNode = i
    } else if (r.length > 1) {
        let i = 64;
        e.codegenNode = Ro(t, n(Po), void 0, e.children, i + "", void 0, void 0, !0, void 0, !1)
    }
}

function l3(e, t) {
    let n = 0;
    const r = () => {
        n--
    };
    for (; n < e.children.length; n++) {
        const i = e.children[n];
        He(i) || (t.grandParent = t.parent, t.parent = e, t.childIndex = n, t.onNodeRemoved = r, ic(i, t))
    }
}

function ic(e, t) {
    t.currentNode = e;
    const {
        nodeTransforms: n
    } = t, r = [];
    for (let s = 0; s < n.length; s++) {
        const o = n[s](e, t);
        if (o && (we(o) ? r.push(...o) : r.push(o)), t.currentNode) e = t.currentNode;
        else return
    }
    switch (e.type) {
        case 3:
            t.ssr || t.helper(Yo);
            break;
        case 5:
            t.ssr || t.helper(nc);
            break;
        case 9:
            for (let s = 0; s < e.branches.length; s++) ic(e.branches[s], t);
            break;
        case 10:
        case 11:
        case 1:
        case 0:
            l3(e, t);
            break
    }
    t.currentNode = e;
    let i = r.length;
    for (; i--;) r[i]()
}

function wv(e, t) {
    const n = He(e) ? r => r === e : r => e.test(r);
    return (r, i) => {
        if (r.type === 1) {
            const {
                props: s
            } = r;
            if (r.tagType === 3 && s.some(VA)) return;
            const o = [];
            for (let a = 0; a < s.length; a++) {
                const l = s[a];
                if (l.type === 7 && n(l.name)) {
                    s.splice(a, 1), a--;
                    const u = t(r, l, i);
                    u && o.push(u)
                }
            }
            return o
        }
    }
}
const sc = "/*#__PURE__*/",
    Sv = e => `${Ls[e]}: _${Ls[e]}`;

function c3(e, {
    mode: t = "function",
    prefixIdentifiers: n = t === "module",
    sourceMap: r = !1,
    filename: i = "template.vue.html",
    scopeId: s = null,
    optimizeImports: o = !1,
    runtimeGlobalName: a = "Vue",
    runtimeModuleName: l = "vue",
    ssrRuntimeModuleName: u = "vue/server-renderer",
    ssr: f = !1,
    isTS: h = !1,
    inSSR: _ = !1
}) {
    const m = {
        mode: t,
        prefixIdentifiers: n,
        sourceMap: r,
        filename: i,
        scopeId: s,
        optimizeImports: o,
        runtimeGlobalName: a,
        runtimeModuleName: l,
        ssrRuntimeModuleName: u,
        ssr: f,
        isTS: h,
        inSSR: _,
        source: e.source,
        code: "",
        column: 1,
        line: 1,
        offset: 0,
        indentLevel: 0,
        pure: !1,
        map: void 0,
        helper(R) {
            return `_${Ls[R]}`
        },
        push(R, B = -2, I) {
            m.code += R
        },
        indent() {
            T(++m.indentLevel)
        },
        deindent(R = !1) {
            R ? --m.indentLevel : T(--m.indentLevel)
        },
        newline() {
            T(m.indentLevel)
        }
    };

    function T(R) {
        m.push(`
` + "  ".repeat(R), 0)
    }
    return m
}

function u3(e, t = {}) {
    const n = c3(e, t);
    t.onContextCreated && t.onContextCreated(n);
    const {
        mode: r,
        push: i,
        prefixIdentifiers: s,
        indent: o,
        deindent: a,
        newline: l,
        scopeId: u,
        ssr: f
    } = n, h = Array.from(e.helpers), _ = h.length > 0, m = !s && r !== "module";
    f3(e, n);
    const R = f ? "ssrRender" : "render",
        I = (f ? ["_ctx", "_push", "_parent", "_attrs"] : ["_ctx", "_cache"]).join(", ");
    if (i(`function ${R}(${I}) {`), o(), m && (i("with (_ctx) {"), o(), _ && (i(`const { ${h.map(Sv).join(", ")} } = _Vue
`, -1), l())), e.components.length && (Lc(e.components, "component", n), (e.directives.length || e.temps > 0) && l()), e.directives.length && (Lc(e.directives, "directive", n), e.temps > 0 && l()), e.filters && e.filters.length && (l(), Lc(e.filters, "filter", n), l()), e.temps > 0) {
        i("let ");
        for (let A = 0; A < e.temps; A++) i(`${A>0?", ":""}_temp${A}`)
    }
    return (e.components.length || e.directives.length || e.temps) && (i(`
`, 0), l()), f || i("return "), e.codegenNode ? dn(e.codegenNode, n) : i("null"), m && (a(), i("}")), a(), i("}"), {
        ast: e,
        code: n.code,
        preamble: "",
        map: n.map ? n.map.toJSON() : void 0
    }
}

function f3(e, t) {
    const {
        ssr: n,
        prefixIdentifiers: r,
        push: i,
        newline: s,
        runtimeModuleName: o,
        runtimeGlobalName: a,
        ssrRuntimeModuleName: l
    } = t, u = a, f = Array.from(e.helpers);
    if (f.length > 0 && (i(`const _Vue = ${u}
`, -1), e.hoists.length)) {
        const h = [Df, jf, Yo, Bf, iv].filter(_ => f.includes(_)).map(Sv).join(", ");
        i(`const { ${h} } = _Vue
`, -1)
    }
    d3(e.hoists, t), s(), i("return ")
}

function Lc(e, t, {
    helper: n,
    push: r,
    newline: i,
    isTS: s
}) {
    const o = n(t === "filter" ? Wf : t === "component" ? Vf : Uf);
    for (let a = 0; a < e.length; a++) {
        let l = e[a];
        const u = l.endsWith("__self");
        u && (l = l.slice(0, -6)), r(`const ${$o(l,t)} = ${o}(${JSON.stringify(l)}${u?", true":""})${s?"!":""}`), a < e.length - 1 && i()
    }
}

function d3(e, t) {
    if (!e.length) return;
    t.pure = !0;
    const {
        push: n,
        newline: r,
        helper: i,
        scopeId: s,
        mode: o
    } = t;
    r();
    for (let a = 0; a < e.length; a++) {
        const l = e[a];
        l && (n(`const _hoisted_${a+1} = `), dn(l, t), r())
    }
    t.pure = !1
}

function td(e, t) {
    const n = e.length > 3 || !1;
    t.push("["), n && t.indent(), Zo(e, t, n), n && t.deindent(), t.push("]")
}

function Zo(e, t, n = !1, r = !0) {
    const {
        push: i,
        newline: s
    } = t;
    for (let o = 0; o < e.length; o++) {
        const a = e[o];
        He(a) ? i(a, -3) : we(a) ? td(a, t) : dn(a, t), o < e.length - 1 && (n ? (r && i(","), s()) : r && i(", "))
    }
}

function dn(e, t) {
    if (He(e)) {
        t.push(e, -3);
        return
    }
    if (Vn(e)) {
        t.push(t.helper(e));
        return
    }
    switch (e.type) {
        case 1:
        case 9:
        case 11:
            dn(e.codegenNode, t);
            break;
        case 2:
            h3(e, t);
            break;
        case 4:
            Tv(e, t);
            break;
        case 5:
            p3(e, t);
            break;
        case 12:
            dn(e.codegenNode, t);
            break;
        case 8:
            Cv(e, t);
            break;
        case 3:
            g3(e, t);
            break;
        case 13:
            _3(e, t);
            break;
        case 14:
            y3(e, t);
            break;
        case 15:
            b3(e, t);
            break;
        case 17:
            w3(e, t);
            break;
        case 18:
            S3(e, t);
            break;
        case 19:
            T3(e, t);
            break;
        case 20:
            C3(e, t);
            break;
        case 21:
            Zo(e.body, t, !0, !1);
            break
    }
}

function h3(e, t) {
    t.push(JSON.stringify(e.content), -3, e)
}

function Tv(e, t) {
    const {
        content: n,
        isStatic: r
    } = e;
    t.push(r ? JSON.stringify(n) : n, -3, e)
}

function p3(e, t) {
    const {
        push: n,
        helper: r,
        pure: i
    } = t;
    i && n(sc), n(`${r(nc)}(`), dn(e.content, t), n(")")
}

function Cv(e, t) {
    for (let n = 0; n < e.children.length; n++) {
        const r = e.children[n];
        He(r) ? t.push(r, -3) : dn(r, t)
    }
}

function m3(e, t) {
    const {
        push: n
    } = t;
    if (e.type === 8) n("["), Cv(e, t), n("]");
    else if (e.isStatic) {
        const r = ed(e.content) ? e.content : JSON.stringify(e.content);
        n(r, -2, e)
    } else n(`[${e.content}]`, -3, e)
}

function g3(e, t) {
    const {
        push: n,
        helper: r,
        pure: i
    } = t;
    i && n(sc), n(`${r(Yo)}(${JSON.stringify(e.content)})`, -3, e)
}

function _3(e, t) {
    const {
        push: n,
        helper: r,
        pure: i
    } = t, {
        tag: s,
        props: o,
        children: a,
        patchFlag: l,
        dynamicProps: u,
        directives: f,
        isBlock: h,
        disableTracking: _,
        isComponent: m
    } = e;
    f && n(r(zf) + "("), h && n(`(${r(Gi)}(${_?"true":""}), `), i && n(sc);
    const T = h ? Ds(t.inSSR, m) : Fs(t.inSSR, m);
    n(r(T) + "(", -2, e), Zo(v3([s, o, a, l, u]), t), n(")"), h && n(")"), f && (n(", "), dn(f, t), n(")"))
}

function v3(e) {
    let t = e.length;
    for (; t-- && e[t] == null;);
    return e.slice(0, t + 1).map(n => n || "null")
}

function y3(e, t) {
    const {
        push: n,
        helper: r,
        pure: i
    } = t, s = He(e.callee) ? e.callee : r(e.callee);
    i && n(sc), n(s + "(", -2, e), Zo(e.arguments, t), n(")")
}

function b3(e, t) {
    const {
        push: n,
        indent: r,
        deindent: i,
        newline: s
    } = t, {
        properties: o
    } = e;
    if (!o.length) {
        n("{}", -2, e);
        return
    }
    const a = o.length > 1 || !1;
    n(a ? "{" : "{ "), a && r();
    for (let l = 0; l < o.length; l++) {
        const {
            key: u,
            value: f
        } = o[l];
        m3(u, t), n(": "), dn(f, t), l < o.length - 1 && (n(","), s())
    }
    a && i(), n(a ? "}" : " }")
}

function w3(e, t) {
    td(e.elements, t)
}

function S3(e, t) {
    const {
        push: n,
        indent: r,
        deindent: i
    } = t, {
        params: s,
        returns: o,
        body: a,
        newline: l,
        isSlot: u
    } = e;
    u && n(`_${Ls[Xf]}(`), n("(", -2, e), we(s) ? Zo(s, t) : s && dn(s, t), n(") => "), (l || a) && (n("{"), r()), o ? (l && n("return "), we(o) ? td(o, t) : dn(o, t)) : a && dn(a, t), (l || a) && (i(), n("}")), u && (e.isNonScopedSlot && n(", undefined, true"), n(")"))
}

function T3(e, t) {
    const {
        test: n,
        consequent: r,
        alternate: i,
        newline: s
    } = e, {
        push: o,
        indent: a,
        deindent: l,
        newline: u
    } = t;
    if (n.type === 4) {
        const h = !ed(n.content);
        h && o("("), Tv(n, t), h && o(")")
    } else o("("), dn(n, t), o(")");
    s && a(), t.indentLevel++, s || o(" "), o("? "), dn(r, t), t.indentLevel--, s && u(), s || o(" "), o(": ");
    const f = i.type === 19;
    f || t.indentLevel++, dn(i, t), f || t.indentLevel--, s && l(!0)
}

function C3(e, t) {
    const {
        push: n,
        helper: r,
        indent: i,
        deindent: s,
        newline: o
    } = t;
    n(`_cache[${e.index}] || (`), e.isVNode && (i(), n(`${r(yl)}(-1),`), o()), n(`_cache[${e.index}] = `), dn(e.value, t), e.isVNode && (n(","), o(), n(`${r(yl)}(1),`), o(), n(`_cache[${e.index}]`), s()), n(")")
}
new RegExp("\\b" + "arguments,await,break,case,catch,class,const,continue,debugger,default,delete,do,else,export,extends,finally,for,function,if,import,let,new,return,super,switch,throw,try,var,void,while,with,yield".split(",").join("\\b|\\b") + "\\b");
const E3 = wv(/^(if|else|else-if)$/, (e, t, n) => A3(e, t, n, (r, i, s) => {
    const o = n.parent.children;
    let a = o.indexOf(r),
        l = 0;
    for (; a-- >= 0;) {
        const u = o[a];
        u && u.type === 9 && (l += u.branches.length)
    }
    return () => {
        if (s) r.codegenNode = gp(i, l, n);
        else {
            const u = x3(r.codegenNode);
            u.alternate = gp(i, l + r.branches.length - 1, n)
        }
    }
}));

function A3(e, t, n, r) {
    if (t.name !== "else" && (!t.exp || !t.exp.content.trim())) {
        const i = t.exp ? t.exp.loc : e.loc;
        n.onError(It(28, t.loc)), t.exp = We("true", !1, i)
    }
    if (t.name === "if") {
        const i = mp(e, t),
            s = {
                type: 9,
                loc: e.loc,
                branches: [i]
            };
        if (n.replaceNode(s), r) return r(s, i, !0)
    } else {
        const i = n.parent.children;
        let s = i.indexOf(e);
        for (; s-- >= -1;) {
            const o = i[s];
            if (o && o.type === 3) {
                n.removeNode(o);
                continue
            }
            if (o && o.type === 2 && !o.content.trim().length) {
                n.removeNode(o);
                continue
            }
            if (o && o.type === 9) {
                t.name === "else-if" && o.branches[o.branches.length - 1].condition === void 0 && n.onError(It(30, e.loc)), n.removeNode();
                const a = mp(e, t);
                o.branches.push(a);
                const l = r && r(o, a, !1);
                ic(a, n), l && l(), n.currentNode = null
            } else n.onError(It(30, e.loc));
            break
        }
    }
}

function mp(e, t) {
    const n = e.tagType === 3;
    return {
        type: 10,
        loc: e.loc,
        condition: t.name === "else" ? void 0 : t.exp,
        children: n && !Un(e, "for") ? e.children : [e],
        userKey: rc(e, "key"),
        isTemplateIf: n
    }
}

function gp(e, t, n) {
    return e.condition ? Eu(e.condition, _p(e, t, n), Xt(n.helper(Yo), ['""', "true"])) : _p(e, t, n)
}

function _p(e, t, n) {
    const {
        helper: r
    } = n, i = Bt("key", We(`${t}`, !1, $n, 2)), {
        children: s
    } = e, o = s[0];
    if (s.length !== 1 || o.type !== 1)
        if (s.length === 1 && o.type === 11) {
            const l = o.codegenNode;
            return Tl(l, i, n), l
        } else {
            let l = 64;
            return Ro(n, r(Po), Dn([i]), s, l + "", void 0, void 0, !0, !1, !1, e.loc)
        }
    else {
        const l = o.codegenNode,
            u = UA(l);
        return u.type === 13 && Zf(u, n), Tl(u, i, n), l
    }
}

function x3(e) {
    for (;;)
        if (e.type === 19)
            if (e.alternate.type === 19) e = e.alternate;
            else return e;
    else e.type === 20 && (e = e.value)
}
const O3 = wv("for", (e, t, n) => {
    const {
        helper: r,
        removeHelper: i
    } = n;
    return P3(e, t, n, s => {
        const o = Xt(r(qf), [s.source]),
            a = wl(e),
            l = Un(e, "memo"),
            u = rc(e, "key"),
            f = u && (u.type === 6 ? We(u.value.content, !0) : u.exp),
            h = u ? Bt("key", f) : null,
            _ = s.source.type === 4 && s.source.constType > 0,
            m = _ ? 64 : u ? 128 : 256;
        return s.codegenNode = Ro(n, r(Po), void 0, o, m + "", void 0, void 0, !0, !_, !1, e.loc), () => {
            let T;
            const {
                children: R
            } = s, B = R.length !== 1 || R[0].type !== 1, I = Sl(e) ? e : a && e.children.length === 1 && Sl(e.children[0]) ? e.children[0] : null;
            if (I ? (T = I.codegenNode, a && h && Tl(T, h, n)) : B ? T = Ro(n, r(Po), h ? Dn([h]) : void 0, e.children, "64", void 0, void 0, !0, void 0, !1) : (T = R[0].codegenNode, a && h && Tl(T, h, n), T.isBlock !== !_ && (T.isBlock ? (i(Gi), i(Ds(n.inSSR, T.isComponent))) : i(Fs(n.inSSR, T.isComponent))), T.isBlock = !_, T.isBlock ? (r(Gi), r(Ds(n.inSSR, T.isComponent))) : r(Fs(n.inSSR, T.isComponent))), l) {
                const A = Ns(Ou(s.parseResult, [We("_cached")]));
                A.body = $A([qn(["const _memo = (", l.exp, ")"]), qn(["if (_cached", ...f ? [" && _cached.key === ", f] : [], ` && ${n.helperString(av)}(_cached, _memo)) return _cached`]), qn(["const _item = ", T]), We("_item.memo = _memo"), We("return _item")]), o.arguments.push(A, We("_cache"), We(String(n.cached++)))
            } else o.arguments.push(Ns(Ou(s.parseResult), T, !0))
        }
    })
});

function P3(e, t, n, r) {
    if (!t.exp) {
        n.onError(It(31, t.loc));
        return
    }
    const i = t.forParseResult;
    if (!i) {
        n.onError(It(32, t.loc));
        return
    }
    Ev(i);
    const {
        addIdentifiers: s,
        removeIdentifiers: o,
        scopes: a
    } = n, {
        source: l,
        value: u,
        key: f,
        index: h
    } = i, _ = {
        type: 11,
        loc: t.loc,
        source: l,
        valueAlias: u,
        keyAlias: f,
        objectIndexAlias: h,
        parseResult: i,
        children: wl(e) ? e.children : [e]
    };
    n.replaceNode(_), a.vFor++;
    const m = r && r(_);
    return () => {
        a.vFor--, m && m()
    }
}

function Ev(e, t) {
    e.finalized || (e.finalized = !0)
}

function Ou({
    value: e,
    key: t,
    index: n
}, r = []) {
    return M3([e, t, n, ...r])
}

function M3(e) {
    let t = e.length;
    for (; t-- && !e[t];);
    return e.slice(0, t + 1).map((n, r) => n || We("_".repeat(r + 1), !1))
}
const vp = We("undefined", !1),
    R3 = (e, t) => {
        if (e.type === 1 && (e.tagType === 1 || e.tagType === 3)) {
            const n = Un(e, "slot");
            if (n) return n.exp, t.scopes.vSlot++, () => {
                t.scopes.vSlot--
            }
        }
    },
    I3 = (e, t, n, r) => Ns(e, n, !1, !0, n.length ? n[0].loc : r);

function $3(e, t, n = I3) {
    t.helper(Xf);
    const {
        children: r,
        loc: i
    } = e, s = [], o = [];
    let a = t.scopes.vSlot > 0 || t.scopes.vFor > 0;
    const l = Un(e, "slot", !0);
    if (l) {
        const {
            arg: B,
            exp: I
        } = l;
        B && !Sn(B) && (a = !0), s.push(Bt(B || We("default", !0), n(I, void 0, r, i)))
    }
    let u = !1,
        f = !1;
    const h = [],
        _ = new Set;
    let m = 0;
    for (let B = 0; B < r.length; B++) {
        const I = r[B];
        let A;
        if (!wl(I) || !(A = Un(I, "slot", !0))) {
            I.type !== 3 && h.push(I);
            continue
        }
        if (l) {
            t.onError(It(37, A.loc));
            break
        }
        u = !0;
        const {
            children: E,
            loc: O
        } = I, {
            arg: P = We("default", !0),
            exp: $,
            loc: H
        } = A;
        let F;
        Sn(P) ? F = P ? P.content : "default" : a = !0;
        const V = Un(I, "for"),
            k = n($, V, E, O);
        let Y, L;
        if (Y = Un(I, "if")) a = !0, o.push(Eu(Y.exp, Ra(P, k, m++), vp));
        else if (L = Un(I, /^else(-if)?$/, !0)) {
            let te = B,
                ie;
            for (; te-- && (ie = r[te], ie.type === 3););
            if (ie && wl(ie) && Un(ie, "if")) {
                r.splice(B, 1), B--;
                let _e = o[o.length - 1];
                for (; _e.alternate.type === 19;) _e = _e.alternate;
                _e.alternate = L.exp ? Eu(L.exp, Ra(P, k, m++), vp) : Ra(P, k, m++)
            } else t.onError(It(30, L.loc))
        } else if (V) {
            a = !0;
            const te = V.forParseResult;
            te ? (Ev(te), o.push(Xt(t.helper(qf), [te.source, Ns(Ou(te), Ra(P, k), !0)]))) : t.onError(It(32, V.loc))
        } else {
            if (F) {
                if (_.has(F)) {
                    t.onError(It(38, H));
                    continue
                }
                _.add(F), F === "default" && (f = !0)
            }
            s.push(Bt(P, k))
        }
    }
    if (!l) {
        const B = (I, A) => {
            const E = n(I, void 0, A, i);
            return t.compatConfig && (E.isNonScopedSlot = !0), Bt("default", E)
        };
        u ? h.length && h.some(I => Av(I)) && (f ? t.onError(It(39, h[0].loc)) : s.push(B(void 0, h))) : s.push(B(void 0, r))
    }
    const T = a ? 2 : Ka(e.children) ? 3 : 1;
    let R = Dn(s.concat(Bt("_", We(T + "", !1))), i);
    return o.length && (R = Xt(t.helper(ov), [R, Jo(o)])), {
        slots: R,
        hasDynamicSlots: a
    }
}

function Ra(e, t, n) {
    const r = [Bt("name", e), Bt("fn", t)];
    return n != null && r.push(Bt("key", We(String(n), !0))), Dn(r)
}

function Ka(e) {
    for (let t = 0; t < e.length; t++) {
        const n = e[t];
        switch (n.type) {
            case 1:
                if (n.tagType === 2 || Ka(n.children)) return !0;
                break;
            case 9:
                if (Ka(n.branches)) return !0;
                break;
            case 10:
            case 11:
                if (Ka(n.children)) return !0;
                break
        }
    }
    return !1
}

function Av(e) {
    return e.type !== 2 && e.type !== 12 ? !0 : e.type === 2 ? !!e.content.trim() : Av(e.content)
}
const xv = new WeakMap,
    k3 = (e, t) => function() {
        if (e = t.currentNode, !(e.type === 1 && (e.tagType === 0 || e.tagType === 1))) return;
        const {
            tag: r,
            props: i
        } = e, s = e.tagType === 1;
        let o = s ? L3(e, t) : `"${r}"`;
        const a = yt(o) && o.callee === Hf;
        let l, u, f, h = 0,
            _, m, T, R = a || o === uo || o === Ff || !s && (r === "svg" || r === "foreignObject");
        if (i.length > 0) {
            const B = Ov(e, t, void 0, s, a);
            l = B.props, h = B.patchFlag, m = B.dynamicPropNames;
            const I = B.directives;
            T = I && I.length ? Jo(I.map(A => F3(A, t))) : void 0, B.shouldUseBlock && (R = !0)
        }
        if (e.children.length > 0)
            if (o === _l && (R = !0, h |= 1024), s && o !== uo && o !== _l) {
                const {
                    slots: I,
                    hasDynamicSlots: A
                } = $3(e, t);
                u = I, A && (h |= 1024)
            } else if (e.children.length === 1 && o !== uo) {
            const I = e.children[0],
                A = I.type,
                E = A === 5 || A === 8;
            E && jn(I, t) === 0 && (h |= 1), E || A === 2 ? u = I : u = e.children
        } else u = e.children;
        h !== 0 && (f = String(h), m && m.length && (_ = D3(m))), e.codegenNode = Ro(t, o, l, u, f, _, T, !!R, !1, s, e.loc)
    };

function L3(e, t, n = !1) {
    let {
        tag: r
    } = e;
    const i = Pu(r),
        s = rc(e, "is", !1, !0);
    if (s)
        if (i || Fi("COMPILER_IS_ON_ELEMENT", t)) {
            let a;
            if (s.type === 6 ? a = s.value && We(s.value.content, !0) : (a = s.exp, a || (a = We("is", !1, s.loc))), a) return Xt(t.helper(Hf), [a])
        } else s.type === 6 && s.value.content.startsWith("vue:") && (r = s.value.content.slice(4));
    const o = cv(r) || t.isBuiltInComponent(r);
    return o ? (n || t.helper(o), o) : (t.helper(Vf), t.components.add(r), $o(r, "component"))
}

function Ov(e, t, n = e.props, r, i, s = !1) {
    const {
        tag: o,
        loc: a,
        children: l
    } = e;
    let u = [];
    const f = [],
        h = [],
        _ = l.length > 0;
    let m = !1,
        T = 0,
        R = !1,
        B = !1,
        I = !1,
        A = !1,
        E = !1,
        O = !1;
    const P = [],
        $ = k => {
            u.length && (f.push(Dn(yp(u), a)), u = []), k && f.push(k)
        },
        H = () => {
            t.scopes.vFor > 0 && u.push(Bt(We("ref_for", !0), We("true")))
        },
        F = ({
            key: k,
            value: Y
        }) => {
            if (Sn(k)) {
                const L = k.content,
                    te = Qi(L);
                if (te && (!r || i) && L.toLowerCase() !== "onclick" && L !== "onUpdate:modelValue" && !ti(L) && (A = !0), te && ti(L) && (O = !0), te && Y.type === 14 && (Y = Y.arguments[0]), Y.type === 20 || (Y.type === 4 || Y.type === 8) && jn(Y, t) > 0) return;
                L === "ref" ? R = !0 : L === "class" ? B = !0 : L === "style" ? I = !0 : L !== "key" && !P.includes(L) && P.push(L), r && (L === "class" || L === "style") && !P.includes(L) && P.push(L)
            } else E = !0
        };
    for (let k = 0; k < n.length; k++) {
        const Y = n[k];
        if (Y.type === 6) {
            const {
                loc: L,
                name: te,
                nameLoc: ie,
                value: _e
            } = Y;
            let X = !0;
            if (te === "ref" && (R = !0, H()), te === "is" && (Pu(o) || _e && _e.content.startsWith("vue:") || Fi("COMPILER_IS_ON_ELEMENT", t))) continue;
            u.push(Bt(We(te, !0, ie), We(_e ? _e.content : "", X, _e ? _e.loc : L)))
        } else {
            const {
                name: L,
                arg: te,
                exp: ie,
                loc: _e,
                modifiers: X
            } = Y, le = L === "bind", ce = L === "on";
            if (L === "slot") {
                r || t.onError(It(40, _e));
                continue
            }
            if (L === "once" || L === "memo" || L === "is" || le && Ai(te, "is") && (Pu(o) || Fi("COMPILER_IS_ON_ELEMENT", t)) || ce && s) continue;
            if ((le && Ai(te, "key") || ce && _ && Ai(te, "vue:before-update")) && (m = !0), le && Ai(te, "ref") && H(), !te && (le || ce)) {
                if (E = !0, ie)
                    if (le) {
                        if (H(), $(), Fi("COMPILER_V_BIND_OBJECT_ORDER", t)) {
                            f.unshift(ie);
                            continue
                        }
                        f.push(ie)
                    } else $({
                        type: 14,
                        loc: _e,
                        callee: t.helper(Yf),
                        arguments: r ? [ie] : [ie, "true"]
                    });
                else t.onError(It(le ? 34 : 35, _e));
                continue
            }
            le && X.includes("prop") && (T |= 32);
            const ue = t.directiveTransforms[L];
            if (ue) {
                const {
                    props: Oe,
                    needRuntime: ke
                } = ue(Y, e, t);
                !s && Oe.forEach(F), ce && te && !Sn(te) ? $(Dn(Oe, a)) : u.push(...Oe), ke && (h.push(Y), Vn(ke) && xv.set(Y, ke))
            } else oT(L) || (h.push(Y), _ && (m = !0))
        }
    }
    let V;
    if (f.length ? ($(), f.length > 1 ? V = Xt(t.helper(vl), f, a) : V = f[0]) : u.length && (V = Dn(yp(u), a)), E ? T |= 16 : (B && !r && (T |= 2), I && !r && (T |= 4), P.length && (T |= 8), A && (T |= 32)), !m && (T === 0 || T === 32) && (R || O || h.length > 0) && (T |= 512), !t.inSSR && V) switch (V.type) {
        case 15:
            let k = -1,
                Y = -1,
                L = !1;
            for (let _e = 0; _e < V.properties.length; _e++) {
                const X = V.properties[_e].key;
                Sn(X) ? X.content === "class" ? k = _e : X.content === "style" && (Y = _e) : X.isHandlerKey || (L = !0)
            }
            const te = V.properties[k],
                ie = V.properties[Y];
            L ? V = Xt(t.helper(Mo), [V]) : (te && !Sn(te.value) && (te.value = Xt(t.helper(Kf), [te.value])), ie && (I || ie.value.type === 4 && ie.value.content.trim()[0] === "[" || ie.value.type === 17) && (ie.value = Xt(t.helper(Gf), [ie.value])));
            break;
        case 14:
            break;
        default:
            V = Xt(t.helper(Mo), [Xt(t.helper(Xo), [V])]);
            break
    }
    return {
        props: V,
        directives: h,
        patchFlag: T,
        dynamicPropNames: P,
        shouldUseBlock: m
    }
}

function yp(e) {
    const t = new Map,
        n = [];
    for (let r = 0; r < e.length; r++) {
        const i = e[r];
        if (i.key.type === 8 || !i.key.isStatic) {
            n.push(i);
            continue
        }
        const s = i.key.content,
            o = t.get(s);
        o ? (s === "style" || s === "class" || Qi(s)) && N3(o, i) : (t.set(s, i), n.push(i))
    }
    return n
}

function N3(e, t) {
    e.value.type === 17 ? e.value.elements.push(t.value) : e.value = Jo([e.value, t.value], e.loc)
}

function F3(e, t) {
    const n = [],
        r = xv.get(e);
    r ? n.push(t.helperString(r)) : (t.helper(Uf), t.directives.add(e.name), n.push($o(e.name, "directive")));
    const {
        loc: i
    } = e;
    if (e.exp && n.push(e.exp), e.arg && (e.exp || n.push("void 0"), n.push(e.arg)), Object.keys(e.modifiers).length) {
        e.arg || (e.exp || n.push("void 0"), n.push("void 0"));
        const s = We("true", !1, i);
        n.push(Dn(e.modifiers.map(o => Bt(o, s)), i))
    }
    return Jo(n, e.loc)
}

function D3(e) {
    let t = "[";
    for (let n = 0, r = e.length; n < r; n++) t += JSON.stringify(e[n]), n < r - 1 && (t += ", ");
    return t + "]"
}

function Pu(e) {
    return e === "component" || e === "Component"
}
const j3 = (e, t) => {
    if (Sl(e)) {
        const {
            children: n,
            loc: r
        } = e, {
            slotName: i,
            slotProps: s
        } = B3(e, t), o = [t.prefixIdentifiers ? "_ctx.$slots" : "$slots", i, "{}", "undefined", "true"];
        let a = 2;
        s && (o[2] = s, a = 3), n.length && (o[3] = Ns([], n, !1, !1, r), a = 4), t.scopeId && !t.slotted && (a = 5), o.splice(a), e.codegenNode = Xt(t.helper(sv), o, r)
    }
};

function B3(e, t) {
    let n = '"default"',
        r;
    const i = [];
    for (let s = 0; s < e.props.length; s++) {
        const o = e.props[s];
        if (o.type === 6) o.value && (o.name === "name" ? n = JSON.stringify(o.value.content) : (o.name = kt(o.name), i.push(o)));
        else if (o.name === "bind" && Ai(o.arg, "name")) {
            if (o.exp) n = o.exp;
            else if (o.arg && o.arg.type === 4) {
                const a = kt(o.arg.content);
                n = o.exp = We(a, !1, o.arg.loc)
            }
        } else o.name === "bind" && o.arg && Sn(o.arg) && (o.arg.content = kt(o.arg.content)), i.push(o)
    }
    if (i.length > 0) {
        const {
            props: s,
            directives: o
        } = Ov(e, t, i, !1, !1);
        r = s, o.length && t.onError(It(36, o[0].loc))
    }
    return {
        slotName: n,
        slotProps: r
    }
}
const V3 = /^\s*(async\s*)?(\([^)]*?\)|[\w$_]+)\s*(:[^=]+)?=>|^\s*(async\s+)?function(?:\s+[\w$]+)?\s*\(/,
    Pv = (e, t, n, r) => {
        const {
            loc: i,
            modifiers: s,
            arg: o
        } = e;
        !e.exp && !s.length && n.onError(It(35, i));
        let a;
        if (o.type === 4)
            if (o.isStatic) {
                let h = o.content;
                h.startsWith("vue:") && (h = `vnode-${h.slice(4)}`);
                const _ = t.tagType !== 0 || h.startsWith("vnode") || !/[A-Z]/.test(h) ? ws(kt(h)) : `on:${h}`;
                a = We(_, !0, o.loc)
            } else a = qn([`${n.helperString(Cu)}(`, o, ")"]);
        else a = o, a.children.unshift(`${n.helperString(Cu)}(`), a.children.push(")");
        let l = e.exp;
        l && !l.content.trim() && (l = void 0);
        let u = n.cacheHandlers && !l && !n.inVOnce;
        if (l) {
            const h = uv(l.content),
                _ = !(h || V3.test(l.content)),
                m = l.content.includes(";");
            (_ || u && h) && (l = qn([`${_?"$event":"(...args)"} => ${m?"{":"("}`, l, m ? "}" : ")"]))
        }
        let f = {
            props: [Bt(a, l || We("() => {}", !1, i))]
        };
        return r && (f = r(f)), u && (f.props[0].value = n.cache(f.props[0].value)), f.props.forEach(h => h.key.isHandlerKey = !0), f
    },
    H3 = (e, t, n) => {
        const {
            modifiers: r,
            loc: i
        } = e, s = e.arg;
        let {
            exp: o
        } = e;
        if (o && o.type === 4 && !o.content.trim() && (o = void 0), !o) {
            if (s.type !== 4 || !s.isStatic) return n.onError(It(52, s.loc)), {
                props: [Bt(s, We("", !0, i))]
            };
            const a = kt(s.content);
            o = e.exp = We(a, !1, s.loc)
        }
        return s.type !== 4 ? (s.children.unshift("("), s.children.push(') || ""')) : s.isStatic || (s.content = `${s.content} || ""`), r.includes("camel") && (s.type === 4 ? s.isStatic ? s.content = kt(s.content) : s.content = `${n.helperString(Tu)}(${s.content})` : (s.children.unshift(`${n.helperString(Tu)}(`), s.children.push(")"))), n.inSSR || (r.includes("prop") && bp(s, "."), r.includes("attr") && bp(s, "^")), {
            props: [Bt(s, o)]
        }
    },
    bp = (e, t) => {
        e.type === 4 ? e.isStatic ? e.content = t + e.content : e.content = `\`${t}\${${e.content}}\`` : (e.children.unshift(`'${t}' + (`), e.children.push(")"))
    },
    U3 = (e, t) => {
        if (e.type === 0 || e.type === 1 || e.type === 11 || e.type === 10) return () => {
            const n = e.children;
            let r, i = !1;
            for (let s = 0; s < n.length; s++) {
                const o = n[s];
                if (kc(o)) {
                    i = !0;
                    for (let a = s + 1; a < n.length; a++) {
                        const l = n[a];
                        if (kc(l)) r || (r = n[s] = qn([o], o.loc)), r.children.push(" + ", l), n.splice(a, 1), a--;
                        else {
                            r = void 0;
                            break
                        }
                    }
                }
            }
            if (!(!i || n.length === 1 && (e.type === 0 || e.type === 1 && e.tagType === 0 && !e.props.find(s => s.type === 7 && !t.directiveTransforms[s.name]) && e.tag !== "template")))
                for (let s = 0; s < n.length; s++) {
                    const o = n[s];
                    if (kc(o) || o.type === 8) {
                        const a = [];
                        (o.type !== 2 || o.content !== " ") && a.push(o), !t.ssr && jn(o, t) === 0 && a.push("1"), n[s] = {
                            type: 12,
                            content: o,
                            loc: o.loc,
                            codegenNode: Xt(t.helper(Bf), a)
                        }
                    }
                }
        }
    },
    wp = new WeakSet,
    W3 = (e, t) => {
        if (e.type === 1 && Un(e, "once", !0)) return wp.has(e) || t.inVOnce || t.inSSR ? void 0 : (wp.add(e), t.inVOnce = !0, t.helper(yl), () => {
            t.inVOnce = !1;
            const n = t.currentNode;
            n.codegenNode && (n.codegenNode = t.cache(n.codegenNode, !0))
        })
    },
    Mv = (e, t, n) => {
        const {
            exp: r,
            arg: i
        } = e;
        if (!r) return n.onError(It(41, e.loc)), Ia();
        const s = r.loc.source,
            o = r.type === 4 ? r.content : s,
            a = n.bindingMetadata[s];
        if (a === "props" || a === "props-aliased") return n.onError(It(44, r.loc)), Ia();
        const l = !1;
        if (!o.trim() || !uv(o) && !l) return n.onError(It(42, r.loc)), Ia();
        const u = i || We("modelValue", !0),
            f = i ? Sn(i) ? `onUpdate:${kt(i.content)}` : qn(['"onUpdate:" + ', i]) : "onUpdate:modelValue";
        let h;
        const _ = n.isTS ? "($event: any)" : "$event";
        h = qn([`${_} => ((`, r, ") = $event)"]);
        const m = [Bt(u, e.exp), Bt(f, h)];
        if (e.modifiers.length && t.tagType === 1) {
            const T = e.modifiers.map(B => (ed(B) ? B : JSON.stringify(B)) + ": true").join(", "),
                R = i ? Sn(i) ? `${i.content}Modifiers` : qn([i, ' + "Modifiers"']) : "modelModifiers";
            m.push(Bt(R, We(`{ ${T} }`, !1, e.loc, 2)))
        }
        return Ia(m)
    };

function Ia(e = []) {
    return {
        props: e
    }
}
const z3 = /[\w).+\-_$\]]/,
    q3 = (e, t) => {
        Fi("COMPILER_FILTERS", t) && (e.type === 5 && El(e.content, t), e.type === 1 && e.props.forEach(n => {
            n.type === 7 && n.name !== "for" && n.exp && El(n.exp, t)
        }))
    };

function El(e, t) {
    if (e.type === 4) Sp(e, t);
    else
        for (let n = 0; n < e.children.length; n++) {
            const r = e.children[n];
            typeof r == "object" && (r.type === 4 ? Sp(r, t) : r.type === 8 ? El(e, t) : r.type === 5 && El(r.content, t))
        }
}

function Sp(e, t) {
    const n = e.content;
    let r = !1,
        i = !1,
        s = !1,
        o = !1,
        a = 0,
        l = 0,
        u = 0,
        f = 0,
        h, _, m, T, R = [];
    for (m = 0; m < n.length; m++)
        if (_ = h, h = n.charCodeAt(m), r) h === 39 && _ !== 92 && (r = !1);
        else if (i) h === 34 && _ !== 92 && (i = !1);
    else if (s) h === 96 && _ !== 92 && (s = !1);
    else if (o) h === 47 && _ !== 92 && (o = !1);
    else if (h === 124 && n.charCodeAt(m + 1) !== 124 && n.charCodeAt(m - 1) !== 124 && !a && !l && !u) T === void 0 ? (f = m + 1, T = n.slice(0, m).trim()) : B();
    else {
        switch (h) {
            case 34:
                i = !0;
                break;
            case 39:
                r = !0;
                break;
            case 96:
                s = !0;
                break;
            case 40:
                u++;
                break;
            case 41:
                u--;
                break;
            case 91:
                l++;
                break;
            case 93:
                l--;
                break;
            case 123:
                a++;
                break;
            case 125:
                a--;
                break
        }
        if (h === 47) {
            let I = m - 1,
                A;
            for (; I >= 0 && (A = n.charAt(I), A === " "); I--);
            (!A || !z3.test(A)) && (o = !0)
        }
    }
    T === void 0 ? T = n.slice(0, m).trim() : f !== 0 && B();

    function B() {
        R.push(n.slice(f, m).trim()), f = m + 1
    }
    if (R.length) {
        for (m = 0; m < R.length; m++) T = K3(T, R[m], t);
        e.content = T
    }
}

function K3(e, t, n) {
    n.helper(Wf);
    const r = t.indexOf("(");
    if (r < 0) return n.filters.add(t), `${$o(t,"filter")}(${e})`; {
        const i = t.slice(0, r),
            s = t.slice(r + 1);
        return n.filters.add(i), `${$o(i,"filter")}(${e}${s!==")"?","+s:s}`
    }
}
const Tp = new WeakSet,
    G3 = (e, t) => {
        if (e.type === 1) {
            const n = Un(e, "memo");
            return !n || Tp.has(e) ? void 0 : (Tp.add(e), () => {
                const r = e.codegenNode || t.currentNode.codegenNode;
                r && r.type === 13 && (e.tagType !== 1 && Zf(r, t), e.codegenNode = Xt(t.helper(Jf), [n.exp, Ns(void 0, r), "_cache", String(t.cached++)]))
            })
        }
    };

function Y3(e) {
    return [
        [W3, E3, G3, O3, q3, j3, k3, R3, U3], {
            on: Pv,
            bind: H3,
            model: Mv
        }
    ]
}

function X3(e, t = {}) {
    const n = t.onError || Qf,
        r = t.mode === "module";
    t.prefixIdentifiers === !0 ? n(It(47)) : r && n(It(48));
    const i = !1;
    t.cacheHandlers && n(It(49)), t.scopeId && !r && n(It(50));
    const s = rt({}, t, {
            prefixIdentifiers: i
        }),
        o = He(e) ? n3(e, s) : e,
        [a, l] = Y3();
    return o3(o, rt({}, s, {
        nodeTransforms: [...a, ...t.nodeTransforms || []],
        directiveTransforms: rt({}, l, t.directiveTransforms || {})
    })), u3(o, s)
}
const J3 = () => ({
    props: []
});
/**
 * @vue/compiler-dom v3.4.27
 * (c) 2018-present Yuxi (Evan) You and Vue contributors
 * @license MIT
 **/
const Rv = Symbol(""),
    Iv = Symbol(""),
    $v = Symbol(""),
    kv = Symbol(""),
    Mu = Symbol(""),
    Lv = Symbol(""),
    Nv = Symbol(""),
    Fv = Symbol(""),
    Dv = Symbol(""),
    jv = Symbol("");
MA({
    [Rv]: "vModelRadio",
    [Iv]: "vModelCheckbox",
    [$v]: "vModelText",
    [kv]: "vModelSelect",
    [Mu]: "vModelDynamic",
    [Lv]: "withModifiers",
    [Nv]: "withKeys",
    [Fv]: "vShow",
    [Dv]: "Transition",
    [jv]: "TransitionGroup"
});
let cs;

function Z3(e, t = !1) {
    return cs || (cs = document.createElement("div")), t ? (cs.innerHTML = `<div foo="${e.replace(/"/g,"&quot;")}">`, cs.children[0].getAttribute("foo")) : (cs.innerHTML = e, cs.textContent)
}
const Q3 = {
        parseMode: "html",
        isVoidTag: wT,
        isNativeTag: e => vT(e) || yT(e) || bT(e),
        isPreTag: e => e === "pre",
        decodeEntities: Z3,
        isBuiltInComponent: e => {
            if (e === "Transition" || e === "transition") return Dv;
            if (e === "TransitionGroup" || e === "transition-group") return jv
        },
        getNamespace(e, t, n) {
            let r = t ? t.ns : n;
            if (t && r === 2)
                if (t.tag === "annotation-xml") {
                    if (e === "svg") return 1;
                    t.props.some(i => i.type === 6 && i.name === "encoding" && i.value != null && (i.value.content === "text/html" || i.value.content === "application/xhtml+xml")) && (r = 0)
                } else /^m(?:[ions]|text)$/.test(t.tag) && e !== "mglyph" && e !== "malignmark" && (r = 0);
            else t && r === 1 && (t.tag === "foreignObject" || t.tag === "desc" || t.tag === "title") && (r = 0);
            if (r === 0) {
                if (e === "svg") return 1;
                if (e === "math") return 2
            }
            return r
        }
    },
    ex = e => {
        e.type === 1 && e.props.forEach((t, n) => {
            t.type === 6 && t.name === "style" && t.value && (e.props[n] = {
                type: 7,
                name: "bind",
                arg: We("style", !0, t.loc),
                exp: tx(t.value.content, t.loc),
                modifiers: [],
                loc: t.loc
            })
        })
    },
    tx = (e, t) => {
        const n = og(e);
        return We(JSON.stringify(n), !1, t, 3)
    };

function ri(e, t) {
    return It(e, t)
}
const nx = (e, t, n) => {
        const {
            exp: r,
            loc: i
        } = e;
        return r || n.onError(ri(53, i)), t.children.length && (n.onError(ri(54, i)), t.children.length = 0), {
            props: [Bt(We("innerHTML", !0, i), r || We("", !0))]
        }
    },
    rx = (e, t, n) => {
        const {
            exp: r,
            loc: i
        } = e;
        return r || n.onError(ri(55, i)), t.children.length && (n.onError(ri(56, i)), t.children.length = 0), {
            props: [Bt(We("textContent", !0), r ? jn(r, n) > 0 ? r : Xt(n.helperString(nc), [r], i) : We("", !0))]
        }
    },
    ix = (e, t, n) => {
        const r = Mv(e, t, n);
        if (!r.props.length || t.tagType === 1) return r;
        e.arg && n.onError(ri(58, e.arg.loc));
        const {
            tag: i
        } = t, s = n.isCustomElement(i);
        if (i === "input" || i === "textarea" || i === "select" || s) {
            let o = $v,
                a = !1;
            if (i === "input" || s) {
                const l = rc(t, "type");
                if (l) {
                    if (l.type === 7) o = Mu;
                    else if (l.value) switch (l.value.content) {
                        case "radio":
                            o = Rv;
                            break;
                        case "checkbox":
                            o = Iv;
                            break;
                        case "file":
                            a = !0, n.onError(ri(59, e.loc));
                            break
                    }
                } else BA(t) && (o = Mu)
            } else i === "select" && (o = kv);
            a || (r.needRuntime = n.helper(o))
        } else n.onError(ri(57, e.loc));
        return r.props = r.props.filter(o => !(o.key.type === 4 && o.key.content === "modelValue")), r
    },
    sx = In("passive,once,capture"),
    ox = In("stop,prevent,self,ctrl,shift,alt,meta,exact,middle"),
    ax = In("left,right"),
    Bv = In("onkeyup,onkeydown,onkeypress", !0),
    lx = (e, t, n, r) => {
        const i = [],
            s = [],
            o = [];
        for (let a = 0; a < t.length; a++) {
            const l = t[a];
            l === "native" && Io("COMPILER_V_ON_NATIVE", n) || sx(l) ? o.push(l) : ax(l) ? Sn(e) ? Bv(e.content) ? i.push(l) : s.push(l) : (i.push(l), s.push(l)) : ox(l) ? s.push(l) : i.push(l)
        }
        return {
            keyModifiers: i,
            nonKeyModifiers: s,
            eventOptionModifiers: o
        }
    },
    Cp = (e, t) => Sn(e) && e.content.toLowerCase() === "onclick" ? We(t, !0) : e.type !== 4 ? qn(["(", e, `) === "onClick" ? "${t}" : (`, e, ")"]) : e,
    cx = (e, t, n) => Pv(e, t, n, r => {
        const {
            modifiers: i
        } = e;
        if (!i.length) return r;
        let {
            key: s,
            value: o
        } = r.props[0];
        const {
            keyModifiers: a,
            nonKeyModifiers: l,
            eventOptionModifiers: u
        } = lx(s, i, n, e.loc);
        if (l.includes("right") && (s = Cp(s, "onContextmenu")), l.includes("middle") && (s = Cp(s, "onMouseup")), l.length && (o = Xt(n.helper(Lv), [o, JSON.stringify(l)])), a.length && (!Sn(s) || Bv(s.content)) && (o = Xt(n.helper(Nv), [o, JSON.stringify(a)])), u.length) {
            const f = u.map(ts).join("");
            s = Sn(s) ? We(`${s.content}${f}`, !0) : qn(["(", s, `) + "${f}"`])
        }
        return {
            props: [Bt(s, o)]
        }
    }),
    ux = (e, t, n) => {
        const {
            exp: r,
            loc: i
        } = e;
        return r || n.onError(ri(61, i)), {
            props: [],
            needRuntime: n.helper(Fv)
        }
    },
    fx = (e, t) => {
        e.type === 1 && e.tagType === 0 && (e.tag === "script" || e.tag === "style") && t.removeNode()
    },
    dx = [ex],
    hx = {
        cloak: J3,
        html: nx,
        text: rx,
        model: ix,
        on: cx,
        show: ux
    };

function px(e, t = {}) {
    return X3(e, rt({}, Q3, t, {
        nodeTransforms: [fx, ...dx, ...t.nodeTransforms || []],
        directiveTransforms: rt({}, hx, t.directiveTransforms || {}),
        transformHoist: null
    }))
}
/**
 * vue v3.4.27
 * (c) 2018-present Yuxi (Evan) You and Vue contributors
 * @license MIT
 **/
const Ep = new WeakMap;

function mx(e) {
    let t = Ep.get(e ? ? ft);
    return t || (t = Object.create(null), Ep.set(e ? ? ft, t)), t
}

function gx(e, t) {
    if (!He(e))
        if (e.nodeType) e = e.innerHTML;
        else return Ut;
    const n = e,
        r = mx(t),
        i = r[n];
    if (i) return i;
    if (e[0] === "#") {
        const l = document.querySelector(e);
        e = l ? l.innerHTML : ""
    }
    const s = rt({
        hoistStatic: !0,
        onError: void 0,
        onWarn: Ut
    }, t);
    !s.isCustomElement && typeof customElements < "u" && (s.isCustomElement = l => !!customElements.get(l));
    const {
        code: o
    } = px(e, s), a = new Function("Vue", o)(CA);
    return a._rc = !0, r[n] = a
}
O_(gx);

function Qo(e) {
    return pf() ? (fg(e), !0) : !1
}

function ii(e) {
    return typeof e == "function" ? e() : Ar(e)
}
const nd = typeof window < "u" && typeof document < "u";
typeof WorkerGlobalScope < "u" && globalThis instanceof WorkerGlobalScope;
const Vv = e => e != null,
    _x = Object.prototype.toString,
    vx = e => _x.call(e) === "[object Object]",
    fo = () => {},
    Ap = yx();

function yx() {
    var e, t;
    return nd && ((e = window == null ? void 0 : window.navigator) == null ? void 0 : e.userAgent) && (/iP(?:ad|hone|od)/.test(window.navigator.userAgent) || ((t = window == null ? void 0 : window.navigator) == null ? void 0 : t.maxTouchPoints) > 2 && /iPad|Macintosh/.test(window == null ? void 0 : window.navigator.userAgent))
}

function bx(e) {
    return e || Jn()
}

function Hv(...e) {
    if (e.length !== 1) return Pg(...e);
    const t = e[0];
    return typeof t == "function" ? Cr(Tf(() => ({
        get: t,
        set: fo
    }))) : Tn(t)
}

function wx(e, t = !0, n) {
    bx() ? is(e, n) : t ? e() : Ws(e)
}

function Sx(e, t, n = {}) {
    const {
        immediate: r = !0
    } = n, i = Tn(!1);
    let s = null;

    function o() {
        s && (clearTimeout(s), s = null)
    }

    function a() {
        i.value = !1, o()
    }

    function l(...u) {
        o(), i.value = !0, s = setTimeout(() => {
            i.value = !1, s = null, e(...u)
        }, ii(t))
    }
    return r && (i.value = !0, nd && l()), Qo(a), {
        isPending: Cr(i),
        start: l,
        stop: a
    }
}

function ho(e) {
    var t;
    const n = ii(e);
    return (t = n == null ? void 0 : n.$el) != null ? t : n
}
const oc = nd ? window : void 0;

function po(...e) {
    let t, n, r, i;
    if (typeof e[0] == "string" || Array.isArray(e[0]) ? ([n, r, i] = e, t = oc) : [t, n, r, i] = e, !t) return fo;
    Array.isArray(n) || (n = [n]), Array.isArray(r) || (r = [r]);
    const s = [],
        o = () => {
            s.forEach(f => f()), s.length = 0
        },
        a = (f, h, _, m) => (f.addEventListener(h, _, m), () => f.removeEventListener(h, _, m)),
        l = zn(() => [ho(t), ii(i)], ([f, h]) => {
            if (o(), !f) return;
            const _ = vx(h) ? { ...h
            } : h;
            s.push(...n.flatMap(m => r.map(T => a(f, m, T, _))))
        }, {
            immediate: !0,
            flush: "post"
        }),
        u = () => {
            l(), o()
        };
    return Qo(u), u
}

function Tx() {
    const e = Tn(!1),
        t = Jn();
    return t && is(() => {
        e.value = !0
    }, t), e
}

function Uv(e) {
    const t = Tx();
    return Ht(() => (t.value, !!e()))
}

function Cx(e, t, n = {}) {
    const {
        window: r = oc,
        ...i
    } = n;
    let s;
    const o = Uv(() => r && "MutationObserver" in r),
        a = () => {
            s && (s.disconnect(), s = void 0)
        },
        l = Ht(() => {
            const _ = ii(e),
                m = (Array.isArray(_) ? _ : [_]).map(ho).filter(Vv);
            return new Set(m)
        }),
        u = zn(() => l.value, _ => {
            a(), o.value && _.size && (s = new MutationObserver(t), _.forEach(m => s.observe(m, i)))
        }, {
            immediate: !0,
            flush: "post"
        }),
        f = () => s == null ? void 0 : s.takeRecords(),
        h = () => {
            a(), u()
        };
    return Qo(h), {
        isSupported: o,
        stop: h,
        takeRecords: f
    }
}

function Ex(e, t, n = {}) {
    const {
        root: r,
        rootMargin: i = "0px",
        threshold: s = .1,
        window: o = oc,
        immediate: a = !0
    } = n, l = Uv(() => o && "IntersectionObserver" in o), u = Ht(() => {
        const T = ii(e);
        return (Array.isArray(T) ? T : [T]).map(ho).filter(Vv)
    });
    let f = fo;
    const h = Tn(a),
        _ = l.value ? zn(() => [u.value, ho(r), h.value], ([T, R]) => {
            if (f(), !h.value || !T.length) return;
            const B = new IntersectionObserver(t, {
                root: ho(R),
                rootMargin: i,
                threshold: s
            });
            T.forEach(I => I && B.observe(I)), f = () => {
                B.disconnect(), f = fo
            }
        }, {
            immediate: a,
            flush: "post"
        }) : fo,
        m = () => {
            f(), _(), h.value = !1
        };
    return Qo(m), {
        isSupported: l,
        isActive: h,
        pause() {
            f(), h.value = !1
        },
        resume() {
            h.value = !0
        },
        stop: m
    }
}

function Ax(e, t = {}) {
    const {
        window: n = oc,
        scrollTarget: r,
        threshold: i = 0
    } = t, s = Tn(!1);
    return Ex(e, o => {
        let a = s.value,
            l = 0;
        for (const u of o) u.time >= l && (l = u.time, a = u.isIntersecting);
        s.value = a
    }, {
        root: r,
        window: n,
        threshold: i
    }), s
}

function Nc(e) {
    return typeof Window < "u" && e instanceof Window ? e.document.documentElement : typeof Document < "u" && e instanceof Document ? e.documentElement : e
}

function xx(e, t = {}) {
    const n = Hv(e),
        {
            threshold: r = 50,
            onSwipe: i,
            onSwipeEnd: s,
            onSwipeStart: o,
            disableTextSelect: a = !1
        } = t,
        l = li({
            x: 0,
            y: 0
        }),
        u = (H, F) => {
            l.x = H, l.y = F
        },
        f = li({
            x: 0,
            y: 0
        }),
        h = (H, F) => {
            f.x = H, f.y = F
        },
        _ = Ht(() => l.x - f.x),
        m = Ht(() => l.y - f.y),
        {
            max: T,
            abs: R
        } = Math,
        B = Ht(() => T(R(_.value), R(m.value)) >= r),
        I = Tn(!1),
        A = Tn(!1),
        E = Ht(() => B.value ? R(_.value) > R(m.value) ? _.value > 0 ? "left" : "right" : m.value > 0 ? "up" : "down" : "none"),
        O = H => {
            var F, V, k;
            const Y = H.buttons === 0,
                L = H.buttons === 1;
            return (k = (V = (F = t.pointerTypes) == null ? void 0 : F.includes(H.pointerType)) != null ? V : Y || L) != null ? k : !0
        },
        P = [po(e, "pointerdown", H => {
            if (!O(H)) return;
            A.value = !0;
            const F = H.target;
            F == null || F.setPointerCapture(H.pointerId);
            const {
                clientX: V,
                clientY: k
            } = H;
            u(V, k), h(V, k), o == null || o(H)
        }), po(e, "pointermove", H => {
            if (!O(H) || !A.value) return;
            const {
                clientX: F,
                clientY: V
            } = H;
            h(F, V), !I.value && B.value && (I.value = !0), I.value && (i == null || i(H))
        }), po(e, "pointerup", H => {
            O(H) && (I.value && (s == null || s(H, E.value)), A.value = !1, I.value = !1)
        })];
    wx(() => {
        var H, F, V, k, Y, L, te, ie;
        (F = (H = n.value) == null ? void 0 : H.style) == null || F.setProperty("touch-action", "none"), a && ((k = (V = n.value) == null ? void 0 : V.style) == null || k.setProperty("-webkit-user-select", "none"), (L = (Y = n.value) == null ? void 0 : Y.style) == null || L.setProperty("-ms-user-select", "none"), (ie = (te = n.value) == null ? void 0 : te.style) == null || ie.setProperty("user-select", "none"))
    });
    const $ = () => P.forEach(H => H());
    return {
        isSwiping: Cr(I),
        direction: Cr(E),
        posStart: Cr(l),
        posEnd: Cr(f),
        distanceX: _,
        distanceY: m,
        stop: $
    }
}

function Wv(e) {
    const t = window.getComputedStyle(e);
    if (t.overflowX === "scroll" || t.overflowY === "scroll" || t.overflowX === "auto" && e.clientWidth < e.scrollWidth || t.overflowY === "auto" && e.clientHeight < e.scrollHeight) return !0; {
        const n = e.parentNode;
        return !n || n.tagName === "BODY" ? !1 : Wv(n)
    }
}

function Ox(e) {
    const t = e || window.event,
        n = t.target;
    return Wv(n) ? !1 : t.touches.length > 1 ? !0 : (t.preventDefault && t.preventDefault(), !1)
}
const Fc = new WeakMap;

function Px(e, t = !1) {
    const n = Tn(t);
    let r = null,
        i = "";
    zn(Hv(e), a => {
        const l = Nc(ii(a));
        if (l) {
            const u = l;
            if (Fc.get(u) || Fc.set(u, u.style.overflow), u.style.overflow !== "hidden" && (i = u.style.overflow), u.style.overflow === "hidden") return n.value = !0;
            if (n.value) return u.style.overflow = "hidden"
        }
    }, {
        immediate: !0
    });
    const s = () => {
            const a = Nc(ii(e));
            !a || n.value || (Ap && (r = po(a, "touchmove", l => {
                Ox(l)
            }, {
                passive: !1
            })), a.style.overflow = "hidden", n.value = !0)
        },
        o = () => {
            const a = Nc(ii(e));
            !a || !n.value || (Ap && (r == null || r()), a.style.overflow = i, Fc.delete(a), n.value = !1)
        };
    return Qo(o), Ht({
        get() {
            return n.value
        },
        set(a) {
            a ? s() : o()
        }
    })
}
/**
 * anime.js - ESM
 * @version v4.0.2
 * @author Julian Garnier
 * @license MIT
 * @copyright (c) 2025 Julian Garnier
 * @see https://animejs.com
 */
const pr = typeof window < "u",
    Qr = pr ? window : null,
    Yt = pr ? document : null,
    jt = {
        OBJECT: 0,
        ATTRIBUTE: 1,
        CSS: 2,
        TRANSFORM: 3,
        CSS_VAR: 4
    },
    Je = {
        NUMBER: 0,
        UNIT: 1,
        COLOR: 2,
        COMPLEX: 3
    },
    Fn = {
        NONE: 0,
        AUTO: 1,
        FORCE: 2
    },
    gn = {
        replace: 0,
        none: 1,
        blend: 2
    },
    xp = Symbol(),
    ac = Symbol(),
    zv = Symbol(),
    lc = Symbol(),
    Mx = Symbol(),
    St = 1e-11,
    qv = 1e12,
    Yi = 1e3,
    Ru = 120,
    ei = "",
    ea = new Map;
ea.set("x", "translateX");
ea.set("y", "translateY");
ea.set("z", "translateZ");
const rd = ["translateX", "translateY", "translateZ", "rotate", "rotateX", "rotateY", "rotateZ", "scale", "scaleX", "scaleY", "scaleZ", "skew", "skewX", "skewY", "perspective", "matrix", "matrix3d"],
    Kv = rd.reduce((e, t) => ({ ...e,
        [t]: t + "("
    }), {}),
    Tt = () => {},
    Rx = /(^#([\da-f]{3}){1,2}$)|(^#([\da-f]{4}){1,2}$)/i,
    Ix = /rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)/i,
    $x = /rgba\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(-?\d+|-?\d*.\d+)\s*\)/i,
    kx = /hsl\(\s*(-?\d+|-?\d*.\d+)\s*,\s*(-?\d+|-?\d*.\d+)%\s*,\s*(-?\d+|-?\d*.\d+)%\s*\)/i,
    Lx = /hsla\(\s*(-?\d+|-?\d*.\d+)\s*,\s*(-?\d+|-?\d*.\d+)%\s*,\s*(-?\d+|-?\d*.\d+)%\s*,\s*(-?\d+|-?\d*.\d+)\s*\)/i,
    Op = /[-+]?\d*\.?\d+(?:e[-+]?\d)?/gi,
    Gv = /^([-+]?\d*\.?\d+(?:e[-+]?\d+)?)([a-z]+|%)$/i,
    Nx = /([a-z])([A-Z])/g,
    Fx = /(\w+)(\([^)]+\)+)/g,
    Yv = /(\*=|\+=|-=)/,
    Xv = {
        id: null,
        keyframes: null,
        playbackEase: null,
        playbackRate: 1,
        frameRate: Ru,
        loop: 0,
        reversed: !1,
        alternate: !1,
        autoplay: !0,
        duration: Yi,
        delay: 0,
        loopDelay: 0,
        ease: "out(2)",
        composition: gn.replace,
        modifier: e => e,
        onBegin: Tt,
        onBeforeUpdate: Tt,
        onUpdate: Tt,
        onLoop: Tt,
        onPause: Tt,
        onComplete: Tt,
        onRender: Tt
    },
    Lt = {
        defaults: Xv,
        root: Yt,
        scope: null,
        precision: 4,
        timeScale: 1,
        tickThreshold: 200
    },
    Jv = {
        version: "4.0.2",
        engine: null
    };
pr && (Qr.AnimeJS || (Qr.AnimeJS = []), Qr.AnimeJS.push(Jv));
const Dx = e => e.replace(Nx, "$1-$2").toLowerCase(),
    Di = (e, t) => e.indexOf(t) === 0,
    Lo = Date.now,
    js = Array.isArray,
    mo = e => e && e.constructor === Object,
    Oi = e => typeof e == "number" && !isNaN(e),
    si = e => typeof e == "string",
    No = e => typeof e == "function",
    Ue = e => typeof e > "u",
    Ga = e => Ue(e) || e === null,
    Zv = e => pr && e instanceof SVGElement,
    Qv = e => Rx.test(e),
    ey = e => Di(e, "rgb"),
    ty = e => Di(e, "hsl"),
    jx = e => Qv(e) || ey(e) || ty(e),
    Ya = e => !Lt.defaults.hasOwnProperty(e),
    Pi = e => si(e) ? parseFloat(e) : e,
    hs = Math.pow,
    ny = Math.sqrt,
    Bx = Math.sin,
    Vx = Math.cos,
    Iu = Math.abs,
    Hx = Math.ceil,
    Al = Math.floor,
    Ux = Math.asin,
    Wx = Math.max,
    id = Math.PI,
    Pp = Math.round,
    rn = (e, t, n) => e < t ? t : e > n ? n : e,
    Mp = {},
    wt = (e, t) => {
        if (t < 0) return e;
        if (!t) return Pp(e);
        let n = Mp[t];
        return n || (n = Mp[t] = 10 ** t), Pp(e * n) / n
    },
    qr = (e, t, n) => e + (t - e) * n,
    sd = e => e === 1 / 0 ? qv : e === -1 / 0 ? -1e12 : e,
    go = e => e <= St ? St : sd(wt(e, 11)),
    pn = e => js(e) ? [...e] : e,
    zx = (e, t) => {
        const n = { ...e
        };
        for (let r in t) {
            const i = e[r];
            n[r] = Ue(i) ? t[r] : i
        }
        return n
    },
    $t = (e, t, n, r = "_prev", i = "_next") => {
        let s = e._head,
            o = i;
        for (n && (s = e._tail, o = r); s;) {
            const a = s[o];
            t(s), s = a
        }
    },
    _s = (e, t, n = "_prev", r = "_next") => {
        const i = t[n],
            s = t[r];
        i ? i[r] = s : e._head = s, s ? s[n] = i : e._tail = i, t[n] = null, t[r] = null
    },
    Mi = (e, t, n, r = "_prev", i = "_next") => {
        let s = e._tail;
        for (; s && n && n(s, t);) s = s[r];
        const o = s ? s[i] : e._head;
        s ? s[i] = t : e._head = t, o ? o[r] = t : e._tail = t, t[r] = s, t[i] = o
    };
class ry {
    constructor(t = 0) {
        this.deltaTime = 0, this._currentTime = t, this._elapsedTime = t, this._startTime = t, this._lastTime = t, this._scheduledTime = 0, this._frameDuration = wt(Yi / Ru, 0), this._fps = Ru, this._speed = 1, this._hasChildren = !1, this._head = null, this._tail = null
    }
    get fps() {
        return this._fps
    }
    set fps(t) {
        const n = this._frameDuration,
            r = +t,
            i = r < St ? St : r,
            s = wt(Yi / i, 0);
        this._fps = i, this._frameDuration = s, this._scheduledTime += s - n
    }
    get speed() {
        return this._speed
    }
    set speed(t) {
        const n = +t;
        this._speed = n < St ? St : n
    }
    requestTick(t) {
        const n = this._scheduledTime,
            r = this._elapsedTime;
        if (this._elapsedTime += t - r, r < n) return Fn.NONE;
        const i = this._frameDuration,
            s = r - n;
        return this._scheduledTime += s < i ? i : s, Fn.AUTO
    }
    computeDeltaTime(t) {
        const n = t - this._lastTime;
        return this.deltaTime = n, this._lastTime = t, n
    }
}
const Xa = (e, t, n, r, i) => {
        const s = e.parent,
            o = e.duration,
            a = e.completed,
            l = e.iterationDuration,
            u = e.iterationCount,
            f = e._currentIteration,
            h = e._loopDelay,
            _ = e._reversed,
            m = e._alternate,
            T = e._hasChildren,
            R = e._delay,
            B = e._currentTime,
            I = R + l,
            A = t - R,
            E = rn(B, -R, o),
            O = rn(A, -R, o),
            P = A - B,
            $ = O > 0,
            H = O >= o,
            F = o <= St,
            V = i === Fn.FORCE;
        let k = 0,
            Y = A,
            L = 0;
        if (u > 1) {
            const le = ~~(O / (l + (H ? 0 : h)));
            e._currentIteration = rn(le, 0, u), H && e._currentIteration--, k = e._currentIteration % 2, Y = O % (l + h) || 0
        }
        const te = _ ^ (m && k),
            ie = e._ease;
        let _e = H ? te ? 0 : o : te ? l - Y : Y;
        ie && (_e = l * ie(_e / l) || 0);
        const X = (s ? s.backwards : A < B) ? !te : !!te;
        if (e._currentTime = A, e._iterationTime = _e, e.backwards = X, $ && !e.began ? (e.began = !0, !n && !(s && (X || !s.began)) && e.onBegin(e)) : A <= 0 && (e.began = !1), !n && !T && $ && e._currentIteration !== f && e.onLoop(e), V || i === Fn.AUTO && (t >= R && t <= I || t <= R && E > R || t >= I && E !== o) || _e >= I && E !== o || _e <= R && E > 0 || t <= E && E === o && a || H && !a && F) {
            if ($ && (e.computeDeltaTime(E), n || e.onBeforeUpdate(e)), !T) {
                const le = V || (X ? P * -1 : P) >= Lt.tickThreshold,
                    ce = e._offset + (s ? s._offset : 0) + R + _e;
                let ue = e._head,
                    Oe, ke, Ze, Fe, Ie = 0;
                for (; ue;) {
                    const Le = ue._composition,
                        Ne = ue._currentTime,
                        W = ue._changeDuration,
                        ge = ue._absoluteStartTime + ue._changeDuration,
                        fe = ue._nextRep,
                        ye = ue._prevRep,
                        Me = Le !== gn.none;
                    if ((le || (Ne !== W || ce <= ge + (fe ? fe._delay : 0)) && (Ne !== 0 || ce >= ue._absoluteStartTime)) && (!Me || !ue._isOverridden && (!ue._isOverlapped || ce <= ge) && (!fe || fe._isOverridden || ce <= fe._absoluteStartTime) && (!ye || ye._isOverridden || ce >= ye._absoluteStartTime + ye._changeDuration + ue._delay))) {
                        const Be = ue._currentTime = rn(_e - ue._startTime, 0, W),
                            S = ue._ease(Be / ue._updateDuration),
                            C = ue._modifier,
                            U = ue._valueType,
                            K = ue._tweenType,
                            z = K === jt.OBJECT,
                            ae = U === Je.NUMBER,
                            me = ae && z || S === 0 || S === 1 ? -1 : Lt.precision;
                        let re, v;
                        if (ae) re = v = C(wt(qr(ue._fromNumber, ue._toNumber, S), me));
                        else if (U === Je.UNIT) v = C(wt(qr(ue._fromNumber, ue._toNumber, S), me)), re = `${v}${ue._unit}`;
                        else if (U === Je.COLOR) {
                            const c = ue._fromNumbers,
                                d = ue._toNumbers,
                                b = wt(rn(C(qr(c[0], d[0], S)), 0, 255), 0),
                                x = wt(rn(C(qr(c[1], d[1], S)), 0, 255), 0),
                                j = wt(rn(C(qr(c[2], d[2], S)), 0, 255), 0),
                                q = rn(C(wt(qr(c[3], d[3], S), me)), 0, 1);
                            if (re = `rgba(${b},${x},${j},${q})`, Me) {
                                const oe = ue._numbers;
                                oe[0] = b, oe[1] = x, oe[2] = j, oe[3] = q
                            }
                        } else if (U === Je.COMPLEX) {
                            re = ue._strings[0];
                            for (let c = 0, d = ue._toNumbers.length; c < d; c++) {
                                const b = C(wt(qr(ue._fromNumbers[c], ue._toNumbers[c], S), me)),
                                    x = ue._strings[c + 1];
                                re += `${x?b+x:b}`, Me && (ue._numbers[c] = b)
                            }
                        }
                        if (Me && (ue._number = v), !r && Le !== gn.blend) {
                            const c = ue.property;
                            Oe = ue.target, z ? Oe[c] = re : K === jt.ATTRIBUTE ? Oe.setAttribute(c, re) : (ke = Oe.style, K === jt.TRANSFORM ? (Oe !== Ze && (Ze = Oe, Fe = Oe[lc]), Fe[c] = re, Ie = 1) : K === jt.CSS ? ke[c] = re : K === jt.CSS_VAR && ke.setProperty(c, re)), $ && (L = 1)
                        } else ue._value = re
                    }
                    if (Ie && ue._renderTransforms) {
                        let Be = ei;
                        for (let S in Fe) Be += `${Kv[S]}${Fe[S]}) `;
                        ke.transform = Be, Ie = 0
                    }
                    ue = ue._next
                }!n && L && e.onRender(e)
            }!n && $ && e.onUpdate(e)
        }
        return s && F ? !n && (s.began && !X && A >= o && !a || X && A <= St && a) && (e.onComplete(e), e.completed = !X) : $ && H ? u === 1 / 0 ? e._startTime += e.duration : e._currentIteration >= u - 1 && (e.paused = !0, !a && !T && (e.completed = !0, !n && !(s && (X || !s.began)) && (e.onComplete(e), e._resolve(e)))) : e.completed = !1, L
    },
    ps = (e, t, n, r, i) => {
        const s = e._currentIteration;
        if (Xa(e, t, n, r, i), e._hasChildren) {
            const o = e,
                a = o.backwards,
                l = r ? t : o._iterationTime,
                u = Lo();
            let f = 0,
                h = !0;
            if (!r && o._currentIteration !== s) {
                const _ = o.iterationDuration;
                $t(o, m => {
                    if (!a) !m.completed && !m.backwards && m._currentTime < m.iterationDuration && Xa(m, _, n, 1, Fn.FORCE), m.began = !1, m.completed = !1;
                    else {
                        const T = m.duration,
                            R = m._offset + m._delay,
                            B = R + T;
                        !n && T <= St && (!R || B === _) && m.onComplete(m)
                    }
                }), n || o.onLoop(o)
            }
            $t(o, _ => {
                const m = wt((l - _._offset) * _._speed, 12),
                    T = _._fps < o._fps ? _.requestTick(u) : i;
                f += Xa(_, m, n, r, T), !_.completed && h && (h = !1)
            }, a), !n && f && o.onRender(o), h && o._currentTime >= o.duration && (o.paused = !0, o.completed || (o.completed = !0, n || (o.onComplete(o), o._resolve(o))))
        }
    },
    Os = {
        animation: null,
        update: Tt
    },
    qx = e => {
        let t = Os.animation;
        return t || (t = {
            duration: St,
            computeDeltaTime: Tt,
            _offset: 0,
            _delay: 0,
            _head: null,
            _tail: null
        }, Os.animation = t, Os.update = () => {
            e.forEach(n => {
                for (let r in n) {
                    const i = n[r],
                        s = i._head;
                    if (s) {
                        const o = s._valueType,
                            a = o === Je.COMPLEX || o === Je.COLOR ? pn(s._fromNumbers) : null;
                        let l = s._fromNumber,
                            u = i._tail;
                        for (; u && u !== s;) {
                            if (a)
                                for (let f = 0, h = u._numbers.length; f < h; f++) a[f] += u._numbers[f];
                            else l += u._number;
                            u = u._prevAdd
                        }
                        s._toNumber = l, s._toNumbers = a
                    }
                }
            }), Xa(t, 1, 1, 0, Fn.FORCE)
        }), t
    },
    iy = pr ? requestAnimationFrame : setImmediate,
    Kx = pr ? cancelAnimationFrame : clearImmediate;
class Gx extends ry {
    constructor(t) {
        super(t), this.useDefaultMainLoop = !0, this.pauseOnDocumentHidden = !0, this.defaults = Xv, this.paused = !!(pr && Yt.hidden), this.reqId = null
    }
    update() {
        const t = this._currentTime = Lo();
        if (this.requestTick(t)) {
            this.computeDeltaTime(t);
            const n = this._speed,
                r = this._fps;
            let i = this._head;
            for (; i;) {
                const s = i._next;
                i.paused ? (_s(this, i), this._hasChildren = !!this._tail, i._running = !1, i.completed && !i._cancelled && i.cancel()) : ps(i, (t - i._startTime) * i._speed * n, 0, 0, i._fps < r ? i.requestTick(t) : Fn.AUTO), i = s
            }
            Os.update()
        }
    }
    wake() {
        return this.useDefaultMainLoop && !this.reqId && !this.paused && (this.reqId = iy(sy)), this
    }
    pause() {
        return this.paused = !0, Yx()
    }
    resume() {
        if (this.paused) return this.paused = !1, $t(this, t => t.resetTime()), this.wake()
    }
    get speed() {
        return this._speed * (Lt.timeScale === 1 ? 1 : Yi)
    }
    set speed(t) {
        this._speed = t * Lt.timeScale, $t(this, n => n.speed = n._speed)
    }
    get timeUnit() {
        return Lt.timeScale === 1 ? "ms" : "s"
    }
    set timeUnit(t) {
        const r = t === "s",
            i = r ? .001 : 1;
        if (Lt.timeScale !== i) {
            Lt.timeScale = i, Lt.tickThreshold = 200 * i;
            const s = r ? .001 : Yi;
            this.defaults.duration *= s, this._speed *= s
        }
    }
    get precision() {
        return Lt.precision
    }
    set precision(t) {
        Lt.precision = t
    }
}
const Qt = (() => {
        const e = new Gx(Lo());
        return pr && (Jv.engine = e, Yt.addEventListener("visibilitychange", () => {
            e.pauseOnDocumentHidden && (Yt.hidden ? e.pause() : e.resume())
        })), e
    })(),
    sy = () => {
        Qt._head ? (Qt.reqId = iy(sy), Qt.update()) : Qt.reqId = 0
    },
    Yx = () => (Kx(Qt.reqId), Qt.reqId = 0, Qt),
    Xx = (e, t, n) => {
        const r = e.style.transform;
        let i;
        if (r) {
            const s = e[lc];
            let o;
            for (; o = Fx.exec(r);) {
                const a = o[1],
                    l = o[2].slice(1, -1);
                s[a] = l, a === t && (i = l, n && (n[t] = l))
            }
        }
        return r && !Ue(i) ? i : Di(t, "scale") ? "1" : Di(t, "rotate") || Di(t, "skew") ? "0deg" : "0px"
    };

function Rp(e) {
    const t = si(e) ? Lt.root.querySelectorAll(e) : e;
    if (t instanceof NodeList || t instanceof HTMLCollection) return t
}

function od(e) {
    if (Ga(e)) return [];
    if (js(e)) {
        const n = e.flat(1 / 0),
            r = [];
        for (let i = 0, s = n.length; i < s; i++) {
            const o = n[i];
            if (!Ga(o)) {
                const a = Rp(o);
                if (a)
                    for (let l = 0, u = a.length; l < u; l++) {
                        const f = a[l];
                        if (!Ga(f)) {
                            let h = !1;
                            for (let _ = 0, m = r.length; _ < m; _++)
                                if (r[_] === f) {
                                    h = !0;
                                    break
                                }
                            h || r.push(f)
                        }
                    } else {
                        let l = !1;
                        for (let u = 0, f = r.length; u < f; u++)
                            if (r[u] === o) {
                                l = !0;
                                break
                            }
                        l || r.push(o)
                    }
            }
        }
        return r
    }
    if (!pr) return [e];
    const t = Rp(e);
    return t ? Array.from(t) : [e]
}

function oy(e) {
    const t = od(e),
        n = t.length;
    if (n)
        for (let r = 0; r < n; r++) {
            const i = t[r];
            if (!i[xp]) {
                i[xp] = !0;
                const s = Zv(i);
                (i.nodeType || s) && (i[ac] = !0, i[zv] = s, i[lc] = {})
            }
        }
    return t
}
const Jx = ["opacity", "rotate", "overflow", "color"],
    Zx = (e, t) => {
        if (Jx.includes(t)) return !1;
        if (e.getAttribute(t) || t in e) {
            if (t === "scale") {
                const n = e.parentNode;
                return n && n.tagName === "filter"
            }
            return !0
        }
    },
    Qx = e => {
        const t = Ix.exec(e) || $x.exec(e),
            n = Ue(t[4]) ? 1 : +t[4];
        return [+t[1], +t[2], +t[3], n]
    },
    eO = e => {
        const t = e.length,
            n = t === 4 || t === 5;
        return [+("0x" + e[1] + e[n ? 1 : 2]), +("0x" + e[n ? 2 : 3] + e[n ? 2 : 4]), +("0x" + e[n ? 3 : 5] + e[n ? 3 : 6]), t === 5 || t === 9 ? +(+("0x" + e[n ? 4 : 7] + e[n ? 4 : 8]) / 255).toFixed(3) : 1]
    },
    Dc = (e, t, n) => (n < 0 && (n += 1), n > 1 && (n -= 1), n < 1 / 6 ? e + (t - e) * 6 * n : n < 1 / 2 ? t : n < 2 / 3 ? e + (t - e) * (2 / 3 - n) * 6 : e),
    tO = e => {
        const t = kx.exec(e) || Lx.exec(e),
            n = +t[1] / 360,
            r = +t[2] / 100,
            i = +t[3] / 100,
            s = Ue(t[4]) ? 1 : +t[4];
        let o, a, l;
        if (r === 0) o = a = l = i;
        else {
            const u = i < .5 ? i * (1 + r) : i + r - i * r,
                f = 2 * i - u;
            o = wt(Dc(f, u, n + 1 / 3) * 255, 0), a = wt(Dc(f, u, n) * 255, 0), l = wt(Dc(f, u, n - 1 / 3) * 255, 0)
        }
        return [o, a, l, s]
    },
    nO = e => ey(e) ? Qx(e) : Qv(e) ? eO(e) : ty(e) ? tO(e) : [0, 0, 0, 1],
    Nt = (e, t) => Ue(e) ? t : e,
    Hr = (e, t, n, r, i) => {
        if (No(e)) {
            const s = () => {
                const o = e(t, n, r);
                return isNaN(+o) ? o || 0 : +o
            };
            return i && (i.func = s), s()
        } else return e
    },
    ad = (e, t) => e[ac] ? e[zv] && Zx(e, t) ? jt.ATTRIBUTE : rd.includes(t) || ea.get(t) ? jt.TRANSFORM : Di(t, "--") ? jt.CSS_VAR : t in e.style ? jt.CSS : t in e ? jt.OBJECT : jt.ATTRIBUTE : jt.OBJECT,
    Ip = (e, t, n) => {
        const r = e.style[t];
        r && n && (n[t] = r);
        const i = r || getComputedStyle(e[Mx] || e).getPropertyValue(t);
        return i === "auto" ? "0" : i
    },
    ms = (e, t, n, r) => {
        const i = Ue(n) ? ad(e, t) : n;
        return i === jt.OBJECT ? e[t] || 0 : i === jt.ATTRIBUTE ? e.getAttribute(t) : i === jt.TRANSFORM ? Xx(e, t, r) : i === jt.CSS_VAR ? Ip(e, t, r).trimStart() : Ip(e, t, r)
    },
    Ps = (e, t, n) => n === "-" ? e - t : n === "+" ? e + t : e * t,
    ld = () => ({
        t: Je.NUMBER,
        n: 0,
        u: null,
        o: null,
        d: null,
        s: null
    }),
    Nn = (e, t) => {
        if (t.t = Je.NUMBER, t.n = 0, t.u = null, t.o = null, t.d = null, t.s = null, !e) return t;
        const n = +e;
        if (isNaN(n)) {
            let r = e;
            r[1] === "=" && (t.o = r[0], r = r.slice(2));
            const i = r.includes(" ") ? !1 : Gv.exec(r);
            if (i) return t.t = Je.UNIT, t.n = +i[1], t.u = i[2], t;
            if (t.o) return t.n = +r, t;
            if (jx(r)) return t.t = Je.COLOR, t.d = nO(r), t; {
                const s = r.match(Op);
                return t.t = Je.COMPLEX, t.d = s ? s.map(Number) : [], t.s = r.split(Op) || [], t
            }
        } else return t.n = n, t
    },
    $p = (e, t) => (t.t = e._valueType, t.n = e._toNumber, t.u = e._unit, t.o = null, t.d = pn(e._toNumbers), t.s = pn(e._strings), t),
    bn = ld(),
    xl = {
        _rep: new WeakMap,
        _add: new Map
    },
    cd = (e, t, n = "_rep") => {
        const r = xl[n];
        let i = r.get(e);
        return i || (i = {}, r.set(e, i)), i[t] ? i[t] : i[t] = {
            _head: null,
            _tail: null
        }
    },
    rO = (e, t) => e._isOverridden || e._absoluteStartTime > t._absoluteStartTime,
    Ja = e => {
        e._isOverlapped = 1, e._isOverridden = 1, e._changeDuration = St, e._currentTime = St
    },
    ay = (e, t) => {
        const n = e._composition;
        if (n === gn.replace) {
            const r = e._absoluteStartTime;
            Mi(t, e, rO, "_prevRep", "_nextRep");
            const i = e._prevRep;
            if (i) {
                const s = i.parent,
                    o = i._absoluteStartTime + i._changeDuration;
                if (e.parent.id !== s.id && s.iterationCount > 1 && o + (s.duration - s.iterationDuration) > r) {
                    Ja(i);
                    let u = i._prevRep;
                    for (; u && u.parent.id === s.id;) Ja(u), u = u._prevRep
                }
                const a = r - e._delay;
                if (o > a) {
                    const u = i._startTime,
                        f = o - (u + i._updateDuration);
                    i._changeDuration = a - f - u, i._currentTime = i._changeDuration, i._isOverlapped = 1, i._changeDuration < St && Ja(i)
                }
                let l = !0;
                if ($t(s, u => {
                        u._isOverlapped || (l = !1)
                    }), l) {
                    const u = s.parent;
                    if (u) {
                        let f = !0;
                        $t(u, h => {
                            h !== s && $t(h, _ => {
                                _._isOverlapped || (f = !1)
                            })
                        }), f && u.cancel()
                    } else s.cancel()
                }
            }
        } else if (n === gn.blend) {
            const r = cd(e.target, e.property, "_add"),
                i = qx(xl._add);
            let s = r._head;
            s || (s = { ...e
            }, s._composition = gn.replace, s._updateDuration = St, s._startTime = 0, s._numbers = pn(e._fromNumbers), s._number = 0, s._next = null, s._prev = null, Mi(r, s), Mi(i, s));
            const o = e._toNumber;
            if (e._fromNumber = s._fromNumber - o, e._toNumber = 0, e._numbers = pn(e._fromNumbers), e._number = 0, s._fromNumber = o, e._toNumbers) {
                const a = pn(e._toNumbers);
                a && a.forEach((l, u) => {
                    e._fromNumbers[u] = s._fromNumbers[u] - l, e._toNumbers[u] = 0
                }), s._fromNumbers = a
            }
            Mi(r, e, null, "_prevAdd", "_nextAdd")
        }
        return e
    },
    iO = e => {
        const t = e._composition;
        if (t !== gn.none) {
            const n = e.target,
                r = e.property,
                o = xl._rep.get(n)[r];
            if (_s(o, e, "_prevRep", "_nextRep"), t === gn.blend) {
                const a = xl._add,
                    l = a.get(n);
                if (!l) return;
                const u = l[r],
                    f = Os.animation;
                _s(u, e, "_prevAdd", "_nextAdd");
                const h = u._head;
                if (h && h === u._tail) {
                    _s(u, h, "_prevAdd", "_nextAdd"), _s(f, h);
                    let _ = !0;
                    for (let m in l)
                        if (l[m]._head) {
                            _ = !1;
                            break
                        }
                    _ && a.delete(n)
                }
            }
        }
        return e
    },
    kp = e => (e.paused = !0, e.began = !1, e.completed = !1, e),
    $u = e => (e._cancelled && (e._hasChildren ? $t(e, $u) : $t(e, t => {
        t._composition !== gn.none && ay(t, cd(t.target, t.property))
    }), e._cancelled = 0), e);
let sO = 0;
class vs extends ry {
    constructor(t = {}, n = null, r = 0) {
        super(0);
        const {
            id: i,
            delay: s,
            duration: o,
            reversed: a,
            alternate: l,
            loop: u,
            loopDelay: f,
            autoplay: h,
            frameRate: _,
            playbackRate: m,
            onComplete: T,
            onLoop: R,
            onPause: B,
            onBegin: I,
            onBeforeUpdate: A,
            onUpdate: E
        } = t, O = n ? 0 : Qt._elapsedTime, P = n ? n.defaults : Lt.defaults, $ = No(s) || Ue(s) ? P.delay : +s, H = No(o) || Ue(o) ? 1 / 0 : +o, F = Nt(u, P.loop), V = Nt(f, P.loopDelay), k = F === !0 || F === 1 / 0 || F < 0 ? 1 / 0 : F + 1;
        let Y = 0;
        if (n) Y = r;
        else {
            let L = Lo();
            Qt.paused && (Qt.requestTick(L), L = Qt._elapsedTime), Y = L - Qt._startTime
        }
        this.id = Ue(i) ? ++sO : i, this.parent = n, this.duration = sd((H + V) * k - V) || St, this.backwards = !1, this.paused = !0, this.began = !1, this.completed = !1, this.onBegin = I || P.onBegin, this.onBeforeUpdate = A || P.onBeforeUpdate, this.onUpdate = E || P.onUpdate, this.onLoop = R || P.onLoop, this.onPause = B || P.onPause, this.onComplete = T || P.onComplete, this.iterationDuration = H, this.iterationCount = k, this._autoplay = n ? !1 : Nt(h, P.autoplay), this._offset = Y, this._delay = $, this._loopDelay = V, this._iterationTime = 0, this._currentIteration = 0, this._resolve = Tt, this._running = !1, this._reversed = +Nt(a, P.reversed), this._reverse = this._reversed, this._cancelled = 0, this._alternate = Nt(l, P.alternate), this._prev = null, this._next = null, this._elapsedTime = O, this._startTime = O, this._lastTime = O, this._fps = Nt(_, P.frameRate), this._speed = Nt(m, P.playbackRate)
    }
    get cancelled() {
        return !!this._cancelled
    }
    set cancelled(t) {
        t ? this.cancel() : this.reset(1).play()
    }
    get currentTime() {
        return rn(wt(this._currentTime, Lt.precision), -this._delay, this.duration)
    }
    set currentTime(t) {
        const n = this.paused;
        this.pause().seek(+t), n || this.resume()
    }
    get iterationCurrentTime() {
        return wt(this._iterationTime, Lt.precision)
    }
    set iterationCurrentTime(t) {
        this.currentTime = this.iterationDuration * this._currentIteration + t
    }
    get progress() {
        return rn(wt(this._currentTime / this.duration, 5), 0, 1)
    }
    set progress(t) {
        this.currentTime = this.duration * t
    }
    get iterationProgress() {
        return rn(wt(this._iterationTime / this.iterationDuration, 5), 0, 1)
    }
    set iterationProgress(t) {
        const n = this.iterationDuration;
        this.currentTime = n * this._currentIteration + n * t
    }
    get currentIteration() {
        return this._currentIteration
    }
    set currentIteration(t) {
        this.currentTime = this.iterationDuration * rn(+t, 0, this.iterationCount - 1)
    }
    get reversed() {
        return !!this._reversed
    }
    set reversed(t) {
        t ? this.reverse() : this.play()
    }
    get speed() {
        return super.speed
    }
    set speed(t) {
        super.speed = t, this.resetTime()
    }
    reset(t = 0) {
        return $u(this), this._reversed && !this._reverse && (this.reversed = !1), this._iterationTime = this.iterationDuration, ps(this, 0, 1, t, Fn.FORCE), kp(this), this._hasChildren && $t(this, kp), this
    }
    init(t = 0) {
        this.fps = this._fps, this.speed = this._speed, !t && this._hasChildren && ps(this, this.duration, 1, t, Fn.FORCE), this.reset(t);
        const n = this._autoplay;
        return n === !0 ? this.resume() : n && !Ue(n.linked) && n.link(this), this
    }
    resetTime() {
        const t = 1 / (this._speed * Qt._speed);
        return this._startTime = Lo() - (this._currentTime + this._delay) * t, this
    }
    pause() {
        return this.paused ? this : (this.paused = !0, this.onPause(this), this)
    }
    resume() {
        return this.paused ? (this.paused = !1, this.duration <= St && !this._hasChildren ? ps(this, St, 0, 0, Fn.FORCE) : (this._running || (Mi(Qt, this), Qt._hasChildren = !0, this._running = !0), this.resetTime(), this._startTime -= 12, Qt.wake()), this) : this
    }
    restart() {
        return this.reset(0).resume()
    }
    seek(t, n = 0, r = 0) {
        $u(this), this.completed = !1;
        const i = this.paused;
        return this.paused = !0, ps(this, t + this._delay, ~~n, ~~r, Fn.AUTO), i ? this : this.resume()
    }
    alternate() {
        const t = this._reversed,
            n = this.iterationCount,
            r = this.iterationDuration,
            i = n === 1 / 0 ? Al(qv / r) : n;
        return this._reversed = +(this._alternate && !(i % 2) ? t : !t), n === 1 / 0 ? this.iterationProgress = this._reversed ? 1 - this.iterationProgress : this.iterationProgress : this.seek(r * i - this._currentTime), this.resetTime(), this
    }
    play() {
        return this._reversed && this.alternate(), this.resume()
    }
    reverse() {
        return this._reversed || this.alternate(), this.resume()
    }
    cancel() {
        return this._hasChildren ? $t(this, t => t.cancel(), !0) : $t(this, iO), this._cancelled = 1, this.pause()
    }
    stretch(t) {
        const n = this.duration,
            r = go(t);
        if (n === r) return this;
        const i = t / n,
            s = t <= St;
        return this.duration = s ? St : r, this.iterationDuration = s ? St : go(this.iterationDuration * i), this._offset *= i, this._delay *= i, this._loopDelay *= i, this
    }
    revert() {
        ps(this, 0, 1, 0, Fn.AUTO);
        const t = this._autoplay;
        return t && t.linked && t.linked === this && t.revert(), this.cancel()
    }
    complete() {
        return this.seek(this.duration).cancel()
    }
    then(t = Tt) {
        const n = this.then,
            r = () => {
                this.then = null, t(this), this.then = n, this._resolve = Tt
            };
        return new Promise(i => (this._resolve = () => i(r()), this.completed && this._resolve(), this))
    }
}
const di = e => e,
    ly = (e, t, n) => (((1 - 3 * n + 3 * t) * e + (3 * n - 6 * t)) * e + 3 * t) * e,
    oO = (e, t, n) => {
        let r = 0,
            i = 1,
            s, o, a = 0;
        do o = r + (i - r) / 2, s = ly(o, t, n) - e, s > 0 ? i = o : r = o; while (Iu(s) > 1e-7 && ++a < 100);
        return o
    },
    aO = (e = .5, t = 0, n = .5, r = 1) => e === t && n === r ? di : i => i === 0 || i === 1 ? i : ly(oO(i, e, n), t, r),
    lO = (e = 10, t) => {
        const n = t ? Hx : Al;
        return r => n(rn(r, 0, 1) * e) * (1 / e)
    },
    cy = (...e) => {
        const t = e.length;
        if (!t) return di;
        const n = t - 1,
            r = e[0],
            i = e[n],
            s = [0],
            o = [Pi(r)];
        for (let a = 1; a < n; a++) {
            const l = e[a],
                u = si(l) ? l.trim().split(" ") : [l],
                f = u[0],
                h = u[1];
            s.push(Ue(h) ? a / n : Pi(h) / 100), o.push(Pi(f))
        }
        return o.push(Pi(i)), s.push(1),
            function(l) {
                for (let u = 1, f = s.length; u < f; u++) {
                    const h = s[u];
                    if (l <= h) {
                        const _ = s[u - 1],
                            m = o[u - 1];
                        return m + (o[u] - m) * (l - _) / (h - _)
                    }
                }
                return o[o.length - 1]
            }
    },
    cO = (e = 10, t = 1) => {
        const n = [0],
            r = e - 1;
        for (let i = 1; i < r; i++) {
            const s = n[i - 1],
                o = i / r,
                a = (i + 1) / r,
                l = o + (a - o) * Math.random(),
                u = o * (1 - t) + l * t;
            n.push(rn(u, s, 1))
        }
        return n.push(1), cy(...n)
    },
    uO = id / 2,
    Lp = id * 2,
    Qs = (e = 1.68) => t => hs(t, +e),
    Np = {
        [ei]: Qs,
        Quad: Qs(2),
        Cubic: Qs(3),
        Quart: Qs(4),
        Quint: Qs(5),
        Sine: e => 1 - Vx(e * uO),
        Circ: e => 1 - ny(1 - e * e),
        Expo: e => e ? hs(2, 10 * e - 10) : 0,
        Bounce: e => {
            let t, n = 4;
            for (; e < ((t = hs(2, --n)) - 1) / 11;);
            return 1 / hs(4, 3 - n) - 7.5625 * hs((t * 3 - 2) / 22 - e, 2)
        },
        Back: (e = 1.70158) => t => (+e + 1) * t * t * t - +e * t * t,
        Elastic: (e = 1, t = .3) => {
            const n = rn(+e, 1, 10),
                r = rn(+t, St, 2),
                i = r / Lp * Ux(1 / n),
                s = Lp / r;
            return o => o === 0 || o === 1 ? o : -n * hs(2, -10 * (1 - o)) * Bx((1 - o - i) * s)
        }
    },
    ku = { in: e => t => e(t),
        out: e => t => 1 - e(1 - t),
        inOut: e => t => t < .5 ? e(t * 2) / 2 : 1 - e(t * -2 + 2) / 2,
        outIn: e => t => t < .5 ? (1 - e(1 - t * 2)) / 2 : (e(t * 2 - 1) + 1) / 2
    },
    fO = (e, t, n) => {
        if (n[e]) return n[e];
        if (e.indexOf("(") <= -1) {
            const i = ku[e] || e.includes("Back") || e.includes("Elastic") ? t[e]() : t[e];
            return i ? n[e] = i : di
        } else {
            const r = e.slice(0, -1).split("("),
                i = t[r[0]];
            return i ? n[e] = i(...r[1].split(",")) : di
        }
    },
    dO = (() => {
        const e = {
            linear: cy,
            irregular: cO,
            steps: lO,
            cubicBezier: aO
        };
        for (let t in ku)
            for (let n in Np) {
                const r = Np[n],
                    i = ku[t];
                e[t + n] = n === ei || n === "Back" || n === "Elastic" ? (s, o) => i(r(s, o)) : i(r)
            }
        return e
    })(),
    hO = {
        linear: di
    },
    Ol = e => No(e) ? e : si(e) ? fO(e, dO, hO) : di,
    Fp = {},
    uy = (e, t, n) => {
        if (n === jt.TRANSFORM) {
            const r = ea.get(e);
            return r || e
        } else if (n === jt.CSS || n === jt.ATTRIBUTE && Zv(t) && e in t.style) {
            const r = Fp[e];
            if (r) return r; {
                const i = e && Dx(e);
                return Fp[e] = i, i
            }
        } else return e
    },
    jc = {
        deg: 1,
        rad: 180 / id,
        turn: 360
    },
    Dp = {},
    ud = (e, t, n, r = !1) => {
        const i = t.u,
            s = t.n;
        if (t.t === Je.UNIT && i === n) return t;
        const o = s + i + n,
            a = Dp[o];
        if (!Ue(a) && !r) t.n = a;
        else {
            let l;
            if (i in jc) l = s * jc[i] / jc[n];
            else {
                const f = e.cloneNode(),
                    h = e.parentNode,
                    _ = h && h !== Yt ? h : Yt.body;
                _.appendChild(f);
                const m = f.style;
                m.width = 100 + i;
                const T = f.offsetWidth || 100;
                m.width = 100 + n;
                const R = f.offsetWidth || 100,
                    B = T / R;
                _.removeChild(f), l = B * s
            }
            t.n = l, Dp[o] = l
        }
        return t.t, Je.UNIT, t.u = n, t
    },
    fy = e => {
        if (e._hasChildren) $t(e, fy, !0);
        else {
            const t = e;
            t.pause(), $t(t, n => {
                const r = n.property,
                    i = n.target;
                if (i[ac]) {
                    const s = i.style,
                        o = t._inlineStyles[r];
                    if (n._tweenType === jt.TRANSFORM) {
                        const a = i[lc];
                        if (Ue(o) || o === ei ? delete a[r] : a[r] = o, n._renderTransforms)
                            if (!Object.keys(a).length) s.removeProperty("transform");
                            else {
                                let l = ei;
                                for (let u in a) l += Kv[u] + a[u] + ") ";
                                s.transform = l
                            }
                    } else Ue(o) || o === ei ? s.removeProperty(r) : s[r] = o;
                    t._tail === n && t.targets.forEach(a => {
                        a.getAttribute && a.getAttribute("style") === ei && a.removeAttribute("style")
                    })
                }
            })
        }
        return e
    },
    je = ld(),
    Ke = ld(),
    $a = {
        func: null
    },
    ka = [null],
    us = [null, null],
    La = {
        to: null
    };
let pO = 0,
    Ur, sr;
const mO = (e, t) => {
    const n = {};
    if (js(e)) {
        const r = [].concat(...e.map(i => Object.keys(i))).filter(Ya);
        for (let i = 0, s = r.length; i < s; i++) {
            const o = r[i],
                a = e.map(l => {
                    const u = {};
                    for (let f in l) {
                        const h = l[f];
                        Ya(f) ? f === o && (u.to = h) : u[f] = h
                    }
                    return u
                });
            n[o] = a
        }
    } else {
        const r = Nt(t.duration, Lt.defaults.duration);
        Object.keys(e).map(s => ({
            o: parseFloat(s) / 100,
            p: e[s]
        })).sort((s, o) => s.o - o.o).forEach(s => {
            const o = s.o,
                a = s.p;
            for (let l in a)
                if (Ya(l)) {
                    let u = n[l];
                    u || (u = n[l] = []);
                    const f = o * r;
                    let h = u.length,
                        _ = u[h - 1];
                    const m = {
                        to: a[l]
                    };
                    let T = 0;
                    for (let R = 0; R < h; R++) T += u[R].duration;
                    h === 1 && (m.from = _.to), a.ease && (m.ease = a.ease), m.duration = f - (h ? T : 0), u.push(m)
                }
            return s
        });
        for (let s in n) {
            const o = n[s];
            let a;
            for (let l = 0, u = o.length; l < u; l++) {
                const f = o[l],
                    h = f.ease;
                f.ease = a || void 0, a = h
            }
            o[0].duration || o.shift()
        }
    }
    return n
};
class dy extends vs {
    constructor(t, n, r, i, s = !1, o = 0, a = 0) {
        super(n, r, i);
        const l = oy(t),
            u = l.length,
            f = n.keyframes,
            h = f ? zx(mO(f, n), n) : n,
            {
                delay: _,
                duration: m,
                ease: T,
                playbackEase: R,
                modifier: B,
                composition: I,
                onRender: A
            } = h,
            E = r ? r.defaults : Lt.defaults,
            O = Nt(R, E.playbackEase),
            P = O ? Ol(O) : null,
            $ = !Ue(T) && !Ue(T.ease),
            H = $ ? T.ease : Nt(T, P ? "linear" : E.ease),
            F = $ ? T.duration : Nt(m, E.duration),
            V = Nt(_, E.delay),
            k = B || E.modifier,
            Y = Ue(I) && u >= Yi ? gn.none : Ue(I) ? E.composition : I,
            L = {},
            te = this._offset + (r ? r._offset : 0);
        let ie = NaN,
            _e = NaN,
            X = 0,
            le = 0;
        for (let ce = 0; ce < u; ce++) {
            const ue = l[ce],
                Oe = o || ce,
                ke = a || u;
            let Ze = NaN,
                Fe = NaN;
            for (let Ie in h)
                if (Ya(Ie)) {
                    const Le = ad(ue, Ie),
                        Ne = uy(Ie, ue, Le);
                    let W = h[Ie];
                    const ge = js(W);
                    if (s && !ge && (us[0] = W, us[1] = W, W = us), ge) {
                        const C = W.length,
                            U = !mo(W[0]);
                        C === 2 && U ? (La.to = W, ka[0] = La, Ur = ka) : C > 2 && U ? (Ur = [], W.forEach((K, z) => {
                            z ? z === 1 ? (us[1] = K, Ur.push(us)) : Ur.push(K) : us[0] = K
                        })) : Ur = W
                    } else ka[0] = W, Ur = ka;
                    let fe = null,
                        ye = null,
                        Me = NaN,
                        Be = 0,
                        S = 0;
                    for (let C = Ur.length; S < C; S++) {
                        const U = Ur[S];
                        mo(U) ? sr = U : (La.to = U, sr = La), $a.func = null;
                        const K = Hr(sr.to, ue, Oe, ke, $a);
                        let z;
                        mo(K) && !Ue(K.to) ? (sr = K, z = K.to) : z = K;
                        const ae = Hr(sr.from, ue, Oe, ke),
                            me = sr.ease,
                            re = !Ue(me) && !Ue(me.ease),
                            v = re ? me.ease : me || H,
                            c = re ? me.duration : Hr(Nt(sr.duration, C > 1 ? Hr(F, ue, Oe, ke) / C : F), ue, Oe, ke),
                            d = Hr(Nt(sr.delay, S ? 0 : V), ue, Oe, ke),
                            b = Hr(Nt(sr.composition, Y), ue, Oe, ke),
                            x = Oi(b) ? b : gn[b],
                            j = sr.modifier || k,
                            q = !Ue(ae),
                            oe = !Ue(z),
                            ne = js(z),
                            de = ne || q && oe,
                            Ae = ye ? Be + d : d,
                            Ge = te + Ae;
                        !le && (q || ne) && (le = 1);
                        let st = ye;
                        if (x !== gn.none) {
                            fe || (fe = cd(ue, Ne));
                            let xe = fe._head;
                            for (; xe && !xe._isOverridden && xe._absoluteStartTime <= Ge;)
                                if (st = xe, xe = xe._nextRep, xe && xe._absoluteStartTime >= Ge)
                                    for (; xe;) Ja(xe), xe = xe._nextRep
                        }
                        if (de ? (Nn(ne ? Hr(z[0], ue, Oe, ke) : ae, je), Nn(ne ? Hr(z[1], ue, Oe, ke, $a) : z, Ke), je.t === Je.NUMBER && (st ? st._valueType === Je.UNIT && (je.t = Je.UNIT, je.u = st._unit) : (Nn(ms(ue, Ne, Le, L), bn), bn.t === Je.UNIT && (je.t = Je.UNIT, je.u = bn.u)))) : (oe ? Nn(z, Ke) : ye ? $p(ye, Ke) : Nn(r && st && st.parent.parent === r ? st._value : ms(ue, Ne, Le, L), Ke), q ? Nn(ae, je) : ye ? $p(ye, je) : Nn(r && st && st.parent.parent === r ? st._value : ms(ue, Ne, Le, L), je)), je.o && (je.n = Ps(st ? st._toNumber : Nn(ms(ue, Ne, Le, L), bn).n, je.n, je.o)), Ke.o && (Ke.n = Ps(je.n, Ke.n, Ke.o)), je.t !== Ke.t) {
                            if (je.t === Je.COMPLEX || Ke.t === Je.COMPLEX) {
                                const xe = je.t === Je.COMPLEX ? je : Ke,
                                    De = je.t === Je.COMPLEX ? Ke : je;
                                De.t = Je.COMPLEX, De.s = pn(xe.s), De.d = xe.d.map(() => De.n)
                            } else if (je.t === Je.UNIT || Ke.t === Je.UNIT) {
                                const xe = je.t === Je.UNIT ? je : Ke,
                                    De = je.t === Je.UNIT ? Ke : je;
                                De.t = Je.UNIT, De.u = xe.u
                            } else if (je.t === Je.COLOR || Ke.t === Je.COLOR) {
                                const xe = je.t === Je.COLOR ? je : Ke,
                                    De = je.t === Je.COLOR ? Ke : je;
                                De.t = Je.COLOR, De.s = xe.s, De.d = [0, 0, 0, 1]
                            }
                        }
                        if (je.u !== Ke.u) {
                            let xe = Ke.u ? je : Ke;
                            xe = ud(ue, xe, Ke.u ? Ke.u : je.u, !1)
                        }
                        if (Ke.d && je.d && Ke.d.length !== je.d.length) {
                            const xe = je.d.length > Ke.d.length ? je : Ke,
                                De = xe === je ? Ke : je;
                            De.d = xe.d.map((Dt, Vt) => Ue(De.d[Vt]) ? 0 : De.d[Vt]), De.s = pn(xe.s)
                        }
                        const Qe = wt(+c || St, 12),
                            ze = {
                                parent: this,
                                id: pO++,
                                property: Ne,
                                target: ue,
                                _value: null,
                                _func: $a.func,
                                _ease: Ol(v),
                                _fromNumbers: pn(je.d),
                                _toNumbers: pn(Ke.d),
                                _strings: pn(Ke.s),
                                _fromNumber: je.n,
                                _toNumber: Ke.n,
                                _numbers: pn(je.d),
                                _number: je.n,
                                _unit: Ke.u,
                                _modifier: j,
                                _currentTime: 0,
                                _startTime: Ae,
                                _delay: +d,
                                _updateDuration: Qe,
                                _changeDuration: Qe,
                                _absoluteStartTime: Ge,
                                _tweenType: Le,
                                _valueType: Ke.t,
                                _composition: x,
                                _isOverlapped: 0,
                                _isOverridden: 0,
                                _renderTransforms: 0,
                                _prevRep: null,
                                _nextRep: null,
                                _prevAdd: null,
                                _nextAdd: null,
                                _prev: null,
                                _next: null
                            };
                        x !== gn.none && ay(ze, fe), isNaN(Me) && (Me = ze._startTime), Be = wt(Ae + Qe, 12), ye = ze, X++, Mi(this, ze)
                    }(isNaN(_e) || Me < _e) && (_e = Me), (isNaN(ie) || Be > ie) && (ie = Be), Le === jt.TRANSFORM && (Ze = X - S, Fe = X)
                }
            if (!isNaN(Ze)) {
                let Ie = 0;
                $t(this, Le => {
                    Ie >= Ze && Ie < Fe && (Le._renderTransforms = 1, Le._composition === gn.blend && $t(Os.animation, Ne => {
                        Ne.id === Le.id && (Ne._renderTransforms = 1)
                    })), Ie++
                })
            }
        }
        u || console.warn("No target found. Make sure the element you're trying to animate is accessible before creating your animation."), _e ? ($t(this, ce => {
            ce._startTime - ce._delay || (ce._delay -= _e), ce._startTime -= _e
        }), ie -= _e) : _e = 0, ie || (ie = St, this.iterationCount = 0), this.targets = l, this.duration = ie === St ? St : sd((ie + this._loopDelay) * this.iterationCount - this._loopDelay) || St, this.onRender = A || E.onRender, this._ease = P, this._delay = _e, this.iterationDuration = ie, this._inlineStyles = L, !this._autoplay && le && this.onRender(this)
    }
    stretch(t) {
        const n = this.duration;
        if (n === go(t)) return this;
        const r = t / n;
        return $t(this, i => {
            i._updateDuration = go(i._updateDuration * r), i._changeDuration = go(i._changeDuration * r), i._currentTime *= r, i._startTime *= r, i._absoluteStartTime *= r
        }), super.stretch(t)
    }
    refresh() {
        return $t(this, t => {
            const n = ms(t.target, t.property, t._tweenType);
            Nn(n, bn), t._fromNumbers = pn(bn.d), t._fromNumber = bn.n, t._func && (Nn(t._func(), Ke), t._toNumbers = pn(Ke.d), t._strings = pn(Ke.s), t._toNumber = Ke.n)
        }), this
    }
    revert() {
        return super.revert(), fy(this)
    }
    then(t) {
        return super.then(t)
    }
}
const gO = (e, t) => new dy(e, t, null, 0, !1).init(),
    _O = ["x", "y", "z"];
[..._O, ...rd.filter(e => ["X", "Y", "Z"].some(t => e.endsWith(t)))];
pr && (Ue(CSS) || Object.hasOwnProperty.call(CSS, "registerProperty"));
const vO = (e = Tt) => new vs({
    duration: 1 * Lt.timeScale,
    onComplete: e
}, null, 0).resume();

function Bc(e, t, n) {
    const r = oy(e);
    if (!r.length) return;
    const [i] = r, s = ad(i, t), o = uy(t, i, s);
    let a = ms(i, o);
    if (Ue(n)) return a;
    if (Nn(a, bn), bn.t === Je.NUMBER || bn.t === Je.UNIT) {
        if (n === !1) return bn.n; {
            const l = ud(i, bn, n, !1);
            return `${wt(l.n,Lt.precision)}${l.u}`
        }
    }
}
const Vc = (e, t) => {
        if (!Ue(t)) return t.duration = St, t.composition = Nt(t.composition, gn.none), new dy(e, t, null, 0, !0).resume()
    },
    yO = (e, t, n, r) => {
        let i = Yi / Lt.defaults.frameRate;
        if (r !== !1) {
            const o = r || Qt._hasChildren && Qt;
            o && o.deltaTime && (i = o.deltaTime)
        }
        const s = 1 - Math.exp(-n * i * .1);
        return n ? n === 1 ? t : (1 - s) * e + s * t : e
    },
    bO = (e, t) => {
        if (Di(t, "<")) {
            const n = t[1] === "<",
                r = e._tail,
                i = r ? r._offset + r._delay : 0;
            return n ? i : i + r.duration
        }
    },
    wO = (e, t) => {
        let n = e.iterationDuration;
        if (n === St && (n = 0), Ue(t)) return n;
        if (Oi(+t)) return +t;
        const r = t,
            i = e ? e.labels : null,
            s = !Ga(i),
            o = bO(e, r),
            a = !Ue(o),
            l = Yv.exec(r);
        if (l) {
            const u = l[0],
                f = r.split(u),
                h = s && f[0] ? i[f[0]] : n,
                _ = a ? o : s ? h : n,
                m = +f[1];
            return Ps(_, m, u[0])
        } else return a ? o : s ? Ue(i[r]) ? n : i[r] : n
    },
    SO = () => {
        const e = document.createElement("div");
        Yt.body.appendChild(e), e.style.height = "100lvh";
        const t = e.offsetHeight;
        return Yt.body.removeChild(e), t
    },
    Na = (e, t) => e && No(e) ? e(t) : e,
    Lu = new Map;
class TO {
    constructor(t) {
        this.element = t, this.useWin = this.element === Yt.body, this.winWidth = 0, this.winHeight = 0, this.width = 0, this.height = 0, this.left = 0, this.top = 0, this.zIndex = 0, this.scrollX = 0, this.scrollY = 0, this.prevScrollX = 0, this.prevScrollY = 0, this.scrollWidth = 0, this.scrollHeight = 0, this.velocity = 0, this.backwardX = !1, this.backwardY = !1, this.scrollTicker = new vs({
            autoplay: !1,
            onBegin: () => this.dataTimer.resume(),
            onUpdate: () => {
                const n = this.backwardX || this.backwardY;
                $t(this, r => r.handleScroll(), n)
            },
            onComplete: () => this.dataTimer.pause()
        }).init(), this.dataTimer = new vs({
            autoplay: !1,
            frameRate: 30,
            onUpdate: n => {
                const r = n.deltaTime,
                    i = this.prevScrollX,
                    s = this.prevScrollY,
                    o = this.scrollX,
                    a = this.scrollY,
                    l = i - o,
                    u = s - a;
                this.prevScrollX = o, this.prevScrollY = a, l && (this.backwardX = i > o), u && (this.backwardY = s > a), this.velocity = wt(r > 0 ? Math.sqrt(l * l + u * u) / r : 0, 5)
            }
        }).init(), this.resizeTicker = new vs({
            autoplay: !1,
            duration: 250 * Lt.timeScale,
            onComplete: () => {
                this.updateWindowBounds(), this.refreshScrollObservers(), this.handleScroll()
            }
        }).init(), this.wakeTicker = new vs({
            autoplay: !1,
            duration: 500 * Lt.timeScale,
            onBegin: () => {
                this.scrollTicker.resume()
            },
            onComplete: () => {
                this.scrollTicker.pause()
            }
        }).init(), this._head = null, this._tail = null, this.updateScrollCoords(), this.updateWindowBounds(), this.updateBounds(), this.refreshScrollObservers(), this.handleScroll(), this.resizeObserver = new ResizeObserver(() => this.resizeTicker.restart()), this.resizeObserver.observe(this.element), (this.useWin ? Qr : this.element).addEventListener("scroll", this, !1)
    }
    updateScrollCoords() {
        const t = this.useWin,
            n = this.element;
        this.scrollX = wt(t ? Qr.scrollX : n.scrollLeft, 0), this.scrollY = wt(t ? Qr.scrollY : n.scrollTop, 0)
    }
    updateWindowBounds() {
        this.winWidth = Qr.innerWidth, this.winHeight = SO()
    }
    updateBounds() {
        const t = getComputedStyle(this.element),
            n = this.element;
        this.scrollWidth = n.scrollWidth + parseFloat(t.marginLeft) + parseFloat(t.marginRight), this.scrollHeight = n.scrollHeight + parseFloat(t.marginTop) + parseFloat(t.marginBottom), this.updateWindowBounds();
        let r, i;
        if (this.useWin) r = this.winWidth, i = this.winHeight;
        else {
            const s = n.getBoundingClientRect();
            r = s.width, i = s.height, this.top = s.top, this.left = s.left
        }
        this.width = r, this.height = i
    }
    refreshScrollObservers() {
        $t(this, t => {
            t._debug && t.removeDebug()
        }), this.updateBounds(), $t(this, t => {
            t.refresh(), t._debug && t.debug()
        })
    }
    refresh() {
        this.updateWindowBounds(), this.updateBounds(), this.refreshScrollObservers(), this.handleScroll()
    }
    handleScroll() {
        this.updateScrollCoords(), this.wakeTicker.restart()
    }
    handleEvent(t) {
        switch (t.type) {
            case "scroll":
                this.handleScroll();
                break
        }
    }
    revert() {
        this.scrollTicker.cancel(), this.dataTimer.cancel(), this.resizeTicker.cancel(), this.wakeTicker.cancel(), this.resizeObserver.unobserve(this.element), (this.useWin ? Qr : this.element).removeEventListener("scroll", this), Lu.delete(this.element)
    }
}
const CO = e => {
        const t = e && od(e)[0] || Yt.body;
        let n = Lu.get(t);
        return n || (n = new TO(t), Lu.set(t, n)), n
    },
    eo = (e, t, n, r, i) => {
        const s = t === "min",
            o = t === "max",
            a = t === "top" || t === "left" || t === "start" || s ? 0 : t === "bottom" || t === "right" || t === "end" || o ? "100%" : t === "center" ? "50%" : t,
            {
                n: l,
                u
            } = Nn(a, bn);
        let f = l;
        return u === "%" ? f = l / 100 * n : u && (f = ud(e, bn, "px", !0).n), o && r < 0 && (f += r), s && i > 0 && (f += i), f
    },
    Fa = (e, t, n, r, i) => {
        let s;
        if (si(t)) {
            const o = Yv.exec(t);
            if (o) {
                const a = o[0],
                    l = a[0],
                    u = t.split(a),
                    f = u[0] === "min",
                    h = u[0] === "max",
                    _ = eo(e, u[0], n, r, i),
                    m = eo(e, u[1], n, r, i);
                if (f) {
                    const T = Ps(eo(e, "min", n), m, l);
                    s = T < _ ? _ : T
                } else if (h) {
                    const T = Ps(eo(e, "max", n), m, l);
                    s = T > _ ? _ : T
                } else s = Ps(_, m, l)
            } else s = eo(e, t, n, r, i)
        } else s = t;
        return wt(s, 0)
    },
    jp = e => {
        let t;
        const n = e.targets;
        for (let r = 0, i = n.length; r < i; r++) {
            const s = n[r];
            if (s[ac]) {
                t = s;
                break
            }
        }
        return t
    };
let EO = 0;
const Bp = ["#FF4B4B", "#FF971B", "#FFC730", "#F9F640", "#7AFF5A", "#18FF74", "#17E09B", "#3CFFEC", "#05DBE9", "#33B3F1", "#638CF9", "#C563FE", "#FF4FCF", "#F93F8A"];
class AO {
    constructor(t = {}) {
        const n = Nt(t.sync, "play pause"),
            r = n ? Ol(n) : null,
            i = n && (n === "linear" || n === di),
            s = n && !(r === di && !i),
            o = n && (Oi(n) || n === !0 || i),
            a = n && si(n) && !s && !o,
            l = a ? n.split(" ").map(f => () => {
                const h = this.linked;
                return h && h[f] ? h[f]() : null
            }) : null,
            u = a && l.length > 2;
        this.index = EO++, this.id = Ue(t.id) ? this.index : t.id, this.container = CO(t.container), this.target = null, this.linked = null, this.repeat = null, this.horizontal = null, this.enter = null, this.leave = null, this.sync = s || o || !!l, this.syncEase = s ? r : null, this.syncSmooth = o ? n === !0 || i ? 1 : n : null, this.onSyncEnter = l && !u && l[0] ? l[0] : Tt, this.onSyncLeave = l && !u && l[1] ? l[1] : Tt, this.onSyncEnterForward = l && u && l[0] ? l[0] : Tt, this.onSyncLeaveForward = l && u && l[1] ? l[1] : Tt, this.onSyncEnterBackward = l && u && l[2] ? l[2] : Tt, this.onSyncLeaveBackward = l && u && l[3] ? l[3] : Tt, this.onEnter = t.onEnter || Tt, this.onLeave = t.onLeave || Tt, this.onEnterForward = t.onEnterForward || Tt, this.onLeaveForward = t.onLeaveForward || Tt, this.onEnterBackward = t.onEnterBackward || Tt, this.onLeaveBackward = t.onLeaveBackward || Tt, this.onUpdate = t.onUpdate || Tt, this.onSyncComplete = t.onSyncComplete || Tt, this.reverted = !1, this.completed = !1, this.began = !1, this.isInView = !1, this.forceEnter = !1, this.hasEntered = !1, this.offsets = [], this.offset = 0, this.offsetStart = 0, this.offsetEnd = 0, this.distance = 0, this.prevProgress = 0, this.thresholds = ["start", "end", "end", "start"], this.coords = [0, 0, 0, 0], this.debugStyles = null, this.$debug = null, this._params = t, this._debug = Nt(t.debug, !1), this._next = null, this._prev = null, Mi(this.container, this), vO(() => {
            if (!this.reverted) {
                if (!this.target) {
                    const f = od(t.target)[0];
                    this.target = f || Yt.body, this.refresh()
                }
                this._debug && this.debug()
            }
        })
    }
    link(t) {
        if (t && (t.pause(), this.linked = t, !this._params.target)) {
            let n;
            Ue(t.targets) ? $t(t, r => {
                r.targets && !n && (n = jp(r))
            }) : n = jp(t), this.target = n || Yt.body, this.refresh()
        }
        return this
    }
    get velocity() {
        return this.container.velocity
    }
    get backward() {
        return this.horizontal ? this.container.backwardX : this.container.backwardY
    }
    get scroll() {
        return this.horizontal ? this.container.scrollX : this.container.scrollY
    }
    get progress() {
        const t = (this.scroll - this.offsetStart) / this.distance;
        return t === 1 / 0 || isNaN(t) ? 0 : wt(rn(t, 0, 1), 6)
    }
    refresh() {
        this.reverted = !1;
        const t = this._params;
        return this.repeat = Nt(Na(t.repeat, this), !0), this.horizontal = Nt(Na(t.axis, this), "y") === "x", this.enter = Nt(Na(t.enter, this), "end start"), this.leave = Nt(Na(t.leave, this), "start end"), this.updateBounds(), this.handleScroll(), this
    }
    removeDebug() {
        return this.$debug && (this.$debug.parentNode.removeChild(this.$debug), this.$debug = null), this.debugStyles && (this.debugStyles.revert(), this.$debug = null), this
    }
    debug() {
        this.removeDebug();
        const t = this.container,
            n = this.horizontal,
            r = t.element.querySelector(":scope > .animejs-onscroll-debug"),
            i = Yt.createElement("div"),
            s = Yt.createElement("div"),
            o = Yt.createElement("div"),
            a = Bp[this.index % Bp.length],
            l = t.useWin,
            u = l ? t.winWidth : t.width,
            f = l ? t.winHeight : t.height,
            h = t.scrollWidth,
            _ = t.scrollHeight,
            m = this.container.width > 360 ? 320 : 260,
            T = n ? 0 : 10,
            R = n ? 10 : 0,
            B = n ? 24 : m / 2,
            I = n ? B : 15,
            A = n ? 60 : B,
            E = n ? A : I,
            O = n ? "repeat-x" : "repeat-y",
            P = k => n ? "0px " + k + "px" : k + "px 2px",
            $ = k => `linear-gradient(${n?90:0}deg, ${k} 2px, transparent 1px)`,
            H = (k, Y, L, te, ie) => `position:${k};left:${Y}px;top:${L}px;width:${te}px;height:${ie}px;`;
        i.style.cssText = `${H("absolute",T,R,n?h:m,n?m:_)}
      pointer-events: none;
      z-index: ${this.container.zIndex++};
      display: flex;
      flex-direction: ${n?"column":"row"};
      filter: drop-shadow(0px 1px 0px rgba(0,0,0,.75));
    `, s.style.cssText = `${H("sticky",0,0,n?u:B,n?B:f)}`, r || (s.style.cssText += `background:
        ${$("#FFFF")}${P(B-10)} / 100px 100px ${O},
        ${$("#FFF8")}${P(B-10)} / 10px 10px ${O};
      `), o.style.cssText = `${H("relative",0,0,n?h:B,n?B:_)}`, r || (o.style.cssText += `background:
        ${$("#FFFF")}${P(0)} / ${n?"100px 10px":"10px 100px"} ${O},
        ${$("#FFF8")}${P(0)} / ${n?"10px 0px":"0px 10px"} ${O};
      `);
        const F = [" enter: ", " leave: "];
        this.coords.forEach((k, Y) => {
            const L = Y > 1,
                te = (L ? 0 : this.offset) + k,
                ie = Y % 2,
                _e = te < E,
                X = te > (L ? n ? u : f : n ? h : _) - E,
                le = (L ? ie && !_e : !ie && !_e) || X,
                ce = Yt.createElement("div"),
                ue = Yt.createElement("div"),
                Oe = n ? le ? "right" : "left" : le ? "bottom" : "top",
                ke = le ? (n ? A : I) + (L ? n ? -1 : X ? 0 : -2 : n ? -1 : -2) : n ? 1 : 0;
            ue.innerHTML = `${this.id}${F[ie]}${this.thresholds[Y]}`, ce.style.cssText = `${H("absolute",0,0,A,I)}
        display: flex;
        flex-direction: ${n?"column":"row"};
        justify-content: flex-${L?"start":"end"};
        align-items: flex-${le?"end":"start"};
        border-${Oe}: 2px solid ${a};
      `, ue.style.cssText = `
        overflow: hidden;
        max-width: ${m/2-10}px;
        height: ${I};
        margin-${n?le?"right":"left":le?"bottom":"top"}: -2px;
        padding: 1px;
        font-family: ui-monospace, monospace;
        font-size: 10px;
        letter-spacing: -.025em;
        line-height: 9px;
        font-weight: 600;
        text-align: ${n&&le||!n&&!L?"right":"left"};
        white-space: pre;
        text-overflow: ellipsis;
        color: ${ie?a:"rgba(0,0,0,.75)"};
        background-color: ${ie?"rgba(0,0,0,.65)":a};
        border: 2px solid ${ie?a:"transparent"};
        border-${n?le?"top-left":"top-right":le?"top-left":"bottom-left"}-radius: 5px;
        border-${n?le?"bottom-left":"bottom-right":le?"top-right":"bottom-right"}-radius: 5px;
      `, ce.appendChild(ue);
            let Ze = te - ke + (n ? 1 : 0);
            ce.style[n ? "left" : "top"] = `${Ze}px`, (L ? s : o).appendChild(ce)
        }), i.appendChild(s), i.appendChild(o), t.element.appendChild(i), r || i.classList.add("animejs-onscroll-debug"), this.$debug = i, Bc(t.element, "position") === "static" && (this.debugStyles = Vc(t.element, {
            position: "relative "
        }))
    }
    updateBounds() {
        this._debug && this.removeDebug();
        let t;
        const n = this.target,
            r = this.container,
            i = this.horizontal,
            s = this.linked;
        let o, a = n,
            l = 0,
            u = 0,
            f = a;
        s && (o = s.currentTime, s.seek(0, !0));
        const h = Bc(r.element, "position") === "static" ? Vc(r.element, {
            position: "relative "
        }) : !1;
        for (; a && a !== r.element && a !== Yt.body;) {
            const X = Bc(a, "position") === "sticky" ? Vc(a, {
                position: "static"
            }) : !1;
            a === f && (l += a.offsetLeft || 0, u += a.offsetTop || 0, f = a.offsetParent), a = a.parentElement, X && (t || (t = []), t.push(X))
        }
        h && h.revert();
        const _ = i ? l : u,
            m = i ? n.offsetWidth : n.offsetHeight,
            T = i ? r.width : r.height,
            B = (i ? r.scrollWidth : r.scrollHeight) - T,
            I = this.enter,
            A = this.leave;
        let E = "start",
            O = "end",
            P = "end",
            $ = "start";
        if (si(I)) {
            const X = I.split(" ");
            P = X[0], E = X.length > 1 ? X[1] : E
        } else if (mo(I)) {
            const X = I;
            Ue(X.container) || (P = X.container), Ue(X.target) || (E = X.target)
        } else Oi(I) && (P = I);
        if (si(A)) {
            const X = A.split(" ");
            $ = X[0], O = X.length > 1 ? X[1] : O
        } else if (mo(A)) {
            const X = A;
            Ue(X.container) || ($ = X.container), Ue(X.target) || (O = X.target)
        } else Oi(A) && ($ = A);
        const H = Fa(n, E, m),
            F = Fa(n, O, m),
            V = H + _ - T,
            k = F + _ - B,
            Y = Fa(n, P, T, V, k),
            L = Fa(n, $, T, V, k),
            te = H + _ - Y,
            ie = F + _ - L,
            _e = ie - te;
        this.offsets[0] = l, this.offsets[1] = u, this.offset = _, this.offsetStart = te, this.offsetEnd = ie, this.distance = _e <= 0 ? 0 : _e, this.thresholds = [E, O, P, $], this.coords = [H, F, Y, L], t && t.forEach(X => X.revert()), s && s.seek(o, !0), this._debug && this.debug()
    }
    handleScroll() {
        const t = this.linked,
            n = this.sync,
            r = this.syncEase,
            i = this.syncSmooth,
            s = t && (r || i),
            o = this.horizontal,
            a = this.container,
            l = this.scroll,
            u = l <= this.offsetStart,
            f = l >= this.offsetEnd,
            h = !u && !f,
            _ = l === this.offsetStart || l === this.offsetEnd,
            m = !this.hasEntered && _,
            T = this._debug && this.$debug;
        let R = !1,
            B = !1,
            I = this.progress;
        if (u && this.began && (this.began = !1), I > 0 && !this.began && (this.began = !0), s) {
            const A = t.progress;
            if (i && Oi(i)) {
                if (i < 1) {
                    const O = A < I && I === 1 ? 1e-4 : A > I && !I ? -1e-4 : 0;
                    I = wt(yO(A, I, qr(.01, .2, i), !1) + O, 6)
                }
            } else r && (I = r(I));
            R = I !== this.prevProgress, B = A === 1, R && !B && i && A && a.wakeTicker.restart()
        }
        if (T) {
            const A = o ? a.scrollY : a.scrollX;
            T.style[o ? "top" : "left"] = A + 10 + "px"
        }(h && !this.isInView || m && !this.forceEnter && !this.hasEntered) && (h && (this.isInView = !0), !this.forceEnter || !this.hasEntered ? (T && h && (T.style.zIndex = `${this.container.zIndex++}`), this.onSyncEnter(this), this.onEnter(this), this.backward ? (this.onSyncEnterBackward(this), this.onEnterBackward(this)) : (this.onSyncEnterForward(this), this.onEnterForward(this)), this.hasEntered = !0, m && (this.forceEnter = !0)) : h && (this.forceEnter = !1)), (h || !h && this.isInView) && (R = !0), R && (s && t.seek(t.duration * I), this.onUpdate(this)), !h && this.isInView && (this.isInView = !1, this.onSyncLeave(this), this.onLeave(this), this.backward ? (this.onSyncLeaveBackward(this), this.onLeaveBackward(this)) : (this.onSyncLeaveForward(this), this.onLeaveForward(this)), n && !i && (B = !0)), I >= 1 && this.began && !this.completed && (n && B || !n) && (n && this.onSyncComplete(this), this.completed = !0, (!this.repeat && !t || !this.repeat && t && t.completed) && this.revert()), I < 1 && this.completed && (this.completed = !1), this.prevProgress = I
    }
    revert() {
        if (this.reverted) return;
        const t = this.container;
        return _s(t, this), t._head || t.revert(), this._debug && this.removeDebug(), this.reverted = !0, this
    }
}
const xO = (e = {}) => new AO(e),
    Nu = (e, t = {}) => {
        let n = [],
            r = 0;
        const i = t.from,
            s = t.reversed,
            o = t.ease,
            a = !Ue(o),
            u = a && !Ue(o.ease) ? o.ease : a ? Ol(o) : null,
            f = t.grid,
            h = t.axis,
            _ = Ue(i) || i === 0 || i === "first",
            m = i === "center",
            T = i === "last",
            R = js(e),
            B = Pi(R ? e[0] : e),
            I = R ? Pi(e[1]) : 0,
            A = Gv.exec((R ? e[1] : e) + ei),
            E = t.start || 0 + (R ? B : 0);
        let O = _ ? 0 : Oi(i) ? i : 0;
        return (P, $, H, F) => {
            if (m && (O = (H - 1) / 2), T && (O = H - 1), !n.length) {
                for (let L = 0; L < H; L++) {
                    if (!f) n.push(Iu(O - L));
                    else {
                        const te = m ? (f[0] - 1) / 2 : O % f[0],
                            ie = m ? (f[1] - 1) / 2 : Al(O / f[0]),
                            _e = L % f[0],
                            X = Al(L / f[0]),
                            le = te - _e,
                            ce = ie - X;
                        let ue = ny(le * le + ce * ce);
                        h === "x" && (ue = -le), h === "y" && (ue = -ce), n.push(ue)
                    }
                    r = Wx(...n)
                }
                u && (n = n.map(L => u(L / r) * r)), s && (n = n.map(L => h ? L < 0 ? L * -1 : -L : Iu(r - L)))
            }
            const V = R ? (I - B) / r : B;
            let Y = (F ? wO(F, Ue(t.start) ? F.iterationDuration : E) : E) + (V * wt(n[$], 2) || 0);
            return t.modifier && (Y = t.modifier(Y)), A && (Y = `${Y}${A[2]}`), Y
        }
    };
(function() {
    function e() {
        for (var r = arguments.length, i = 0; i < r; i++) {
            var s = i < 0 || arguments.length <= i ? void 0 : arguments[i];
            s.nodeType === 1 || s.nodeType === 11 ? this.appendChild(s) : this.appendChild(document.createTextNode(String(s)))
        }
    }

    function t() {
        for (; this.lastChild;) this.removeChild(this.lastChild);
        arguments.length && this.append.apply(this, arguments)
    }

    function n() {
        for (var r = this.parentNode, i = arguments.length, s = new Array(i), o = 0; o < i; o++) s[o] = arguments[o];
        var a = s.length;
        if (r)
            for (a || r.removeChild(this); a--;) {
                var l = s[a];
                typeof l != "object" ? l = this.ownerDocument.createTextNode(l) : l.parentNode && l.parentNode.removeChild(l), a ? r.insertBefore(this.previousSibling, l) : r.replaceChild(l, this)
            }
    }
    typeof Element < "u" && (Element.prototype.append || (Element.prototype.append = e, DocumentFragment.prototype.append = e), Element.prototype.replaceChildren || (Element.prototype.replaceChildren = t, DocumentFragment.prototype.replaceChildren = t), Element.prototype.replaceWith || (Element.prototype.replaceWith = n, DocumentFragment.prototype.replaceWith = n))
})();

function OO(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function Vp(e, t) {
    for (var n = 0; n < t.length; n++) {
        var r = t[n];
        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
    }
}

function Hp(e, t, n) {
    return t && Vp(e.prototype, t), n && Vp(e, n), e
}

function PO(e, t, n) {
    return t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e
}

function Up(e, t) {
    var n = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(e);
        t && (r = r.filter(function(i) {
            return Object.getOwnPropertyDescriptor(e, i).enumerable
        })), n.push.apply(n, r)
    }
    return n
}

function Wp(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t] != null ? arguments[t] : {};
        t % 2 ? Up(Object(n), !0).forEach(function(r) {
            PO(e, r, n[r])
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : Up(Object(n)).forEach(function(r) {
            Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(n, r))
        })
    }
    return e
}

function hy(e, t) {
    return RO(e) || $O(e, t) || py(e, t) || LO()
}

function mn(e) {
    return MO(e) || IO(e) || py(e) || kO()
}

function MO(e) {
    if (Array.isArray(e)) return Fu(e)
}

function RO(e) {
    if (Array.isArray(e)) return e
}

function IO(e) {
    if (typeof Symbol < "u" && Symbol.iterator in Object(e)) return Array.from(e)
}

function $O(e, t) {
    if (!(typeof Symbol > "u" || !(Symbol.iterator in Object(e)))) {
        var n = [],
            r = !0,
            i = !1,
            s = void 0;
        try {
            for (var o = e[Symbol.iterator](), a; !(r = (a = o.next()).done) && (n.push(a.value), !(t && n.length === t)); r = !0);
        } catch (l) {
            i = !0, s = l
        } finally {
            try {
                !r && o.return != null && o.return()
            } finally {
                if (i) throw s
            }
        }
        return n
    }
}

function py(e, t) {
    if (e) {
        if (typeof e == "string") return Fu(e, t);
        var n = Object.prototype.toString.call(e).slice(8, -1);
        if (n === "Object" && e.constructor && (n = e.constructor.name), n === "Map" || n === "Set") return Array.from(e);
        if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return Fu(e, t)
    }
}

function Fu(e, t) {
    (t == null || t > e.length) && (t = e.length);
    for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
    return r
}

function kO() {
    throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)
}

function LO() {
    throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)
}

function Ri(e, t) {
    return Object.getOwnPropertyNames(Object(e)).reduce(function(n, r) {
        var i = Object.getOwnPropertyDescriptor(Object(e), r),
            s = Object.getOwnPropertyDescriptor(Object(t), r);
        return Object.defineProperty(n, r, s || i)
    }, {})
}

function ta(e) {
    return typeof e == "string"
}

function fd(e) {
    return Array.isArray(e)
}

function Da() {
    var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {},
        t = Ri(e),
        n;
    return t.types !== void 0 ? n = t.types : t.split !== void 0 && (n = t.split), n !== void 0 && (t.types = (ta(n) || fd(n) ? String(n) : "").split(",").map(function(r) {
        return String(r).trim()
    }).filter(function(r) {
        return /((line)|(word)|(char))/i.test(r)
    })), (t.absolute || t.position) && (t.absolute = t.absolute || /absolute/.test(e.position)), t
}

function dd(e) {
    var t = ta(e) || fd(e) ? String(e) : "";
    return {
        none: !t,
        lines: /line/i.test(t),
        words: /word/i.test(t),
        chars: /char/i.test(t)
    }
}

function cc(e) {
    return e !== null && typeof e == "object"
}

function NO(e) {
    return cc(e) && /^(1|3|11)$/.test(e.nodeType)
}

function FO(e) {
    return typeof e == "number" && e > -1 && e % 1 === 0
}

function DO(e) {
    return cc(e) && FO(e.length)
}

function Xi(e) {
    return fd(e) ? e : e == null ? [] : DO(e) ? Array.prototype.slice.call(e) : [e]
}

function zp(e) {
    var t = e;
    return ta(e) && (/^(#[a-z]\w+)$/.test(e.trim()) ? t = document.getElementById(e.trim().slice(1)) : t = document.querySelectorAll(e)), Xi(t).reduce(function(n, r) {
        return [].concat(mn(n), mn(Xi(r).filter(NO)))
    }, [])
}
var jO = Object.entries,
    Pl = "_splittype",
    Kn = {},
    BO = 0;

function cr(e, t, n) {
    if (!cc(e)) return console.warn("[data.set] owner is not an object"), null;
    var r = e[Pl] || (e[Pl] = ++BO),
        i = Kn[r] || (Kn[r] = {});
    return n === void 0 ? t && Object.getPrototypeOf(t) === Object.prototype && (Kn[r] = Wp(Wp({}, i), t)) : t !== void 0 && (i[t] = n), n
}

function Ii(e, t) {
    var n = cc(e) ? e[Pl] : null,
        r = n && Kn[n] || {};
    return t === void 0 ? r : r[t]
}

function my(e) {
    var t = e && e[Pl];
    t && (delete e[t], delete Kn[t])
}

function VO() {
    Object.keys(Kn).forEach(function(e) {
        delete Kn[e]
    })
}

function HO() {
    jO(Kn).forEach(function(e) {
        var t = hy(e, 2),
            n = t[0],
            r = t[1],
            i = r.isRoot,
            s = r.isSplit;
        (!i || !s) && (Kn[n] = null, delete Kn[n])
    })
}

function UO(e) {
    var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : " ",
        n = e ? String(e) : "";
    return n.trim().replace(/\s+/g, " ").split(t)
}
var hd = "\\ud800-\\udfff",
    gy = "\\u0300-\\u036f\\ufe20-\\ufe23",
    _y = "\\u20d0-\\u20f0",
    vy = "\\ufe0e\\ufe0f",
    WO = "[".concat(hd, "]"),
    Du = "[".concat(gy).concat(_y, "]"),
    ju = "\\ud83c[\\udffb-\\udfff]",
    zO = "(?:".concat(Du, "|").concat(ju, ")"),
    yy = "[^".concat(hd, "]"),
    by = "(?:\\ud83c[\\udde6-\\uddff]){2}",
    wy = "[\\ud800-\\udbff][\\udc00-\\udfff]",
    Sy = "\\u200d",
    Ty = "".concat(zO, "?"),
    Cy = "[".concat(vy, "]?"),
    qO = "(?:" + Sy + "(?:" + [yy, by, wy].join("|") + ")" + Cy + Ty + ")*",
    KO = Cy + Ty + qO,
    GO = "(?:".concat(["".concat(yy).concat(Du, "?"), Du, by, wy, WO].join("|"), `
)`),
    YO = RegExp("".concat(ju, "(?=").concat(ju, ")|").concat(GO).concat(KO), "g"),
    XO = [Sy, hd, gy, _y, vy],
    JO = RegExp("[".concat(XO.join(""), "]"));

function ZO(e) {
    return e.split("")
}

function Ey(e) {
    return JO.test(e)
}

function QO(e) {
    return e.match(YO) || []
}

function eP(e) {
    return Ey(e) ? QO(e) : ZO(e)
}

function tP(e) {
    return e == null ? "" : String(e)
}

function nP(e) {
    var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "";
    return e = tP(e), e && ta(e) && !t && Ey(e) ? eP(e) : e.split(t)
}

function Bu(e, t) {
    var n = document.createElement(e);
    return t && Object.keys(t).forEach(function(r) {
        var i = t[r],
            s = ta(i) ? i.trim() : i;
        s === null || s === "" || (r === "children" ? n.append.apply(n, mn(Xi(s))) : n.setAttribute(r, s))
    }), n
}
var pd = {
    splitClass: "",
    lineClass: "line",
    wordClass: "word",
    charClass: "char",
    types: ["lines", "words", "chars"],
    absolute: !1,
    tagName: "div"
};

function rP(e, t) {
    t = Ri(pd, t);
    var n = dd(t.types),
        r = t.tagName,
        i = e.nodeValue,
        s = document.createDocumentFragment(),
        o = [],
        a = [];
    return /^\s/.test(i) && s.append(" "), o = UO(i).reduce(function(l, u, f, h) {
        var _, m;
        return n.chars && (m = nP(u).map(function(T) {
            var R = Bu(r, {
                class: "".concat(t.splitClass, " ").concat(t.charClass),
                style: "display: inline-block;",
                children: T
            });
            return cr(R, "isChar", !0), a = [].concat(mn(a), [R]), R
        })), n.words || n.lines ? (_ = Bu(r, {
            class: "".concat(t.wordClass, " ").concat(t.splitClass),
            style: "display: inline-block; ".concat(n.words && t.absolute ? "position: relative;" : ""),
            children: n.chars ? m : u
        }), cr(_, {
            isWord: !0,
            isWordStart: !0,
            isWordEnd: !0
        }), s.appendChild(_)) : m.forEach(function(T) {
            s.appendChild(T)
        }), f < h.length - 1 && s.append(" "), n.words ? l.concat(_) : l
    }, []), /\s$/.test(i) && s.append(" "), e.replaceWith(s), {
        words: o,
        chars: a
    }
}

function Ay(e, t) {
    var n = e.nodeType,
        r = {
            words: [],
            chars: []
        };
    if (!/(1|3|11)/.test(n)) return r;
    if (n === 3 && /\S/.test(e.nodeValue)) return rP(e, t);
    var i = Xi(e.childNodes);
    if (i.length && (cr(e, "isSplit", !0), !Ii(e).isRoot)) {
        e.style.display = "inline-block", e.style.position = "relative";
        var s = e.nextSibling,
            o = e.previousSibling,
            a = e.textContent || "",
            l = s ? s.textContent : " ",
            u = o ? o.textContent : " ";
        cr(e, {
            isWordEnd: /\s$/.test(a) || /^\s/.test(l),
            isWordStart: /^\s/.test(a) || /\s$/.test(u)
        })
    }
    return i.reduce(function(f, h) {
        var _ = Ay(h, t),
            m = _.words,
            T = _.chars;
        return {
            words: [].concat(mn(f.words), mn(m)),
            chars: [].concat(mn(f.chars), mn(T))
        }
    }, r)
}

function iP(e, t, n, r) {
    if (!n.absolute) return {
        top: t ? e.offsetTop : null
    };
    var i = e.offsetParent,
        s = hy(r, 2),
        o = s[0],
        a = s[1],
        l = 0,
        u = 0;
    if (i && i !== document.body) {
        var f = i.getBoundingClientRect();
        l = f.x + o, u = f.y + a
    }
    var h = e.getBoundingClientRect(),
        _ = h.width,
        m = h.height,
        T = h.x,
        R = h.y,
        B = R + a - u,
        I = T + o - l;
    return {
        width: _,
        height: m,
        top: B,
        left: I
    }
}

function xy(e) {
    Ii(e).isWord ? (my(e), e.replaceWith.apply(e, mn(e.childNodes))) : Xi(e.children).forEach(function(t) {
        return xy(t)
    })
}
var sP = function() {
    return document.createDocumentFragment()
};

function oP(e, t, n) {
    var r = dd(t.types),
        i = t.tagName,
        s = e.getElementsByTagName("*"),
        o = [],
        a = [],
        l = null,
        u, f, h, _ = [],
        m = e.parentElement,
        T = e.nextElementSibling,
        R = sP(),
        B = window.getComputedStyle(e),
        I = B.textAlign,
        A = parseFloat(B.fontSize),
        E = A * .2;
    return t.absolute && (h = {
        left: e.offsetLeft,
        top: e.offsetTop,
        width: e.offsetWidth
    }, f = e.offsetWidth, u = e.offsetHeight, cr(e, {
        cssWidth: e.style.width,
        cssHeight: e.style.height
    })), Xi(s).forEach(function(O) {
        var P = O.parentElement === e,
            $ = iP(O, P, t, n),
            H = $.width,
            F = $.height,
            V = $.top,
            k = $.left;
        /^br$/i.test(O.nodeName) || (r.lines && P && ((l === null || V - l >= E) && (l = V, o.push(a = [])), a.push(O)), t.absolute && cr(O, {
            top: V,
            left: k,
            width: H,
            height: F
        }))
    }), m && m.removeChild(e), r.lines && (_ = o.map(function(O) {
        var P = Bu(i, {
            class: "".concat(t.splitClass, " ").concat(t.lineClass),
            style: "display: block; text-align: ".concat(I, "; width: 100%;")
        });
        cr(P, "isLine", !0);
        var $ = {
            height: 0,
            top: 1e4
        };
        return R.appendChild(P), O.forEach(function(H, F, V) {
            var k = Ii(H),
                Y = k.isWordEnd,
                L = k.top,
                te = k.height,
                ie = V[F + 1];
            $.height = Math.max($.height, te), $.top = Math.min($.top, L), P.appendChild(H), Y && Ii(ie).isWordStart && P.append(" ")
        }), t.absolute && cr(P, {
            height: $.height,
            top: $.top
        }), P
    }), r.words || xy(R), e.replaceChildren(R)), t.absolute && (e.style.width = "".concat(e.style.width || f, "px"), e.style.height = "".concat(u, "px"), Xi(s).forEach(function(O) {
        var P = Ii(O),
            $ = P.isLine,
            H = P.top,
            F = P.left,
            V = P.width,
            k = P.height,
            Y = Ii(O.parentElement),
            L = !$ && Y.isLine;
        O.style.top = "".concat(L ? H - Y.top : H, "px"), O.style.left = $ ? "".concat(h.left, "px") : "".concat(F - (L ? h.left : 0), "px"), O.style.height = "".concat(k, "px"), O.style.width = $ ? "".concat(h.width, "px") : "".concat(V, "px"), O.style.position = "absolute"
    })), m && (T ? m.insertBefore(e, T) : m.appendChild(e)), _
}
var fs = Ri(pd, {}),
    aP = function() {
        Hp(e, null, [{
            key: "clearData",
            value: function() {
                VO()
            }
        }, {
            key: "setDefaults",
            value: function(n) {
                return fs = Ri(fs, Da(n)), pd
            }
        }, {
            key: "revert",
            value: function(n) {
                zp(n).forEach(function(r) {
                    var i = Ii(r),
                        s = i.isSplit,
                        o = i.html,
                        a = i.cssWidth,
                        l = i.cssHeight;
                    s && (r.innerHTML = o, r.style.width = a || "", r.style.height = l || "", my(r))
                })
            }
        }, {
            key: "create",
            value: function(n, r) {
                return new e(n, r)
            }
        }, {
            key: "data",
            get: function() {
                return Kn
            }
        }, {
            key: "defaults",
            get: function() {
                return fs
            },
            set: function(n) {
                fs = Ri(fs, Da(n))
            }
        }]);

        function e(t, n) {
            OO(this, e), this.isSplit = !1, this.settings = Ri(fs, Da(n)), this.elements = zp(t), this.split()
        }
        return Hp(e, [{
            key: "split",
            value: function(n) {
                var r = this;
                this.revert(), this.elements.forEach(function(o) {
                    cr(o, "html", o.innerHTML)
                }), this.lines = [], this.words = [], this.chars = [];
                var i = [window.pageXOffset, window.pageYOffset];
                n !== void 0 && (this.settings = Ri(this.settings, Da(n)));
                var s = dd(this.settings.types);
                s.none || (this.elements.forEach(function(o) {
                    cr(o, "isRoot", !0);
                    var a = Ay(o, r.settings),
                        l = a.words,
                        u = a.chars;
                    r.words = [].concat(mn(r.words), mn(l)), r.chars = [].concat(mn(r.chars), mn(u))
                }), this.elements.forEach(function(o) {
                    if (s.lines || r.settings.absolute) {
                        var a = oP(o, r.settings, i);
                        r.lines = [].concat(mn(r.lines), mn(a))
                    }
                }), this.isSplit = !0, window.scrollTo(i[0], i[1]), HO())
            }
        }, {
            key: "revert",
            value: function() {
                this.isSplit && (this.lines = null, this.words = null, this.chars = null, this.isSplit = !1), e.revert(this.elements)
            }
        }]), e
    }();
const Rt = {
        v: null,
        global: null,
        components: []
    },
    lP = "1.1.0",
    fk = "hextail.com",
    dk = "pomegranate",
    Sr = window.$ssr ? JSON.parse(window.$ssr) : null,
    Oy = window.location.href.includes("?preview=draft"),
    Ml = window.location.hostname,
    Fo = Ml.includes("dev.") || Ml.includes("localhost"),
    Rl = Ml.includes("staging.") || Ml.includes("demo."),
    Mn = (e, t) => {
        (Fo || Rl) && (Wo(t) ? console.log("%c" + t, "color:#5E35B1", e) : console.error("%c" + t, "color:#00D9C0", e))
    },
    cP = Z_,
    Za = Kg,
    zs = li,
    Py = Ax,
    uP = Cx,
    fP = po,
    dP = Px,
    Bs = Sx,
    hk = xx,
    ji = gO,
    Bi = xO,
    hP = aP,
    Ee = (e, t) => {
        const n = e.__vccOpts || e;
        for (const [r, i] of t) n[r] = i;
        return n
    },
    pP = {
        props: {
            content: {
                type: Object,
                default: () => ({})
            }
        },
        computed: {
            blockName() {
                const e = this.content.block_type,
                    t = "block-" + (e || "").replace("_", "-");
                return Rt.components.includes(t) ? t : (Mn('"blocks/' + e + '.vue" file is missing', 404), null)
            }
        }
    };

function mP(e, t, n, r, i, s) {
    return s.blockName ? (Q(), Et(kr(s.blockName), {
        key: 0,
        content: n.content
    }, null, 8, ["content"])) : dt("", !0)
}
const gP = Ee(pP, [
        ["render", mP]
    ]),
    _P = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: gP
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    vP = {
        props: {
            transition: {
                type: [Object, Boolean],
                default: null
            },
            tag: {
                type: [String, Boolean],
                default: null
            }
        }
    };

function yP(e, t, n, r, i, s) {
    return n.transition ? (Q(), Et(U_, ag(ui({
        key: 0
    }, n.transition)), {
        default: Ct(() => [Mt(e.$slots, "default")]),
        _: 3
    }, 16)) : n.tag ? (Q(), Et(kr(n.tag), {
        key: 1
    }, {
        default: Ct(() => [Mt(e.$slots, "default")]),
        _: 3
    })) : Mt(e.$slots, "default", {
        key: 2
    })
}
const bP = Ee(vP, [
        ["render", yP]
    ]),
    wP = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: bP
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    SP = {
        props: {
            name: {
                type: String,
                default: null
            }
        },
        computed: {
            iconName() {
                const e = "icon-" + (this.name || "");
                return Rt.components.includes(e) ? e : (Mn('"icons/' + e + '.vue" file is missing', 404), null)
            }
        }
    };

function TP(e, t, n, r, i, s) {
    return Q(), pe("svg", {
        role: "img",
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 24 24",
        preserveAspectRatio: "xMidYMin meet",
        class: Ot(["--icon", "--" + s.iconName])
    }, [s.iconName ? (Q(), Et(kr(s.iconName), {
        key: 0
    })) : dt("", !0)], 2)
}
const CP = Ee(SP, [
        ["render", TP]
    ]),
    EP = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: CP
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    AP = {
        computed: {
            component() {
                let e = gt(this.$attrs, "media.src.extention");
                return e || (e = gt(this.$attrs, "media.src", "").split(".").pop()), e === "riv" ? "ui-rive" : lf(["mp4", "webm"], e) ? "ui-video" : "ui-image"
            }
        }
    };

function xP(e, t, n, r, i, s) {
    return Q(), Et(kr(s.component), ui(e.$attrs, {
        class: "--ui-media"
    }), null, 16)
}
const OP = Ee(AP, [
        ["render", xP]
    ]),
    PP = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: OP
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    MP = {
        props: {
            group: {
                type: [Object, Boolean],
                default: null
            },
            query: {
                type: Object,
                default: () => ({})
            },
            options: {
                type: Object,
                default: () => ({})
            },
            cached: {
                type: Boolean,
                default: !0
            },
            loadMore: {
                type: [Object, Boolean],
                default: null
            },
            pageIncrease: {
                type: Boolean,
                default: !0
            },
            postAppend: {
                type: Boolean,
                default: !0
            }
        },
        emits: ["load", "error"],
        data() {
            return {
                loaded: !1,
                loading: !1,
                current: this.query.page || 1,
                posts: [],
                total: 0,
                end: !1
            }
        },
        created() {
            this.loadPosts()
        },
        watch: {
            "query.page" (e) {
                this.current = e
            }
        },
        methods: {
            loadPosts(e) {
                const t = this;
                t.loading || (t.loading = !0, t._api.query({ ...t.query,
                    page: t.current
                }, {
                    cached: t.cached,
                    ...t.options
                }).then(n => {
                    t.posts = e ? t.posts.concat(n.posts) : n.posts, t.total = n.query.pagination.total, t.end = n.query.pagination.end, t.loading = !1, t.loaded = !0, t.$emit("load", n)
                }, ({
                    message: n,
                    status: r
                }) => {
                    t.loading = !1, t.$emit("error", {
                        message: n,
                        status: r
                    })
                }))
            },
            loadMorePosts() {
                const e = this;
                e.loading || (e.pageIncrease && e.current++, e.loadPosts(e.postAppend))
            }
        }
    };

function RP(e, t, n, r, i, s) {
    const o = vt("ui-button"),
        a = vt("group");
    return Q(), Et(a, {
        transition: n.group
    }, {
        default: Ct(() => [Mt(e.$slots, "before", {
            posts: i.posts,
            current: i.current,
            total: i.total,
            end: i.end
        }), i.loaded ? dt("", !0) : Mt(e.$slots, "loading", {
            key: 0
        }), i.loaded ? Mt(e.$slots, "posts", {
            key: 1,
            posts: i.posts,
            current: i.current,
            total: i.total,
            end: i.end
        }) : dt("", !0), i.loaded && !e.$slots.posts ? (Q(!0), pe(nt, {
            key: 2
        }, Wi(i.posts, (l, u) => Mt(e.$slots, "post", {
            key: u,
            post: l,
            index: u,
            posts: i.posts,
            current: i.current,
            total: i.total,
            end: i.end
        })), 128)) : dt("", !0), i.posts.length === 0 && i.end ? Mt(e.$slots, "empty", {
            key: 3
        }, () => [Pr(" No posts found ")]) : dt("", !0), Mt(e.$slots, "after", {
            posts: i.posts,
            current: i.current,
            total: i.total,
            end: i.end
        }), n.loadMore && i.loaded && !i.end ? (Q(), pe("div", ui({
            key: 4
        }, n.loadMore.container, {
            class: "--load-more"
        }), [Pe(o, ui(n.loadMore.button, {
            onClick: s.loadMorePosts
        }), null, 16, ["onClick"])], 16)) : dt("", !0)]),
        _: 3
    }, 8, ["transition"])
}
const IP = Ee(MP, [
        ["render", RP]
    ]),
    $P = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: IP
    }, Symbol.toStringTag, {
        value: "Module"
    }));
var kP = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
    My = {
        exports: {}
    };
(function(e, t) {
    (function(r, i) {
        e.exports = i()
    })(kP, () => (() => {
        var n = [, (o, a, l) => {
                l.r(a), l.d(a, {
                    default: () => f
                });
                var u = (() => {
                    var h = typeof document < "u" && document.currentScript ? document.currentScript.src : void 0;
                    return function(_ = {}) {
                        var m = _,
                            T, R;
                        m.ready = new Promise((g, p) => {
                            T = g, R = p
                        });

                        function B() {
                            function g(Z) {
                                const G = w;
                                y = p = 0, w = new Map, G.forEach(ee => {
                                    try {
                                        ee(Z)
                                    } catch (J) {
                                        console.error(J)
                                    }
                                }), this.xa(), M && M.Ta()
                            }
                            let p = 0,
                                y = 0,
                                w = new Map,
                                M = null,
                                N = null;
                            this.requestAnimationFrame = function(Z) {
                                p || (p = requestAnimationFrame(g.bind(this)));
                                const G = ++y;
                                return w.set(G, Z), G
                            }, this.cancelAnimationFrame = function(Z) {
                                w.delete(Z), p && w.size == 0 && (cancelAnimationFrame(p), p = 0)
                            }, this.Ra = function(Z) {
                                N && (document.body.remove(N), N = null), Z || (N = document.createElement("div"), N.style.backgroundColor = "black", N.style.position = "fixed", N.style.right = 0, N.style.top = 0, N.style.color = "white", N.style.padding = "4px", N.innerHTML = "RIVE FPS", Z = function(G) {
                                    N.innerHTML = "RIVE FPS " + G.toFixed(1)
                                }, document.body.appendChild(N)), M = new function() {
                                    let G = 0,
                                        ee = 0;
                                    this.Ta = function() {
                                        var J = performance.now();
                                        ee ? (++G, J -= ee, 1e3 < J && (Z(1e3 * G / J), G = ee = 0)) : (ee = J, G = 0)
                                    }
                                }
                            }, this.Oa = function() {
                                N && (document.body.remove(N), N = null), M = null
                            }, this.xa = function() {}
                        }

                        function I(g) {
                            console.assert(!0);
                            const p = new Map;
                            let y = -1 / 0;
                            this.push = function(w) {
                                return w = w + ((1 << g) - 1) >> g, p.has(w) && clearTimeout(p.get(w)), p.set(w, setTimeout(function() {
                                    p.delete(w), p.length == 0 ? y = -1 / 0 : w == y && (y = Math.max(...p.keys()), console.assert(y < w))
                                }, 1e3)), y = Math.max(w, y), y << g
                            }
                        }
                        const A = m.onRuntimeInitialized;
                        m.onRuntimeInitialized = function() {
                            A && A();
                            let g = m.decodeAudio;
                            m.decodeAudio = function(M, N) {
                                M = g(M), N(M)
                            };
                            let p = m.decodeFont;
                            m.decodeFont = function(M, N) {
                                M = p(M), N(M)
                            };
                            const y = m.FileAssetLoader;
                            m.ptrToAsset = M => {
                                let N = m.ptrToFileAsset(M);
                                return N.isImage ? m.ptrToImageAsset(M) : N.isFont ? m.ptrToFontAsset(M) : N.isAudio ? m.ptrToAudioAsset(M) : N
                            }, m.CustomFileAssetLoader = y.extend("CustomFileAssetLoader", {
                                __construct: function({
                                    loadContents: M
                                }) {
                                    this.__parent.__construct.call(this), this.Ha = M
                                },
                                loadContents: function(M, N) {
                                    return M = m.ptrToAsset(M), this.Ha(M, N)
                                }
                            }), m.CDNFileAssetLoader = y.extend("CDNFileAssetLoader", {
                                __construct: function() {
                                    this.__parent.__construct.call(this)
                                },
                                loadContents: function(M) {
                                    let N = m.ptrToAsset(M);
                                    return M = N.cdnUuid, M === "" ? !1 : (function(Z, G) {
                                        var ee = new XMLHttpRequest;
                                        ee.responseType = "arraybuffer", ee.onreadystatechange = function() {
                                            ee.readyState == 4 && ee.status == 200 && G(ee)
                                        }, ee.open("GET", Z, !0), ee.send(null)
                                    }(N.cdnBaseUrl + "/" + M, Z => {
                                        N.decode(new Uint8Array(Z.response))
                                    }), !0)
                                }
                            }), m.FallbackFileAssetLoader = y.extend("FallbackFileAssetLoader", {
                                __construct: function() {
                                    this.__parent.__construct.call(this), this.wa = []
                                },
                                addLoader: function(M) {
                                    this.wa.push(M)
                                },
                                loadContents: function(M, N) {
                                    for (let Z of this.wa)
                                        if (Z.loadContents(M, N)) return !0;
                                    return !1
                                }
                            });
                            let w = m.computeAlignment;
                            m.computeAlignment = function(M, N, Z, G, ee = 1) {
                                return w.call(this, M, N, Z, G, ee)
                            }
                        };
                        const E = "createConicGradient createImageData createLinearGradient createPattern createRadialGradient getContextAttributes getImageData getLineDash getTransform isContextLost isPointInPath isPointInStroke measureText".split(" "),
                            O = new function() {
                                function g() {
                                    if (!p) {
                                        let ut = function(ot, Ce, At) {
                                            if (Ce = he.createShader(Ce), he.shaderSource(Ce, At), he.compileShader(Ce), At = he.getShaderInfoLog(Ce), 0 < (At || "").length) throw At;
                                            he.attachShader(ot, Ce)
                                        };
                                        var D = document.createElement("canvas"),
                                            ve = {
                                                alpha: 1,
                                                depth: 0,
                                                stencil: 0,
                                                antialias: 0,
                                                premultipliedAlpha: 1,
                                                preserveDrawingBuffer: 0,
                                                powerPreference: "high-performance",
                                                failIfMajorPerformanceCaveat: 0,
                                                enableExtensionsByDefault: 1,
                                                explicitSwapControl: 1,
                                                renderViaOffscreenBackBuffer: 1
                                            };
                                        let he;
                                        if (/iPhone|iPad|iPod/i.test(navigator.userAgent)) {
                                            if (he = D.getContext("webgl", ve), y = 1, !he) return console.log("No WebGL support. Image mesh will not be drawn."), !1
                                        } else if (he = D.getContext("webgl2", ve)) y = 2;
                                        else if (he = D.getContext("webgl", ve)) y = 1;
                                        else return console.log("No WebGL support. Image mesh will not be drawn."), !1;
                                        if (he = new Proxy(he, {
                                                get(ot, Ce) {
                                                    if (ot.isContextLost()) {
                                                        if (ee || (console.error("Cannot render the mesh because the GL Context was lost. Tried to invoke ", Ce), ee = !0), typeof ot[Ce] == "function") return function() {}
                                                    } else return typeof ot[Ce] == "function" ? function(...At) {
                                                        return ot[Ce].apply(ot, At)
                                                    } : ot[Ce]
                                                },
                                                set(ot, Ce, At) {
                                                    if (ot.isContextLost()) ee || (console.error("Cannot render the mesh because the GL Context was lost. Tried to set property " + Ce), ee = !0);
                                                    else return ot[Ce] = At, !0
                                                }
                                            }), w = Math.min(he.getParameter(he.MAX_RENDERBUFFER_SIZE), he.getParameter(he.MAX_TEXTURE_SIZE)), D = he.createProgram(), ut(D, he.VERTEX_SHADER, `attribute vec2 vertex;
                attribute vec2 uv;
                uniform vec4 mat;
                uniform vec2 translate;
                varying vec2 st;
                void main() {
                    st = uv;
                    gl_Position = vec4(mat2(mat) * vertex + translate, 0, 1);
                }`), ut(D, he.FRAGMENT_SHADER, `precision highp float;
                uniform sampler2D image;
                varying vec2 st;
                void main() {
                    gl_FragColor = texture2D(image, st);
                }`), he.bindAttribLocation(D, 0, "vertex"), he.bindAttribLocation(D, 1, "uv"), he.linkProgram(D), ve = he.getProgramInfoLog(D), 0 < (ve || "").trim().length) throw ve;
                                        M = he.getUniformLocation(D, "mat"), N = he.getUniformLocation(D, "translate"), he.useProgram(D), he.bindBuffer(he.ARRAY_BUFFER, he.createBuffer()), he.enableVertexAttribArray(0), he.enableVertexAttribArray(1), he.bindBuffer(he.ELEMENT_ARRAY_BUFFER, he.createBuffer()), he.uniform1i(he.getUniformLocation(D, "image"), 0), he.pixelStorei(he.UNPACK_PREMULTIPLY_ALPHA_WEBGL, !0), p = he
                                    }
                                    return !0
                                }
                                let p = null,
                                    y = 0,
                                    w = 0,
                                    M = null,
                                    N = null,
                                    Z = 0,
                                    G = 0,
                                    ee = !1;
                                g(), this.eb = function() {
                                    return g(), w
                                }, this.Ma = function(D) {
                                    p.deleteTexture && p.deleteTexture(D)
                                }, this.La = function(D) {
                                    if (!g()) return null;
                                    const ve = p.createTexture();
                                    return ve ? (p.bindTexture(p.TEXTURE_2D, ve), p.texImage2D(p.TEXTURE_2D, 0, p.RGBA, p.RGBA, p.UNSIGNED_BYTE, D), p.texParameteri(p.TEXTURE_2D, p.TEXTURE_WRAP_S, p.CLAMP_TO_EDGE), p.texParameteri(p.TEXTURE_2D, p.TEXTURE_WRAP_T, p.CLAMP_TO_EDGE), p.texParameteri(p.TEXTURE_2D, p.TEXTURE_MAG_FILTER, p.LINEAR), y == 2 ? (p.texParameteri(p.TEXTURE_2D, p.TEXTURE_MIN_FILTER, p.LINEAR_MIPMAP_LINEAR), p.generateMipmap(p.TEXTURE_2D)) : p.texParameteri(p.TEXTURE_2D, p.TEXTURE_MIN_FILTER, p.LINEAR), ve) : null
                                };
                                const J = new I(8),
                                    be = new I(8),
                                    Te = new I(10),
                                    $e = new I(10);
                                this.Qa = function(D, ve, he, ut, ot) {
                                    if (g()) {
                                        var Ce = J.push(D),
                                            At = be.push(ve);
                                        if (p.canvas) {
                                            (p.canvas.width != Ce || p.canvas.height != At) && (p.canvas.width = Ce, p.canvas.height = At), p.viewport(0, At - ve, D, ve), p.disable(p.SCISSOR_TEST), p.clearColor(0, 0, 0, 0), p.clear(p.COLOR_BUFFER_BIT), p.enable(p.SCISSOR_TEST), he.sort((et, rr) => rr.Ba - et.Ba), Ce = Te.push(ut), Z != Ce && (p.bufferData(p.ARRAY_BUFFER, 8 * Ce, p.DYNAMIC_DRAW), Z = Ce), Ce = 0;
                                            for (var en of he) p.bufferSubData(p.ARRAY_BUFFER, Ce, en.ia), Ce += 4 * en.ia.length;
                                            console.assert(Ce == 4 * ut);
                                            for (var nr of he) p.bufferSubData(p.ARRAY_BUFFER, Ce, nr.Ea), Ce += 4 * nr.Ea.length;
                                            console.assert(Ce == 8 * ut), Ce = $e.push(ot), G != Ce && (p.bufferData(p.ELEMENT_ARRAY_BUFFER, 2 * Ce, p.DYNAMIC_DRAW), G = Ce), en = 0;
                                            for (var _i of he) p.bufferSubData(p.ELEMENT_ARRAY_BUFFER, en, _i.indices), en += 2 * _i.indices.length;
                                            console.assert(en == 2 * ot), _i = 0, nr = !0, Ce = en = 0;
                                            for (const et of he) {
                                                et.image.da != _i && (p.bindTexture(p.TEXTURE_2D, et.image.ca || null), _i = et.image.da), et.hb ? (p.scissor(et.na, At - et.oa - et.va, et.sb, et.va), nr = !0) : nr && (p.scissor(0, At - ve, D, ve), nr = !1), he = 2 / D;
                                                const rr = -2 / ve;
                                                p.uniform4f(M, et.N[0] * he * et.X, et.N[1] * rr * et.Y, et.N[2] * he * et.X, et.N[3] * rr * et.Y), p.uniform2f(N, et.N[4] * he * et.X + he * (et.na - et.fb * et.X) - 1, et.N[5] * rr * et.Y + rr * (et.oa - et.gb * et.Y) + 1), p.vertexAttribPointer(0, 2, p.FLOAT, !1, 0, Ce), p.vertexAttribPointer(1, 2, p.FLOAT, !1, 0, Ce + 4 * ut), p.drawElements(p.TRIANGLES, et.indices.length, p.UNSIGNED_SHORT, en), Ce += 4 * et.ia.length, en += 2 * et.indices.length
                                            }
                                            console.assert(Ce == 4 * ut), console.assert(en == 2 * ot)
                                        }
                                    }
                                }, this.canvas = function() {
                                    return g() && p.canvas
                                }
                            },
                            P = m.onRuntimeInitialized;
                        m.onRuntimeInitialized = function() {
                            function g(se) {
                                switch (se) {
                                    case J.srcOver:
                                        return "source-over";
                                    case J.screen:
                                        return "screen";
                                    case J.overlay:
                                        return "overlay";
                                    case J.darken:
                                        return "darken";
                                    case J.lighten:
                                        return "lighten";
                                    case J.colorDodge:
                                        return "color-dodge";
                                    case J.colorBurn:
                                        return "color-burn";
                                    case J.hardLight:
                                        return "hard-light";
                                    case J.softLight:
                                        return "soft-light";
                                    case J.difference:
                                        return "difference";
                                    case J.exclusion:
                                        return "exclusion";
                                    case J.multiply:
                                        return "multiply";
                                    case J.hue:
                                        return "hue";
                                    case J.saturation:
                                        return "saturation";
                                    case J.color:
                                        return "color";
                                    case J.luminosity:
                                        return "luminosity"
                                }
                            }

                            function p(se) {
                                return "rgba(" + ((16711680 & se) >>> 16) + "," + ((65280 & se) >>> 8) + "," + ((255 & se) >>> 0) + "," + ((4278190080 & se) >>> 24) / 255 + ")"
                            }

                            function y() {
                                0 < At.length && (O.Qa(Ce.drawWidth(), Ce.drawHeight(), At, en, nr), At = [], nr = en = 0, Ce.reset(512, 512));
                                for (const se of ot) {
                                    for (const Se of se.u) Se();
                                    se.u = []
                                }
                                ot.clear()
                            }
                            P && P();
                            var w = m.RenderPaintStyle;
                            const M = m.RenderPath,
                                N = m.RenderPaint,
                                Z = m.Renderer,
                                G = m.StrokeCap,
                                ee = m.StrokeJoin,
                                J = m.BlendMode,
                                be = w.fill,
                                Te = w.stroke,
                                $e = m.FillRule.evenOdd;
                            let D = 1;
                            var ve = m.RenderImage.extend("CanvasRenderImage", {
                                    __construct: function({
                                        R: se,
                                        W: Se
                                    } = {}) {
                                        this.__parent.__construct.call(this), this.da = D, D = D + 1 & 2147483647 || 1, this.R = se, this.W = Se
                                    },
                                    __destruct: function() {
                                        this.ca && (O.Ma(this.ca), URL.revokeObjectURL(this.la)), this.__parent.__destruct.call(this)
                                    },
                                    decode: function(se) {
                                        var Se = this;
                                        Se.W && Se.W(Se);
                                        var Ye = new Image;
                                        Se.la = URL.createObjectURL(new Blob([se], {
                                            type: "image/png"
                                        })), Ye.onload = function() {
                                            Se.Ga = Ye, Se.ca = O.La(Ye), Se.size(Ye.width, Ye.height), Se.R && Se.R(Se)
                                        }, Ye.src = Se.la
                                    }
                                }),
                                he = M.extend("CanvasRenderPath", {
                                    __construct: function() {
                                        this.__parent.__construct.call(this), this.F = new Path2D
                                    },
                                    rewind: function() {
                                        this.F = new Path2D
                                    },
                                    addPath: function(se, Se, Ye, Xe, Ve, at, lt) {
                                        var mt = this.F,
                                            kn = mt.addPath;
                                        se = se.F;
                                        const Kt = new DOMMatrix;
                                        Kt.a = Se, Kt.b = Ye, Kt.c = Xe, Kt.d = Ve, Kt.e = at, Kt.f = lt, kn.call(mt, se, Kt)
                                    },
                                    fillRule: function(se) {
                                        this.ka = se
                                    },
                                    moveTo: function(se, Se) {
                                        this.F.moveTo(se, Se)
                                    },
                                    lineTo: function(se, Se) {
                                        this.F.lineTo(se, Se)
                                    },
                                    cubicTo: function(se, Se, Ye, Xe, Ve, at) {
                                        this.F.bezierCurveTo(se, Se, Ye, Xe, Ve, at)
                                    },
                                    close: function() {
                                        this.F.closePath()
                                    }
                                }),
                                ut = N.extend("CanvasRenderPaint", {
                                    color: function(se) {
                                        this.ma = p(se)
                                    },
                                    thickness: function(se) {
                                        this.Ja = se
                                    },
                                    join: function(se) {
                                        switch (se) {
                                            case ee.miter:
                                                this.ba = "miter";
                                                break;
                                            case ee.round:
                                                this.ba = "round";
                                                break;
                                            case ee.bevel:
                                                this.ba = "bevel"
                                        }
                                    },
                                    cap: function(se) {
                                        switch (se) {
                                            case G.butt:
                                                this.aa = "butt";
                                                break;
                                            case G.round:
                                                this.aa = "round";
                                                break;
                                            case G.square:
                                                this.aa = "square"
                                        }
                                    },
                                    style: function(se) {
                                        this.Ia = se
                                    },
                                    blendMode: function(se) {
                                        this.Fa = g(se)
                                    },
                                    clearGradient: function() {
                                        this.P = null
                                    },
                                    linearGradient: function(se, Se, Ye, Xe) {
                                        this.P = {
                                            Ca: se,
                                            Da: Se,
                                            qa: Ye,
                                            ra: Xe,
                                            ga: []
                                        }
                                    },
                                    radialGradient: function(se, Se, Ye, Xe) {
                                        this.P = {
                                            Ca: se,
                                            Da: Se,
                                            qa: Ye,
                                            ra: Xe,
                                            ga: [],
                                            bb: !0
                                        }
                                    },
                                    addStop: function(se, Se) {
                                        this.P.ga.push({
                                            color: se,
                                            stop: Se
                                        })
                                    },
                                    completeGradient: function() {},
                                    draw: function(se, Se, Ye) {
                                        let Xe = this.Ia;
                                        var Ve = this.ma,
                                            at = this.P;
                                        if (se.globalCompositeOperation = this.Fa, at != null) {
                                            Ve = at.Ca;
                                            var lt = at.Da;
                                            const kn = at.qa;
                                            var mt = at.ra;
                                            const Kt = at.ga;
                                            at.bb ? (at = kn - Ve, mt -= lt, Ve = se.createRadialGradient(Ve, lt, 0, Ve, lt, Math.sqrt(at * at + mt * mt))) : Ve = se.createLinearGradient(Ve, lt, kn, mt);
                                            for (let ir = 0, Zt = Kt.length; ir < Zt; ir++) lt = Kt[ir], Ve.addColorStop(lt.stop, p(lt.color));
                                            this.ma = Ve, this.P = null
                                        }
                                        switch (Xe) {
                                            case Te:
                                                se.strokeStyle = Ve, se.lineWidth = this.Ja, se.lineCap = this.aa, se.lineJoin = this.ba, se.stroke(Se);
                                                break;
                                            case be:
                                                se.fillStyle = Ve, se.fill(Se, Ye)
                                        }
                                    }
                                });
                            const ot = new Set;
                            let Ce = null,
                                At = [],
                                en = 0,
                                nr = 0;
                            var _i = m.CanvasRenderer = Z.extend("Renderer", {
                                __construct: function(se) {
                                    this.__parent.__construct.call(this), this.D = [1, 0, 0, 1, 0, 0], this.o = se.getContext("2d"), this.ja = se, this.u = []
                                },
                                save: function() {
                                    this.D.push(...this.D.slice(this.D.length - 6)), this.u.push(this.o.save.bind(this.o))
                                },
                                restore: function() {
                                    const se = this.D.length - 6;
                                    if (6 > se) throw "restore() called without matching save().";
                                    this.D.splice(se), this.u.push(this.o.restore.bind(this.o))
                                },
                                transform: function(se, Se, Ye, Xe, Ve, at) {
                                    const lt = this.D,
                                        mt = lt.length - 6;
                                    lt.splice(mt, 6, lt[mt] * se + lt[mt + 2] * Se, lt[mt + 1] * se + lt[mt + 3] * Se, lt[mt] * Ye + lt[mt + 2] * Xe, lt[mt + 1] * Ye + lt[mt + 3] * Xe, lt[mt] * Ve + lt[mt + 2] * at + lt[mt + 4], lt[mt + 1] * Ve + lt[mt + 3] * at + lt[mt + 5]), this.u.push(this.o.transform.bind(this.o, se, Se, Ye, Xe, Ve, at))
                                },
                                rotate: function(se) {
                                    const Se = Math.sin(se);
                                    se = Math.cos(se), this.transform(se, Se, -Se, se, 0, 0)
                                },
                                _drawPath: function(se, Se) {
                                    this.u.push(Se.draw.bind(Se, this.o, se.F, se.ka === $e ? "evenodd" : "nonzero"))
                                },
                                _drawRiveImage: function(se, Se, Ye) {
                                    var Xe = se.Ga;
                                    if (Xe) {
                                        var Ve = this.o,
                                            at = g(Se);
                                        this.u.push(function() {
                                            Ve.globalCompositeOperation = at, Ve.globalAlpha = Ye, Ve.drawImage(Xe, 0, 0), Ve.globalAlpha = 1
                                        })
                                    }
                                },
                                _getMatrix: function(se) {
                                    const Se = this.D,
                                        Ye = Se.length - 6;
                                    for (let Xe = 0; 6 > Xe; ++Xe) se[Xe] = Se[Ye + Xe]
                                },
                                _drawImageMesh: function(se, Se, Ye, Xe, Ve, at, lt, mt, kn, Kt) {
                                    var ir = this.o.canvas.width,
                                        Zt = this.o.canvas.height;
                                    const Fd = kn - lt,
                                        Dd = Kt - mt;
                                    lt = Math.max(lt, 0), mt = Math.max(mt, 0), kn = Math.min(kn, ir), Kt = Math.min(Kt, Zt);
                                    const Gs = kn - lt,
                                        Ys = Kt - mt;
                                    if (console.assert(Gs <= Math.min(Fd, ir)), console.assert(Ys <= Math.min(Dd, Zt)), !(0 >= Gs || 0 >= Ys)) {
                                        kn = Gs < Fd || Ys < Dd, ir = Kt = 1;
                                        var vi = Math.ceil(Gs * Kt),
                                            yi = Math.ceil(Ys * ir);
                                        Zt = O.eb(), vi > Zt && (Kt *= Zt / vi, vi = Zt), yi > Zt && (ir *= Zt / yi, yi = Zt), Ce || (Ce = new m.DynamicRectanizer(Zt), Ce.reset(512, 512)), Zt = Ce.addRect(vi, yi), 0 > Zt && (y(), ot.add(this), Zt = Ce.addRect(vi, yi), console.assert(0 <= Zt));
                                        var jd = Zt & 65535,
                                            Bd = Zt >> 16;
                                        At.push({
                                            N: this.D.slice(this.D.length - 6),
                                            image: se,
                                            na: jd,
                                            oa: Bd,
                                            fb: lt,
                                            gb: mt,
                                            sb: vi,
                                            va: yi,
                                            X: Kt,
                                            Y: ir,
                                            ia: new Float32Array(Xe),
                                            Ea: new Float32Array(Ve),
                                            indices: new Uint16Array(at),
                                            hb: kn,
                                            Ba: se.da << 1 | (kn ? 1 : 0)
                                        }), en += Xe.length, nr += at.length;
                                        var ls = this.o,
                                            h0 = g(Se);
                                        this.u.push(function() {
                                            ls.save(), ls.resetTransform(), ls.globalCompositeOperation = h0, ls.globalAlpha = Ye;
                                            const Vd = O.canvas();
                                            Vd && ls.drawImage(Vd, jd, Bd, vi, yi, lt, mt, Gs, Ys), ls.restore()
                                        })
                                    }
                                },
                                _clipPath: function(se) {
                                    this.u.push(this.o.clip.bind(this.o, se.F, se.ka === $e ? "evenodd" : "nonzero"))
                                },
                                clear: function() {
                                    ot.add(this), this.u.push(this.o.clearRect.bind(this.o, 0, 0, this.ja.width, this.ja.height))
                                },
                                flush: function() {},
                                translate: function(se, Se) {
                                    this.transform(1, 0, 0, 1, se, Se)
                                }
                            });
                            m.makeRenderer = function(se) {
                                const Se = new _i(se),
                                    Ye = Se.o;
                                return new Proxy(Se, {
                                    get(Xe, Ve) {
                                        if (typeof Xe[Ve] == "function") return function(...at) {
                                            return Xe[Ve].apply(Xe, at)
                                        };
                                        if (typeof Ye[Ve] == "function") {
                                            if (-1 < E.indexOf(Ve)) throw Error("RiveException: Method call to '" + Ve + "()' is not allowed, as the renderer cannot immediately pass through the return                 values of any canvas 2d context methods.");
                                            return function(...at) {
                                                Se.u.push(Ye[Ve].bind(Ye, ...at))
                                            }
                                        }
                                        return Xe[Ve]
                                    },
                                    set(Xe, Ve, at) {
                                        if (Ve in Ye) return Se.u.push(() => {
                                            Ye[Ve] = at
                                        }), !0
                                    }
                                })
                            }, m.decodeImage = function(se, Se) {
                                new ve({
                                    R: Se
                                }).decode(se)
                            }, m.renderFactory = {
                                makeRenderPaint: function() {
                                    return new ut
                                },
                                makeRenderPath: function() {
                                    return new he
                                },
                                makeRenderImage: function() {
                                    let se = rr;
                                    return new ve({
                                        W: () => {
                                            se.total++
                                        },
                                        R: () => {
                                            if (se.loaded++, se.loaded === se.total) {
                                                const Se = se.ready;
                                                Se && (Se(), se.ready = null)
                                            }
                                        }
                                    })
                                }
                            };
                            let et = m.load,
                                rr = null;
                            m.load = function(se, Se, Ye = !0) {
                                const Xe = new m.FallbackFileAssetLoader;
                                return Se !== void 0 && Xe.addLoader(Se), Ye && (Se = new m.CDNFileAssetLoader, Xe.addLoader(Se)), new Promise(function(Ve) {
                                    let at = null;
                                    rr = {
                                        total: 0,
                                        loaded: 0,
                                        ready: function() {
                                            Ve(at)
                                        }
                                    }, at = et(se, Xe), rr.total == 0 && Ve(at)
                                })
                            };
                            let d0 = m.RendererWrapper.prototype.align;
                            m.RendererWrapper.prototype.align = function(se, Se, Ye, Xe, Ve = 1) {
                                d0.call(this, se, Se, Ye, Xe, Ve)
                            }, w = new B, m.requestAnimationFrame = w.requestAnimationFrame.bind(w), m.cancelAnimationFrame = w.cancelAnimationFrame.bind(w), m.enableFPSCounter = w.Ra.bind(w), m.disableFPSCounter = w.Oa, w.xa = y, m.resolveAnimationFrame = y, m.cleanup = function() {
                                Ce && Ce.delete()
                            }
                        };
                        var $ = Object.assign({}, m),
                            H = "./this.program",
                            F = typeof window == "object",
                            V = typeof importScripts == "function",
                            k = "",
                            Y, L;
                        (F || V) && (V ? k = self.location.href : typeof document < "u" && document.currentScript && (k = document.currentScript.src), h && (k = h), k.indexOf("blob:") !== 0 ? k = k.substr(0, k.replace(/[?#].*/, "").lastIndexOf("/") + 1) : k = "", V && (L = g => {
                            var p = new XMLHttpRequest;
                            return p.open("GET", g, !1), p.responseType = "arraybuffer", p.send(null), new Uint8Array(p.response)
                        }), Y = (g, p, y) => {
                            var w = new XMLHttpRequest;
                            w.open("GET", g, !0), w.responseType = "arraybuffer", w.onload = () => {
                                w.status == 200 || w.status == 0 && w.response ? p(w.response) : y()
                            }, w.onerror = y, w.send(null)
                        });
                        var te = m.print || console.log.bind(console),
                            ie = m.printErr || console.error.bind(console);
                        Object.assign(m, $), $ = null, m.thisProgram && (H = m.thisProgram);
                        var _e;
                        m.wasmBinary && (_e = m.wasmBinary), m.noExitRuntime, typeof WebAssembly != "object" && U("no native wasm support detected");
                        var X, le, ce = !1,
                            ue, Oe, ke, Ze, Fe, Ie, Le, Ne;

                        function W() {
                            var g = X.buffer;
                            m.HEAP8 = ue = new Int8Array(g), m.HEAP16 = ke = new Int16Array(g), m.HEAP32 = Fe = new Int32Array(g), m.HEAPU8 = Oe = new Uint8Array(g), m.HEAPU16 = Ze = new Uint16Array(g), m.HEAPU32 = Ie = new Uint32Array(g), m.HEAPF32 = Le = new Float32Array(g), m.HEAPF64 = Ne = new Float64Array(g)
                        }
                        var ge, fe = [],
                            ye = [],
                            Me = [];

                        function Be() {
                            var g = m.preRun.shift();
                            fe.unshift(g)
                        }
                        var S = 0,
                            C = null;

                        function U(g) {
                            throw m.onAbort && m.onAbort(g), g = "Aborted(" + g + ")", ie(g), ce = !0, g = new WebAssembly.RuntimeError(g + ". Build with -sASSERTIONS for more info."), R(g), g
                        }

                        function K(g) {
                            return g.startsWith("data:application/octet-stream;base64,")
                        }
                        var z;
                        if (z = "canvas_advanced.wasm", !K(z)) {
                            var ae = z;
                            z = m.locateFile ? m.locateFile(ae, k) : k + ae
                        }

                        function me(g) {
                            if (g == z && _e) return new Uint8Array(_e);
                            if (L) return L(g);
                            throw "both async and sync fetching of the wasm failed"
                        }

                        function re(g) {
                            if (!_e && (F || V)) {
                                if (typeof fetch == "function" && !g.startsWith("file://")) return fetch(g, {
                                    credentials: "same-origin"
                                }).then(p => {
                                    if (!p.ok) throw "failed to load wasm binary file at '" + g + "'";
                                    return p.arrayBuffer()
                                }).catch(() => me(g));
                                if (Y) return new Promise((p, y) => {
                                    Y(g, w => p(new Uint8Array(w)), y)
                                })
                            }
                            return Promise.resolve().then(() => me(g))
                        }

                        function v(g, p, y) {
                            return re(g).then(w => WebAssembly.instantiate(w, p)).then(w => w).then(y, w => {
                                ie("failed to asynchronously prepare wasm: " + w), U(w)
                            })
                        }

                        function c(g, p) {
                            var y = z;
                            return _e || typeof WebAssembly.instantiateStreaming != "function" || K(y) || y.startsWith("file://") || typeof fetch != "function" ? v(y, g, p) : fetch(y, {
                                credentials: "same-origin"
                            }).then(w => WebAssembly.instantiateStreaming(w, g).then(p, function(M) {
                                return ie("wasm streaming compile failed: " + M), ie("falling back to ArrayBuffer instantiation"), v(y, g, p)
                            }))
                        }
                        var d = g => {
                            for (; 0 < g.length;) g.shift()(m)
                        };

                        function b(g) {
                            if (g === void 0) return "_unknown";
                            g = g.replace(/[^a-zA-Z0-9_]/g, "$");
                            var p = g.charCodeAt(0);
                            return 48 <= p && 57 >= p ? `_${g}` : g
                        }

                        function x(g, p) {
                            return g = b(g), {
                                [g]: function() {
                                    return p.apply(this, arguments)
                                }
                            }[g]
                        }

                        function j() {
                            this.G = [void 0], this.ta = []
                        }
                        var q = new j,
                            oe = void 0;

                        function ne(g) {
                            throw new oe(g)
                        }
                        var de = g => (g || ne("Cannot use deleted val. handle = " + g), q.get(g).value),
                            Ae = g => {
                                switch (g) {
                                    case void 0:
                                        return 1;
                                    case null:
                                        return 2;
                                    case !0:
                                        return 3;
                                    case !1:
                                        return 4;
                                    default:
                                        return q.Za({
                                            Aa: 1,
                                            value: g
                                        })
                                }
                            };

                        function Ge(g) {
                            var p = Error,
                                y = x(g, function(w) {
                                    this.name = g, this.message = w, w = Error(w).stack, w !== void 0 && (this.stack = this.toString() + `
` + w.replace(/^Error(:[^\n]*)?\n/, ""))
                                });
                            return y.prototype = Object.create(p.prototype), y.prototype.constructor = y, y.prototype.toString = function() {
                                return this.message === void 0 ? this.name : `${this.name}: ${this.message}`
                            }, y
                        }
                        var st = void 0,
                            Qe = void 0;

                        function ze(g) {
                            for (var p = ""; Oe[g];) p += Qe[Oe[g++]];
                            return p
                        }
                        var xe = [];

                        function De() {
                            for (; xe.length;) {
                                var g = xe.pop();
                                g.g.M = !1, g.delete()
                            }
                        }
                        var Dt = void 0,
                            Vt = {};

                        function bt(g, p) {
                            for (p === void 0 && ne("ptr should not be undefined"); g.l;) p = g.S(p), g = g.l;
                            return p
                        }
                        var Qn = {};

                        function ss(g) {
                            g = Ld(g);
                            var p = ze(g);
                            return _r(g), p
                        }

                        function Hn(g, p) {
                            var y = Qn[g];
                            return y === void 0 && ne(p + " has unknown type " + ss(g)), y
                        }

                        function Nr() {}
                        var er = !1;

                        function _d(g) {
                            --g.count.value, g.count.value === 0 && (g.s ? g.A.H(g.s) : g.j.h.H(g.i))
                        }

                        function vd(g, p, y) {
                            return p === y ? g : y.l === void 0 ? null : (g = vd(g, p, y.l), g === null ? null : y.Pa(g))
                        }
                        var yd = {};

                        function Wy(g, p) {
                            return p = bt(g, p), Vt[p]
                        }
                        var bd = void 0;

                        function na(g) {
                            throw new bd(g)
                        }

                        function ra(g, p) {
                            return p.j && p.i || na("makeClassHandle requires ptr and ptrType"), !!p.A != !!p.s && na("Both smartPtrType and smartPtr must be specified"), p.count = {
                                value: 1
                            }, os(Object.create(g, {
                                g: {
                                    value: p
                                }
                            }))
                        }

                        function os(g) {
                            return typeof FinalizationRegistry > "u" ? (os = p => p, g) : (er = new FinalizationRegistry(p => {
                                _d(p.g)
                            }), os = p => {
                                var y = p.g;
                                return y.s && er.register(p, {
                                    g: y
                                }, p), p
                            }, Nr = p => {
                                er.unregister(p)
                            }, os(g))
                        }
                        var ia = {};

                        function qs(g) {
                            for (; g.length;) {
                                var p = g.pop();
                                g.pop()(p)
                            }
                        }

                        function Ks(g) {
                            return this.fromWireType(Fe[g >> 2])
                        }
                        var as = {},
                            sa = {};

                        function En(g, p, y) {
                            function w(G) {
                                G = y(G), G.length !== g.length && na("Mismatched type converter count");
                                for (var ee = 0; ee < g.length; ++ee) tr(g[ee], G[ee])
                            }
                            g.forEach(function(G) {
                                sa[G] = p
                            });
                            var M = Array(p.length),
                                N = [],
                                Z = 0;
                            p.forEach((G, ee) => {
                                Qn.hasOwnProperty(G) ? M[ee] = Qn[G] : (N.push(G), as.hasOwnProperty(G) || (as[G] = []), as[G].push(() => {
                                    M[ee] = Qn[G], ++Z, Z === N.length && w(M)
                                }))
                            }), N.length === 0 && w(M)
                        }

                        function oa(g) {
                            switch (g) {
                                case 1:
                                    return 0;
                                case 2:
                                    return 1;
                                case 4:
                                    return 2;
                                case 8:
                                    return 3;
                                default:
                                    throw new TypeError(`Unknown type size: ${g}`)
                            }
                        }

                        function zy(g, p, y = {}) {
                            var w = p.name;
                            if (g || ne(`type "${w}" must have a positive integer typeid pointer`), Qn.hasOwnProperty(g)) {
                                if (y.ab) return;
                                ne(`Cannot register type '${w}' twice`)
                            }
                            Qn[g] = p, delete sa[g], as.hasOwnProperty(g) && (p = as[g], delete as[g], p.forEach(M => M()))
                        }

                        function tr(g, p, y = {}) {
                            if (!("argPackAdvance" in p)) throw new TypeError("registerType registeredInstance requires argPackAdvance");
                            zy(g, p, y)
                        }

                        function fc(g) {
                            ne(g.g.j.h.name + " instance already deleted")
                        }

                        function Fr() {}

                        function dc(g, p, y) {
                            if (g[p].m === void 0) {
                                var w = g[p];
                                g[p] = function() {
                                    return g[p].m.hasOwnProperty(arguments.length) || ne(`Function '${y}' called with an invalid number of arguments (${arguments.length}) - expects one of (${g[p].m})!`), g[p].m[arguments.length].apply(this, arguments)
                                }, g[p].m = [], g[p].m[w.L] = w
                            }
                        }

                        function hc(g, p, y) {
                            m.hasOwnProperty(g) ? ((y === void 0 || m[g].m !== void 0 && m[g].m[y] !== void 0) && ne(`Cannot register public name '${g}' twice`), dc(m, g, g), m.hasOwnProperty(y) && ne(`Cannot register multiple overloads of a function with the same number of arguments (${y})!`), m[g].m[y] = p) : (m[g] = p, y !== void 0 && (m[g].tb = y))
                        }

                        function qy(g, p, y, w, M, N, Z, G) {
                            this.name = g, this.constructor = p, this.B = y, this.H = w, this.l = M, this.Ua = N, this.S = Z, this.Pa = G, this.ya = []
                        }

                        function aa(g, p, y) {
                            for (; p !== y;) p.S || ne(`Expected null or instance of ${y.name}, got an instance of ${p.name}`), g = p.S(g), p = p.l;
                            return g
                        }

                        function Ky(g, p) {
                            return p === null ? (this.ea && ne(`null is not a valid ${this.name}`), 0) : (p.g || ne(`Cannot pass "${mc(p)}" as a ${this.name}`), p.g.i || ne(`Cannot pass deleted object as a pointer of type ${this.name}`), aa(p.g.i, p.g.j.h, this.h))
                        }

                        function Gy(g, p) {
                            if (p === null) {
                                if (this.ea && ne(`null is not a valid ${this.name}`), this.V) {
                                    var y = this.fa();
                                    return g !== null && g.push(this.H, y), y
                                }
                                return 0
                            }
                            if (p.g || ne(`Cannot pass "${mc(p)}" as a ${this.name}`), p.g.i || ne(`Cannot pass deleted object as a pointer of type ${this.name}`), !this.U && p.g.j.U && ne(`Cannot convert argument of type ${p.g.A?p.g.A.name:p.g.j.name} to parameter type ${this.name}`), y = aa(p.g.i, p.g.j.h, this.h), this.V) switch (p.g.s === void 0 && ne("Passing raw pointer to smart pointer is illegal"), this.nb) {
                                case 0:
                                    p.g.A === this ? y = p.g.s : ne(`Cannot convert argument of type ${p.g.A?p.g.A.name:p.g.j.name} to parameter type ${this.name}`);
                                    break;
                                case 1:
                                    y = p.g.s;
                                    break;
                                case 2:
                                    if (p.g.A === this) y = p.g.s;
                                    else {
                                        var w = p.clone();
                                        y = this.jb(y, Ae(function() {
                                            w.delete()
                                        })), g !== null && g.push(this.H, y)
                                    }
                                    break;
                                default:
                                    ne("Unsupporting sharing policy")
                            }
                            return y
                        }

                        function Yy(g, p) {
                            return p === null ? (this.ea && ne(`null is not a valid ${this.name}`), 0) : (p.g || ne(`Cannot pass "${mc(p)}" as a ${this.name}`), p.g.i || ne(`Cannot pass deleted object as a pointer of type ${this.name}`), p.g.j.U && ne(`Cannot convert argument of type ${p.g.j.name} to parameter type ${this.name}`), aa(p.g.i, p.g.j.h, this.h))
                        }

                        function mr(g, p, y, w) {
                            this.name = g, this.h = p, this.ea = y, this.U = w, this.V = !1, this.H = this.jb = this.fa = this.za = this.nb = this.ib = void 0, p.l !== void 0 ? this.toWireType = Gy : (this.toWireType = w ? Ky : Yy, this.v = null)
                        }

                        function wd(g, p, y) {
                            m.hasOwnProperty(g) || na("Replacing nonexistant public symbol"), m[g].m !== void 0 && y !== void 0 ? m[g].m[y] = p : (m[g] = p, m[g].L = y)
                        }
                        var la = [],
                            Sd = g => {
                                var p = la[g];
                                return p || (g >= la.length && (la.length = g + 1), la[g] = p = ge.get(g)), p
                            },
                            Xy = (g, p) => {
                                var y = [];
                                return function() {
                                    if (y.length = 0, Object.assign(y, arguments), g.includes("j")) {
                                        var w = m["dynCall_" + g];
                                        w = y && y.length ? w.apply(null, [p].concat(y)) : w.call(null, p)
                                    } else w = Sd(p).apply(null, y);
                                    return w
                                }
                            };

                        function ln(g, p) {
                            g = ze(g);
                            var y = g.includes("j") ? Xy(g, p) : Sd(p);
                            return typeof y != "function" && ne(`unknown function pointer with signature ${g}: ${p}`), y
                        }
                        var Td = void 0;

                        function gr(g, p) {
                            function y(N) {
                                M[N] || Qn[N] || (sa[N] ? sa[N].forEach(y) : (w.push(N), M[N] = !0))
                            }
                            var w = [],
                                M = {};
                            throw p.forEach(y), new Td(`${g}: ` + w.map(ss).join([", "]))
                        }

                        function ca(g, p, y, w, M) {
                            var N = p.length;
                            2 > N && ne("argTypes array size mismatch! Must at least get return value and 'this' types!");
                            var Z = p[1] !== null && y !== null,
                                G = !1;
                            for (y = 1; y < p.length; ++y)
                                if (p[y] !== null && p[y].v === void 0) {
                                    G = !0;
                                    break
                                }
                            var ee = p[0].name !== "void",
                                J = N - 2,
                                be = Array(J),
                                Te = [],
                                $e = [];
                            return function() {
                                if (arguments.length !== J && ne(`function ${g} called with ${arguments.length} arguments, expected ${J} args!`), $e.length = 0, Te.length = Z ? 2 : 1, Te[0] = M, Z) {
                                    var D = p[1].toWireType($e, this);
                                    Te[1] = D
                                }
                                for (var ve = 0; ve < J; ++ve) be[ve] = p[ve + 2].toWireType($e, arguments[ve]), Te.push(be[ve]);
                                if (ve = w.apply(null, Te), G) qs($e);
                                else
                                    for (var he = Z ? 1 : 2; he < p.length; he++) {
                                        var ut = he === 1 ? D : be[he - 2];
                                        p[he].v !== null && p[he].v(ut)
                                    }
                                return D = ee ? p[0].fromWireType(ve) : void 0, D
                            }
                        }

                        function ua(g, p) {
                            for (var y = [], w = 0; w < g; w++) y.push(Ie[p + 4 * w >> 2]);
                            return y
                        }

                        function Cd(g, p, y) {
                            return g instanceof Object || ne(`${y} with invalid "this": ${g}`), g instanceof p.h.constructor || ne(`${y} incompatible with "this" of type ${g.constructor.name}`), g.g.i || ne(`cannot call emscripten binding method ${y} on deleted object`), aa(g.g.i, g.g.j.h, p.h)
                        }

                        function pc(g) {
                            g >= q.ua && --q.get(g).Aa === 0 && q.$a(g)
                        }

                        function Jy(g, p, y) {
                            switch (p) {
                                case 0:
                                    return function(w) {
                                        return this.fromWireType((y ? ue : Oe)[w])
                                    };
                                case 1:
                                    return function(w) {
                                        return this.fromWireType((y ? ke : Ze)[w >> 1])
                                    };
                                case 2:
                                    return function(w) {
                                        return this.fromWireType((y ? Fe : Ie)[w >> 2])
                                    };
                                default:
                                    throw new TypeError("Unknown integer type: " + g)
                            }
                        }

                        function mc(g) {
                            if (g === null) return "null";
                            var p = typeof g;
                            return p === "object" || p === "array" || p === "function" ? g.toString() : "" + g
                        }

                        function Zy(g, p) {
                            switch (p) {
                                case 2:
                                    return function(y) {
                                        return this.fromWireType(Le[y >> 2])
                                    };
                                case 3:
                                    return function(y) {
                                        return this.fromWireType(Ne[y >> 3])
                                    };
                                default:
                                    throw new TypeError("Unknown float type: " + g)
                            }
                        }

                        function Qy(g, p, y) {
                            switch (p) {
                                case 0:
                                    return y ? function(w) {
                                        return ue[w]
                                    } : function(w) {
                                        return Oe[w]
                                    };
                                case 1:
                                    return y ? function(w) {
                                        return ke[w >> 1]
                                    } : function(w) {
                                        return Ze[w >> 1]
                                    };
                                case 2:
                                    return y ? function(w) {
                                        return Fe[w >> 2]
                                    } : function(w) {
                                        return Ie[w >> 2]
                                    };
                                default:
                                    throw new TypeError("Unknown integer type: " + g)
                            }
                        }
                        var Ed = (g, p, y, w) => {
                                if (0 < w) {
                                    w = y + w - 1;
                                    for (var M = 0; M < g.length; ++M) {
                                        var N = g.charCodeAt(M);
                                        if (55296 <= N && 57343 >= N) {
                                            var Z = g.charCodeAt(++M);
                                            N = 65536 + ((N & 1023) << 10) | Z & 1023
                                        }
                                        if (127 >= N) {
                                            if (y >= w) break;
                                            p[y++] = N
                                        } else {
                                            if (2047 >= N) {
                                                if (y + 1 >= w) break;
                                                p[y++] = 192 | N >> 6
                                            } else {
                                                if (65535 >= N) {
                                                    if (y + 2 >= w) break;
                                                    p[y++] = 224 | N >> 12
                                                } else {
                                                    if (y + 3 >= w) break;
                                                    p[y++] = 240 | N >> 18, p[y++] = 128 | N >> 12 & 63
                                                }
                                                p[y++] = 128 | N >> 6 & 63
                                            }
                                            p[y++] = 128 | N & 63
                                        }
                                    }
                                    p[y] = 0
                                }
                            },
                            Ad = g => {
                                for (var p = 0, y = 0; y < g.length; ++y) {
                                    var w = g.charCodeAt(y);
                                    127 >= w ? p++ : 2047 >= w ? p += 2 : 55296 <= w && 57343 >= w ? (p += 4, ++y) : p += 3
                                }
                                return p
                            },
                            xd = typeof TextDecoder < "u" ? new TextDecoder("utf8") : void 0,
                            fa = (g, p, y) => {
                                var w = p + y;
                                for (y = p; g[y] && !(y >= w);) ++y;
                                if (16 < y - p && g.buffer && xd) return xd.decode(g.subarray(p, y));
                                for (w = ""; p < y;) {
                                    var M = g[p++];
                                    if (M & 128) {
                                        var N = g[p++] & 63;
                                        if ((M & 224) == 192) w += String.fromCharCode((M & 31) << 6 | N);
                                        else {
                                            var Z = g[p++] & 63;
                                            M = (M & 240) == 224 ? (M & 15) << 12 | N << 6 | Z : (M & 7) << 18 | N << 12 | Z << 6 | g[p++] & 63, 65536 > M ? w += String.fromCharCode(M) : (M -= 65536, w += String.fromCharCode(55296 | M >> 10, 56320 | M & 1023))
                                        }
                                    } else w += String.fromCharCode(M)
                                }
                                return w
                            },
                            Od = typeof TextDecoder < "u" ? new TextDecoder("utf-16le") : void 0,
                            e0 = (g, p) => {
                                for (var y = g >> 1, w = y + p / 2; !(y >= w) && Ze[y];) ++y;
                                if (y <<= 1, 32 < y - g && Od) return Od.decode(Oe.subarray(g, y));
                                for (y = "", w = 0; !(w >= p / 2); ++w) {
                                    var M = ke[g + 2 * w >> 1];
                                    if (M == 0) break;
                                    y += String.fromCharCode(M)
                                }
                                return y
                            },
                            t0 = (g, p, y) => {
                                if (y === void 0 && (y = 2147483647), 2 > y) return 0;
                                y -= 2;
                                var w = p;
                                y = y < 2 * g.length ? y / 2 : g.length;
                                for (var M = 0; M < y; ++M) ke[p >> 1] = g.charCodeAt(M), p += 2;
                                return ke[p >> 1] = 0, p - w
                            },
                            n0 = g => 2 * g.length,
                            r0 = (g, p) => {
                                for (var y = 0, w = ""; !(y >= p / 4);) {
                                    var M = Fe[g + 4 * y >> 2];
                                    if (M == 0) break;
                                    ++y, 65536 <= M ? (M -= 65536, w += String.fromCharCode(55296 | M >> 10, 56320 | M & 1023)) : w += String.fromCharCode(M)
                                }
                                return w
                            },
                            i0 = (g, p, y) => {
                                if (y === void 0 && (y = 2147483647), 4 > y) return 0;
                                var w = p;
                                y = w + y - 4;
                                for (var M = 0; M < g.length; ++M) {
                                    var N = g.charCodeAt(M);
                                    if (55296 <= N && 57343 >= N) {
                                        var Z = g.charCodeAt(++M);
                                        N = 65536 + ((N & 1023) << 10) | Z & 1023
                                    }
                                    if (Fe[p >> 2] = N, p += 4, p + 4 > y) break
                                }
                                return Fe[p >> 2] = 0, p - w
                            },
                            s0 = g => {
                                for (var p = 0, y = 0; y < g.length; ++y) {
                                    var w = g.charCodeAt(y);
                                    55296 <= w && 57343 >= w && ++y, p += 4
                                }
                                return p
                            },
                            o0 = {};

                        function da(g) {
                            var p = o0[g];
                            return p === void 0 ? ze(g) : p
                        }
                        var ha = [];

                        function a0(g) {
                            var p = ha.length;
                            return ha.push(g), p
                        }

                        function l0(g, p) {
                            for (var y = Array(g), w = 0; w < g; ++w) y[w] = Hn(Ie[p + 4 * w >> 2], "parameter " + w);
                            return y
                        }
                        var Pd = [],
                            gc = {},
                            Md = () => {
                                if (!_c) {
                                    var g = {
                                            USER: "web_user",
                                            LOGNAME: "web_user",
                                            PATH: "/",
                                            PWD: "/",
                                            HOME: "/home/web_user",
                                            LANG: (typeof navigator == "object" && navigator.languages && navigator.languages[0] || "C").replace("-", "_") + ".UTF-8",
                                            _: H || "./this.program"
                                        },
                                        p;
                                    for (p in gc) gc[p] === void 0 ? delete g[p] : g[p] = gc[p];
                                    var y = [];
                                    for (p in g) y.push(`${p}=${g[p]}`);
                                    _c = y
                                }
                                return _c
                            },
                            _c, c0 = [null, [],
                                []
                            ],
                            pa = g => g % 4 === 0 && (g % 100 !== 0 || g % 400 === 0),
                            Rd = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31],
                            Id = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

                        function u0(g) {
                            var p = Array(Ad(g) + 1);
                            return Ed(g, p, 0, p.length), p
                        }
                        var f0 = (g, p, y, w) => {
                            function M(D, ve, he) {
                                for (D = typeof D == "number" ? D.toString() : D || ""; D.length < ve;) D = he[0] + D;
                                return D
                            }

                            function N(D, ve) {
                                return M(D, ve, "0")
                            }

                            function Z(D, ve) {
                                function he(ot) {
                                    return 0 > ot ? -1 : 0 < ot ? 1 : 0
                                }
                                var ut;
                                return (ut = he(D.getFullYear() - ve.getFullYear())) === 0 && (ut = he(D.getMonth() - ve.getMonth())) === 0 && (ut = he(D.getDate() - ve.getDate())), ut
                            }

                            function G(D) {
                                switch (D.getDay()) {
                                    case 0:
                                        return new Date(D.getFullYear() - 1, 11, 29);
                                    case 1:
                                        return D;
                                    case 2:
                                        return new Date(D.getFullYear(), 0, 3);
                                    case 3:
                                        return new Date(D.getFullYear(), 0, 2);
                                    case 4:
                                        return new Date(D.getFullYear(), 0, 1);
                                    case 5:
                                        return new Date(D.getFullYear() - 1, 11, 31);
                                    case 6:
                                        return new Date(D.getFullYear() - 1, 11, 30)
                                }
                            }

                            function ee(D) {
                                var ve = D.J;
                                for (D = new Date(new Date(D.K + 1900, 0, 1).getTime()); 0 < ve;) {
                                    var he = D.getMonth(),
                                        ut = (pa(D.getFullYear()) ? Rd : Id)[he];
                                    if (ve > ut - D.getDate()) ve -= ut - D.getDate() + 1, D.setDate(1), 11 > he ? D.setMonth(he + 1) : (D.setMonth(0), D.setFullYear(D.getFullYear() + 1));
                                    else {
                                        D.setDate(D.getDate() + ve);
                                        break
                                    }
                                }
                                return he = new Date(D.getFullYear() + 1, 0, 4), ve = G(new Date(D.getFullYear(), 0, 4)), he = G(he), 0 >= Z(ve, D) ? 0 >= Z(he, D) ? D.getFullYear() + 1 : D.getFullYear() : D.getFullYear() - 1
                            }
                            var J = Fe[w + 40 >> 2];
                            w = {
                                qb: Fe[w >> 2],
                                pb: Fe[w + 4 >> 2],
                                Z: Fe[w + 8 >> 2],
                                ha: Fe[w + 12 >> 2],
                                $: Fe[w + 16 >> 2],
                                K: Fe[w + 20 >> 2],
                                C: Fe[w + 24 >> 2],
                                J: Fe[w + 28 >> 2],
                                ub: Fe[w + 32 >> 2],
                                ob: Fe[w + 36 >> 2],
                                rb: J && J ? fa(Oe, J) : ""
                            }, y = y ? fa(Oe, y) : "", J = {
                                "%c": "%a %b %d %H:%M:%S %Y",
                                "%D": "%m/%d/%y",
                                "%F": "%Y-%m-%d",
                                "%h": "%b",
                                "%r": "%I:%M:%S %p",
                                "%R": "%H:%M",
                                "%T": "%H:%M:%S",
                                "%x": "%m/%d/%y",
                                "%X": "%H:%M:%S",
                                "%Ec": "%c",
                                "%EC": "%C",
                                "%Ex": "%m/%d/%y",
                                "%EX": "%H:%M:%S",
                                "%Ey": "%y",
                                "%EY": "%Y",
                                "%Od": "%d",
                                "%Oe": "%e",
                                "%OH": "%H",
                                "%OI": "%I",
                                "%Om": "%m",
                                "%OM": "%M",
                                "%OS": "%S",
                                "%Ou": "%u",
                                "%OU": "%U",
                                "%OV": "%V",
                                "%Ow": "%w",
                                "%OW": "%W",
                                "%Oy": "%y"
                            };
                            for (var be in J) y = y.replace(new RegExp(be, "g"), J[be]);
                            var Te = "Sunday Monday Tuesday Wednesday Thursday Friday Saturday".split(" "),
                                $e = "January February March April May June July August September October November December".split(" ");
                            J = {
                                "%a": D => Te[D.C].substring(0, 3),
                                "%A": D => Te[D.C],
                                "%b": D => $e[D.$].substring(0, 3),
                                "%B": D => $e[D.$],
                                "%C": D => N((D.K + 1900) / 100 | 0, 2),
                                "%d": D => N(D.ha, 2),
                                "%e": D => M(D.ha, 2, " "),
                                "%g": D => ee(D).toString().substring(2),
                                "%G": D => ee(D),
                                "%H": D => N(D.Z, 2),
                                "%I": D => (D = D.Z, D == 0 ? D = 12 : 12 < D && (D -= 12), N(D, 2)),
                                "%j": D => {
                                    for (var ve = 0, he = 0; he <= D.$ - 1; ve += (pa(D.K + 1900) ? Rd : Id)[he++]);
                                    return N(D.ha + ve, 3)
                                },
                                "%m": D => N(D.$ + 1, 2),
                                "%M": D => N(D.pb, 2),
                                "%n": () => `
`,
                                "%p": D => 0 <= D.Z && 12 > D.Z ? "AM" : "PM",
                                "%S": D => N(D.qb, 2),
                                "%t": () => "	",
                                "%u": D => D.C || 7,
                                "%U": D => N(Math.floor((D.J + 7 - D.C) / 7), 2),
                                "%V": D => {
                                    var ve = Math.floor((D.J + 7 - (D.C + 6) % 7) / 7);
                                    if (2 >= (D.C + 371 - D.J - 2) % 7 && ve++, ve) ve == 53 && (he = (D.C + 371 - D.J) % 7, he == 4 || he == 3 && pa(D.K) || (ve = 1));
                                    else {
                                        ve = 52;
                                        var he = (D.C + 7 - D.J - 1) % 7;
                                        (he == 4 || he == 5 && pa(D.K % 400 - 1)) && ve++
                                    }
                                    return N(ve, 2)
                                },
                                "%w": D => D.C,
                                "%W": D => N(Math.floor((D.J + 7 - (D.C + 6) % 7) / 7), 2),
                                "%y": D => (D.K + 1900).toString().substring(2),
                                "%Y": D => D.K + 1900,
                                "%z": D => {
                                    D = D.ob;
                                    var ve = 0 <= D;
                                    return D = Math.abs(D) / 60, (ve ? "+" : "-") + ("0000" + (D / 60 * 100 + D % 60)).slice(-4)
                                },
                                "%Z": D => D.rb,
                                "%%": () => "%"
                            }, y = y.replace(/%%/g, "\0\0");
                            for (be in J) y.includes(be) && (y = y.replace(new RegExp(be, "g"), J[be](w)));
                            return y = y.replace(/\0\0/g, "%"), be = u0(y), be.length > p ? 0 : (ue.set(be, g), be.length - 1)
                        };
                        Object.assign(j.prototype, {
                            get(g) {
                                return this.G[g]
                            },
                            has(g) {
                                return this.G[g] !== void 0
                            },
                            Za(g) {
                                var p = this.ta.pop() || this.G.length;
                                return this.G[p] = g, p
                            },
                            $a(g) {
                                this.G[g] = void 0, this.ta.push(g)
                            }
                        }), oe = m.BindingError = class extends Error {
                            constructor(g) {
                                super(g), this.name = "BindingError"
                            }
                        }, q.G.push({
                            value: void 0
                        }, {
                            value: null
                        }, {
                            value: !0
                        }, {
                            value: !1
                        }), q.ua = q.G.length, m.count_emval_handles = function() {
                            for (var g = 0, p = q.ua; p < q.G.length; ++p) q.G[p] !== void 0 && ++g;
                            return g
                        }, st = m.PureVirtualError = Ge("PureVirtualError");
                        for (var $d = Array(256), ma = 0; 256 > ma; ++ma) $d[ma] = String.fromCharCode(ma);
                        Qe = $d, m.getInheritedInstanceCount = function() {
                            return Object.keys(Vt).length
                        }, m.getLiveInheritedInstances = function() {
                            var g = [],
                                p;
                            for (p in Vt) Vt.hasOwnProperty(p) && g.push(Vt[p]);
                            return g
                        }, m.flushPendingDeletes = De, m.setDelayFunction = function(g) {
                            Dt = g, xe.length && Dt && Dt(De)
                        }, bd = m.InternalError = class extends Error {
                            constructor(g) {
                                super(g), this.name = "InternalError"
                            }
                        }, Fr.prototype.isAliasOf = function(g) {
                            if (!(this instanceof Fr && g instanceof Fr)) return !1;
                            var p = this.g.j.h,
                                y = this.g.i,
                                w = g.g.j.h;
                            for (g = g.g.i; p.l;) y = p.S(y), p = p.l;
                            for (; w.l;) g = w.S(g), w = w.l;
                            return p === w && y === g
                        }, Fr.prototype.clone = function() {
                            if (this.g.i || fc(this), this.g.O) return this.g.count.value += 1, this;
                            var g = os,
                                p = Object,
                                y = p.create,
                                w = Object.getPrototypeOf(this),
                                M = this.g;
                            return g = g(y.call(p, w, {
                                g: {
                                    value: {
                                        count: M.count,
                                        M: M.M,
                                        O: M.O,
                                        i: M.i,
                                        j: M.j,
                                        s: M.s,
                                        A: M.A
                                    }
                                }
                            })), g.g.count.value += 1, g.g.M = !1, g
                        }, Fr.prototype.delete = function() {
                            this.g.i || fc(this), this.g.M && !this.g.O && ne("Object already scheduled for deletion"), Nr(this), _d(this.g), this.g.O || (this.g.s = void 0, this.g.i = void 0)
                        }, Fr.prototype.isDeleted = function() {
                            return !this.g.i
                        }, Fr.prototype.deleteLater = function() {
                            return this.g.i || fc(this), this.g.M && !this.g.O && ne("Object already scheduled for deletion"), xe.push(this), xe.length === 1 && Dt && Dt(De), this.g.M = !0, this
                        }, mr.prototype.Va = function(g) {
                            return this.za && (g = this.za(g)), g
                        }, mr.prototype.pa = function(g) {
                            this.H && this.H(g)
                        }, mr.prototype.argPackAdvance = 8, mr.prototype.readValueFromPointer = Ks, mr.prototype.deleteObject = function(g) {
                            g !== null && g.delete()
                        }, mr.prototype.fromWireType = function(g) {
                            function p() {
                                return this.V ? ra(this.h.B, {
                                    j: this.ib,
                                    i: y,
                                    A: this,
                                    s: g
                                }) : ra(this.h.B, {
                                    j: this,
                                    i: g
                                })
                            }
                            var y = this.Va(g);
                            if (!y) return this.pa(g), null;
                            var w = Wy(this.h, y);
                            if (w !== void 0) return w.g.count.value === 0 ? (w.g.i = y, w.g.s = g, w.clone()) : (w = w.clone(), this.pa(g), w);
                            if (w = this.h.Ua(y), w = yd[w], !w) return p.call(this);
                            w = this.U ? w.Ka : w.pointerType;
                            var M = vd(y, this.h, w.h);
                            return M === null ? p.call(this) : this.V ? ra(w.h.B, {
                                j: w,
                                i: M,
                                A: this,
                                s: g
                            }) : ra(w.h.B, {
                                j: w,
                                i: M
                            })
                        }, Td = m.UnboundTypeError = Ge("UnboundTypeError");
                        var kd = {
                            _embind_create_inheriting_constructor: function(g, p, y) {
                                g = ze(g), p = Hn(p, "wrapper"), y = de(y);
                                var w = [].slice,
                                    M = p.h,
                                    N = M.B,
                                    Z = M.l.B,
                                    G = M.l.constructor;
                                g = x(g, function() {
                                    M.l.ya.forEach((function(J) {
                                        if (this[J] === Z[J]) throw new st(`Pure virtual function ${J} must be implemented in JavaScript`)
                                    }).bind(this)), Object.defineProperty(this, "__parent", {
                                        value: N
                                    }), this.__construct.apply(this, w.call(arguments))
                                }), N.__construct = function() {
                                    this === N && ne("Pass correct 'this' to __construct");
                                    var J = G.implement.apply(void 0, [this].concat(w.call(arguments)));
                                    Nr(J);
                                    var be = J.g;
                                    J.notifyOnDestruction(), be.O = !0, Object.defineProperties(this, {
                                        g: {
                                            value: be
                                        }
                                    }), os(this), J = be.i, J = bt(M, J), Vt.hasOwnProperty(J) ? ne(`Tried to register registered instance: ${J}`) : Vt[J] = this
                                }, N.__destruct = function() {
                                    this === N && ne("Pass correct 'this' to __destruct"), Nr(this);
                                    var J = this.g.i;
                                    J = bt(M, J), Vt.hasOwnProperty(J) ? delete Vt[J] : ne(`Tried to unregister unregistered instance: ${J}`)
                                }, g.prototype = Object.create(N);
                                for (var ee in y) g.prototype[ee] = y[ee];
                                return Ae(g)
                            },
                            _embind_finalize_value_object: function(g) {
                                var p = ia[g];
                                delete ia[g];
                                var y = p.fa,
                                    w = p.H,
                                    M = p.sa,
                                    N = M.map(Z => Z.Ya).concat(M.map(Z => Z.lb));
                                En([g], N, Z => {
                                    var G = {};
                                    return M.forEach((ee, J) => {
                                        var be = Z[J],
                                            Te = ee.Wa,
                                            $e = ee.Xa,
                                            D = Z[J + M.length],
                                            ve = ee.kb,
                                            he = ee.mb;
                                        G[ee.Sa] = {
                                            read: ut => be.fromWireType(Te($e, ut)),
                                            write: (ut, ot) => {
                                                var Ce = [];
                                                ve(he, ut, D.toWireType(Ce, ot)), qs(Ce)
                                            }
                                        }
                                    }), [{
                                        name: p.name,
                                        fromWireType: function(ee) {
                                            var J = {},
                                                be;
                                            for (be in G) J[be] = G[be].read(ee);
                                            return w(ee), J
                                        },
                                        toWireType: function(ee, J) {
                                            for (var be in G)
                                                if (!(be in J)) throw new TypeError(`Missing field: "${be}"`);
                                            var Te = y();
                                            for (be in G) G[be].write(Te, J[be]);
                                            return ee !== null && ee.push(w, Te), Te
                                        },
                                        argPackAdvance: 8,
                                        readValueFromPointer: Ks,
                                        v: w
                                    }]
                                })
                            },
                            _embind_register_bigint: function() {},
                            _embind_register_bool: function(g, p, y, w, M) {
                                var N = oa(y);
                                p = ze(p), tr(g, {
                                    name: p,
                                    fromWireType: function(Z) {
                                        return !!Z
                                    },
                                    toWireType: function(Z, G) {
                                        return G ? w : M
                                    },
                                    argPackAdvance: 8,
                                    readValueFromPointer: function(Z) {
                                        if (y === 1) var G = ue;
                                        else if (y === 2) G = ke;
                                        else if (y === 4) G = Fe;
                                        else throw new TypeError("Unknown boolean type size: " + p);
                                        return this.fromWireType(G[Z >> N])
                                    },
                                    v: null
                                })
                            },
                            _embind_register_class: function(g, p, y, w, M, N, Z, G, ee, J, be, Te, $e) {
                                be = ze(be), N = ln(M, N), G && (G = ln(Z, G)), J && (J = ln(ee, J)), $e = ln(Te, $e);
                                var D = b(be);
                                hc(D, function() {
                                    gr(`Cannot construct ${be} due to unbound types`, [w])
                                }), En([g, p, y], w ? [w] : [], function(ve) {
                                    if (ve = ve[0], w) var he = ve.h,
                                        ut = he.B;
                                    else ut = Fr.prototype;
                                    ve = x(D, function() {
                                        if (Object.getPrototypeOf(this) !== ot) throw new oe("Use 'new' to construct " + be);
                                        if (Ce.I === void 0) throw new oe(be + " has no accessible constructor");
                                        var en = Ce.I[arguments.length];
                                        if (en === void 0) throw new oe(`Tried to invoke ctor of ${be} with invalid number of parameters (${arguments.length}) - expected (${Object.keys(Ce.I).toString()}) parameters instead!`);
                                        return en.apply(this, arguments)
                                    });
                                    var ot = Object.create(ut, {
                                        constructor: {
                                            value: ve
                                        }
                                    });
                                    ve.prototype = ot;
                                    var Ce = new qy(be, ve, ot, $e, he, N, G, J);
                                    Ce.l && (Ce.l.T === void 0 && (Ce.l.T = []), Ce.l.T.push(Ce)), he = new mr(be, Ce, !0, !1), ut = new mr(be + "*", Ce, !1, !1);
                                    var At = new mr(be + " const*", Ce, !1, !0);
                                    return yd[g] = {
                                        pointerType: ut,
                                        Ka: At
                                    }, wd(D, ve), [he, ut, At]
                                })
                            },
                            _embind_register_class_class_function: function(g, p, y, w, M, N, Z) {
                                var G = ua(y, w);
                                p = ze(p), N = ln(M, N), En([], [g], function(ee) {
                                    function J() {
                                        gr(`Cannot call ${be} due to unbound types`, G)
                                    }
                                    ee = ee[0];
                                    var be = `${ee.name}.${p}`;
                                    p.startsWith("@@") && (p = Symbol[p.substring(2)]);
                                    var Te = ee.h.constructor;
                                    return Te[p] === void 0 ? (J.L = y - 1, Te[p] = J) : (dc(Te, p, be), Te[p].m[y - 1] = J), En([], G, function($e) {
                                        if ($e = ca(be, [$e[0], null].concat($e.slice(1)), null, N, Z), Te[p].m === void 0 ? ($e.L = y - 1, Te[p] = $e) : Te[p].m[y - 1] = $e, ee.h.T)
                                            for (const D of ee.h.T) D.constructor.hasOwnProperty(p) || (D.constructor[p] = $e);
                                        return []
                                    }), []
                                })
                            },
                            _embind_register_class_class_property: function(g, p, y, w, M, N, Z, G) {
                                p = ze(p), N = ln(M, N), En([], [g], function(ee) {
                                    ee = ee[0];
                                    var J = `${ee.name}.${p}`,
                                        be = {
                                            get() {
                                                gr(`Cannot access ${J} due to unbound types`, [y])
                                            },
                                            enumerable: !0,
                                            configurable: !0
                                        };
                                    return be.set = G ? () => {
                                        gr(`Cannot access ${J} due to unbound types`, [y])
                                    } : () => {
                                        ne(`${J} is a read-only property`)
                                    }, Object.defineProperty(ee.h.constructor, p, be), En([], [y], function(Te) {
                                        Te = Te[0];
                                        var $e = {
                                            get() {
                                                return Te.fromWireType(N(w))
                                            },
                                            enumerable: !0
                                        };
                                        return G && (G = ln(Z, G), $e.set = D => {
                                            var ve = [];
                                            G(w, Te.toWireType(ve, D)), qs(ve)
                                        }), Object.defineProperty(ee.h.constructor, p, $e), []
                                    }), []
                                })
                            },
                            _embind_register_class_constructor: function(g, p, y, w, M, N) {
                                var Z = ua(p, y);
                                M = ln(w, M), En([], [g], function(G) {
                                    G = G[0];
                                    var ee = `constructor ${G.name}`;
                                    if (G.h.I === void 0 && (G.h.I = []), G.h.I[p - 1] !== void 0) throw new oe(`Cannot register multiple constructors with identical number of parameters (${p-1}) for class '${G.name}'! Overload resolution is currently only performed using the parameter count, not actual type info!`);
                                    return G.h.I[p - 1] = () => {
                                        gr(`Cannot construct ${G.name} due to unbound types`, Z)
                                    }, En([], Z, function(J) {
                                        return J.splice(1, 0, null), G.h.I[p - 1] = ca(ee, J, null, M, N), []
                                    }), []
                                })
                            },
                            _embind_register_class_function: function(g, p, y, w, M, N, Z, G) {
                                var ee = ua(y, w);
                                p = ze(p), N = ln(M, N), En([], [g], function(J) {
                                    function be() {
                                        gr(`Cannot call ${Te} due to unbound types`, ee)
                                    }
                                    J = J[0];
                                    var Te = `${J.name}.${p}`;
                                    p.startsWith("@@") && (p = Symbol[p.substring(2)]), G && J.h.ya.push(p);
                                    var $e = J.h.B,
                                        D = $e[p];
                                    return D === void 0 || D.m === void 0 && D.className !== J.name && D.L === y - 2 ? (be.L = y - 2, be.className = J.name, $e[p] = be) : (dc($e, p, Te), $e[p].m[y - 2] = be), En([], ee, function(ve) {
                                        return ve = ca(Te, ve, J, N, Z), $e[p].m === void 0 ? (ve.L = y - 2, $e[p] = ve) : $e[p].m[y - 2] = ve, []
                                    }), []
                                })
                            },
                            _embind_register_class_property: function(g, p, y, w, M, N, Z, G, ee, J) {
                                p = ze(p), M = ln(w, M), En([], [g], function(be) {
                                    be = be[0];
                                    var Te = `${be.name}.${p}`,
                                        $e = {
                                            get() {
                                                gr(`Cannot access ${Te} due to unbound types`, [y, Z])
                                            },
                                            enumerable: !0,
                                            configurable: !0
                                        };
                                    return $e.set = ee ? () => {
                                        gr(`Cannot access ${Te} due to unbound types`, [y, Z])
                                    } : () => {
                                        ne(Te + " is a read-only property")
                                    }, Object.defineProperty(be.h.B, p, $e), En([], ee ? [y, Z] : [y], function(D) {
                                        var ve = D[0],
                                            he = {
                                                get() {
                                                    var ot = Cd(this, be, Te + " getter");
                                                    return ve.fromWireType(M(N, ot))
                                                },
                                                enumerable: !0
                                            };
                                        if (ee) {
                                            ee = ln(G, ee);
                                            var ut = D[1];
                                            he.set = function(ot) {
                                                var Ce = Cd(this, be, Te + " setter"),
                                                    At = [];
                                                ee(J, Ce, ut.toWireType(At, ot)), qs(At)
                                            }
                                        }
                                        return Object.defineProperty(be.h.B, p, he), []
                                    }), []
                                })
                            },
                            _embind_register_emval: function(g, p) {
                                p = ze(p), tr(g, {
                                    name: p,
                                    fromWireType: function(y) {
                                        var w = de(y);
                                        return pc(y), w
                                    },
                                    toWireType: function(y, w) {
                                        return Ae(w)
                                    },
                                    argPackAdvance: 8,
                                    readValueFromPointer: Ks,
                                    v: null
                                })
                            },
                            _embind_register_enum: function(g, p, y, w) {
                                function M() {}
                                y = oa(y), p = ze(p), M.values = {}, tr(g, {
                                    name: p,
                                    constructor: M,
                                    fromWireType: function(N) {
                                        return this.constructor.values[N]
                                    },
                                    toWireType: function(N, Z) {
                                        return Z.value
                                    },
                                    argPackAdvance: 8,
                                    readValueFromPointer: Jy(p, y, w),
                                    v: null
                                }), hc(p, M)
                            },
                            _embind_register_enum_value: function(g, p, y) {
                                var w = Hn(g, "enum");
                                p = ze(p), g = w.constructor, w = Object.create(w.constructor.prototype, {
                                    value: {
                                        value: y
                                    },
                                    constructor: {
                                        value: x(`${w.name}_${p}`, function() {})
                                    }
                                }), g.values[y] = w, g[p] = w
                            },
                            _embind_register_float: function(g, p, y) {
                                y = oa(y), p = ze(p), tr(g, {
                                    name: p,
                                    fromWireType: function(w) {
                                        return w
                                    },
                                    toWireType: function(w, M) {
                                        return M
                                    },
                                    argPackAdvance: 8,
                                    readValueFromPointer: Zy(p, y),
                                    v: null
                                })
                            },
                            _embind_register_function: function(g, p, y, w, M, N) {
                                var Z = ua(p, y);
                                g = ze(g), M = ln(w, M), hc(g, function() {
                                    gr(`Cannot call ${g} due to unbound types`, Z)
                                }, p - 1), En([], Z, function(G) {
                                    return wd(g, ca(g, [G[0], null].concat(G.slice(1)), null, M, N), p - 1), []
                                })
                            },
                            _embind_register_integer: function(g, p, y, w, M) {
                                p = ze(p), M === -1 && (M = 4294967295), M = oa(y);
                                var N = G => G;
                                if (w === 0) {
                                    var Z = 32 - 8 * y;
                                    N = G => G << Z >>> Z
                                }
                                y = p.includes("unsigned") ? function(G, ee) {
                                    return ee >>> 0
                                } : function(G, ee) {
                                    return ee
                                }, tr(g, {
                                    name: p,
                                    fromWireType: N,
                                    toWireType: y,
                                    argPackAdvance: 8,
                                    readValueFromPointer: Qy(p, M, w !== 0),
                                    v: null
                                })
                            },
                            _embind_register_memory_view: function(g, p, y) {
                                function w(N) {
                                    N >>= 2;
                                    var Z = Ie;
                                    return new M(Z.buffer, Z[N + 1], Z[N])
                                }
                                var M = [Int8Array, Uint8Array, Int16Array, Uint16Array, Int32Array, Uint32Array, Float32Array, Float64Array][p];
                                y = ze(y), tr(g, {
                                    name: y,
                                    fromWireType: w,
                                    argPackAdvance: 8,
                                    readValueFromPointer: w
                                }, {
                                    ab: !0
                                })
                            },
                            _embind_register_std_string: function(g, p) {
                                p = ze(p);
                                var y = p === "std::string";
                                tr(g, {
                                    name: p,
                                    fromWireType: function(w) {
                                        var M = Ie[w >> 2],
                                            N = w + 4;
                                        if (y)
                                            for (var Z = N, G = 0; G <= M; ++G) {
                                                var ee = N + G;
                                                if (G == M || Oe[ee] == 0) {
                                                    if (Z = Z ? fa(Oe, Z, ee - Z) : "", J === void 0) var J = Z;
                                                    else J += String.fromCharCode(0), J += Z;
                                                    Z = ee + 1
                                                }
                                            } else {
                                                for (J = Array(M), G = 0; G < M; ++G) J[G] = String.fromCharCode(Oe[N + G]);
                                                J = J.join("")
                                            }
                                        return _r(w), J
                                    },
                                    toWireType: function(w, M) {
                                        M instanceof ArrayBuffer && (M = new Uint8Array(M));
                                        var N = typeof M == "string";
                                        N || M instanceof Uint8Array || M instanceof Uint8ClampedArray || M instanceof Int8Array || ne("Cannot pass non-string to std::string");
                                        var Z = y && N ? Ad(M) : M.length,
                                            G = vc(4 + Z + 1),
                                            ee = G + 4;
                                        if (Ie[G >> 2] = Z, y && N) Ed(M, Oe, ee, Z + 1);
                                        else if (N)
                                            for (N = 0; N < Z; ++N) {
                                                var J = M.charCodeAt(N);
                                                255 < J && (_r(ee), ne("String has UTF-16 code units that do not fit in 8 bits")), Oe[ee + N] = J
                                            } else
                                                for (N = 0; N < Z; ++N) Oe[ee + N] = M[N];
                                        return w !== null && w.push(_r, G), G
                                    },
                                    argPackAdvance: 8,
                                    readValueFromPointer: Ks,
                                    v: function(w) {
                                        _r(w)
                                    }
                                })
                            },
                            _embind_register_std_wstring: function(g, p, y) {
                                if (y = ze(y), p === 2) var w = e0,
                                    M = t0,
                                    N = n0,
                                    Z = () => Ze,
                                    G = 1;
                                else p === 4 && (w = r0, M = i0, N = s0, Z = () => Ie, G = 2);
                                tr(g, {
                                    name: y,
                                    fromWireType: function(ee) {
                                        for (var J = Ie[ee >> 2], be = Z(), Te, $e = ee + 4, D = 0; D <= J; ++D) {
                                            var ve = ee + 4 + D * p;
                                            (D == J || be[ve >> G] == 0) && ($e = w($e, ve - $e), Te === void 0 ? Te = $e : (Te += String.fromCharCode(0), Te += $e), $e = ve + p)
                                        }
                                        return _r(ee), Te
                                    },
                                    toWireType: function(ee, J) {
                                        typeof J != "string" && ne(`Cannot pass non-string to C++ string type ${y}`);
                                        var be = N(J),
                                            Te = vc(4 + be + p);
                                        return Ie[Te >> 2] = be >> G, M(J, Te + 4, be + p), ee !== null && ee.push(_r, Te), Te
                                    },
                                    argPackAdvance: 8,
                                    readValueFromPointer: Ks,
                                    v: function(ee) {
                                        _r(ee)
                                    }
                                })
                            },
                            _embind_register_value_object: function(g, p, y, w, M, N) {
                                ia[g] = {
                                    name: ze(p),
                                    fa: ln(y, w),
                                    H: ln(M, N),
                                    sa: []
                                }
                            },
                            _embind_register_value_object_field: function(g, p, y, w, M, N, Z, G, ee, J) {
                                ia[g].sa.push({
                                    Sa: ze(p),
                                    Ya: y,
                                    Wa: ln(w, M),
                                    Xa: N,
                                    lb: Z,
                                    kb: ln(G, ee),
                                    mb: J
                                })
                            },
                            _embind_register_void: function(g, p) {
                                p = ze(p), tr(g, {
                                    cb: !0,
                                    name: p,
                                    argPackAdvance: 0,
                                    fromWireType: function() {},
                                    toWireType: function() {}
                                })
                            },
                            _emscripten_get_now_is_monotonic: () => !0,
                            _emval_as: function(g, p, y) {
                                g = de(g), p = Hn(p, "emval::as");
                                var w = [],
                                    M = Ae(w);
                                return Ie[y >> 2] = M, p.toWireType(w, g)
                            },
                            _emval_call_method: function(g, p, y, w, M) {
                                g = ha[g], p = de(p), y = da(y);
                                var N = [];
                                return Ie[w >> 2] = Ae(N), g(p, y, N, M)
                            },
                            _emval_call_void_method: function(g, p, y, w) {
                                g = ha[g], p = de(p), y = da(y), g(p, y, null, w)
                            },
                            _emval_decref: pc,
                            _emval_get_method_caller: function(g, p) {
                                var y = l0(g, p),
                                    w = y[0];
                                p = w.name + "_$" + y.slice(1).map(function(Z) {
                                    return Z.name
                                }).join("_") + "$";
                                var M = Pd[p];
                                if (M !== void 0) return M;
                                var N = Array(g - 1);
                                return M = a0((Z, G, ee, J) => {
                                    for (var be = 0, Te = 0; Te < g - 1; ++Te) N[Te] = y[Te + 1].readValueFromPointer(J + be), be += y[Te + 1].argPackAdvance;
                                    for (Z = Z[G].apply(Z, N), Te = 0; Te < g - 1; ++Te) y[Te + 1].Na && y[Te + 1].Na(N[Te]);
                                    if (!w.cb) return w.toWireType(ee, Z)
                                }), Pd[p] = M
                            },
                            _emval_get_module_property: function(g) {
                                return g = da(g), Ae(m[g])
                            },
                            _emval_get_property: function(g, p) {
                                return g = de(g), p = de(p), Ae(g[p])
                            },
                            _emval_incref: function(g) {
                                4 < g && (q.get(g).Aa += 1)
                            },
                            _emval_new_array: function() {
                                return Ae([])
                            },
                            _emval_new_cstring: function(g) {
                                return Ae(da(g))
                            },
                            _emval_new_object: function() {
                                return Ae({})
                            },
                            _emval_run_destructors: function(g) {
                                var p = de(g);
                                qs(p), pc(g)
                            },
                            _emval_set_property: function(g, p, y) {
                                g = de(g), p = de(p), y = de(y), g[p] = y
                            },
                            _emval_take_value: function(g, p) {
                                return g = Hn(g, "_emval_take_value"), g = g.readValueFromPointer(p), Ae(g)
                            },
                            abort: () => {
                                U("")
                            },
                            emscripten_date_now: function() {
                                return Date.now()
                            },
                            emscripten_get_now: () => performance.now(),
                            emscripten_memcpy_big: (g, p, y) => Oe.copyWithin(g, p, p + y),
                            emscripten_resize_heap: g => {
                                var p = Oe.length;
                                if (g >>>= 0, 2147483648 < g) return !1;
                                for (var y = 1; 4 >= y; y *= 2) {
                                    var w = p * (1 + .2 / y);
                                    w = Math.min(w, g + 100663296);
                                    var M = Math;
                                    w = Math.max(g, w);
                                    e: {
                                        M = M.min.call(M, 2147483648, w + (65536 - w % 65536) % 65536) - X.buffer.byteLength + 65535 >>> 16;
                                        try {
                                            X.grow(M), W();
                                            var N = 1;
                                            break e
                                        } catch {}
                                        N = void 0
                                    }
                                    if (N) return !0
                                }
                                return !1
                            },
                            environ_get: (g, p) => {
                                var y = 0;
                                return Md().forEach(function(w, M) {
                                    var N = p + y;
                                    for (M = Ie[g + 4 * M >> 2] = N, N = 0; N < w.length; ++N) ue[M++ >> 0] = w.charCodeAt(N);
                                    ue[M >> 0] = 0, y += w.length + 1
                                }), 0
                            },
                            environ_sizes_get: (g, p) => {
                                var y = Md();
                                Ie[g >> 2] = y.length;
                                var w = 0;
                                return y.forEach(function(M) {
                                    w += M.length + 1
                                }), Ie[p >> 2] = w, 0
                            },
                            fd_close: () => 52,
                            fd_seek: function() {
                                return 70
                            },
                            fd_write: (g, p, y, w) => {
                                for (var M = 0, N = 0; N < y; N++) {
                                    var Z = Ie[p >> 2],
                                        G = Ie[p + 4 >> 2];
                                    p += 8;
                                    for (var ee = 0; ee < G; ee++) {
                                        var J = Oe[Z + ee],
                                            be = c0[g];
                                        J === 0 || J === 10 ? ((g === 1 ? te : ie)(fa(be, 0)), be.length = 0) : be.push(J)
                                    }
                                    M += G
                                }
                                return Ie[w >> 2] = M, 0
                            },
                            strftime_l: (g, p, y, w) => f0(g, p, y, w)
                        };
                        (function() {
                            function g(y) {
                                if (le = y = y.exports, X = le.memory, W(), ge = le.__indirect_function_table, ye.unshift(le.__wasm_call_ctors), S--, m.monitorRunDependencies && m.monitorRunDependencies(S), S == 0 && C) {
                                    var w = C;
                                    C = null, w()
                                }
                                return y
                            }
                            var p = {
                                env: kd,
                                wasi_snapshot_preview1: kd
                            };
                            if (S++, m.monitorRunDependencies && m.monitorRunDependencies(S), m.instantiateWasm) try {
                                return m.instantiateWasm(p, g)
                            } catch (y) {
                                ie("Module.instantiateWasm callback failed with error: " + y), R(y)
                            }
                            return c(p, function(y) {
                                g(y.instance)
                            }).catch(R), {}
                        })();
                        var _r = g => (_r = le.free)(g),
                            vc = g => (vc = le.malloc)(g),
                            Ld = g => (Ld = le.__getTypeName)(g);
                        m.__embind_initialize_bindings = () => (m.__embind_initialize_bindings = le._embind_initialize_bindings)(), m.dynCall_jiji = (g, p, y, w, M) => (m.dynCall_jiji = le.dynCall_jiji)(g, p, y, w, M), m.dynCall_viijii = (g, p, y, w, M, N, Z) => (m.dynCall_viijii = le.dynCall_viijii)(g, p, y, w, M, N, Z), m.dynCall_iiiiij = (g, p, y, w, M, N, Z) => (m.dynCall_iiiiij = le.dynCall_iiiiij)(g, p, y, w, M, N, Z), m.dynCall_iiiiijj = (g, p, y, w, M, N, Z, G, ee) => (m.dynCall_iiiiijj = le.dynCall_iiiiijj)(g, p, y, w, M, N, Z, G, ee), m.dynCall_iiiiiijj = (g, p, y, w, M, N, Z, G, ee, J) => (m.dynCall_iiiiiijj = le.dynCall_iiiiiijj)(g, p, y, w, M, N, Z, G, ee, J);
                        var ga;
                        C = function g() {
                            ga || Nd(), ga || (C = g)
                        };

                        function Nd() {
                            function g() {
                                if (!ga && (ga = !0, m.calledRun = !0, !ce)) {
                                    if (d(ye), T(m), m.onRuntimeInitialized && m.onRuntimeInitialized(), m.postRun)
                                        for (typeof m.postRun == "function" && (m.postRun = [m.postRun]); m.postRun.length;) {
                                            var p = m.postRun.shift();
                                            Me.unshift(p)
                                        }
                                    d(Me)
                                }
                            }
                            if (!(0 < S)) {
                                if (m.preRun)
                                    for (typeof m.preRun == "function" && (m.preRun = [m.preRun]); m.preRun.length;) Be();
                                d(fe), 0 < S || (m.setStatus ? (m.setStatus("Running..."), setTimeout(function() {
                                    setTimeout(function() {
                                        m.setStatus("")
                                    }, 1), g()
                                }, 1)) : g())
                            }
                        }
                        if (m.preInit)
                            for (typeof m.preInit == "function" && (m.preInit = [m.preInit]); 0 < m.preInit.length;) m.preInit.pop()();
                        return Nd(), _.ready
                    }
                })();
                const f = u
            }, o => {
                o.exports = JSON.parse(`{"name":"@rive-app/canvas-lite","version":"2.27.2","description":"A lite version of Rive's canvas based web api.","main":"rive.js","homepage":"https://rive.app","repository":{"type":"git","url":"https://github.com/rive-app/rive-wasm/tree/master/js"},"keywords":["rive","animation"],"author":"Rive","contributors":["Luigi Rosso <luigi@rive.app> (https://rive.app)","Maxwell Talbot <max@rive.app> (https://rive.app)","Arthur Vivian <arthur@rive.app> (https://rive.app)","Umberto Sonnino <umberto@rive.app> (https://rive.app)","Matthew Sullivan <matt.j.sullivan@gmail.com> (mailto:matt.j.sullivan@gmail.com)"],"license":"MIT","files":["rive.js","rive.js.map","rive.wasm","rive_fallback.wasm","rive.d.ts","rive_advanced.mjs.d.ts"],"typings":"rive.d.ts","dependencies":{},"browser":{"fs":false,"path":false}}`)
            }, (o, a, l) => {
                l.r(a), l.d(a, {
                    Animation: () => u.Animation
                });
                var u = l(4)
            }, (o, a, l) => {
                l.r(a), l.d(a, {
                    Animation: () => u
                });
                var u = function() {
                    function f(h, _, m, T) {
                        this.animation = h, this.artboard = _, this.playing = T, this.loopCount = 0, this.scrubTo = null, this.instance = new m.LinearAnimationInstance(h, _)
                    }
                    return Object.defineProperty(f.prototype, "name", {
                        get: function() {
                            return this.animation.name
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(f.prototype, "time", {
                        get: function() {
                            return this.instance.time
                        },
                        set: function(h) {
                            this.instance.time = h
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(f.prototype, "loopValue", {
                        get: function() {
                            return this.animation.loopValue
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(f.prototype, "needsScrub", {
                        get: function() {
                            return this.scrubTo !== null
                        },
                        enumerable: !1,
                        configurable: !0
                    }), f.prototype.advance = function(h) {
                        this.scrubTo === null ? this.instance.advance(h) : (this.instance.time = 0, this.instance.advance(this.scrubTo), this.scrubTo = null)
                    }, f.prototype.apply = function(h) {
                        this.instance.apply(h)
                    }, f.prototype.cleanup = function() {
                        this.instance.delete()
                    }, f
                }()
            }, (o, a, l) => {
                l.r(a), l.d(a, {
                    BLANK_URL: () => f.BLANK_URL,
                    registerTouchInteractions: () => u.registerTouchInteractions,
                    sanitizeUrl: () => f.sanitizeUrl
                });
                var u = l(6),
                    f = l(7)
            }, (o, a, l) => {
                l.r(a), l.d(a, {
                    registerTouchInteractions: () => h
                });
                var u = void 0,
                    f = function(_, m) {
                        var T, R;
                        return ["touchstart", "touchmove"].indexOf(_.type) > -1 && (!((T = _.touches) === null || T === void 0) && T.length) ? (m || _.preventDefault(), {
                            clientX: _.touches[0].clientX,
                            clientY: _.touches[0].clientY
                        }) : _.type === "touchend" && (!((R = _.changedTouches) === null || R === void 0) && R.length) ? {
                            clientX: _.changedTouches[0].clientX,
                            clientY: _.changedTouches[0].clientY
                        } : {
                            clientX: _.clientX,
                            clientY: _.clientY
                        }
                    },
                    h = function(_) {
                        var m = _.canvas,
                            T = _.artboard,
                            R = _.stateMachines,
                            B = R === void 0 ? [] : R,
                            I = _.renderer,
                            A = _.rive,
                            E = _.fit,
                            O = _.alignment,
                            P = _.isTouchScrollEnabled,
                            $ = P === void 0 ? !1 : P,
                            H = _.layoutScaleFactor,
                            F = H === void 0 ? 1 : H;
                        if (!m || !B.length || !I || !A || !T || typeof window > "u") return null;
                        var V = null,
                            k = !1,
                            Y = function(te) {
                                if (k && te instanceof MouseEvent) {
                                    te.type == "mouseup" && (k = !1);
                                    return
                                }
                                k = $ && te.type === "touchend" && V === "touchstart", V = te.type;
                                var ie = te.currentTarget.getBoundingClientRect(),
                                    _e = f(te, $),
                                    X = _e.clientX,
                                    le = _e.clientY;
                                if (!(!X && !le)) {
                                    var ce = X - ie.left,
                                        ue = le - ie.top,
                                        Oe = A.computeAlignment(E, O, {
                                            minX: 0,
                                            minY: 0,
                                            maxX: ie.width,
                                            maxY: ie.height
                                        }, T.bounds, F),
                                        ke = new A.Mat2D;
                                    Oe.invert(ke);
                                    var Ze = new A.Vec2D(ce, ue),
                                        Fe = A.mapXY(ke, Ze),
                                        Ie = Fe.x(),
                                        Le = Fe.y();
                                    switch (Fe.delete(), ke.delete(), Ze.delete(), Oe.delete(), te.type) {
                                        case "mouseout":
                                            for (var Ne = 0, W = B; Ne < W.length; Ne++) {
                                                var ge = W[Ne];
                                                ge.pointerMove(Ie, Le)
                                            }
                                            break;
                                        case "touchmove":
                                        case "mouseover":
                                        case "mousemove":
                                            {
                                                for (var fe = 0, ye = B; fe < ye.length; fe++) {
                                                    var ge = ye[fe];
                                                    ge.pointerMove(Ie, Le)
                                                }
                                                break
                                            }
                                        case "touchstart":
                                        case "mousedown":
                                            {
                                                for (var Me = 0, Be = B; Me < Be.length; Me++) {
                                                    var ge = Be[Me];
                                                    ge.pointerDown(Ie, Le)
                                                }
                                                break
                                            }
                                        case "touchend":
                                        case "mouseup":
                                            {
                                                for (var S = 0, C = B; S < C.length; S++) {
                                                    var ge = C[S];
                                                    ge.pointerUp(Ie, Le)
                                                }
                                                break
                                            }
                                    }
                                }
                            },
                            L = Y.bind(u);
                        return m.addEventListener("mouseover", L), m.addEventListener("mouseout", L), m.addEventListener("mousemove", L), m.addEventListener("mousedown", L), m.addEventListener("mouseup", L), m.addEventListener("touchmove", L, {
                                passive: $
                            }), m.addEventListener("touchstart", L, {
                                passive: $
                            }), m.addEventListener("touchend", L),
                            function() {
                                m.removeEventListener("mouseover", L), m.removeEventListener("mouseout", L), m.removeEventListener("mousemove", L), m.removeEventListener("mousedown", L), m.removeEventListener("mouseup", L), m.removeEventListener("touchmove", L), m.removeEventListener("touchstart", L), m.removeEventListener("touchend", L)
                            }
                    }
            }, (o, a, l) => {
                l.r(a), l.d(a, {
                    BLANK_URL: () => R,
                    sanitizeUrl: () => A
                });
                var u = /^([^\w]*)(javascript|data|vbscript)/im,
                    f = /&#(\w+)(^\w|;)?/g,
                    h = /&(newline|tab);/gi,
                    _ = /[\u0000-\u001F\u007F-\u009F\u2000-\u200D\uFEFF]/gim,
                    m = /^.+(:|&colon;)/gim,
                    T = [".", "/"],
                    R = "about:blank";

                function B(E) {
                    return T.indexOf(E[0]) > -1
                }

                function I(E) {
                    var O = E.replace(_, "");
                    return O.replace(f, function(P, $) {
                        return String.fromCharCode($)
                    })
                }

                function A(E) {
                    if (!E) return R;
                    var O = I(E).replace(h, "").replace(_, "").trim();
                    if (!O) return R;
                    if (B(O)) return O;
                    var P = O.match(m);
                    if (!P) return O;
                    var $ = P[0];
                    return u.test($) ? R : O
                }
            }],
            r = {};

        function i(o) {
            var a = r[o];
            if (a !== void 0) return a.exports;
            var l = r[o] = {
                exports: {}
            };
            return n[o](l, l.exports, i), l.exports
        }
        i.d = (o, a) => {
            for (var l in a) i.o(a, l) && !i.o(o, l) && Object.defineProperty(o, l, {
                enumerable: !0,
                get: a[l]
            })
        }, i.o = (o, a) => Object.prototype.hasOwnProperty.call(o, a), i.r = o => {
            typeof Symbol < "u" && Symbol.toStringTag && Object.defineProperty(o, Symbol.toStringTag, {
                value: "Module"
            }), Object.defineProperty(o, "__esModule", {
                value: !0
            })
        };
        var s = {};
        return (() => {
            i.r(s), i.d(s, {
                Alignment: () => A,
                DataEnum: () => Ie,
                EventType: () => k,
                Fit: () => I,
                Layout: () => E,
                LoopType: () => Y,
                Rive: () => Ze,
                RiveEventType: () => H,
                RiveFile: () => ke,
                RuntimeLoader: () => O,
                StateMachineInput: () => $,
                StateMachineInputType: () => P,
                Testing: () => z,
                ViewModel: () => Fe,
                ViewModelInstance: () => Ne,
                ViewModelInstanceBoolean: () => ye,
                ViewModelInstanceColor: () => C,
                ViewModelInstanceEnum: () => Be,
                ViewModelInstanceList: () => S,
                ViewModelInstanceNumber: () => fe,
                ViewModelInstanceString: () => ge,
                ViewModelInstanceTrigger: () => Me,
                ViewModelInstanceValue: () => W,
                decodeAudio: () => ae,
                decodeFont: () => re,
                decodeImage: () => me
            });
            var o = i(1),
                a = i(2),
                l = i(3),
                u = i(5),
                f = function() {
                    var v = function(c, d) {
                        return v = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(b, x) {
                            b.__proto__ = x
                        } || function(b, x) {
                            for (var j in x) Object.prototype.hasOwnProperty.call(x, j) && (b[j] = x[j])
                        }, v(c, d)
                    };
                    return function(c, d) {
                        if (typeof d != "function" && d !== null) throw new TypeError("Class extends value " + String(d) + " is not a constructor or null");
                        v(c, d);

                        function b() {
                            this.constructor = c
                        }
                        c.prototype = d === null ? Object.create(d) : (b.prototype = d.prototype, new b)
                    }
                }(),
                h = function() {
                    return h = Object.assign || function(v) {
                        for (var c, d = 1, b = arguments.length; d < b; d++) {
                            c = arguments[d];
                            for (var x in c) Object.prototype.hasOwnProperty.call(c, x) && (v[x] = c[x])
                        }
                        return v
                    }, h.apply(this, arguments)
                },
                _ = function(v, c, d, b) {
                    function x(j) {
                        return j instanceof d ? j : new d(function(q) {
                            q(j)
                        })
                    }
                    return new(d || (d = Promise))(function(j, q) {
                        function oe(Ae) {
                            try {
                                de(b.next(Ae))
                            } catch (Ge) {
                                q(Ge)
                            }
                        }

                        function ne(Ae) {
                            try {
                                de(b.throw(Ae))
                            } catch (Ge) {
                                q(Ge)
                            }
                        }

                        function de(Ae) {
                            Ae.done ? j(Ae.value) : x(Ae.value).then(oe, ne)
                        }
                        de((b = b.apply(v, c || [])).next())
                    })
                },
                m = function(v, c) {
                    var d = {
                            label: 0,
                            sent: function() {
                                if (j[0] & 1) throw j[1];
                                return j[1]
                            },
                            trys: [],
                            ops: []
                        },
                        b, x, j, q = Object.create((typeof Iterator == "function" ? Iterator : Object).prototype);
                    return q.next = oe(0), q.throw = oe(1), q.return = oe(2), typeof Symbol == "function" && (q[Symbol.iterator] = function() {
                        return this
                    }), q;

                    function oe(de) {
                        return function(Ae) {
                            return ne([de, Ae])
                        }
                    }

                    function ne(de) {
                        if (b) throw new TypeError("Generator is already executing.");
                        for (; q && (q = 0, de[0] && (d = 0)), d;) try {
                            if (b = 1, x && (j = de[0] & 2 ? x.return : de[0] ? x.throw || ((j = x.return) && j.call(x), 0) : x.next) && !(j = j.call(x, de[1])).done) return j;
                            switch (x = 0, j && (de = [de[0] & 2, j.value]), de[0]) {
                                case 0:
                                case 1:
                                    j = de;
                                    break;
                                case 4:
                                    return d.label++, {
                                        value: de[1],
                                        done: !1
                                    };
                                case 5:
                                    d.label++, x = de[1], de = [0];
                                    continue;
                                case 7:
                                    de = d.ops.pop(), d.trys.pop();
                                    continue;
                                default:
                                    if (j = d.trys, !(j = j.length > 0 && j[j.length - 1]) && (de[0] === 6 || de[0] === 2)) {
                                        d = 0;
                                        continue
                                    }
                                    if (de[0] === 3 && (!j || de[1] > j[0] && de[1] < j[3])) {
                                        d.label = de[1];
                                        break
                                    }
                                    if (de[0] === 6 && d.label < j[1]) {
                                        d.label = j[1], j = de;
                                        break
                                    }
                                    if (j && d.label < j[2]) {
                                        d.label = j[2], d.ops.push(de);
                                        break
                                    }
                                    j[2] && d.ops.pop(), d.trys.pop();
                                    continue
                            }
                            de = c.call(v, d)
                        } catch (Ae) {
                            de = [6, Ae], x = 0
                        } finally {
                            b = j = 0
                        }
                        if (de[0] & 5) throw de[1];
                        return {
                            value: de[0] ? de[1] : void 0,
                            done: !0
                        }
                    }
                },
                T = function(v, c, d) {
                    if (d || arguments.length === 2)
                        for (var b = 0, x = c.length, j; b < x; b++)(j || !(b in c)) && (j || (j = Array.prototype.slice.call(c, 0, b)), j[b] = c[b]);
                    return v.concat(j || Array.prototype.slice.call(c))
                },
                R = function(v) {
                    f(c, v);

                    function c() {
                        var d = v !== null && v.apply(this, arguments) || this;
                        return d.isHandledError = !0, d
                    }
                    return c
                }(Error),
                B = function(v) {
                    return v && v.isHandledError ? v.message : "Problem loading file; may be corrupt!"
                },
                I;
            (function(v) {
                v.Cover = "cover", v.Contain = "contain", v.Fill = "fill", v.FitWidth = "fitWidth", v.FitHeight = "fitHeight", v.None = "none", v.ScaleDown = "scaleDown", v.Layout = "layout"
            })(I || (I = {}));
            var A;
            (function(v) {
                v.Center = "center", v.TopLeft = "topLeft", v.TopCenter = "topCenter", v.TopRight = "topRight", v.CenterLeft = "centerLeft", v.CenterRight = "centerRight", v.BottomLeft = "bottomLeft", v.BottomCenter = "bottomCenter", v.BottomRight = "bottomRight"
            })(A || (A = {}));
            var E = function() {
                    function v(c) {
                        var d, b, x, j, q, oe, ne;
                        this.fit = (d = c == null ? void 0 : c.fit) !== null && d !== void 0 ? d : I.Contain, this.alignment = (b = c == null ? void 0 : c.alignment) !== null && b !== void 0 ? b : A.Center, this.layoutScaleFactor = (x = c == null ? void 0 : c.layoutScaleFactor) !== null && x !== void 0 ? x : 1, this.minX = (j = c == null ? void 0 : c.minX) !== null && j !== void 0 ? j : 0, this.minY = (q = c == null ? void 0 : c.minY) !== null && q !== void 0 ? q : 0, this.maxX = (oe = c == null ? void 0 : c.maxX) !== null && oe !== void 0 ? oe : 0, this.maxY = (ne = c == null ? void 0 : c.maxY) !== null && ne !== void 0 ? ne : 0
                    }
                    return v.new = function(c) {
                        var d = c.fit,
                            b = c.alignment,
                            x = c.minX,
                            j = c.minY,
                            q = c.maxX,
                            oe = c.maxY;
                        return console.warn("This function is deprecated: please use `new Layout({})` instead"), new v({
                            fit: d,
                            alignment: b,
                            minX: x,
                            minY: j,
                            maxX: q,
                            maxY: oe
                        })
                    }, v.prototype.copyWith = function(c) {
                        var d = c.fit,
                            b = c.alignment,
                            x = c.layoutScaleFactor,
                            j = c.minX,
                            q = c.minY,
                            oe = c.maxX,
                            ne = c.maxY;
                        return new v({
                            fit: d ? ? this.fit,
                            alignment: b ? ? this.alignment,
                            layoutScaleFactor: x ? ? this.layoutScaleFactor,
                            minX: j ? ? this.minX,
                            minY: q ? ? this.minY,
                            maxX: oe ? ? this.maxX,
                            maxY: ne ? ? this.maxY
                        })
                    }, v.prototype.runtimeFit = function(c) {
                        if (this.cachedRuntimeFit) return this.cachedRuntimeFit;
                        var d;
                        return this.fit === I.Cover ? d = c.Fit.cover : this.fit === I.Contain ? d = c.Fit.contain : this.fit === I.Fill ? d = c.Fit.fill : this.fit === I.FitWidth ? d = c.Fit.fitWidth : this.fit === I.FitHeight ? d = c.Fit.fitHeight : this.fit === I.ScaleDown ? d = c.Fit.scaleDown : this.fit === I.Layout ? d = c.Fit.layout : d = c.Fit.none, this.cachedRuntimeFit = d, d
                    }, v.prototype.runtimeAlignment = function(c) {
                        if (this.cachedRuntimeAlignment) return this.cachedRuntimeAlignment;
                        var d;
                        return this.alignment === A.TopLeft ? d = c.Alignment.topLeft : this.alignment === A.TopCenter ? d = c.Alignment.topCenter : this.alignment === A.TopRight ? d = c.Alignment.topRight : this.alignment === A.CenterLeft ? d = c.Alignment.centerLeft : this.alignment === A.CenterRight ? d = c.Alignment.centerRight : this.alignment === A.BottomLeft ? d = c.Alignment.bottomLeft : this.alignment === A.BottomCenter ? d = c.Alignment.bottomCenter : this.alignment === A.BottomRight ? d = c.Alignment.bottomRight : d = c.Alignment.center, this.cachedRuntimeAlignment = d, d
                    }, v
                }(),
                O = function() {
                    function v() {}
                    return v.loadRuntime = function() {
                        o.default({
                            locateFile: function() {
                                return v.wasmURL
                            }
                        }).then(function(c) {
                            var d;
                            for (v.runtime = c; v.callBackQueue.length > 0;)(d = v.callBackQueue.shift()) === null || d === void 0 || d(v.runtime)
                        }).catch(function(c) {
                            var d = {
                                message: (c == null ? void 0 : c.message) || "Unknown error",
                                type: (c == null ? void 0 : c.name) || "Error",
                                wasmError: c instanceof WebAssembly.CompileError || c instanceof WebAssembly.RuntimeError,
                                originalError: c
                            };
                            console.debug("Rive WASM load error details:", d);
                            var b = "https://cdn.jsdelivr.net/npm/".concat(a.name, "@").concat(a.version, "/rive_fallback.wasm");
                            if (v.wasmURL.toLowerCase() !== b) console.warn("Failed to load WASM from ".concat(v.wasmURL, " (").concat(d.message, "), trying jsdelivr as a backup")), v.setWasmUrl(b), v.loadRuntime();
                            else {
                                var x = ["Could not load Rive WASM file from ".concat(v.wasmURL, " or ").concat(b, "."), "Possible reasons:", "- Network connection is down", "- WebAssembly is not supported in this environment", "- The WASM file is corrupted or incompatible", `
Error details:`, "- Type: ".concat(d.type), "- Message: ".concat(d.message), "- WebAssembly-specific error: ".concat(d.wasmError), `
To resolve, you may need to:`, "1. Check your network connection", "2. Set a new WASM source via RuntimeLoader.setWasmUrl()", "3. Call RuntimeLoader.loadRuntime() again"].join(`
`);
                                console.error(x)
                            }
                        })
                    }, v.getInstance = function(c) {
                        v.isLoading || (v.isLoading = !0, v.loadRuntime()), v.runtime ? c(v.runtime) : v.callBackQueue.push(c)
                    }, v.awaitInstance = function() {
                        return new Promise(function(c) {
                            return v.getInstance(function(d) {
                                return c(d)
                            })
                        })
                    }, v.setWasmUrl = function(c) {
                        v.wasmURL = c
                    }, v.getWasmUrl = function() {
                        return v.wasmURL
                    }, v.isLoading = !1, v.callBackQueue = [], v.wasmURL = "https://unpkg.com/".concat(a.name, "@").concat(a.version, "/rive.wasm"), v
                }(),
                P;
            (function(v) {
                v[v.Number = 56] = "Number", v[v.Trigger = 58] = "Trigger", v[v.Boolean = 59] = "Boolean"
            })(P || (P = {}));
            var $ = function() {
                    function v(c, d) {
                        this.type = c, this.runtimeInput = d
                    }
                    return Object.defineProperty(v.prototype, "name", {
                        get: function() {
                            return this.runtimeInput.name
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(v.prototype, "value", {
                        get: function() {
                            return this.runtimeInput.value
                        },
                        set: function(c) {
                            this.runtimeInput.value = c
                        },
                        enumerable: !1,
                        configurable: !0
                    }), v.prototype.fire = function() {
                        this.type === P.Trigger && this.runtimeInput.fire()
                    }, v.prototype.delete = function() {
                        this.runtimeInput = null
                    }, v
                }(),
                H;
            (function(v) {
                v[v.General = 128] = "General", v[v.OpenUrl = 131] = "OpenUrl"
            })(H || (H = {}));
            var F = function() {
                    function v(c, d, b, x) {
                        this.stateMachine = c, this.playing = b, this.artboard = x, this.inputs = [], this.instance = new d.StateMachineInstance(c, x), this.initInputs(d)
                    }
                    return Object.defineProperty(v.prototype, "name", {
                        get: function() {
                            return this.stateMachine.name
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(v.prototype, "statesChanged", {
                        get: function() {
                            for (var c = [], d = 0; d < this.instance.stateChangedCount(); d++) c.push(this.instance.stateChangedNameByIndex(d));
                            return c
                        },
                        enumerable: !1,
                        configurable: !0
                    }), v.prototype.advance = function(c) {
                        this.instance.advance(c)
                    }, v.prototype.advanceAndApply = function(c) {
                        this.instance.advanceAndApply(c)
                    }, v.prototype.reportedEventCount = function() {
                        return this.instance.reportedEventCount()
                    }, v.prototype.reportedEventAt = function(c) {
                        return this.instance.reportedEventAt(c)
                    }, v.prototype.initInputs = function(c) {
                        for (var d = 0; d < this.instance.inputCount(); d++) {
                            var b = this.instance.input(d);
                            this.inputs.push(this.mapRuntimeInput(b, c))
                        }
                    }, v.prototype.mapRuntimeInput = function(c, d) {
                        if (c.type === d.SMIInput.bool) return new $(P.Boolean, c.asBool());
                        if (c.type === d.SMIInput.number) return new $(P.Number, c.asNumber());
                        if (c.type === d.SMIInput.trigger) return new $(P.Trigger, c.asTrigger())
                    }, v.prototype.cleanup = function() {
                        this.inputs.forEach(function(c) {
                            c.delete()
                        }), this.inputs.length = 0, this.instance.delete()
                    }, v.prototype.bindViewModelInstance = function(c) {
                        c.runtimeInstance != null && this.instance.bindViewModelInstance(c.runtimeInstance)
                    }, v
                }(),
                V = function() {
                    function v(c, d, b, x, j) {
                        x === void 0 && (x = []), j === void 0 && (j = []), this.runtime = c, this.artboard = d, this.eventManager = b, this.animations = x, this.stateMachines = j
                    }
                    return v.prototype.add = function(c, d, b) {
                        if (b === void 0 && (b = !0), c = K(c), c.length === 0) this.animations.forEach(function(Qe) {
                            return Qe.playing = d
                        }), this.stateMachines.forEach(function(Qe) {
                            return Qe.playing = d
                        });
                        else
                            for (var x = this.animations.map(function(Qe) {
                                    return Qe.name
                                }), j = this.stateMachines.map(function(Qe) {
                                    return Qe.name
                                }), q = 0; q < c.length; q++) {
                                var oe = x.indexOf(c[q]),
                                    ne = j.indexOf(c[q]);
                                if (oe >= 0 || ne >= 0) oe >= 0 ? this.animations[oe].playing = d : this.stateMachines[ne].playing = d;
                                else {
                                    var de = this.artboard.animationByName(c[q]);
                                    if (de) {
                                        var Ae = new l.Animation(de, this.artboard, this.runtime, d);
                                        Ae.advance(0), Ae.apply(1), this.animations.push(Ae)
                                    } else {
                                        var Ge = this.artboard.stateMachineByName(c[q]);
                                        if (Ge) {
                                            var st = new F(Ge, this.runtime, d, this.artboard);
                                            this.stateMachines.push(st)
                                        }
                                    }
                                }
                            }
                        return b && (d ? this.eventManager.fire({
                            type: k.Play,
                            data: this.playing
                        }) : this.eventManager.fire({
                            type: k.Pause,
                            data: this.paused
                        })), d ? this.playing : this.paused
                    }, v.prototype.initLinearAnimations = function(c, d) {
                        for (var b = this.animations.map(function(ne) {
                                return ne.name
                            }), x = 0; x < c.length; x++) {
                            var j = b.indexOf(c[x]);
                            if (j >= 0) this.animations[j].playing = d;
                            else {
                                var q = this.artboard.animationByName(c[x]);
                                if (q) {
                                    var oe = new l.Animation(q, this.artboard, this.runtime, d);
                                    oe.advance(0), oe.apply(1), this.animations.push(oe)
                                } else console.error("Animation with name ".concat(c[x], " not found."))
                            }
                        }
                    }, v.prototype.initStateMachines = function(c, d) {
                        for (var b = this.stateMachines.map(function(ne) {
                                return ne.name
                            }), x = 0; x < c.length; x++) {
                            var j = b.indexOf(c[x]);
                            if (j >= 0) this.stateMachines[j].playing = d;
                            else {
                                var q = this.artboard.stateMachineByName(c[x]);
                                if (q) {
                                    var oe = new F(q, this.runtime, d, this.artboard);
                                    this.stateMachines.push(oe), d || oe.advanceAndApply(0)
                                } else console.warn("State Machine with name ".concat(c[x], " not found.")), this.initLinearAnimations([c[x]], d)
                            }
                        }
                    }, v.prototype.play = function(c) {
                        return this.add(c, !0)
                    }, v.prototype.pause = function(c) {
                        return this.add(c, !1)
                    }, v.prototype.scrub = function(c, d) {
                        var b = this.animations.filter(function(x) {
                            return c.includes(x.name)
                        });
                        return b.forEach(function(x) {
                            return x.scrubTo = d
                        }), b.map(function(x) {
                            return x.name
                        })
                    }, Object.defineProperty(v.prototype, "playing", {
                        get: function() {
                            return this.animations.filter(function(c) {
                                return c.playing
                            }).map(function(c) {
                                return c.name
                            }).concat(this.stateMachines.filter(function(c) {
                                return c.playing
                            }).map(function(c) {
                                return c.name
                            }))
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(v.prototype, "paused", {
                        get: function() {
                            return this.animations.filter(function(c) {
                                return !c.playing
                            }).map(function(c) {
                                return c.name
                            }).concat(this.stateMachines.filter(function(c) {
                                return !c.playing
                            }).map(function(c) {
                                return c.name
                            }))
                        },
                        enumerable: !1,
                        configurable: !0
                    }), v.prototype.stop = function(c) {
                        var d = this;
                        c = K(c);
                        var b = [];
                        if (c.length === 0) b = this.animations.map(function(q) {
                            return q.name
                        }).concat(this.stateMachines.map(function(q) {
                            return q.name
                        })), this.animations.forEach(function(q) {
                            return q.cleanup()
                        }), this.stateMachines.forEach(function(q) {
                            return q.cleanup()
                        }), this.animations.splice(0, this.animations.length), this.stateMachines.splice(0, this.stateMachines.length);
                        else {
                            var x = this.animations.filter(function(q) {
                                return c.includes(q.name)
                            });
                            x.forEach(function(q) {
                                q.cleanup(), d.animations.splice(d.animations.indexOf(q), 1)
                            });
                            var j = this.stateMachines.filter(function(q) {
                                return c.includes(q.name)
                            });
                            j.forEach(function(q) {
                                q.cleanup(), d.stateMachines.splice(d.stateMachines.indexOf(q), 1)
                            }), b = x.map(function(q) {
                                return q.name
                            }).concat(j.map(function(q) {
                                return q.name
                            }))
                        }
                        return this.eventManager.fire({
                            type: k.Stop,
                            data: b
                        }), b
                    }, Object.defineProperty(v.prototype, "isPlaying", {
                        get: function() {
                            return this.animations.reduce(function(c, d) {
                                return c || d.playing
                            }, !1) || this.stateMachines.reduce(function(c, d) {
                                return c || d.playing
                            }, !1)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(v.prototype, "isPaused", {
                        get: function() {
                            return !this.isPlaying && (this.animations.length > 0 || this.stateMachines.length > 0)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(v.prototype, "isStopped", {
                        get: function() {
                            return this.animations.length === 0 && this.stateMachines.length === 0
                        },
                        enumerable: !1,
                        configurable: !0
                    }), v.prototype.atLeastOne = function(c, d) {
                        d === void 0 && (d = !0);
                        var b;
                        return this.animations.length === 0 && this.stateMachines.length === 0 && (this.artboard.animationCount() > 0 ? this.add([b = this.artboard.animationByIndex(0).name], c, d) : this.artboard.stateMachineCount() > 0 && this.add([b = this.artboard.stateMachineByIndex(0).name], c, d)), b
                    }, v.prototype.handleLooping = function() {
                        for (var c = 0, d = this.animations.filter(function(x) {
                                return x.playing
                            }); c < d.length; c++) {
                            var b = d[c];
                            b.loopValue === 0 && b.loopCount ? (b.loopCount = 0, this.stop(b.name)) : b.loopValue === 1 && b.loopCount ? (this.eventManager.fire({
                                type: k.Loop,
                                data: {
                                    animation: b.name,
                                    type: Y.Loop
                                }
                            }), b.loopCount = 0) : b.loopValue === 2 && b.loopCount > 1 && (this.eventManager.fire({
                                type: k.Loop,
                                data: {
                                    animation: b.name,
                                    type: Y.PingPong
                                }
                            }), b.loopCount = 0)
                        }
                    }, v.prototype.handleStateChanges = function() {
                        for (var c = [], d = 0, b = this.stateMachines.filter(function(j) {
                                return j.playing
                            }); d < b.length; d++) {
                            var x = b[d];
                            c.push.apply(c, x.statesChanged)
                        }
                        c.length > 0 && this.eventManager.fire({
                            type: k.StateChange,
                            data: c
                        })
                    }, v.prototype.handleAdvancing = function(c) {
                        this.eventManager.fire({
                            type: k.Advance,
                            data: c
                        })
                    }, v
                }(),
                k;
            (function(v) {
                v.Load = "load", v.LoadError = "loaderror", v.Play = "play", v.Pause = "pause", v.Stop = "stop", v.Loop = "loop", v.Draw = "draw", v.Advance = "advance", v.StateChange = "statechange", v.RiveEvent = "riveevent", v.AudioStatusChange = "audiostatuschange"
            })(k || (k = {}));
            var Y;
            (function(v) {
                v.OneShot = "oneshot", v.Loop = "loop", v.PingPong = "pingpong"
            })(Y || (Y = {}));
            var L = function() {
                    function v(c) {
                        c === void 0 && (c = []), this.listeners = c
                    }
                    return v.prototype.getListeners = function(c) {
                        return this.listeners.filter(function(d) {
                            return d.type === c
                        })
                    }, v.prototype.add = function(c) {
                        this.listeners.includes(c) || this.listeners.push(c)
                    }, v.prototype.remove = function(c) {
                        for (var d = 0; d < this.listeners.length; d++) {
                            var b = this.listeners[d];
                            if (b.type === c.type && b.callback === c.callback) {
                                this.listeners.splice(d, 1);
                                break
                            }
                        }
                    }, v.prototype.removeAll = function(c) {
                        var d = this;
                        c ? this.listeners.filter(function(b) {
                            return b.type === c
                        }).forEach(function(b) {
                            return d.remove(b)
                        }) : this.listeners.splice(0, this.listeners.length)
                    }, v.prototype.fire = function(c) {
                        var d = this.getListeners(c.type);
                        d.forEach(function(b) {
                            return b.callback(c)
                        })
                    }, v
                }(),
                te = function() {
                    function v(c) {
                        this.eventManager = c, this.queue = []
                    }
                    return v.prototype.add = function(c) {
                        this.queue.push(c)
                    }, v.prototype.process = function() {
                        for (; this.queue.length > 0;) {
                            var c = this.queue.shift();
                            c != null && c.action && c.action(), c != null && c.event && this.eventManager.fire(c.event)
                        }
                    }, v
                }(),
                ie;
            (function(v) {
                v[v.AVAILABLE = 0] = "AVAILABLE", v[v.UNAVAILABLE = 1] = "UNAVAILABLE"
            })(ie || (ie = {}));
            var _e = function(v) {
                    f(c, v);

                    function c() {
                        var d = v !== null && v.apply(this, arguments) || this;
                        return d._started = !1, d._enabled = !1, d._status = ie.UNAVAILABLE, d
                    }
                    return c.prototype.delay = function(d) {
                        return _(this, void 0, void 0, function() {
                            return m(this, function(b) {
                                return [2, new Promise(function(x) {
                                    return setTimeout(x, d)
                                })]
                            })
                        })
                    }, c.prototype.timeout = function() {
                        return _(this, void 0, void 0, function() {
                            return m(this, function(d) {
                                return [2, new Promise(function(b, x) {
                                    return setTimeout(x, 50)
                                })]
                            })
                        })
                    }, c.prototype.reportToListeners = function() {
                        this.fire({
                            type: k.AudioStatusChange
                        }), this.removeAll()
                    }, c.prototype.enableAudio = function() {
                        return _(this, void 0, void 0, function() {
                            return m(this, function(d) {
                                return this._enabled || (this._enabled = !0, this._status = ie.AVAILABLE, this.reportToListeners()), [2]
                            })
                        })
                    }, c.prototype.testAudio = function() {
                        return _(this, void 0, void 0, function() {
                            return m(this, function(d) {
                                switch (d.label) {
                                    case 0:
                                        if (!(this._status === ie.UNAVAILABLE && this._audioContext !== null)) return [3, 4];
                                        d.label = 1;
                                    case 1:
                                        return d.trys.push([1, 3, , 4]), [4, Promise.race([this._audioContext.resume(), this.timeout()])];
                                    case 2:
                                        return d.sent(), this.enableAudio(), [3, 4];
                                    case 3:
                                        return d.sent(), [3, 4];
                                    case 4:
                                        return [2]
                                }
                            })
                        })
                    }, c.prototype._establishAudio = function() {
                        return _(this, void 0, void 0, function() {
                            return m(this, function(d) {
                                switch (d.label) {
                                    case 0:
                                        return this._started ? [3, 5] : (this._started = !0, typeof window > "u" ? (this.enableAudio(), [3, 5]) : [3, 1]);
                                    case 1:
                                        this._audioContext = new AudioContext, this.listenForUserAction(), d.label = 2;
                                    case 2:
                                        return this._status !== ie.UNAVAILABLE ? [3, 5] : [4, this.testAudio()];
                                    case 3:
                                        return d.sent(), [4, this.delay(1e3)];
                                    case 4:
                                        return d.sent(), [3, 2];
                                    case 5:
                                        return [2]
                                }
                            })
                        })
                    }, c.prototype.listenForUserAction = function() {
                        var d = this,
                            b = function() {
                                return _(d, void 0, void 0, function() {
                                    return m(this, function(x) {
                                        return this.enableAudio(), [2]
                                    })
                                })
                            };
                        document.addEventListener("pointerdown", b, {
                            once: !0
                        })
                    }, c.prototype.establishAudio = function() {
                        return _(this, void 0, void 0, function() {
                            return m(this, function(d) {
                                return this._establishAudio(), [2]
                            })
                        })
                    }, Object.defineProperty(c.prototype, "systemVolume", {
                        get: function() {
                            return this._status === ie.UNAVAILABLE ? (this.testAudio(), 0) : 1
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(c.prototype, "status", {
                        get: function() {
                            return this._status
                        },
                        enumerable: !1,
                        configurable: !0
                    }), c
                }(L),
                X = new _e,
                le = function() {
                    function v() {}
                    return v.prototype.observe = function() {}, v.prototype.unobserve = function() {}, v.prototype.disconnect = function() {}, v
                }(),
                ce = globalThis.ResizeObserver || le,
                ue = function() {
                    function v() {
                        var c = this;
                        this._elementsMap = new Map, this._onObservedEntry = function(d) {
                            var b = c._elementsMap.get(d.target);
                            b !== null ? b.onResize(d.target.clientWidth == 0 || d.target.clientHeight == 0) : c._resizeObserver.unobserve(d.target)
                        }, this._onObserved = function(d) {
                            d.forEach(c._onObservedEntry)
                        }, this._resizeObserver = new ce(this._onObserved)
                    }
                    return v.prototype.add = function(c, d) {
                        var b = {
                            onResize: d,
                            element: c
                        };
                        return this._elementsMap.set(c, b), this._resizeObserver.observe(c), b
                    }, v.prototype.remove = function(c) {
                        this._resizeObserver.unobserve(c.element), this._elementsMap.delete(c.element)
                    }, v
                }(),
                Oe = new ue,
                ke = function() {
                    function v(c) {
                        this.enableRiveAssetCDN = !0, this.referenceCount = 0, this.destroyed = !1, this.src = c.src, this.buffer = c.buffer, c.assetLoader && (this.assetLoader = c.assetLoader), this.enableRiveAssetCDN = typeof c.enableRiveAssetCDN == "boolean" ? c.enableRiveAssetCDN : !0, this.eventManager = new L, c.onLoad && this.on(k.Load, c.onLoad), c.onLoadError && this.on(k.LoadError, c.onLoadError)
                    }
                    return v.prototype.initData = function() {
                        return _(this, void 0, void 0, function() {
                            var c, d, b, x;
                            return m(this, function(j) {
                                switch (j.label) {
                                    case 0:
                                        return this.src ? (c = this, [4, U(this.src)]) : [3, 2];
                                    case 1:
                                        c.buffer = j.sent(), j.label = 2;
                                    case 2:
                                        return this.destroyed ? [2] : (this.assetLoader && (d = new this.runtime.CustomFileAssetLoader({
                                            loadContents: this.assetLoader
                                        })), b = this, [4, this.runtime.load(new Uint8Array(this.buffer), d, this.enableRiveAssetCDN)]);
                                    case 3:
                                        if (b.file = j.sent(), this.destroyed) return (x = this.file) === null || x === void 0 || x.delete(), this.file = null, [2];
                                        if (this.file !== null) this.eventManager.fire({
                                            type: k.Load,
                                            data: this
                                        });
                                        else throw this.eventManager.fire({
                                            type: k.LoadError,
                                            data: null
                                        }), new Error(v.fileLoadErrorMessage);
                                        return [2]
                                }
                            })
                        })
                    }, v.prototype.init = function() {
                        return _(this, void 0, void 0, function() {
                            var c;
                            return m(this, function(d) {
                                switch (d.label) {
                                    case 0:
                                        if (!this.src && !this.buffer) throw new Error(v.missingErrorMessage);
                                        return c = this, [4, O.awaitInstance()];
                                    case 1:
                                        return c.runtime = d.sent(), this.destroyed ? [2] : [4, this.initData()];
                                    case 2:
                                        return d.sent(), [2]
                                }
                            })
                        })
                    }, v.prototype.on = function(c, d) {
                        this.eventManager.add({
                            type: c,
                            callback: d
                        })
                    }, v.prototype.off = function(c, d) {
                        this.eventManager.remove({
                            type: c,
                            callback: d
                        })
                    }, v.prototype.cleanup = function() {
                        var c;
                        this.referenceCount -= 1, this.referenceCount <= 0 && (this.removeAllRiveEventListeners(), (c = this.file) === null || c === void 0 || c.delete(), this.file = null, this.destroyed = !0)
                    }, v.prototype.removeAllRiveEventListeners = function(c) {
                        this.eventManager.removeAll(c)
                    }, v.prototype.getInstance = function() {
                        if (this.file !== null) return this.referenceCount += 1, this.file
                    }, v.missingErrorMessage = "Rive source file or data buffer required", v.fileLoadErrorMessage = "The file failed to load", v
                }(),
                Ze = function() {
                    function v(c) {
                        var d = this,
                            b;
                        this.loaded = !1, this.destroyed = !1, this._observed = null, this.readyForPlaying = !1, this.artboard = null, this.eventCleanup = null, this.shouldDisableRiveListeners = !1, this.automaticallyHandleEvents = !1, this.enableRiveAssetCDN = !0, this._volume = 1, this._artboardWidth = void 0, this._artboardHeight = void 0, this._devicePixelRatioUsed = 1, this._hasZeroSize = !1, this._audioEventListener = null, this._boundDraw = null, this._viewModelInstance = null, this._dataEnums = null, this.durations = [], this.frameTimes = [], this.frameCount = 0, this.isTouchScrollEnabled = !1, this.onCanvasResize = function(x) {
                            var j = d._hasZeroSize !== x;
                            d._hasZeroSize = x, x ? (!d._layout.maxX || !d._layout.maxY) && d.resizeToCanvas() : j && d.resizeDrawingSurfaceToCanvas()
                        }, this.renderSecondTimer = 0, this._boundDraw = this.draw.bind(this), this.canvas = c.canvas, c.canvas.constructor === HTMLCanvasElement && (this._observed = Oe.add(this.canvas, this.onCanvasResize)), this.src = c.src, this.buffer = c.buffer, this.riveFile = c.riveFile, this.layout = (b = c.layout) !== null && b !== void 0 ? b : new E, this.shouldDisableRiveListeners = !!c.shouldDisableRiveListeners, this.isTouchScrollEnabled = !!c.isTouchScrollEnabled, this.automaticallyHandleEvents = !!c.automaticallyHandleEvents, this.enableRiveAssetCDN = c.enableRiveAssetCDN === void 0 ? !0 : c.enableRiveAssetCDN, this.eventManager = new L, c.onLoad && this.on(k.Load, c.onLoad), c.onLoadError && this.on(k.LoadError, c.onLoadError), c.onPlay && this.on(k.Play, c.onPlay), c.onPause && this.on(k.Pause, c.onPause), c.onStop && this.on(k.Stop, c.onStop), c.onLoop && this.on(k.Loop, c.onLoop), c.onStateChange && this.on(k.StateChange, c.onStateChange), c.onAdvance && this.on(k.Advance, c.onAdvance), c.onload && !c.onLoad && this.on(k.Load, c.onload), c.onloaderror && !c.onLoadError && this.on(k.LoadError, c.onloaderror), c.onplay && !c.onPlay && this.on(k.Play, c.onplay), c.onpause && !c.onPause && this.on(k.Pause, c.onpause), c.onstop && !c.onStop && this.on(k.Stop, c.onstop), c.onloop && !c.onLoop && this.on(k.Loop, c.onloop), c.onstatechange && !c.onStateChange && this.on(k.StateChange, c.onstatechange), c.assetLoader && (this.assetLoader = c.assetLoader), this.taskQueue = new te(this.eventManager), this.init({
                            src: this.src,
                            buffer: this.buffer,
                            riveFile: this.riveFile,
                            autoplay: c.autoplay,
                            autoBind: c.autoBind,
                            animations: c.animations,
                            stateMachines: c.stateMachines,
                            artboard: c.artboard,
                            useOffscreenRenderer: c.useOffscreenRenderer
                        })
                    }
                    return Object.defineProperty(v.prototype, "viewModelCount", {
                        get: function() {
                            return this.file.viewModelCount()
                        },
                        enumerable: !1,
                        configurable: !0
                    }), v.new = function(c) {
                        return console.warn("This function is deprecated: please use `new Rive({})` instead"), new v(c)
                    }, v.prototype.onSystemAudioChanged = function() {
                        this.volume = this._volume
                    }, v.prototype.init = function(c) {
                        var d = this,
                            b = c.src,
                            x = c.buffer,
                            j = c.riveFile,
                            q = c.animations,
                            oe = c.stateMachines,
                            ne = c.artboard,
                            de = c.autoplay,
                            Ae = de === void 0 ? !1 : de,
                            Ge = c.useOffscreenRenderer,
                            st = Ge === void 0 ? !1 : Ge,
                            Qe = c.autoBind,
                            ze = Qe === void 0 ? !1 : Qe;
                        if (!this.destroyed) {
                            if (this.src = b, this.buffer = x, this.riveFile = j, !this.src && !this.buffer && !this.riveFile) throw new R(v.missingErrorMessage);
                            var xe = K(q),
                                De = K(oe);
                            this.loaded = !1, this.readyForPlaying = !1, O.awaitInstance().then(function(Dt) {
                                d.destroyed || (d.runtime = Dt, d.removeRiveListeners(), d.deleteRiveRenderer(), d.renderer = d.runtime.makeRenderer(d.canvas, st), d.canvas.width || d.canvas.height || d.resizeDrawingSurfaceToCanvas(), d.initData(ne, xe, De, Ae, ze).then(function() {
                                    return d.setupRiveListeners()
                                }).catch(function(Vt) {
                                    console.error(Vt)
                                }))
                            }).catch(function(Dt) {
                                console.error(Dt)
                            })
                        }
                    }, v.prototype.setupRiveListeners = function(c) {
                        var d = this;
                        if (this.eventCleanup && this.eventCleanup(), !this.shouldDisableRiveListeners) {
                            var b = (this.animator.stateMachines || []).filter(function(j) {
                                    return j.playing && d.runtime.hasListeners(j.instance)
                                }).map(function(j) {
                                    return j.instance
                                }),
                                x = this.isTouchScrollEnabled;
                            c && "isTouchScrollEnabled" in c && (x = c.isTouchScrollEnabled), this.eventCleanup = (0, u.registerTouchInteractions)({
                                canvas: this.canvas,
                                artboard: this.artboard,
                                stateMachines: b,
                                renderer: this.renderer,
                                rive: this.runtime,
                                fit: this._layout.runtimeFit(this.runtime),
                                alignment: this._layout.runtimeAlignment(this.runtime),
                                isTouchScrollEnabled: x,
                                layoutScaleFactor: this._layout.layoutScaleFactor
                            })
                        }
                    }, v.prototype.removeRiveListeners = function() {
                        this.eventCleanup && (this.eventCleanup(), this.eventCleanup = null)
                    }, v.prototype.initializeAudio = function() {
                        var c = this,
                            d;
                        X.status == ie.UNAVAILABLE && !((d = this.artboard) === null || d === void 0) && d.hasAudio && this._audioEventListener === null && (this._audioEventListener = {
                            type: k.AudioStatusChange,
                            callback: function() {
                                return c.onSystemAudioChanged()
                            }
                        }, X.add(this._audioEventListener), X.establishAudio())
                    }, v.prototype.initArtboardSize = function() {
                        this.artboard && (this._artboardWidth = this.artboard.width = this._artboardWidth || this.artboard.width, this._artboardHeight = this.artboard.height = this._artboardHeight || this.artboard.height)
                    }, v.prototype.initData = function(c, d, b, x, j) {
                        return _(this, void 0, void 0, function() {
                            var q, oe, ne;
                            return m(this, function(de) {
                                switch (de.label) {
                                    case 0:
                                        return de.trys.push([0, 3, , 4]), this.riveFile != null ? [3, 2] : (this.riveFile = new ke({
                                            src: this.src,
                                            buffer: this.buffer,
                                            enableRiveAssetCDN: this.enableRiveAssetCDN,
                                            assetLoader: this.assetLoader
                                        }), [4, this.riveFile.init()]);
                                    case 1:
                                        de.sent(), de.label = 2;
                                    case 2:
                                        if (!this.riveFile) throw new R(v.cleanupErrorMessage);
                                        return this.file = this.riveFile.getInstance(), this.initArtboard(c, d, b, x, j), this.initArtboardSize(), this.initializeAudio(), this.loaded = !0, this.eventManager.fire({
                                            type: k.Load,
                                            data: (ne = this.src) !== null && ne !== void 0 ? ne : "buffer"
                                        }), this.readyForPlaying = !0, this.taskQueue.process(), this.drawFrame(), [2, Promise.resolve()];
                                    case 3:
                                        return q = de.sent(), oe = B(q), console.warn(oe), this.eventManager.fire({
                                            type: k.LoadError,
                                            data: oe
                                        }), [2, Promise.reject(oe)];
                                    case 4:
                                        return [2]
                                }
                            })
                        })
                    }, v.prototype.initArtboard = function(c, d, b, x, j) {
                        if (this.file) {
                            var q = c ? this.file.artboardByName(c) : this.file.defaultArtboard();
                            if (!q) {
                                var oe = "Invalid artboard name or no default artboard";
                                console.warn(oe), this.eventManager.fire({
                                    type: k.LoadError,
                                    data: oe
                                });
                                return
                            }
                            if (this.artboard = q, q.volume = this._volume * X.systemVolume, this.artboard.animationCount() < 1) {
                                var oe = "Artboard has no animations";
                                throw this.eventManager.fire({
                                    type: k.LoadError,
                                    data: oe
                                }), oe
                            }
                            this.animator = new V(this.runtime, this.artboard, this.eventManager);
                            var ne;
                            if (d.length > 0 || b.length > 0 ? (ne = d.concat(b), this.animator.initLinearAnimations(d, x), this.animator.initStateMachines(b, x)) : ne = [this.animator.atLeastOne(x, !1)], this.taskQueue.add({
                                    event: {
                                        type: x ? k.Play : k.Pause,
                                        data: ne
                                    }
                                }), j) {
                                var de = this.file.defaultArtboardViewModel(q);
                                if (de !== null) {
                                    var Ae = de.defaultInstance();
                                    if (Ae !== null) {
                                        var Ge = new Ne(Ae, null);
                                        this.bindViewModelInstance(Ge)
                                    }
                                }
                            }
                        }
                    }, v.prototype.drawFrame = function() {
                        var c, d;
                        !((c = document == null ? void 0 : document.timeline) === null || c === void 0) && c.currentTime ? this.loaded && this.artboard && !this.frameRequestId && (this._boundDraw(document.timeline.currentTime), (d = this.runtime) === null || d === void 0 || d.resolveAnimationFrame()) : this.startRendering()
                    }, v.prototype.draw = function(c, d) {
                        var b;
                        this.frameRequestId = null;
                        var x = performance.now();
                        this.lastRenderTime || (this.lastRenderTime = c), this.renderSecondTimer += c - this.lastRenderTime, this.renderSecondTimer > 5e3 && (this.renderSecondTimer = 0, d == null || d());
                        var j = (c - this.lastRenderTime) / 1e3;
                        this.lastRenderTime = c;
                        for (var q = this.animator.animations.filter(function(er) {
                                return er.playing || er.needsScrub
                            }).sort(function(er) {
                                return er.needsScrub ? -1 : 1
                            }), oe = 0, ne = q; oe < ne.length; oe++) {
                            var de = ne[oe];
                            de.advance(j), de.instance.didLoop && (de.loopCount += 1), de.apply(1)
                        }
                        for (var Ae = this.animator.stateMachines.filter(function(er) {
                                return er.playing
                            }), Ge = 0, st = Ae; Ge < st.length; Ge++) {
                            var Qe = st[Ge],
                                ze = Qe.reportedEventCount();
                            if (ze)
                                for (var xe = 0; xe < ze; xe++) {
                                    var De = Qe.reportedEventAt(xe);
                                    if (De)
                                        if (De.type === H.OpenUrl) {
                                            if (this.eventManager.fire({
                                                    type: k.RiveEvent,
                                                    data: De
                                                }), this.automaticallyHandleEvents) {
                                                var Dt = document.createElement("a"),
                                                    Vt = De,
                                                    bt = Vt.url,
                                                    Qn = Vt.target,
                                                    ss = (0, u.sanitizeUrl)(bt);
                                                bt && Dt.setAttribute("href", ss), Qn && Dt.setAttribute("target", Qn), ss && ss !== u.BLANK_URL && Dt.click()
                                            }
                                        } else this.eventManager.fire({
                                            type: k.RiveEvent,
                                            data: De
                                        })
                                }
                            Qe.advanceAndApply(j)
                        }
                        this.animator.stateMachines.length == 0 && this.artboard.advance(j);
                        var Hn = this.renderer;
                        Hn.clear(), Hn.save(), this.alignRenderer(), this._hasZeroSize || this.artboard.draw(Hn), Hn.restore(), Hn.flush(), this.animator.handleLooping(), this.animator.handleStateChanges(), this.animator.handleAdvancing(j), this.frameCount++;
                        var Nr = performance.now();
                        for (this.frameTimes.push(Nr), this.durations.push(Nr - x); this.frameTimes[0] <= Nr - 1e3;) this.frameTimes.shift(), this.durations.shift();
                        (b = this._viewModelInstance) === null || b === void 0 || b.handleCallbacks(), this.animator.isPlaying ? this.startRendering() : this.animator.isPaused ? this.lastRenderTime = 0 : this.animator.isStopped && (this.lastRenderTime = 0)
                    }, v.prototype.alignRenderer = function() {
                        var c = this,
                            d = c.renderer,
                            b = c.runtime,
                            x = c._layout,
                            j = c.artboard;
                        d.align(x.runtimeFit(b), x.runtimeAlignment(b), {
                            minX: x.minX,
                            minY: x.minY,
                            maxX: x.maxX,
                            maxY: x.maxY
                        }, j.bounds, this._devicePixelRatioUsed * x.layoutScaleFactor)
                    }, Object.defineProperty(v.prototype, "fps", {
                        get: function() {
                            return this.durations.length
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(v.prototype, "frameTime", {
                        get: function() {
                            return this.durations.length === 0 ? 0 : (this.durations.reduce(function(c, d) {
                                return c + d
                            }, 0) / this.durations.length).toFixed(4)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), v.prototype.cleanup = function() {
                        var c, d;
                        this.destroyed = !0, this.stopRendering(), this.cleanupInstances(), this._observed !== null && Oe.remove(this._observed), this.removeRiveListeners(), this.file && ((c = this.riveFile) === null || c === void 0 || c.cleanup(), this.file = null), this.riveFile = null, this.deleteRiveRenderer(), this._audioEventListener !== null && (X.remove(this._audioEventListener), this._audioEventListener = null), (d = this._viewModelInstance) === null || d === void 0 || d.cleanup(), this._viewModelInstance = null, this._dataEnums = null
                    }, v.prototype.deleteRiveRenderer = function() {
                        var c;
                        (c = this.renderer) === null || c === void 0 || c.delete(), this.renderer = null
                    }, v.prototype.cleanupInstances = function() {
                        this.eventCleanup !== null && this.eventCleanup(), this.stop(), this.artboard && (this.artboard.delete(), this.artboard = null)
                    }, v.prototype.retrieveTextRun = function(c) {
                        var d;
                        if (!c) {
                            console.warn("No text run name provided");
                            return
                        }
                        if (!this.artboard) {
                            console.warn("Tried to access text run, but the Artboard is null");
                            return
                        }
                        var b = this.artboard.textRun(c);
                        if (!b) {
                            console.warn("Could not access a text run with name '".concat(c, "' in the '").concat((d = this.artboard) === null || d === void 0 ? void 0 : d.name, "' Artboard. Note that you must rename a text run node in the Rive editor to make it queryable at runtime."));
                            return
                        }
                        return b
                    }, v.prototype.getTextRunValue = function(c) {
                        var d = this.retrieveTextRun(c);
                        return d ? d.text : void 0
                    }, v.prototype.setTextRunValue = function(c, d) {
                        var b = this.retrieveTextRun(c);
                        b && (b.text = d)
                    }, v.prototype.play = function(c, d) {
                        var b = this;
                        if (c = K(c), !this.readyForPlaying) {
                            this.taskQueue.add({
                                action: function() {
                                    return b.play(c, d)
                                }
                            });
                            return
                        }
                        this.animator.play(c), this.eventCleanup && this.eventCleanup(), this.setupRiveListeners(), this.startRendering()
                    }, v.prototype.pause = function(c) {
                        var d = this;
                        if (c = K(c), !this.readyForPlaying) {
                            this.taskQueue.add({
                                action: function() {
                                    return d.pause(c)
                                }
                            });
                            return
                        }
                        this.eventCleanup && this.eventCleanup(), this.animator.pause(c)
                    }, v.prototype.scrub = function(c, d) {
                        var b = this;
                        if (c = K(c), !this.readyForPlaying) {
                            this.taskQueue.add({
                                action: function() {
                                    return b.scrub(c, d)
                                }
                            });
                            return
                        }
                        this.animator.scrub(c, d || 0), this.drawFrame()
                    }, v.prototype.stop = function(c) {
                        var d = this;
                        if (c = K(c), !this.readyForPlaying) {
                            this.taskQueue.add({
                                action: function() {
                                    return d.stop(c)
                                }
                            });
                            return
                        }
                        this.animator && this.animator.stop(c), this.eventCleanup && this.eventCleanup()
                    }, v.prototype.reset = function(c) {
                        var d, b, x = c == null ? void 0 : c.artboard,
                            j = K(c == null ? void 0 : c.animations),
                            q = K(c == null ? void 0 : c.stateMachines),
                            oe = (d = c == null ? void 0 : c.autoplay) !== null && d !== void 0 ? d : !1,
                            ne = (b = c == null ? void 0 : c.autoBind) !== null && b !== void 0 ? b : !1;
                        this.cleanupInstances(), this.initArtboard(x, j, q, oe, ne), this.taskQueue.process()
                    }, v.prototype.load = function(c) {
                        this.file = null, this.stop(), this.init(c)
                    }, Object.defineProperty(v.prototype, "layout", {
                        get: function() {
                            return this._layout
                        },
                        set: function(c) {
                            this._layout = c, (!c.maxX || !c.maxY) && this.resizeToCanvas(), this.loaded && !this.animator.isPlaying && this.drawFrame()
                        },
                        enumerable: !1,
                        configurable: !0
                    }), v.prototype.resizeToCanvas = function() {
                        this._layout = this.layout.copyWith({
                            minX: 0,
                            minY: 0,
                            maxX: this.canvas.width,
                            maxY: this.canvas.height
                        })
                    }, v.prototype.resizeDrawingSurfaceToCanvas = function(c) {
                        if (this.canvas instanceof HTMLCanvasElement && window) {
                            var d = this.canvas.getBoundingClientRect(),
                                b = d.width,
                                x = d.height,
                                j = c || window.devicePixelRatio || 1;
                            if (this.devicePixelRatioUsed = j, this.canvas.width = j * b, this.canvas.height = j * x, this.resizeToCanvas(), this.drawFrame(), this.layout.fit === I.Layout) {
                                var q = this._layout.layoutScaleFactor;
                                this.artboard.width = b / q, this.artboard.height = x / q
                            }
                        }
                    }, Object.defineProperty(v.prototype, "source", {
                        get: function() {
                            return this.src
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(v.prototype, "activeArtboard", {
                        get: function() {
                            return this.artboard ? this.artboard.name : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(v.prototype, "animationNames", {
                        get: function() {
                            if (!this.loaded || !this.artboard) return [];
                            for (var c = [], d = 0; d < this.artboard.animationCount(); d++) c.push(this.artboard.animationByIndex(d).name);
                            return c
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(v.prototype, "stateMachineNames", {
                        get: function() {
                            if (!this.loaded || !this.artboard) return [];
                            for (var c = [], d = 0; d < this.artboard.stateMachineCount(); d++) c.push(this.artboard.stateMachineByIndex(d).name);
                            return c
                        },
                        enumerable: !1,
                        configurable: !0
                    }), v.prototype.stateMachineInputs = function(c) {
                        if (this.loaded) {
                            var d = this.animator.stateMachines.find(function(b) {
                                return b.name === c
                            });
                            return d == null ? void 0 : d.inputs
                        }
                    }, v.prototype.retrieveInputAtPath = function(c, d) {
                        if (!c) {
                            console.warn("No input name provided for path '".concat(d, "'"));
                            return
                        }
                        if (!this.artboard) {
                            console.warn("Tried to access input: '".concat(c, "', at path: '").concat(d, "', but the Artboard is null"));
                            return
                        }
                        var b = this.artboard.inputByPath(c, d);
                        if (!b) {
                            console.warn("Could not access an input with name: '".concat(c, "', at path:'").concat(d, "'"));
                            return
                        }
                        return b
                    }, v.prototype.setBooleanStateAtPath = function(c, d, b) {
                        var x = this.retrieveInputAtPath(c, b);
                        x && (x.type === P.Boolean ? x.asBool().value = d : console.warn("Input with name: '".concat(c, "', at path:'").concat(b, "' is not a boolean")))
                    }, v.prototype.setNumberStateAtPath = function(c, d, b) {
                        var x = this.retrieveInputAtPath(c, b);
                        x && (x.type === P.Number ? x.asNumber().value = d : console.warn("Input with name: '".concat(c, "', at path:'").concat(b, "' is not a number")))
                    }, v.prototype.fireStateAtPath = function(c, d) {
                        var b = this.retrieveInputAtPath(c, d);
                        b && (b.type === P.Trigger ? b.asTrigger().fire() : console.warn("Input with name: '".concat(c, "', at path:'").concat(d, "' is not a trigger")))
                    }, v.prototype.retrieveTextAtPath = function(c, d) {
                        if (!c) {
                            console.warn("No text name provided for path '".concat(d, "'"));
                            return
                        }
                        if (!d) {
                            console.warn("No path provided for text '".concat(c, "'"));
                            return
                        }
                        if (!this.artboard) {
                            console.warn("Tried to access text: '".concat(c, "', at path: '").concat(d, "', but the Artboard is null"));
                            return
                        }
                        var b = this.artboard.textByPath(c, d);
                        if (!b) {
                            console.warn("Could not access text with name: '".concat(c, "', at path:'").concat(d, "'"));
                            return
                        }
                        return b
                    }, v.prototype.getTextRunValueAtPath = function(c, d) {
                        var b = this.retrieveTextAtPath(c, d);
                        if (!b) {
                            console.warn("Could not get text with name: '".concat(c, "', at path:'").concat(d, "'"));
                            return
                        }
                        return b.text
                    }, v.prototype.setTextRunValueAtPath = function(c, d, b) {
                        var x = this.retrieveTextAtPath(c, b);
                        if (!x) {
                            console.warn("Could not set text with name: '".concat(c, "', at path:'").concat(b, "'"));
                            return
                        }
                        x.text = d
                    }, Object.defineProperty(v.prototype, "playingStateMachineNames", {
                        get: function() {
                            return this.loaded ? this.animator.stateMachines.filter(function(c) {
                                return c.playing
                            }).map(function(c) {
                                return c.name
                            }) : []
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(v.prototype, "playingAnimationNames", {
                        get: function() {
                            return this.loaded ? this.animator.animations.filter(function(c) {
                                return c.playing
                            }).map(function(c) {
                                return c.name
                            }) : []
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(v.prototype, "pausedAnimationNames", {
                        get: function() {
                            return this.loaded ? this.animator.animations.filter(function(c) {
                                return !c.playing
                            }).map(function(c) {
                                return c.name
                            }) : []
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(v.prototype, "pausedStateMachineNames", {
                        get: function() {
                            return this.loaded ? this.animator.stateMachines.filter(function(c) {
                                return !c.playing
                            }).map(function(c) {
                                return c.name
                            }) : []
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(v.prototype, "isPlaying", {
                        get: function() {
                            return this.animator.isPlaying
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(v.prototype, "isPaused", {
                        get: function() {
                            return this.animator.isPaused
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(v.prototype, "isStopped", {
                        get: function() {
                            return this.animator.isStopped
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(v.prototype, "bounds", {
                        get: function() {
                            return this.artboard ? this.artboard.bounds : void 0
                        },
                        enumerable: !1,
                        configurable: !0
                    }), v.prototype.on = function(c, d) {
                        this.eventManager.add({
                            type: c,
                            callback: d
                        })
                    }, v.prototype.off = function(c, d) {
                        this.eventManager.remove({
                            type: c,
                            callback: d
                        })
                    }, v.prototype.unsubscribe = function(c, d) {
                        console.warn("This function is deprecated: please use `off()` instead."), this.off(c, d)
                    }, v.prototype.removeAllRiveEventListeners = function(c) {
                        this.eventManager.removeAll(c)
                    }, v.prototype.unsubscribeAll = function(c) {
                        console.warn("This function is deprecated: please use `removeAllRiveEventListeners()` instead."), this.removeAllRiveEventListeners(c)
                    }, v.prototype.stopRendering = function() {
                        this.loaded && this.frameRequestId && (this.runtime.cancelAnimationFrame ? this.runtime.cancelAnimationFrame(this.frameRequestId) : cancelAnimationFrame(this.frameRequestId), this.frameRequestId = null)
                    }, v.prototype.startRendering = function() {
                        this.loaded && this.artboard && !this.frameRequestId && (this.runtime.requestAnimationFrame ? this.frameRequestId = this.runtime.requestAnimationFrame(this._boundDraw) : this.frameRequestId = requestAnimationFrame(this._boundDraw))
                    }, v.prototype.enableFPSCounter = function(c) {
                        this.runtime.enableFPSCounter(c)
                    }, v.prototype.disableFPSCounter = function() {
                        this.runtime.disableFPSCounter()
                    }, Object.defineProperty(v.prototype, "contents", {
                        get: function() {
                            if (this.loaded) {
                                for (var c = {
                                        artboards: []
                                    }, d = 0; d < this.file.artboardCount(); d++) {
                                    for (var b = this.file.artboardByIndex(d), x = {
                                            name: b.name,
                                            animations: [],
                                            stateMachines: []
                                        }, j = 0; j < b.animationCount(); j++) {
                                        var q = b.animationByIndex(j);
                                        x.animations.push(q.name)
                                    }
                                    for (var oe = 0; oe < b.stateMachineCount(); oe++) {
                                        for (var ne = b.stateMachineByIndex(oe), de = ne.name, Ae = new this.runtime.StateMachineInstance(ne, b), Ge = [], st = 0; st < Ae.inputCount(); st++) {
                                            var Qe = Ae.input(st);
                                            Ge.push({
                                                name: Qe.name,
                                                type: Qe.type
                                            })
                                        }
                                        x.stateMachines.push({
                                            name: de,
                                            inputs: Ge
                                        })
                                    }
                                    c.artboards.push(x)
                                }
                                return c
                            }
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(v.prototype, "volume", {
                        get: function() {
                            return this.artboard && this.artboard.volume !== this._volume && (this._volume = this.artboard.volume), this._volume
                        },
                        set: function(c) {
                            this._volume = c, this.artboard && (this.artboard.volume = c * X.systemVolume)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(v.prototype, "artboardWidth", {
                        get: function() {
                            var c;
                            return this.artboard ? this.artboard.width : (c = this._artboardWidth) !== null && c !== void 0 ? c : 0
                        },
                        set: function(c) {
                            this._artboardWidth = c, this.artboard && (this.artboard.width = c)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(v.prototype, "artboardHeight", {
                        get: function() {
                            var c;
                            return this.artboard ? this.artboard.height : (c = this._artboardHeight) !== null && c !== void 0 ? c : 0
                        },
                        set: function(c) {
                            this._artboardHeight = c, this.artboard && (this.artboard.height = c)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), v.prototype.resetArtboardSize = function() {
                        this.artboard ? (this.artboard.resetArtboardSize(), this._artboardWidth = this.artboard.width, this._artboardHeight = this.artboard.height) : (this._artboardWidth = void 0, this._artboardHeight = void 0)
                    }, Object.defineProperty(v.prototype, "devicePixelRatioUsed", {
                        get: function() {
                            return this._devicePixelRatioUsed
                        },
                        set: function(c) {
                            this._devicePixelRatioUsed = c
                        },
                        enumerable: !1,
                        configurable: !0
                    }), v.prototype.bindViewModelInstance = function(c) {
                        var d;
                        this.artboard && !this.destroyed && c && c.runtimeInstance && (c.internalIncrementReferenceCount(), (d = this._viewModelInstance) === null || d === void 0 || d.cleanup(), this._viewModelInstance = c, this.animator.stateMachines.length > 0 ? this.animator.stateMachines.forEach(function(b) {
                            return b.bindViewModelInstance(c)
                        }) : this.artboard.bindViewModelInstance(c.runtimeInstance))
                    }, Object.defineProperty(v.prototype, "viewModelInstance", {
                        get: function() {
                            return this._viewModelInstance
                        },
                        enumerable: !1,
                        configurable: !0
                    }), v.prototype.viewModelByIndex = function(c) {
                        var d = this.file.viewModelByIndex(c);
                        return d !== null ? new Fe(d) : null
                    }, v.prototype.viewModelByName = function(c) {
                        var d = this.file.viewModelByName(c);
                        return d !== null ? new Fe(d) : null
                    }, v.prototype.enums = function() {
                        if (this._dataEnums === null) {
                            var c = this.file.enums();
                            this._dataEnums = c.map(function(d) {
                                return new Ie(d)
                            })
                        }
                        return this._dataEnums
                    }, v.prototype.defaultViewModel = function() {
                        if (this.artboard) {
                            var c = this.file.defaultArtboardViewModel(this.artboard);
                            if (c) return new Fe(c)
                        }
                        return null
                    }, v.missingErrorMessage = "Rive source file or data buffer required", v.cleanupErrorMessage = "Attempt to use file after calling cleanup.", v
                }(),
                Fe = function() {
                    function v(c) {
                        this._viewModel = c
                    }
                    return Object.defineProperty(v.prototype, "instanceCount", {
                        get: function() {
                            return this._viewModel.instanceCount
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(v.prototype, "name", {
                        get: function() {
                            return this._viewModel.name
                        },
                        enumerable: !1,
                        configurable: !0
                    }), v.prototype.instanceByIndex = function(c) {
                        var d = this._viewModel.instanceByIndex(c);
                        return d !== null ? new Ne(d, null) : null
                    }, v.prototype.instanceByName = function(c) {
                        var d = this._viewModel.instanceByName(c);
                        return d !== null ? new Ne(d, null) : null
                    }, v.prototype.defaultInstance = function() {
                        var c = this._viewModel.defaultInstance();
                        return c !== null ? new Ne(c, null) : null
                    }, v.prototype.instance = function() {
                        var c = this._viewModel.instance();
                        return c !== null ? new Ne(c, null) : null
                    }, Object.defineProperty(v.prototype, "properties", {
                        get: function() {
                            return this._viewModel.getProperties()
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(v.prototype, "instanceNames", {
                        get: function() {
                            return this._viewModel.getInstanceNames()
                        },
                        enumerable: !1,
                        configurable: !0
                    }), v
                }(),
                Ie = function() {
                    function v(c) {
                        this._dataEnum = c
                    }
                    return Object.defineProperty(v.prototype, "name", {
                        get: function() {
                            return this._dataEnum.name
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(v.prototype, "values", {
                        get: function() {
                            return this._dataEnum.values
                        },
                        enumerable: !1,
                        configurable: !0
                    }), v
                }(),
                Le;
            (function(v) {
                v.Number = "number", v.String = "string", v.Boolean = "boolean", v.Color = "color", v.Trigger = "trigger", v.Enum = "enum", v.List = "list"
            })(Le || (Le = {}));
            var Ne = function() {
                    function v(c, d) {
                        this._parents = [], this._children = [], this._viewModelInstances = new Map, this._propertiesWithCallbacks = [], this._referenceCount = 0, this._runtimeInstance = c, d !== null && this._parents.push(d)
                    }
                    return Object.defineProperty(v.prototype, "runtimeInstance", {
                        get: function() {
                            return this._runtimeInstance
                        },
                        enumerable: !1,
                        configurable: !0
                    }), v.prototype.handleCallbacks = function() {
                        this._propertiesWithCallbacks.length !== 0 && (this._propertiesWithCallbacks.forEach(function(c) {
                            c.handleCallbacks()
                        }), this._propertiesWithCallbacks.forEach(function(c) {
                            c.clearChanges()
                        })), this._children.forEach(function(c) {
                            return c.handleCallbacks()
                        })
                    }, v.prototype.addParent = function(c) {
                        this._parents.push(c), (this._propertiesWithCallbacks.length > 0 || this._children.length > 0) && c.addToViewModelCallbacks(this)
                    }, v.prototype.removeParent = function(c) {
                        var d = this._parents.indexOf(c);
                        if (d !== -1) {
                            var b = this._parents[d];
                            b.removeFromViewModelCallbacks(this), this._parents.splice(d, 1)
                        }
                    }, v.prototype.addToPropertyCallbacks = function(c) {
                        var d = this;
                        this._propertiesWithCallbacks.includes(c) || (this._propertiesWithCallbacks.push(c), this._propertiesWithCallbacks.length > 0 && this._parents.forEach(function(b) {
                            b.addToViewModelCallbacks(d)
                        }))
                    }, v.prototype.removeFromPropertyCallbacks = function(c) {
                        var d = this;
                        this._propertiesWithCallbacks.includes(c) && (this._propertiesWithCallbacks = this._propertiesWithCallbacks.filter(function(b) {
                            return b !== c
                        }), this._children.length === 0 && this._propertiesWithCallbacks.length === 0 && this._parents.forEach(function(b) {
                            b.removeFromViewModelCallbacks(d)
                        }))
                    }, v.prototype.addToViewModelCallbacks = function(c) {
                        var d = this;
                        this._children.includes(c) || (this._children.push(c), this._parents.forEach(function(b) {
                            b.addToViewModelCallbacks(d)
                        }))
                    }, v.prototype.removeFromViewModelCallbacks = function(c) {
                        var d = this;
                        this._children.includes(c) && (this._children = this._children.filter(function(b) {
                            return b !== c
                        }), this._children.length === 0 && this._propertiesWithCallbacks.length === 0 && this._parents.forEach(function(b) {
                            b.removeFromViewModelCallbacks(d)
                        }))
                    }, v.prototype.clearCallbacks = function() {
                        this._propertiesWithCallbacks.forEach(function(c) {
                            c.clearCallbacks()
                        })
                    }, v.prototype.propertyFromPath = function(c, d) {
                        var b = c.split("/");
                        return this.propertyFromPathSegments(b, 0, d)
                    }, v.prototype.viewModelFromPathSegments = function(c, d) {
                        var b = this.internalViewModelInstance(c[d]);
                        return b !== null ? d == c.length - 1 ? b : b.viewModelFromPathSegments(c, d++) : null
                    }, v.prototype.propertyFromPathSegments = function(c, d, b) {
                        var x, j, q, oe, ne, de, Ae, Ge, st, Qe, ze, xe, De, Dt;
                        if (d < c.length - 1) {
                            var Vt = this.internalViewModelInstance(c[d]);
                            return Vt !== null ? Vt.propertyFromPathSegments(c, d + 1, b) : null
                        }
                        var bt = null;
                        switch (b) {
                            case Le.Number:
                                if (bt = (j = (x = this._runtimeInstance) === null || x === void 0 ? void 0 : x.number(c[d])) !== null && j !== void 0 ? j : null, bt !== null) return new fe(bt, this);
                                break;
                            case Le.String:
                                if (bt = (oe = (q = this._runtimeInstance) === null || q === void 0 ? void 0 : q.string(c[d])) !== null && oe !== void 0 ? oe : null, bt !== null) return new ge(bt, this);
                                break;
                            case Le.Boolean:
                                if (bt = (de = (ne = this._runtimeInstance) === null || ne === void 0 ? void 0 : ne.boolean(c[d])) !== null && de !== void 0 ? de : null, bt !== null) return new ye(bt, this);
                                break;
                            case Le.Color:
                                if (bt = (Ge = (Ae = this._runtimeInstance) === null || Ae === void 0 ? void 0 : Ae.color(c[d])) !== null && Ge !== void 0 ? Ge : null, bt !== null) return new C(bt, this);
                                break;
                            case Le.Trigger:
                                if (bt = (Qe = (st = this._runtimeInstance) === null || st === void 0 ? void 0 : st.trigger(c[d])) !== null && Qe !== void 0 ? Qe : null, bt !== null) return new Me(bt, this);
                                break;
                            case Le.Enum:
                                if (bt = (xe = (ze = this._runtimeInstance) === null || ze === void 0 ? void 0 : ze.enum(c[d])) !== null && xe !== void 0 ? xe : null, bt !== null) return new Be(bt, this);
                                break;
                            case Le.List:
                                if (bt = (Dt = (De = this._runtimeInstance) === null || De === void 0 ? void 0 : De.list(c[d])) !== null && Dt !== void 0 ? Dt : null, bt !== null) return new S(bt, this);
                                break
                        }
                        return null
                    }, v.prototype.internalViewModelInstance = function(c) {
                        var d;
                        if (this._viewModelInstances.has(c)) return this._viewModelInstances.get(c);
                        var b = (d = this._runtimeInstance) === null || d === void 0 ? void 0 : d.viewModel(c);
                        if (b !== null) {
                            var x = new v(b, this);
                            return x.internalIncrementReferenceCount(), this._viewModelInstances.set(c, x), x
                        }
                        return null
                    }, v.prototype.number = function(c) {
                        var d = this.propertyFromPath(c, Le.Number);
                        return d
                    }, v.prototype.string = function(c) {
                        var d = this.propertyFromPath(c, Le.String);
                        return d
                    }, v.prototype.boolean = function(c) {
                        var d = this.propertyFromPath(c, Le.Boolean);
                        return d
                    }, v.prototype.color = function(c) {
                        var d = this.propertyFromPath(c, Le.Color);
                        return d
                    }, v.prototype.trigger = function(c) {
                        var d = this.propertyFromPath(c, Le.Trigger);
                        return d
                    }, v.prototype.enum = function(c) {
                        var d = this.propertyFromPath(c, Le.Enum);
                        return d
                    }, v.prototype.list = function(c) {
                        var d = this.propertyFromPath(c, Le.List);
                        return d
                    }, v.prototype.viewModel = function(c) {
                        var d = c.split("/"),
                            b = d.length > 1 ? this.viewModelFromPathSegments(d.slice(0, d.length - 1), 0) : this;
                        return b != null ? b.internalViewModelInstance(d[d.length - 1]) : null
                    }, v.prototype.internalReplaceViewModel = function(c, d) {
                        var b;
                        if (d.runtimeInstance !== null) {
                            var x = ((b = this._runtimeInstance) === null || b === void 0 ? void 0 : b.replaceViewModel(c, d.runtimeInstance)) || !1;
                            if (x) {
                                d.internalIncrementReferenceCount();
                                var j = this.internalViewModelInstance(c);
                                j !== null && (j.removeParent(this), this._children.includes(j) && (this._children = this._children.filter(function(q) {
                                    return q !== j
                                })), j.cleanup()), this._viewModelInstances.set(c, d), d.addParent(this)
                            }
                            return x
                        }
                        return !1
                    }, v.prototype.replaceViewModel = function(c, d) {
                        var b, x = c.split("/"),
                            j = x.length > 1 ? this.viewModelFromPathSegments(x.slice(0, x.length - 1), 0) : this;
                        return (b = j == null ? void 0 : j.internalReplaceViewModel(x[x.length - 1], d)) !== null && b !== void 0 ? b : !1
                    }, v.prototype.incrementReferenceCount = function() {
                        var c;
                        this._referenceCount++, (c = this._runtimeInstance) === null || c === void 0 || c.incrementReferenceCount()
                    }, v.prototype.decrementReferenceCount = function() {
                        var c;
                        this._referenceCount--, (c = this._runtimeInstance) === null || c === void 0 || c.decrementReferenceCount()
                    }, Object.defineProperty(v.prototype, "properties", {
                        get: function() {
                            var c;
                            return ((c = this._runtimeInstance) === null || c === void 0 ? void 0 : c.getProperties().map(function(d) {
                                return h({}, d)
                            })) || []
                        },
                        enumerable: !1,
                        configurable: !0
                    }), v.prototype.internalIncrementReferenceCount = function() {
                        this._referenceCount++
                    }, v.prototype.cleanup = function() {
                        var c = this;
                        if (this._referenceCount--, this._referenceCount <= 0) {
                            this._runtimeInstance = null, this.clearCallbacks(), this._propertiesWithCallbacks = [], this._viewModelInstances.forEach(function(x) {
                                x.cleanup()
                            }), this._viewModelInstances.clear();
                            var d = T([], this._children, !0);
                            this._children.length = 0;
                            var b = T([], this._parents, !0);
                            this._parents.length = 0, d.forEach(function(x) {
                                x.removeParent(c)
                            }), b.forEach(function(x) {
                                x.removeFromViewModelCallbacks(c)
                            })
                        }
                    }, v
                }(),
                W = function() {
                    function v(c, d) {
                        this.callbacks = [], this._viewModelInstanceValue = c, this._parentViewModel = d
                    }
                    return v.prototype.on = function(c) {
                        this.callbacks.length === 0 && this._viewModelInstanceValue.clearChanges(), this.callbacks.includes(c) || (this.callbacks.push(c), this._parentViewModel.addToPropertyCallbacks(this))
                    }, v.prototype.off = function(c) {
                        c ? this.callbacks = this.callbacks.filter(function(d) {
                            return d !== c
                        }) : this.callbacks.length = 0, this.callbacks.length === 0 && this._parentViewModel.removeFromPropertyCallbacks(this)
                    }, v.prototype.internalHandleCallback = function(c) {}, v.prototype.handleCallbacks = function() {
                        var c = this;
                        this._viewModelInstanceValue.hasChanged && this.callbacks.forEach(function(d) {
                            c.internalHandleCallback(d)
                        })
                    }, v.prototype.clearChanges = function() {
                        this._viewModelInstanceValue.clearChanges()
                    }, v.prototype.clearCallbacks = function() {
                        this.callbacks.length = 0
                    }, Object.defineProperty(v.prototype, "name", {
                        get: function() {
                            return this._viewModelInstanceValue.name
                        },
                        enumerable: !1,
                        configurable: !0
                    }), v
                }(),
                ge = function(v) {
                    f(c, v);

                    function c(d, b) {
                        return v.call(this, d, b) || this
                    }
                    return Object.defineProperty(c.prototype, "value", {
                        get: function() {
                            return this._viewModelInstanceValue.value
                        },
                        set: function(d) {
                            this._viewModelInstanceValue.value = d
                        },
                        enumerable: !1,
                        configurable: !0
                    }), c.prototype.internalHandleCallback = function(d) {
                        d(this.value)
                    }, c
                }(W),
                fe = function(v) {
                    f(c, v);

                    function c(d, b) {
                        return v.call(this, d, b) || this
                    }
                    return Object.defineProperty(c.prototype, "value", {
                        get: function() {
                            return this._viewModelInstanceValue.value
                        },
                        set: function(d) {
                            this._viewModelInstanceValue.value = d
                        },
                        enumerable: !1,
                        configurable: !0
                    }), c.prototype.internalHandleCallback = function(d) {
                        d(this.value)
                    }, c
                }(W),
                ye = function(v) {
                    f(c, v);

                    function c(d, b) {
                        return v.call(this, d, b) || this
                    }
                    return Object.defineProperty(c.prototype, "value", {
                        get: function() {
                            return this._viewModelInstanceValue.value
                        },
                        set: function(d) {
                            this._viewModelInstanceValue.value = d
                        },
                        enumerable: !1,
                        configurable: !0
                    }), c.prototype.internalHandleCallback = function(d) {
                        d(this.value)
                    }, c
                }(W),
                Me = function(v) {
                    f(c, v);

                    function c(d, b) {
                        return v.call(this, d, b) || this
                    }
                    return c.prototype.trigger = function() {
                        return this._viewModelInstanceValue.trigger()
                    }, c.prototype.internalHandleCallback = function(d) {
                        d()
                    }, c
                }(W),
                Be = function(v) {
                    f(c, v);

                    function c(d, b) {
                        return v.call(this, d, b) || this
                    }
                    return Object.defineProperty(c.prototype, "value", {
                        get: function() {
                            return this._viewModelInstanceValue.value
                        },
                        set: function(d) {
                            this._viewModelInstanceValue.value = d
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(c.prototype, "valueIndex", {
                        get: function() {
                            return this._viewModelInstanceValue.valueIndex
                        },
                        set: function(d) {
                            this._viewModelInstanceValue.valueIndex = d
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(c.prototype, "values", {
                        get: function() {
                            return this._viewModelInstanceValue.values
                        },
                        enumerable: !1,
                        configurable: !0
                    }), c.prototype.internalHandleCallback = function(d) {
                        d(this.value)
                    }, c
                }(W),
                S = function(v) {
                    f(c, v);

                    function c(d, b) {
                        return v.call(this, d, b) || this
                    }
                    return Object.defineProperty(c.prototype, "length", {
                        get: function() {
                            return this._viewModelInstanceValue.size
                        },
                        enumerable: !1,
                        configurable: !0
                    }), c.prototype.addInstance = function(d) {
                        d.runtimeInstance != null && this._viewModelInstanceValue.addInstance(d.runtimeInstance)
                    }, c.prototype.removeInstance = function(d) {
                        d.runtimeInstance != null && this._viewModelInstanceValue.removeInstance(d.runtimeInstance)
                    }, c.prototype.removeInstanceAt = function(d) {
                        this._viewModelInstanceValue.removeInstanceAt(d)
                    }, c.prototype.instanceAt = function(d) {
                        var b = this._viewModelInstanceValue.instanceAt(d);
                        if (b != null) {
                            var x = new Ne(b, null);
                            return x
                        }
                        return null
                    }, c.prototype.internalHandleCallback = function(d) {
                        d()
                    }, c
                }(W),
                C = function(v) {
                    f(c, v);

                    function c(d, b) {
                        return v.call(this, d, b) || this
                    }
                    return Object.defineProperty(c.prototype, "value", {
                        get: function() {
                            return this._viewModelInstanceValue.value
                        },
                        set: function(d) {
                            this._viewModelInstanceValue.value = d
                        },
                        enumerable: !1,
                        configurable: !0
                    }), c.prototype.rgb = function(d, b, x) {
                        this._viewModelInstanceValue.rgb(d, b, x)
                    }, c.prototype.rgba = function(d, b, x, j) {
                        this._viewModelInstanceValue.argb(j, d, b, x)
                    }, c.prototype.argb = function(d, b, x, j) {
                        this._viewModelInstanceValue.argb(d, b, x, j)
                    }, c.prototype.alpha = function(d) {
                        this._viewModelInstanceValue.alpha(d)
                    }, c.prototype.opacity = function(d) {
                        this._viewModelInstanceValue.alpha(Math.round(Math.max(0, Math.min(1, d)) * 255))
                    }, c.prototype.internalHandleCallback = function(d) {
                        d(this.value)
                    }, c
                }(W),
                U = function(v) {
                    return _(void 0, void 0, void 0, function() {
                        var c, d, b;
                        return m(this, function(x) {
                            switch (x.label) {
                                case 0:
                                    return c = new Request(v), [4, fetch(c)];
                                case 1:
                                    return d = x.sent(), [4, d.arrayBuffer()];
                                case 2:
                                    return b = x.sent(), [2, b]
                            }
                        })
                    })
                },
                K = function(v) {
                    return typeof v == "string" ? [v] : v instanceof Array ? v : []
                },
                z = {
                    EventManager: L,
                    TaskQueueManager: te
                },
                ae = function(v) {
                    return new Promise(function(c) {
                        return O.getInstance(function(d) {
                            d.decodeAudio(v, c)
                        })
                    })
                },
                me = function(v) {
                    return new Promise(function(c) {
                        return O.getInstance(function(d) {
                            d.decodeImage(v, c)
                        })
                    })
                },
                re = function(v) {
                    return new Promise(function(c) {
                        return O.getInstance(function(d) {
                            d.decodeFont(v, c)
                        })
                    })
                }
        })(), s
    })())
})(My);
var ja = My.exports;
const LP = {
        props: {
            src: {
                type: String,
                default: null
            },
            local: {
                type: Boolean,
                default: !1
            },
            state: {
                type: String,
                default: "State Machine"
            },
            animations: {
                type: [String, Array],
                default: null
            },
            artboard: {
                type: String,
                default: "Artboard"
            },
            autoplay: {
                type: Boolean,
                default: !0
            },
            active: {
                type: Boolean,
                default: null
            },
            options: {
                type: Object,
                default: () => ({})
            },
            width: {
                type: [String, Number],
                default: null
            },
            height: {
                type: [String, Number],
                default: null
            }
        },
        emits: ["load"],
        data() {
            return {
                artWidth: null,
                artHeight: null
            }
        },
        mounted() {
            this.riveInit()
        },
        beforeUnmount() {
            this.$rive && this.$rive.cleanup()
        },
        watch: {
            artWidth() {
                const e = this;
                e.$nextTick(() => {
                    e.$rive && e.$rive.resizeToCanvas()
                })
            },
            artHeight() {
                const e = this;
                e.$nextTick(() => {
                    e.$rive && e.$rive.resizeToCanvas()
                })
            },
            active(e) {
                this.activeInput && (this.activeInput.value = e)
            }
        },
        methods: {
            riveInit() {
                const e = this,
                    t = e.local ? new URL(Object.assign({})[`/src/assets/rive/${e.src}`], self.location).href : e.src;
                t && (e.$rive = new ja.Rive({
                    src: t,
                    autoplay: e.autoplay,
                    canvas: e.$refs.canvas,
                    stateMachines: e.state,
                    animations: e.animations,
                    artboard: e.artboard,
                    isTouchScrollEnabled: !0,
                    layout: new ja.Layout({
                        fit: ja.Fit.Cover,
                        alignment: ja.Alignment.Center
                    }),
                    onLoad: () => {
                        if (e.artWidth = e.$rive.bounds.maxX, e.artHeight = e.$rive.bounds.maxY, e.active !== null) {
                            const n = e.$rive.stateMachineInputs(e.state) || [];
                            e.activeInput = n.find(r => r.name === "isActive"), e.activeInput !== void 0 && (e.activeInput.value = e.active)
                        }
                        e.$emit("load", e.$rive)
                    },
                    ...e.options
                }))
            }
        }
    },
    NP = ["width", "height"];

function FP(e, t, n, r, i, s) {
    return Q(), pe("canvas", {
        ref: "canvas",
        width: n.width || i.artWidth,
        height: n.height || i.artHeight
    }, null, 8, NP)
}
const DP = Ee(LP, [
        ["render", FP]
    ]),
    jP = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: DP
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    BP = {
        props: {
            link: {
                type: [String, Object, Boolean],
                default: null
            },
            label: {
                type: String,
                default: null
            },
            text: {
                type: String,
                default: null
            },
            tag: {
                type: String,
                default: null
            }
        },
        computed: {
            options() {
                const e = this.link;
                return qt(e) ? {
                    path: e.path,
                    external: e.external,
                    text: this.text || e.text
                } : {
                    path: e,
                    external: /http:|https:|mailto:|tel:/.test(e),
                    text: this.text
                }
            },
            component() {
                return this.tag ? this.tag : this.options.external ? "a" : this.options.path ? "router-link" : "button"
            },
            ariaLabel() {
                return this.label || this.options.text
            },
            to() {
                return this.component !== "button" && !this.options.external ? this.options.path : null
            },
            href() {
                return this.component !== "button" ? this.options.path : null
            },
            target() {
                return this.component === "a" ? "_blank" : null
            },
            rel() {
                return this.component === "a" ? "noreferrer" : null
            },
            isActive() {
                if (this.options.path) {
                    const e = gt(this.$routing.post, "permalink.path", "");
                    if (this.options.path === e) return !0;
                    const t = e.split("/")[1];
                    if (this.options.path === "/" + t) return !0
                }
                return !1
            }
        }
    };

function VP(e, t, n, r, i, s) {
    return Q(), Et(kr(s.component), {
        to: s.to,
        href: s.href,
        target: s.target,
        "aria-label": s.ariaLabel,
        rel: s.rel,
        class: Ot({
            "--route-active": s.isActive
        })
    }, {
        default: Ct(() => [e.$slots.default ? Mt(e.$slots, "default", {
            key: 0
        }) : (Q(), pe(nt, {
            key: 1
        }, [Pr(Hi(s.options.text), 1)], 64))]),
        _: 3
    }, 8, ["to", "href", "target", "aria-label", "rel", "class"])
}
const HP = Ee(BP, [
        ["render", VP]
    ]),
    UP = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: HP
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    WP = {},
    zP = {
        d: "M12 8V12M12 16H12.01M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12Z",
        stroke: "currentColor",
        "stroke-width": "2",
        "stroke-linecap": "round",
        "stroke-linejoin": "round"
    };

function qP(e, t) {
    return Q(), pe("path", zP)
}
const KP = Ee(WP, [
        ["render", qP]
    ]),
    GP = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: KP
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    YP = {},
    XP = {
        d: "M20 7L9 19L4 13",
        stroke: "currentColor",
        "stroke-width": "2",
        "stroke-linecap": "round",
        "stroke-linejoin": "round"
    };

function JP(e, t) {
    return Q(), pe("path", XP)
}
const ZP = Ee(YP, [
        ["render", JP]
    ]),
    QP = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: ZP
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    eM = {},
    tM = {
        d: "M18 6L6 18M6 6L18 18",
        stroke: "currentColor",
        "stroke-width": "2",
        "stroke-linecap": "round",
        "stroke-linejoin": "round"
    };

function nM(e, t) {
    return Q(), pe("path", tM)
}
const rM = Ee(eM, [
        ["render", nM]
    ]),
    iM = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: rM
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    sM = {},
    oM = {
        d: "M21 9V3m0 0h-6m6 0-8 8m-3-6H5L3 7v12l2 2h12l2-2v-5",
        stroke: "currentColor",
        "stroke-width": "2",
        "stroke-linecap": "round",
        "stroke-linejoin": "round"
    };

function aM(e, t) {
    return Q(), pe("path", oM)
}
const lM = Ee(sM, [
        ["render", aM]
    ]),
    cM = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: lM
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    uM = {},
    fM = {
        d: "M15.75 2.25h-7.5v6h-6v7.5h6v6h7.5v-6h6v-7.5h-6v-6Zm-6 7.5v-6h4.5v6h6v4.5h-6v6h-4.5v-6h-6v-4.5h6Z",
        fill: "currentColor"
    };

function dM(e, t) {
    return Q(), pe("path", fM)
}
const hM = Ee(uM, [
        ["render", dM]
    ]),
    pM = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: hM
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    mM = {},
    gM = {
        d: "M9.09 9C9.3251 8.33167 9.78915 7.76811 10.4 7.40913C11.0108 7.05016 11.7289 6.91894 12.4272 7.03871C13.1255 7.15849 13.7588 7.52152 14.2151 8.06353C14.6713 8.60553 14.9211 9.29152 14.92 10C14.92 12 11.92 13 11.92 13M12 17H12.01M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12Z",
        stroke: "currentColor",
        "stroke-width": "2",
        "stroke-linecap": "round",
        "stroke-linejoin": "round"
    };

function _M(e, t) {
    return Q(), pe("path", gM)
}
const vM = Ee(mM, [
        ["render", _M]
    ]),
    yM = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: vM
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    bM = {},
    wM = qe("path", {
        d: "M14.75 15.75h-2v-6h-3.5v1.5h2v4.5h-2v1.5h5.5v-1.5Zm-2-7.5v-2h-1.5v2h1.5Z",
        fill: "currentColor"
    }, null, -1),
    SM = qe("path", {
        "fill-rule": "evenodd",
        d: "M12 1.25C6.06294 1.25 1.25 6.06294 1.25 12c0 5.9371 4.81294 10.75 10.75 10.75 5.9371 0 10.75-4.8129 10.75-10.75 0-5.93706-4.8129-10.75-10.75-10.75ZM2.75 12c0-5.10863 4.14137-9.25 9.25-9.25 5.1086 0 9.25 4.14137 9.25 9.25 0 5.1086-4.1414 9.25-9.25 9.25-5.10863 0-9.25-4.1414-9.25-9.25Z",
        "clip-rule": "evenodd",
        fill: "currentColor"
    }, null, -1);

function TM(e, t) {
    return Q(), pe(nt, null, [wM, SM], 64)
}
const CM = Ee(bM, [
        ["render", TM]
    ]),
    EM = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: CM
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    AM = {},
    xM = qe("path", {
        d: "M11.8034 8.16478c-.3731-.21024-.8072-.35122-1.2534-.4317V6.25H9.05005v1.42971c-.4767.05129-.94715.1711-1.35535.37529-.64603.32316-1.22931.92067-1.22931 1.82851 0 .90439.60651 1.44569 1.19112 1.76579.53821.2947 1.22674.4985 1.82847.6767l.10167.0301c.71275.2115 1.31335.3998 1.74255.6599.396.24.5208.4598.5208.7366 0 .2797-.1417.5287-.5056.7431-.38.2238-.9378.3588-1.53865.3542-.60089-.0046-1.15524-.148-1.53313-.3842-.35642-.2229-.52262-.4973-.52262-.8436v-.75h-1.5v.75c0 .9726.53382 1.6818 1.22742 2.1154.46536.291 1.01392.4697 1.57263.5541V17.75H10.55v-1.4483c.5534-.0757 1.0952-.2423 1.5557-.5136.686-.4041 1.2443-1.0841 1.2443-2.0355 0-.9871-.5846-1.6201-1.2433-2.0194-.6256-.3792-1.4249-.6167-2.0933-.8151l-.0117-.0035c-.67926-.2016-1.23083-.3653-1.62477-.581-.3804-.2083-.41154-.34954-.41154-.45009 0-.15459.07239-.32292.40036-.48698.34194-.17105.85297-.26578 1.40366-.24326.51829.02119.98629.14289 1.29759.31833.3108.17508.3522.32584.3522.41191v.74999h1.5v-.74999c0-.83108-.5423-1.39557-1.1158-1.71873Z",
        fill: "currentColor"
    }, null, -1),
    OM = qe("path", {
        "fill-rule": "evenodd",
        d: "M19.5 20.75c1.7949 0 3.25-1.4551 3.25-3.25V8.25h-5v-5H1.25v8.8064c-.00002 1.8378-.00003 3.2934.15314 4.4326.15762 1.1724.48974 2.1214 1.2381 2.8698.74837.7483 1.69732 1.0804 2.86974 1.2381 1.1392.1531 2.59482.1531 4.43256.1531H19.5ZM5.71085 19.1102c1.02766.1382 2.38233.1398 4.28915.1398h6.7609c-.3234-.5051-.5109-1.1057-.5109-1.75V4.75H2.75V12c0 1.9068.00159 3.2615.13976 4.2892.13526 1.006.38893 1.5857.81214 2.0089s1.00286.6769 2.00895.8121ZM19.5 19.25c-.9665 0-1.75-.7835-1.75-1.75V9.75h3.5v7.75c0 .9665-.7835 1.75-1.75 1.75Z",
        "clip-rule": "evenodd",
        fill: "currentColor"
    }, null, -1);

function PM(e, t) {
    return Q(), pe(nt, null, [xM, OM], 64)
}
const MM = Ee(AM, [
        ["render", PM]
    ]),
    RM = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: MM
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    IM = {},
    $M = {
        d: "M3 12H15M3 6H21M3 18H21",
        stroke: "currentColor",
        "stroke-width": "2",
        "stroke-linecap": "round",
        "stroke-linejoin": "round"
    };

function kM(e, t) {
    return Q(), pe("path", $M)
}
const LM = Ee(IM, [
        ["render", kM]
    ]),
    NM = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: LM
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    FM = {},
    DM = {
        d: "M19 19L13.0001 13M15 8C15 11.866 11.866 15 8 15C4.13401 15 1 11.866 1 8C1 4.13401 4.13401 1 8 1C11.866 1 15 4.13401 15 8Z",
        stroke: "currentColor",
        "stroke-width": "2",
        "stroke-linecap": "round",
        "stroke-linejoin": "round"
    };

function jM(e, t) {
    return Q(), pe("path", DM)
}
const BM = Ee(FM, [
        ["render", jM]
    ]),
    VM = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: BM
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    HM = {},
    UM = qe("path", {
        fill: "currentColor",
        "fill-rule": "evenodd",
        d: "M12.0223 4.92733 11.957 4.25h-1.914l-.0654.67799-.00053.00516-.00274.02538c-.00261.02343-.00683.05964-.01293.10731-.01221.09539-.0319.23632-.06123.41224-.05881.35271-.15561.84165-.30686 1.38402-.30954 1.10995-.81843 2.33684-1.6064 3.12481-.78797.78799-2.01486 1.29689-3.12481 1.60639-.54237.1513-1.03131.2481-1.38402.3069-.17592.0293-.31685.049-.41224.0612-.04767.0061-.08388.0103-.10731.0129l-.02538.0028-.00582.0006-.67733.0653v1.914l.67799.0654.00516.0005.02538.0028c.02343.0026.05964.0068.10731.0129.09539.0122.23632.0319.41224.0612.35271.0588.84165.1556 1.38402.3069 1.10995.3095 2.33684.8184 3.12481 1.6064.78797.788 1.29686 2.0149 1.6064 3.1248.15125.5424.24805 1.0313.30686 1.384.02933.1759.04902.3169.06123.4123.0061.0476.01032.0838.01293.1073l.00274.0254.0006.0058.06533.6773h1.914l.0654-.678.0005-.0051.0028-.0254c.0026-.0235.0068-.0597.0129-.1073.0122-.0954.0319-.2364.0612-.4123.0588-.3527.1556-.8416.3069-1.384.3095-1.1099.8184-2.3368 1.6064-3.1248.788-.788 2.0149-1.2969 3.1248-1.6064.5424-.1513 1.0313-.2481 1.384-.3069.1759-.0293.3169-.049.4123-.0612.0476-.0061.0838-.0103.1073-.0129l.0254-.0028.0058-.0006.6773-.0653v-1.914l-.678-.0654-.0051-.0005-.0254-.0028c-.0235-.0026-.0597-.0068-.1073-.0129-.0954-.0122-.2364-.0319-.4123-.0612-.3527-.0588-.8416-.1556-1.384-.3069-1.1099-.3095-2.3368-.8184-3.1248-1.60639-.788-.78797-1.2969-2.01486-1.6064-3.12481-.1513-.54237-.2481-1.03131-.3069-1.38402-.0293-.17592-.049-.31685-.0612-.41224-.0061-.04767-.0103-.08388-.0129-.10731l-.0028-.02538-.0006-.00582ZM9.04757 11.0476C10.0733 10.0219 10.6625 8.56417 11 7.39933c.3375 1.16484.9267 2.62257 1.9524 3.64827S15.4358 12.6625 16.6007 13c-1.1649.3375-2.6226.9267-3.6483 1.9524S11.3375 17.4358 11 18.6007c-.3375-1.1649-.9267-2.6226-1.95243-3.6483C8.02189 13.9267 6.56417 13.3375 5.39933 13c1.16484-.3375 2.62256-.9267 3.64824-1.9524Z",
        "clip-rule": "evenodd"
    }, null, -1),
    WM = qe("path", {
        fill: "currentColor",
        d: "M19.25 4.75v-2.5h-1.5v2.5h-2.5v1.5h2.5v2.5h1.5v-2.5h2.5v-1.5h-2.5Z"
    }, null, -1);

function zM(e, t) {
    return Q(), pe(nt, null, [UM, WM], 64)
}
const qM = Ee(HM, [
        ["render", zM]
    ]),
    KM = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: qM
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    GM = {},
    YM = qe("path", {
        fill: "currentColor",
        "fill-rule": "evenodd",
        d: "M9 2.25c-1.60676 0-2.9747.38262-3.92329 1.39898C4.13935 4.65328 3.75 6.13044 3.75 8c0 1.86956.38935 3.3467 1.32671 4.351C6.0253 13.3674 7.39324 13.75 9 13.75c1.6068 0 2.9747-.3826 3.9233-1.399C13.8606 11.3467 14.25 9.86956 14.25 8c0-1.86956-.3894-3.34672-1.3267-4.35102C11.9747 2.63262 10.6068 2.25 9 2.25ZM5.25 8c0-1.70187.36065-2.72471.92329-3.32755C6.7247 4.08166 7.60676 3.75 9 3.75c1.3932 0 2.2753.33166 2.8267.92245.5627.60284.9233 1.62568.9233 3.32755s-.3606 2.7247-.9233 3.3275c-.5514.5908-1.4335.9225-2.8267.9225-1.39324 0-2.2753-.3317-2.82671-.9225C5.61065 10.7247 5.25 9.70187 5.25 8Z",
        "clip-rule": "evenodd"
    }, null, -1),
    XM = qe("path", {
        fill: "currentColor",
        d: "M19.1804 4.42458C18.3997 3.5642 17.279 3.25 16 3.25h-.75v1.5H16c1.0543 0 1.6836.25723 2.0696.68256.4012.44222.6804 1.21845.6804 2.56744s-.2792 2.1252-.6804 2.5674c-.386.4254-1.0153.6826-2.0696.6826h-.75v1.5H16c1.279 0 2.3997-.3142 3.1804-1.1746C19.9458 10.7319 20.25 9.50815 20.25 8s-.3042-2.73192-1.0696-3.57542ZM15.0576 15.2522l-.7478-.0576-.1152 1.4956.7478.0576c1.579.1216 2.809.4517 3.6823 1.0957.8401.6196 1.4423 1.5991 1.6302 3.2417l.0852.7452 1.4903-.1705-.0853-.7451c-.2251-1.9693-.99-3.3639-2.2301-4.2785-1.2069-.8901-2.7704-1.2541-4.4574-1.3841ZM11.42 16.2569C9.68699 15.4544 7.43552 15.25 5 15.25H2.25v1.5H5c2.40636 0 4.37364.2123 5.7896.8681.6936.3212 1.2402.7426 1.645 1.2892.4049.5467.6956 1.2557.8221 2.193l.1004.7433 1.4865-.2007-.1003-.7432c-.1548-1.1461-.5245-2.1037-1.1033-2.8852-.5788-.7815-1.3392-1.3496-2.22-1.7576Z"
    }, null, -1);

function JM(e, t) {
    return Q(), pe(nt, null, [YM, XM], 64)
}
const ZM = Ee(GM, [
        ["render", JM]
    ]),
    QM = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: ZM
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    eR = {},
    tR = qe("path", {
        fill: "currentColor",
        "fill-rule": "evenodd",
        d: "M12.0001 2.25c-1.6068 0-2.97471.38262-3.9233 1.39898C7.13945 4.65328 6.75009 6.13044 6.75009 8c0 1.86956.38936 3.3467 1.32671 4.351.94859 1.0164 2.3165 1.399 3.9233 1.399 1.6068 0 2.9747-.3826 3.9233-1.399.9373-1.0043 1.3267-2.48144 1.3267-4.351 0-1.86956-.3894-3.34672-1.3267-4.35102C14.9748 2.63262 13.6069 2.25 12.0001 2.25ZM8.25009 8c0-1.70187.36065-2.72471.92329-3.32755C9.72479 4.08166 10.6069 3.75 12.0001 3.75s2.2753.33166 2.8267.92245c.5626.60284.9233 1.62568.9233 3.32755s-.3607 2.7247-.9233 3.3275c-.5514.5908-1.4335.9225-2.8267.9225-1.3932 0-2.27531-.3317-2.82672-.9225-.56264-.6028-.92329-1.62563-.92329-3.3275Z",
        "clip-rule": "evenodd"
    }, null, -1),
    nR = qe("path", {
        fill: "currentColor",
        d: "M12.0001 15.25c-2.43553 0-4.687.2044-6.41996 1.0069-.88086.408-1.64124.9761-2.22007 1.7576-.57881.7815-.94852 1.7391-1.10324 2.8852l-.10034.7432 1.48652.2007.10034-.7433c.12653-.9373.41722-1.6463.8221-2.193.40485-.5466.95147-.968 1.64506-1.2892 1.41594-.6558 3.38322-.8681 5.78959-.8681 2.4064 0 4.3736.2123 5.7896.8681.6936.3212 1.2402.7426 1.645 1.2892.4049.5467.6956 1.2557.8221 2.193l.1004.7433 1.4865-.2007-.1004-.7432c-.1547-1.1461-.5244-2.1037-1.1032-2.8852-.5788-.7815-1.3392-1.3496-2.2201-1.7576-1.7329-.8025-3.9844-1.0069-6.4199-1.0069Z"
    }, null, -1);

function rR(e, t) {
    return Q(), pe(nt, null, [tR, nR], 64)
}
const iR = Ee(eR, [
        ["render", rR]
    ]),
    sR = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: iR
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    oR = {},
    aR = {
        d: "M12 5V19M12 19L19 12M12 19L5 12",
        stroke: "currentColor",
        "stroke-width": "2",
        "stroke-linecap": "round",
        "stroke-linejoin": "round"
    };

function lR(e, t) {
    return Q(), pe("path", aR)
}
const cR = Ee(oR, [
        ["render", lR]
    ]),
    uR = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: cR
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    fR = {},
    dR = {
        d: "M19 12H5M5 12L12 19M5 12L12 5",
        stroke: "currentColor",
        "stroke-width": "2",
        "stroke-linecap": "round",
        "stroke-linejoin": "round"
    };

function hR(e, t) {
    return Q(), pe("path", dR)
}
const pR = Ee(fR, [
        ["render", hR]
    ]),
    mR = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: pR
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    gR = {},
    _R = {
        d: "M5 12H19M19 12L12 5M19 12L12 19",
        stroke: "currentColor",
        "stroke-width": "2",
        "stroke-linecap": "round",
        "stroke-linejoin": "round"
    };

function vR(e, t) {
    return Q(), pe("path", _R)
}
const yR = Ee(gR, [
        ["render", vR]
    ]),
    bR = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: yR
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    wR = {},
    SR = {
        d: "M12 19V5M12 5L5 12M12 5L19 12",
        stroke: "currentColor",
        "stroke-width": "2",
        "stroke-linecap": "round",
        "stroke-linejoin": "round"
    };

function TR(e, t) {
    return Q(), pe("path", SR)
}
const CR = Ee(wR, [
        ["render", TR]
    ]),
    ER = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: CR
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    AR = {},
    xR = {
        d: "M6 9L12 15L18 9",
        stroke: "currentColor",
        "stroke-width": "2",
        "stroke-linecap": "round",
        "stroke-linejoin": "round"
    };

function OR(e, t) {
    return Q(), pe("path", xR)
}
const PR = Ee(AR, [
        ["render", OR]
    ]),
    MR = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: PR
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    RR = {},
    IR = {
        d: "M15 18L9 12L15 6",
        stroke: "currentColor",
        "stroke-width": "2",
        "stroke-linecap": "round",
        "stroke-linejoin": "round"
    };

function $R(e, t) {
    return Q(), pe("path", IR)
}
const kR = Ee(RR, [
        ["render", $R]
    ]),
    LR = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: kR
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    NR = {},
    FR = {
        d: "M9 18L15 12L9 6",
        stroke: "currentColor",
        "stroke-width": "2",
        "stroke-linecap": "round",
        "stroke-linejoin": "round"
    };

function DR(e, t) {
    return Q(), pe("path", FR)
}
const jR = Ee(NR, [
        ["render", DR]
    ]),
    BR = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: jR
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    VR = {},
    HR = {
        d: "M18 15L12 9L6 15",
        stroke: "currentColor",
        "stroke-width": "2",
        "stroke-linecap": "round",
        "stroke-linejoin": "round"
    };

function UR(e, t) {
    return Q(), pe("path", HR)
}
const WR = Ee(VR, [
        ["render", UR]
    ]),
    zR = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: WR
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    qR = {},
    KR = {
        d: "M7 15L12 20L17 15M7 9L12 4L17 9",
        stroke: "currentColor",
        "stroke-width": "2",
        "stroke-linecap": "round",
        "stroke-linejoin": "round"
    };

function GR(e, t) {
    return Q(), pe("path", KR)
}
const YR = Ee(qR, [
        ["render", GR]
    ]),
    XR = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: YR
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    JR = {},
    ZR = {
        d: "M5 12H19",
        stroke: "currentColor",
        "stroke-width": "2",
        "stroke-linecap": "round",
        "stroke-linejoin": "round"
    };

function QR(e, t) {
    return Q(), pe("path", ZR)
}
const e5 = Ee(JR, [
        ["render", QR]
    ]),
    t5 = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: e5
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    n5 = {},
    r5 = {
        d: "M12 5V19M5 12H19",
        stroke: "currentColor",
        "stroke-width": "2",
        "stroke-linecap": "round",
        "stroke-linejoin": "round"
    };

function i5(e, t) {
    return Q(), pe("path", r5)
}
const s5 = Ee(n5, [
        ["render", i5]
    ]),
    o5 = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: s5
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    a5 = {},
    l5 = {
        d: "M22 8.99993L16 14.9999M16 8.99993L22 14.9999M9.63432 5.36561L6.46863 8.5313C6.29568 8.70425 6.2092 8.79073 6.10828 8.85257C6.01881 8.9074 5.92127 8.9478 5.81923 8.9723C5.70414 8.99993 5.58185 8.99993 5.33726 8.99993H3.6C3.03995 8.99993 2.75992 8.99993 2.54601 9.10892C2.35785 9.20479 2.20487 9.35777 2.10899 9.54594C2 9.75985 2 10.0399 2 10.5999V13.3999C2 13.96 2 14.24 2.10899 14.4539C2.20487 14.6421 2.35785 14.7951 2.54601 14.8909C2.75992 14.9999 3.03995 14.9999 3.6 14.9999H5.33726C5.58185 14.9999 5.70414 14.9999 5.81923 15.0276C5.92127 15.0521 6.01881 15.0925 6.10828 15.1473C6.2092 15.2091 6.29568 15.2956 6.46863 15.4686L9.63431 18.6342C10.0627 19.0626 10.2769 19.2768 10.4608 19.2913C10.6203 19.3038 10.7763 19.2392 10.8802 19.1175C11 18.9773 11 18.6744 11 18.0686V5.9313C11 5.32548 11 5.02257 10.8802 4.88231C10.7763 4.76061 10.6203 4.69602 10.4608 4.70858C10.2769 4.72305 10.0627 4.93724 9.63432 5.36561Z",
        stroke: "currentColor",
        "stroke-width": "2",
        "stroke-linecap": "round",
        "stroke-linejoin": "round",
        fill: "none"
    };

function c5(e, t) {
    return Q(), pe("path", l5)
}
const u5 = Ee(a5, [
        ["render", c5]
    ]),
    f5 = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: u5
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    d5 = {},
    h5 = {
        d: "M5 4.98951C5 4.01835 5 3.53277 5.20249 3.2651C5.37889 3.03191 5.64852 2.88761 5.9404 2.87018C6.27544 2.85017 6.67946 3.11953 7.48752 3.65823L18.0031 10.6686C18.6708 11.1137 19.0046 11.3363 19.1209 11.6168C19.2227 11.8621 19.2227 12.1377 19.1209 12.383C19.0046 12.6635 18.6708 12.886 18.0031 13.3312L7.48752 20.3415C6.67946 20.8802 6.27544 21.1496 5.9404 21.1296C5.64852 21.1122 5.37889 20.9679 5.20249 20.7347C5 20.467 5 19.9814 5 19.0103V4.98951Z",
        stroke: "currentColor",
        "stroke-width": "2",
        "stroke-linecap": "round",
        "stroke-linejoin": "round",
        fill: "none"
    };

function p5(e, t) {
    return Q(), pe("path", h5)
}
const m5 = Ee(d5, [
        ["render", p5]
    ]),
    g5 = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: m5
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    _5 = {},
    v5 = {
        d: "M19.7479 4.99993C21.1652 6.97016 22 9.38756 22 11.9999C22 14.6123 21.1652 17.0297 19.7479 18.9999M15.7453 7.99993C16.5362 9.13376 17 10.5127 17 11.9999C17 13.4872 16.5362 14.8661 15.7453 15.9999M9.63432 5.36561L6.46863 8.5313C6.29568 8.70425 6.2092 8.79073 6.10828 8.85257C6.01881 8.9074 5.92127 8.9478 5.81923 8.9723C5.70414 8.99993 5.58185 8.99993 5.33726 8.99993H3.6C3.03995 8.99993 2.75992 8.99993 2.54601 9.10892C2.35785 9.20479 2.20487 9.35777 2.10899 9.54594C2 9.75985 2 10.0399 2 10.5999V13.3999C2 13.96 2 14.24 2.10899 14.4539C2.20487 14.6421 2.35785 14.7951 2.54601 14.8909C2.75992 14.9999 3.03995 14.9999 3.6 14.9999H5.33726C5.58185 14.9999 5.70414 14.9999 5.81923 15.0276C5.92127 15.0521 6.01881 15.0925 6.10828 15.1473C6.2092 15.2091 6.29568 15.2956 6.46863 15.4686L9.63431 18.6342C10.0627 19.0626 10.2769 19.2768 10.4608 19.2913C10.6203 19.3038 10.7763 19.2392 10.8802 19.1175C11 18.9773 11 18.6744 11 18.0686V5.9313C11 5.32548 11 5.02257 10.8802 4.88231C10.7763 4.76061 10.6203 4.69602 10.4608 4.70858C10.2769 4.72305 10.0627 4.93724 9.63432 5.36561Z",
        stroke: "currentColor",
        "stroke-width": "2",
        "stroke-linecap": "round",
        "stroke-linejoin": "round",
        fill: "none"
    };

function y5(e, t) {
    return Q(), pe("path", v5)
}
const b5 = Ee(_5, [
        ["render", y5]
    ]),
    w5 = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: b5
    }, Symbol.toStringTag, {
        value: "Module"
    }));
const S5 = {
        props: {
            link: {
                type: [String, Object],
                default: null
            },
            label: {
                type: String,
                default: null
            },
            text: {
                type: String,
                default: null
            },
            size: {
                type: String,
                default: null
            },
            expand: {
                type: Boolean,
                default: !1
            },
            round: {
                type: [String, Boolean],
                default: null
            },
            variant: {
                type: String,
                default: null
            },
            icon: {
                type: String,
                default: null
            },
            iconRight: {
                type: String,
                default: null
            },
            iconLeft: {
                type: String,
                default: null
            },
            disabled: {
                type: Boolean,
                default: !1
            },
            nested: {
                type: Boolean,
                default: !1
            }
        },
        computed: {
            buttonText() {
                const e = this;
                return e.text || gt(e.link, "text")
            },
            cssClasses() {
                const e = this;
                return [e.size ? "--" + e.size : null, e.expand ? "--expand" : null, e.round === !0 ? "--round" : e.round ? "--round-" + e.round : null, e.variant ? "--" + e.variant : null, e.icon && !e.expand ? "--icon-single" : null, e.iconLeft ? "--solo-icon" : null, e.iconRight ? "--solo-icon" : null]
            }
        }
    },
    T5 = {
        class: "ui-button_content --ui-center"
    };

function C5(e, t, n, r, i, s) {
    const o = vt("icon"),
        a = vt("route");
    return Q(), Et(a, {
        class: Ot(["ui-button", s.cssClasses]),
        link: n.link,
        label: n.label,
        text: n.text,
        disabled: n.disabled,
        tag: n.nested ? "div" : null
    }, {
        default: Ct(() => [qe("span", T5, [e.$slots.default ? Mt(e.$slots, "default", {
            key: 0
        }) : n.icon ? (Q(), Et(o, {
            key: 1,
            name: n.icon
        }, null, 8, ["name"])) : (Q(), pe(nt, {
            key: 2
        }, [n.iconLeft ? (Q(), Et(o, {
            key: 0,
            name: n.iconLeft
        }, null, 8, ["name"])) : dt("", !0), Pr(" " + Hi(s.buttonText) + " ", 1), n.iconRight ? (Q(), Et(o, {
            key: 1,
            name: n.iconRight
        }, null, 8, ["name"])) : dt("", !0)], 64))])]),
        _: 3
    }, 8, ["class", "link", "label", "text", "disabled", "tag"])
}
const E5 = Ee(S5, [
        ["render", C5]
    ]),
    A5 = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: E5
    }, Symbol.toStringTag, {
        value: "Module"
    }));
const x5 = {
        props: {
            hero: {
                type: Boolean,
                default: !1
            },
            dark: {
                type: Boolean,
                default: !1
            }
        }
    },
    O5 = {
        class: "ui-card_gradient --ui-card --ui-relative"
    },
    P5 = {
        class: "ui-card_content --ui-x --ui-px --type-center --ui-space-sm"
    };

function M5(e, t, n, r, i, s) {
    const o = vt("ui-gradient"),
        a = vt("ui-tag");
    return Q(), pe("div", {
        class: Ot(["ui-card --ui-x-outer --ui-px-sm", {
            "--hero": n.hero,
            "--dark": n.dark
        }])
    }, [qe("div", O5, [Pe(o, {
        colors: ["spot-2", "pom-1", "pom-3", n.dark ? "pom-4" : "soft-1"],
        immediate: n.hero,
        flush: ""
    }, null, 8, ["colors", "immediate"]), qe("div", P5, [Mt(e.$slots, "before"), e.$slots.tag ? (Q(), Et(a, {
        key: 0,
        variant: n.hero ? n.dark ? "pom" : "dark" : null,
        size: "lg",
        delay: 200
    }, {
        default: Ct(() => [Mt(e.$slots, "tag")]),
        _: 3
    }, 8, ["variant"])) : dt("", !0), Mt(e.$slots, "default")]), Mt(e.$slots, "after")])], 2)
}
const R5 = Ee(x5, [
        ["render", M5]
    ]),
    I5 = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: R5
    }, Symbol.toStringTag, {
        value: "Module"
    }));
const $5 = {
        props: {
            expanded: {
                type: Boolean,
                default: null
            },
            transition: {
                type: String,
                default: null
            },
            show: {
                type: Boolean,
                default: null
            }
        },
        methods: {
            onAfterEnter(e) {
                e.style.height = "auto"
            },
            onEnter(e) {
                const {
                    width: t
                } = getComputedStyle(e);
                e.style.width = t, e.style.position = "absolute", e.style.visibility = "hidden", e.style.height = "auto";
                const {
                    height: n
                } = getComputedStyle(e);
                e.style.width = null, e.style.position = null, e.style.visibility = null, e.style.height = 0, getComputedStyle(e).height, requestAnimationFrame(() => {
                    e.style.height = n
                })
            },
            onLeave(e) {
                const {
                    height: t
                } = getComputedStyle(e);
                e.style.height = t, getComputedStyle(e).height, requestAnimationFrame(() => {
                    e.style.height = 0
                })
            }
        }
    },
    k5 = {
        key: 0,
        class: "ui-expand_content"
    },
    L5 = {
        key: 0,
        class: "ui-expand_content"
    };

function N5(e, t, n, r, i, s) {
    return Q(), Et(Mr, {
        name: "ui-expand",
        class: Ot(n.transition ? "--" + n.transition : ""),
        onAfterEnter: s.onAfterEnter,
        onEnter: s.onEnter,
        onLeave: s.onLeave
    }, {
        default: Ct(() => [n.show ? zt((Q(), pe("div", k5, [Mt(e.$slots, "default")], 512)), [
            [Oo, n.expanded]
        ]) : (Q(), pe(nt, {
            key: 1
        }, [n.expanded ? (Q(), pe("div", L5, [Mt(e.$slots, "default")])) : dt("", !0)], 64))]),
        _: 3
    }, 8, ["class", "onAfterEnter", "onEnter", "onLeave"])
}
const F5 = Ee($5, [
        ["render", N5]
    ]),
    D5 = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: F5
    }, Symbol.toStringTag, {
        value: "Module"
    }));
const j5 = {
        props: {
            size: {
                type: Number,
                default: 32
            },
            height: {
                type: Number,
                default: .6
            },
            colors: {
                type: Array,
                default: () => ["pom-1", "pom-2", "pom-3", "soft-1"]
            },
            flip: {
                type: Boolean,
                default: !1
            },
            flush: {
                type: Boolean,
                default: !1
            },
            immediate: {
                type: Boolean,
                default: !1
            }
        },
        computed: {
            responsiveSize() {
                const e = this;
                return e.$window.width, e._isBelow("sm") ? e.size * 3 : e._isBelow("md") ? e.size * 2 : e._isBelow("lg") ? e.size * 1.5 : e.size
            },
            layers() {
                const e = this;
                return af(e.colors, (t, n) => {
                    const r = this._window.data("colors[" + t.replace("-", ".") + "]"),
                        i = n * e.responsiveSize * (e.colors.length * e.height - n * e.height / 2);
                    return {
                        color: r,
                        y: i
                    }
                })
            },
            totalHeight() {
                const e = this;
                return OS(e.layers, "y").y + e.responsiveSize
            }
        },
        mounted() {
            Bs(() => {
                this.animeInit()
            }, 100)
        },
        methods: {
            animeInit() {
                const e = this;
                ji(e.$refs.gradient.querySelectorAll("rect"), {
                    scaleY: [0, 1],
                    autoplay: e.immediate ? !0 : Bi({
                        target: e.$refs.gradient
                    }),
                    ease: "outExpo",
                    duration: Nu(500)
                })
            }
        }
    },
    B5 = ["viewBox"],
    V5 = ["fill", "rx", "y"];

function H5(e, t, n, r, i, s) {
    return Q(), pe("div", {
        class: Ot(["ui-gradient", {
            "--flip": n.flip,
            "--flush": n.flush
        }]),
        ref: "gradient"
    }, [(Q(), pe("svg", {
        class: "ui-gradient_svg",
        xmlns: "http://www.w3.org/2000/svg",
        preserveAspectRatio: "xMinYMin meet",
        viewBox: "0 0 1440 " + s.totalHeight,
        "aria-label": "Gradient",
        fill: "none",
        role: "img"
    }, [(Q(!0), pe(nt, null, Wi(s.layers, o => (Q(), pe("rect", {
        fill: o.color,
        width: "1440",
        height: "999",
        rx: s.responsiveSize,
        y: o.y,
        "stroke-width": "2",
        "vector-effect": "non-scaling-stroke"
    }, null, 8, V5))), 256))], 8, B5))], 2)
}
const U5 = Ee(j5, [
        ["render", H5]
    ]),
    W5 = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: U5
    }, Symbol.toStringTag, {
        value: "Module"
    }));
const z5 = {
        props: {
            media: {
                type: [String, Object],
                default: null
            },
            alt: {
                type: String,
                default: ""
            },
            width: {
                type: [String, Number],
                default: null
            },
            height: {
                type: [String, Number],
                default: null
            },
            loading: {
                type: String,
                default: "lazy"
            },
            retina: {
                type: Boolean,
                default: !0
            },
            placeholder: {
                type: Boolean,
                default: !1
            },
            thumb: {
                type: [String, Array],
                default: ""
            }
        },
        computed: {
            options() {
                const e = this,
                    t = e.media;
                return qt(t) ? {
                    id: t.id,
                    extention: t.extention,
                    text: e.alt || t.text || null,
                    src: t.src
                } : {
                    id: null,
                    extention: t ? t.split(".").pop() : "",
                    text: e.alt || null,
                    src: t
                }
            },
            thumbs() {
                const e = this;
                let t = [];
                return e.thumb && e.options.id && lf(["jpeg", "jpg", "png", "pdf"], e.options.extention) && (on(e.thumb) ? t = af(e.thumb, n => {
                    const r = qt(n) ? Object.keys(n)[0] : 0,
                        i = qt(n) ? Object.values(n)[0] : n;
                    return {
                        size: r,
                        name: i
                    }
                }) : t.push({
                    size: 0,
                    name: e.thumb
                })), t.reverse()
            },
            imageSrc() {
                const e = this;
                return e.thumbs.length ? e.sourceSet(mS(e.thumbs).name) : e.options.src
            }
        },
        methods: {
            sourceMedia(e) {
                const t = this._window.data("screens"),
                    n = Wo(e) ? t[e] : e;
                return n ? "(min-width: " + n + "px)" : null
            },
            sourceSet(e, t) {
                const n = this,
                    r = "/thumbs/" + n.options.id + "_" + e,
                    i = n.placeholder ? "-placeholder" : "",
                    s = n.retina && n._window.data("retina") ? "-retina" : "";
                let o = "." + n.options.extention;
                return n.options.extention === "pdf" ? o = "_" + n.options.extention + ".jpg" : t && (o = "_" + n.options.extention + ".webp"), r + i + s + o
            }
        }
    },
    q5 = {
        class: "ui-image"
    },
    K5 = ["media", "srcset"],
    G5 = ["media", "srcset", "type"],
    Y5 = ["src", "alt", "aria-hidden", "width", "height", "loading"];

function X5(e, t, n, r, i, s) {
    return Q(), pe("picture", q5, [(Q(!0), pe(nt, null, Wi(s.thumbs, o => (Q(), pe("source", {
        media: s.sourceMedia(o.size),
        srcset: s.sourceSet(o.name, !0),
        type: "image/webp"
    }, null, 8, K5))), 256)), (Q(!0), pe(nt, null, Wi(s.thumbs, o => (Q(), pe("source", {
        media: s.sourceMedia(o.size),
        srcset: s.sourceSet(o.name),
        type: "image/" + s.options.extention
    }, null, 8, G5))), 256)), qe("img", {
        src: s.imageSrc,
        alt: s.options.text,
        "aria-hidden": s.options.text ? null : "true",
        width: n.width,
        height: n.height,
        loading: n.loading
    }, null, 8, Y5)])
}
const J5 = Ee(z5, [
        ["render", X5]
    ]),
    Z5 = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: J5
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    Q5 = {
        props: {
            media: {
                type: [String, Object],
                default: null
            },
            width: {
                type: [String, Number],
                default: null
            },
            height: {
                type: [String, Number],
                default: null
            },
            delay: {
                type: Number,
                default: null
            },
            alt: null,
            loading: null,
            retina: null,
            placeholder: null,
            thumb: null
        },
        data() {
            return {
                load: !1,
                isActive: !1
            }
        },
        computed: {
            riveSrc() {
                const t = this.media;
                return qt(t) ? t.src : t
            }
        },
        mounted() {
            this.animeInit()
        },
        watch: {
            delay: {
                handler(e) {
                    e !== null && Bs(() => {
                        this.load = !0
                    }, e)
                },
                immediate: !0
            }
        },
        methods: {
            animeInit() {
                const e = this;
                ji(e.$refs.rive, {
                    opacity: {
                        from: 0,
                        duration: 50,
                        ease: "linear"
                    },
                    autoplay: Bi({
                        enter: "center+=3em top"
                    }),
                    onBegin: () => {
                        e.isActive = !0
                    }
                })
            }
        }
    },
    e6 = {
        class: "ui-rive",
        ref: "rive"
    };

function t6(e, t, n, r, i, s) {
    const o = vt("rive", !0);
    return Q(), pe("div", e6, [s.riveSrc && i.load ? (Q(), Et(o, {
        key: 0,
        src: s.riveSrc,
        width: n.width,
        height: n.height,
        active: i.isActive
    }, null, 8, ["src", "width", "height", "active"])) : dt("", !0)], 512)
}
const n6 = Ee(Q5, [
        ["render", t6]
    ]),
    r6 = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: n6
    }, Symbol.toStringTag, {
        value: "Module"
    }));
const i6 = {
    props: {
        active: {
            type: Boolean,
            default: !0
        },
        fadeTop: {
            type: Boolean,
            default: !0
        },
        fadeBottom: {
            type: Boolean,
            default: !0
        },
        tag: {
            type: String,
            default: "div"
        },
        container: {
            type: Object,
            default: {}
        }
    },
    data() {
        return {
            top: !1,
            bottom: !1
        }
    },
    mounted() {
        const e = this;
        e.scroll(), fP(e.$refs.scrollbar, "scroll", e.scroll), uP(e.$refs.scrollbar, t => {
            e.scroll()
        }, {
            childList: !0,
            subtree: !0
        })
    },
    computed: {
        color() {
            const e = this;
            return e._window.data("colors." + e.fadeColor) || null
        }
    },
    watch: {
        active() {
            this.scroll()
        }
    },
    methods: {
        scroll() {
            const e = this,
                t = e.$refs.scrollbar;
            if (!e.active) {
                e.top = !0, e.bottom = !0;
                return
            }
            t && (e.top = Math.floor(t.scrollTop) < 1, e.bottom = Math.abs(t.scrollHeight - t.scrollTop - t.clientHeight) < 1)
        }
    }
};

function s6(e, t, n, r, i, s) {
    return Q(), pe("div", {
        class: Ot(["ui-scroll", {
            "--fade-top": n.fadeTop && !i.top,
            "--fade-bottom": n.fadeBottom && !i.bottom,
            "--fade-large": n.fadeBottom && !i.bottom && i.top
        }])
    }, [(Q(), Et(kr(n.tag), ui({
        ref: "scrollbar"
    }, n.container, {
        class: {
            "--app-scrollbar": n.active
        }
    }), {
        default: Ct(() => [Mt(e.$slots, "default")]),
        _: 3
    }, 16, ["class"]))], 2)
}
const o6 = Ee(i6, [
        ["render", s6]
    ]),
    a6 = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: o6
    }, Symbol.toStringTag, {
        value: "Module"
    }));
const l6 = {
        components: {
            "ui-skeleton-lazy": {
                template: "<slot />",
                props: ["delay"],
                async setup(e) {
                    return await new Promise(t => {
                        if (e.delay === 0) {
                            t();
                            return
                        }
                        Bs(t, e.delay)
                    })
                }
            }
        },
        props: {
            delay: {
                type: Number,
                default: 0
            }
        }
    },
    c6 = {
        key: 0,
        class: "ui-skeleton --ui-space"
    },
    u6 = qe("div", {
        class: "--skeleton-default"
    }, null, -1),
    f6 = {
        class: "ui-skeleton --ui-space"
    },
    d6 = qe("div", {
        class: "--skeleton-default"
    }, null, -1);

function h6(e, t, n, r, i, s) {
    const o = vt("ui-skeleton-lazy");
    return n.delay < 0 ? (Q(), pe("div", c6, [Mt(e.$slots, "default", {}, () => [u6])])) : (Q(), Et(Dg, {
        key: 1
    }, {
        fallback: Ct(() => [qe("div", f6, [Mt(e.$slots, "default", {}, () => [d6])])]),
        default: Ct(() => [Pe(o, {
            delay: n.delay
        }, {
            default: Ct(() => [Mt(e.$slots, "lazy")]),
            _: 3
        }, 8, ["delay"])]),
        _: 3
    }))
}
const p6 = Ee(l6, [
        ["render", h6]
    ]),
    m6 = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: p6
    }, Symbol.toStringTag, {
        value: "Module"
    }));
const g6 = {
        props: {
            text: {
                type: String,
                default: null
            },
            size: {
                type: String,
                default: null
            },
            variant: {
                type: String,
                default: null
            },
            delay: {
                type: Number,
                default: 80
            }
        },
        computed: {
            cssClasses() {
                const e = this;
                return [e.size ? "--" + e.size : null, e.variant ? "--" + e.variant : null]
            }
        },
        mounted() {
            this.animeInit()
        },
        methods: {
            animeInit() {
                ji(this.$refs.tag, {
                    scaleX: {
                        from: .66
                    },
                    opacity: {
                        from: 0,
                        duration: 50,
                        ease: "linear"
                    },
                    duration: 1200,
                    delay: this.delay,
                    ease: "outElastic(1, .5)",
                    autoplay: Bi({
                        enter: "center+=3em top"
                    })
                })
            }
        }
    },
    _6 = {
        class: "ui-tag_content --ui-center"
    };

function v6(e, t, n, r, i, s) {
    return Q(), pe("span", {
        class: Ot(["ui-tag", s.cssClasses]),
        ref: "tag"
    }, [qe("span", _6, [Mt(e.$slots, "default", {}, () => [Pr(Hi(n.text), 1)])])], 2)
}
const y6 = Ee(g6, [
        ["render", v6]
    ]),
    b6 = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: y6
    }, Symbol.toStringTag, {
        value: "Module"
    }));
const w6 = {
        props: {
            media: {
                type: [String, Object],
                default: null
            },
            autoplay: {
                type: Boolean,
                default: !1
            },
            audio: {
                type: Boolean,
                default: !1
            },
            poster: {
                type: [String, Object],
                default: null
            },
            thumb: {
                type: [String, Array],
                default: ""
            },
            alt: {
                type: String,
                default: ""
            },
            loop: {
                type: Boolean,
                default: !0
            },
            autoPause: {
                type: Boolean,
                default: !0
            }
        },
        data() {
            return {
                show: !1,
                playing: !1,
                muted: !0,
                width: 0,
                height: 0
            }
        },
        created() {
            const e = this;
            e.show = !e.usePoster, e.playing = !e.usePoster, e.muted = !0
        },
        mounted() {
            const e = this,
                t = e.$refs.video;
            e.autoPause && Py(t, ([{
                isIntersecting: n
            }]) => {
                !t || !t.playing || (n && t.paused ? t.play() : t.pause())
            })
        },
        computed: {
            options() {
                const e = this,
                    t = this.media;
                return qt(t) ? {
                    id: t.id,
                    extention: t.extention,
                    text: e.alt || t.text || null,
                    src: t.id ? "/api/media-stream/" + t.id + "." + t.extention + "/" : t.src,
                    autoplay: t.autoplay || null,
                    audio: t.audio || null,
                    poster: e.poster || t.poster || null
                } : {
                    id: null,
                    extention: t ? nT(t.split(".").pop(), "/") : "",
                    text: e.alt || null,
                    src: t,
                    autoplay: e.autoplay,
                    audio: e.audio,
                    poster: e.poster || null
                }
            },
            usePoster() {
                return !this.options.autoplay && this.options.poster
            },
            component() {
                return this.usePoster || this.options.audio ? "button" : "div"
            },
            ariaLabel() {
                return this.usePoster ? this.playing ? "Pause" : "Play" : this.options.audio ? this.muted ? "Unmute" : "Mute" : null
            }
        },
        methods: {
            videoDetails() {
                const e = this,
                    t = e.$refs.video;
                t && (e.width = t.videoWidth, e.height = t.videoHeight)
            },
            clickVideo() {
                const e = this,
                    t = e.$refs.video;
                if (!(!t || e.component !== "button")) {
                    if (e.usePoster) {
                        e.show ? e.playing ? (e.playing = !1, t.pause()) : (e.playing = !0, t.play()) : (e.show = !0, e.playing = !0, e.muted = !1);
                        return
                    }
                    if (e.options.audio) {
                        e.muted = !e.muted, t.muted = e.muted;
                        return
                    }
                }
            }
        }
    },
    S6 = ["defaultMuted", "muted", "loop"],
    T6 = ["type", "src"],
    C6 = {
        key: 0
    },
    E6 = {
        class: "ui-video_paused"
    };

function A6(e, t, n, r, i, s) {
    const o = vt("media"),
        a = vt("icon");
    return Q(), Et(kr(s.component), {
        style: ns({
            aspectRatio: i.width / i.height
        }),
        "aria-label": s.ariaLabel,
        onClick: s.clickVideo,
        class: "ui-video"
    }, {
        default: Ct(() => [zt(qe("video", {
            onLoadedmetadata: t[0] || (t[0] = (...l) => s.videoDetails && s.videoDetails(...l)),
            defaultMuted: i.muted,
            muted: i.muted,
            loop: n.loop,
            preload: "metadata",
            ref: "video",
            disablePictureInPicture: "",
            disableRemotePlayback: "",
            playsinline: "",
            autobuffer: "",
            autoplay: ""
        }, [qe("source", {
            type: "video/" + s.options.extention,
            src: s.options.src
        }, null, 8, T6)], 40, S6), [
            [Oo, i.show]
        ]), zt(Pe(o, {
            media: s.options.poster,
            alt: s.options.alt,
            thumb: n.thumb,
            width: i.width,
            height: i.height
        }, null, 8, ["media", "alt", "thumb", "width", "height"]), [
            [Oo, !i.show]
        ]), Pe(Mr, {
            name: "ui-video_fade"
        }, {
            default: Ct(() => [i.playing ? dt("", !0) : (Q(), pe("div", C6, [qe("div", E6, [Pe(a, {
                name: "media-play"
            })])]))]),
            _: 1
        }), Pe(Mr, {
            name: "ui-video_fade"
        }, {
            default: Ct(() => [s.options.audio && i.playing ? (Q(), pe("div", {
                key: i.muted ? "muted" : "unmuted"
            }, [(Q(), pe("div", {
                class: "ui-video_tl --ui-video_fade-out",
                key: i.muted ? "muted" : "unmuted"
            }, [Pe(a, {
                name: "media-" + (i.muted ? "muted" : "unmuted")
            }, null, 8, ["name"])]))])) : dt("", !0)]),
            _: 1
        })]),
        _: 1
    }, 8, ["style", "aria-label", "onClick"])
}
const x6 = Ee(w6, [
        ["render", A6]
    ]),
    O6 = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: x6
    }, Symbol.toStringTag, {
        value: "Module"
    }));
const P6 = {
        props: {
            items: {
                type: Array,
                default: () => []
            }
        },
        data() {
            return {
                active: 0
            }
        }
    },
    M6 = {
        class: "ui-accordion"
    },
    R6 = {
        class: "ui-accordion_item --ui-card"
    },
    I6 = ["onClick"],
    $6 = {
        class: "ui-accordion_header"
    },
    k6 = ["textContent"],
    L6 = ["innerHTML"];

function N6(e, t, n, r, i, s) {
    const o = vt("icon"),
        a = vt("ui-expand"),
        l = pt("orphans"),
        u = pt("nl2br"),
        f = pt("links");
    return Q(), pe("ul", M6, [(Q(!0), pe(nt, null, Wi(n.items, (h, _) => (Q(), pe("li", R6, [qe("article", null, [qe("button", {
        onClick: m => i.active = _,
        class: "ui-accordion_trigger"
    }, [qe("header", $6, [zt(qe("p", {
        class: "--type-subtitle",
        textContent: Hi(h.header.trim())
    }, null, 8, k6), [
        [l]
    ]), Pe(Mr, {
        name: "ui-accordion_icon",
        mode: "out-in"
    }, {
        default: Ct(() => [(Q(), pe("div", {
            class: Ot(["ui-accordion_icon --ui-icon", {
                "--active": i.active === _
            }]),
            key: i.active === _ ? "open" : "closed"
        }, [Pe(o, {
            name: i.active === _ ? "math-minus" : "math-plus"
        }, null, 8, ["name"])], 2))]),
        _: 2
    }, 1024)])], 8, I6), Pe(a, {
        expanded: _ === i.active,
        show: ""
    }, {
        default: Ct(() => [qe("div", {
            class: Ot(["ui-accordion_area", {
                "--active": i.active === _
            }])
        }, [Mt(e.$slots, "item", ui({
            ref_for: !0
        }, {
            item: h
        }), () => [zt(qe("p", {
            class: "--type-text",
            innerHTML: h.content.trim()
        }, null, 8, L6), [
            [l],
            [u],
            [f]
        ])])], 2)]),
        _: 2
    }, 1032, ["expanded"])])]))), 256))])
}
const Ry = Ee(P6, [
        ["render", N6]
    ]),
    pk = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: Ry
    }, Symbol.toStringTag, {
        value: "Module"
    }));
const F6 = {
        components: {
            "ui-accordion": Ry
        },
        props: {
            content: {
                type: Object,
                default: () => ({})
            }
        },
        computed: {
            style() {
                return gt(this.content, "style") || "media-accordion"
            },
            media() {
                const e = gt(this.content, "media", {});
                return e.src ? e : null
            },
            items() {
                const e = this;
                return lS(eT(5, t => {
                    const n = gt(e.content, "heading_" + (t + 1), "").trim(),
                        r = gt(e.content, "paragraph_" + (t + 1), "").trim();
                    return n && r && ![n, r].includes("<br>") ? {
                        header: n,
                        content: r
                    } : null
                }))
            }
        },
        mounted() {
            const e = this;
            e._motion.animateType({
                heading: e.$refs.heading,
                text: e.$refs.text,
                scroll: e.$refs.accordion
            }), e._motion.animateMedia({
                el: e.$refs.media
            }), lr(e.$refs.accordion.querySelectorAll(".ui-accordion_item"), (t, n) => {
                ji(t, {
                    x: {
                        from: e.style === "accordion-media" ? "-20%" : "20%"
                    },
                    opacity: {
                        from: 0,
                        duration: 100,
                        ease: "linear"
                    },
                    delay: n * 20,
                    duration: 1500,
                    ease: "outElastic(1, 1)",
                    autoplay: Bi({
                        enter: "center+=10em top"
                    })
                })
            })
        }
    },
    D6 = {
        ref: "accordion",
        class: "block-accordion"
    },
    j6 = {
        class: "--ui-space-sm --ui-py-lg --type-center"
    },
    B6 = ["innerHTML"],
    V6 = ["innerHTML"],
    H6 = {
        key: 0,
        ref: "media"
    };

function U6(e, t, n, r, i, s) {
    const o = vt("media"),
        a = vt("ui-accordion"),
        l = pt("orphans"),
        u = pt("nl2br"),
        f = pt("links");
    return Q(), pe("div", D6, [qe("div", j6, [n.content.heading ? zt((Q(), pe("h2", {
        key: 0,
        ref: "heading",
        class: "--ui-x-reduced --ui-px --type-title --type-cms --type-balance",
        innerHTML: n.content.heading
    }, null, 8, B6)), [
        [l],
        [u],
        [f]
    ]) : dt("", !0), n.content.text ? zt((Q(), pe("p", {
        key: 1,
        ref: "text",
        class: "--ui-x-narrow --ui-px --type-opening --type-cms",
        innerHTML: n.content.text
    }, null, 8, V6)), [
        [l],
        [u],
        [f]
    ]) : dt("", !0)]), qe("div", {
        class: Ot(["block-accordion_grid --ui-px-lg", [{
            "--with-media --ui-x-outer": s.media,
            "--ui-x-narrow": !s.media
        }, "--" + s.style]])
    }, [s.media ? (Q(), pe("div", H6, [Pe(o, {
        media: s.media,
        thumb: ["accordion-block", {
            md: "accordion-block-md"
        }],
        class: "--ui-card --ui-shadow"
    }, null, 8, ["media"])], 512)) : dt("", !0), Pe(a, {
        items: s.items
    }, null, 8, ["items"])], 2)], 512)
}
const W6 = Ee(F6, [
        ["render", U6]
    ]),
    z6 = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: W6
    }, Symbol.toStringTag, {
        value: "Module"
    }));
const q6 = {
        props: {
            content: {
                type: Object,
                default: () => ({})
            }
        }
    },
    K6 = {
        class: "block-blockquote --ui-x-narrow --ui-px --type-opening --type-cms"
    },
    G6 = ["innerHTML"];

function Y6(e, t, n, r, i, s) {
    const o = pt("orphans"),
        a = pt("nl2br"),
        l = pt("links");
    return Q(), pe("div", K6, [zt(qe("blockquote", {
        innerHTML: n.content.blockquote.trim()
    }, null, 8, G6), [
        [o],
        [a],
        [l]
    ])])
}
const X6 = Ee(q6, [
        ["render", Y6]
    ]),
    J6 = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: X6
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    Z6 = {
        props: {
            content: {
                type: Object,
                default: () => ({})
            }
        },
        computed: {
            button() {
                return this.content.button
            },
            buttonText() {
                return this.button.text.replace(/[←→]/g, "").trim()
            },
            arrowLeft() {
                return this.button.text.includes("←") ? "arrow-left" : null
            },
            arrowRight() {
                return this.button.text.includes("→") ? "arrow-right" : null
            }
        }
    },
    Q6 = {
        class: "block-button --ui-center --ui-x-slim --ui-px"
    };

function eI(e, t, n, r, i, s) {
    const o = vt("ui-button");
    return Q(), pe("div", Q6, [Pe(o, {
        link: s.button,
        text: s.buttonText,
        "icon-left": s.arrowLeft,
        "icon-right": s.arrowRight
    }, null, 8, ["link", "text", "icon-left", "icon-right"])])
}
const tI = Ee(Z6, [
        ["render", eI]
    ]),
    nI = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: tI
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    rI = {
        props: {
            content: {
                type: Object,
                default: () => ({})
            }
        }
    },
    iI = ["innerHTML"];

function sI(e, t, n, r, i, s) {
    const o = pt("orphans"),
        a = pt("nl2br"),
        l = pt("links");
    return zt((Q(), pe("p", {
        class: "block-caption --ui-x-narrow --ui-px --type-caption --type-cms --type-center",
        innerHTML: n.content.caption.trim()
    }, null, 8, iI)), [
        [o],
        [a],
        [l]
    ])
}
const oI = Ee(rI, [
        ["render", sI]
    ]),
    aI = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: oI
    }, Symbol.toStringTag, {
        value: "Module"
    }));
const lI = {
        props: {
            content: {
                type: Object,
                default: () => ({})
            }
        }
    },
    cI = {
        class: "block-columns --ui-x --ui-px"
    },
    uI = ["innerHTML"],
    fI = ["innerHTML"];

function dI(e, t, n, r, i, s) {
    const o = pt("orphans"),
        a = pt("nl2br"),
        l = pt("links");
    return Q(), pe("div", cI, [zt(qe("p", {
        class: Ot(["--type-cms", {
            "--type-title": n.content.style === "heading-paragraph",
            "--type-text": n.content.style !== "heading-paragraph"
        }]),
        innerHTML: n.content.column_0.trim()
    }, null, 10, uI), [
        [o],
        [a],
        [l]
    ]), zt(qe("p", {
        class: "--type-text --type-cms",
        innerHTML: n.content.column_1.trim()
    }, null, 8, fI), [
        [o],
        [a],
        [l]
    ])])
}
const hI = Ee(lI, [
        ["render", dI]
    ]),
    pI = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: hI
    }, Symbol.toStringTag, {
        value: "Module"
    }));
const mI = {
        props: {
            content: {
                type: Object,
                default: () => ({})
            }
        },
        data() {
            return {
                index: null
            }
        },
        computed: {
            style() {
                return gt(this.content, "style") || "text-media"
            },
            media() {
                const e = gt(this.content, "media", {});
                return e.src ? e : null
            },
            riveDelay() {
                return this.index !== null ? 800 + this.index * 100 : null
            }
        },
        mounted() {
            const e = this;
            e._motion.animateType({
                heading: e.$refs.heading,
                text: e.$refs.text,
                scroll: e.$refs.feature
            }), e.media && e.media.extention === "jpg" && e._motion.animateMedia({
                el: e.$refs.media
            }), e.media && e.media.extention === "riv" && (e.index = [...e.$refs.feature.parentElement.children].indexOf(e.$refs.feature))
        }
    },
    gI = ["innerHTML"],
    _I = ["innerHTML"],
    vI = {
        key: 0,
        class: "block-feature_media"
    },
    yI = {
        class: "--ui-center"
    },
    bI = {
        class: "--ui-space-sm"
    },
    wI = ["innerHTML"],
    SI = ["innerHTML"],
    TI = {
        key: 0,
        class: "block-feature_media",
        ref: "media"
    };

function CI(e, t, n, r, i, s) {
    const o = vt("media"),
        a = vt("ui-card"),
        l = vt("ui-tag"),
        u = pt("orphans"),
        f = pt("nl2br"),
        h = pt("links");
    return Q(), pe("div", {
        class: Ot(["block-feature", [{
            "--ui-x-outer --ui-px-lg --ui-py": s.style !== "large"
        }, "--" + s.style]]),
        ref: "feature"
    }, [s.style === "large" ? (Q(), Et(a, {
        key: 0
    }, {
        tag: Ct(() => [Pr(Hi(n.content.tag), 1)]),
        after: Ct(() => [s.media ? (Q(), pe("div", vI, [Pe(o, {
            media: s.media,
            thumb: s.media.extention === "jpg" ? ["feature-block", {
                md: "feature-block-md"
            }] : null,
            class: Ot({
                "--ui-card --ui-shadow": s.media.extention === "jpg"
            }),
            delay: s.riveDelay,
            loading: "eager"
        }, null, 8, ["media", "thumb", "class", "delay"])])) : dt("", !0)]),
        default: Ct(() => [n.content.heading ? zt((Q(), pe("h1", {
            key: 0,
            ref: "heading",
            class: "--ui-x-reduced --type-heading --type-cms --type-balance --ui-py-xs",
            innerHTML: n.content.heading
        }, null, 8, gI)), [
            [u],
            [f],
            [h]
        ]) : dt("", !0), n.content.text ? zt((Q(), pe("p", {
            key: 1,
            ref: "text",
            class: "--ui-x-narrow --type-opening --type-balance --type-cms",
            innerHTML: n.content.text
        }, null, 8, _I)), [
            [u],
            [f],
            [h]
        ]) : dt("", !0)]),
        _: 1
    })) : (Q(), pe(nt, {
        key: 1
    }, [qe("div", yI, [qe("div", bI, [n.content.tag ? (Q(), Et(l, {
        key: 0,
        delay: 500,
        variant: "soft",
        size: "lg"
    }, {
        default: Ct(() => [Pr(Hi(n.content.tag), 1)]),
        _: 1
    })) : dt("", !0), n.content.heading ? zt((Q(), pe("h2", {
        key: 1,
        ref: "heading",
        class: "--type-subheading --type-cms --type-balance",
        innerHTML: n.content.heading
    }, null, 8, wI)), [
        [u],
        [f],
        [h]
    ]) : dt("", !0), n.content.text ? zt((Q(), pe("p", {
        key: 2,
        ref: "text",
        class: "--type-opening --type-cms",
        innerHTML: n.content.text
    }, null, 8, SI)), [
        [u],
        [f],
        [h]
    ]) : dt("", !0)])]), s.media ? (Q(), pe("div", TI, [Pe(o, {
        media: s.media,
        thumb: s.media.extention === "jpg" ? ["feature-block", {
            md: "feature-block-md"
        }] : null,
        class: Ot({
            "--ui-card --ui-shadow": s.media.extention === "jpg"
        }),
        delay: s.riveDelay,
        loading: "eager"
    }, null, 8, ["media", "thumb", "class", "delay"])], 512)) : dt("", !0)], 64))], 2)
}
const EI = Ee(mI, [
        ["render", CI]
    ]),
    AI = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: EI
    }, Symbol.toStringTag, {
        value: "Module"
    }));
const xI = {
    props: {
        content: {
            type: Object,
            default: () => ({})
        }
    },
    computed: {
        style() {
            return "--" + (this.content.style || "grid-sm")
        },
        thumb() {
            return ["image-block", {
                md: "image-block-md"
            }, {
                lg: "image-block-lg"
            }]
        }
    }
};

function OI(e, t, n, r, i, s) {
    const o = vt("media");
    return Q(), pe("div", {
        class: Ot(["block-grid --ui-x-limit --ui-px", s.style])
    }, [(Q(!0), pe(nt, null, Wi(n.content.items, a => (Q(), pe(nt, null, [a.src ? (Q(), Et(o, {
        key: 0,
        media: a,
        thumb: s.thumb,
        class: "--ui-card"
    }, null, 8, ["media", "thumb"])) : dt("", !0)], 64))), 256))], 2)
}
const PI = Ee(xI, [
        ["render", OI]
    ]),
    MI = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: PI
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    RI = {
        props: {
            content: {
                type: Object,
                default: () => ({})
            }
        }
    },
    II = ["innerHTML"];

function $I(e, t, n, r, i, s) {
    const o = pt("orphans"),
        a = pt("nl2br"),
        l = pt("links");
    return zt((Q(), pe("h2", {
        class: "block-heading --ui-x-reduced --ui-px --type-title --type-cms --type-center --type-balance",
        innerHTML: n.content.heading.trim()
    }, null, 8, II)), [
        [o],
        [a],
        [l]
    ])
}
const kI = Ee(RI, [
        ["render", $I]
    ]),
    LI = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: kI
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    NI = {
        props: {
            content: {
                type: Object,
                default: () => ({})
            }
        },
        computed: {
            src() {
                return gt(this.content, "image.src")
            },
            ext() {
                return gt(this.content, "image.extention")
            },
            style() {
                return gt(this.content, "style", "card")
            },
            width() {
                return parseInt(gt(this.content, "width", 0))
            },
            thumb() {
                return this.style !== "original" && lf(["png", "jpg", "jpeg"], this.ext) ? ["image-block", {
                    md: "image-block-md"
                }, {
                    lg: "image-block-lg"
                }] : null
            }
        }
    };

function FI(e, t, n, r, i, s) {
    const o = vt("media");
    return Q(), pe("div", {
        class: Ot(["block-image --ui-center", {
            "--ui-x --ui-px": s.style !== "original"
        }])
    }, [s.src ? (Q(), Et(o, {
        key: 0,
        media: n.content.image,
        thumb: s.thumb,
        class: Ot({
            "--ui-col --ui-grow --ui-card": s.style === "card"
        }),
        style: ns({
            "max-width": s.width ? s.width + "px" : null
        })
    }, null, 8, ["media", "thumb", "class", "style"])) : dt("", !0)], 2)
}
const DI = Ee(NI, [
        ["render", FI]
    ]),
    jI = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: DI
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    BI = {
        props: {
            content: {
                type: Object,
                default: () => ({})
            }
        }
    },
    VI = ["innerHTML"];

function HI(e, t, n, r, i, s) {
    const o = pt("orphans"),
        a = pt("nl2br"),
        l = pt("links");
    return zt((Q(), pe("p", {
        class: "block-list --ui-x-narrow --ui-px --type-text --type-cms",
        innerHTML: n.content.list.trim()
    }, null, 8, VI)), [
        [o],
        [a],
        [l]
    ])
}
const UI = Ee(BI, [
        ["render", HI]
    ]),
    WI = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: UI
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    zI = {
        props: {
            content: {
                type: Object,
                default: () => ({})
            }
        }
    },
    qI = ["innerHTML"];

function KI(e, t, n, r, i, s) {
    const o = pt("orphans"),
        a = pt("nl2br"),
        l = pt("links");
    return zt((Q(), pe("p", {
        class: "block-opening --ui-x-reduced --ui-px --type-opening --type-cms --type-center --type-balance",
        innerHTML: n.content.paragraph.trim()
    }, null, 8, qI)), [
        [o],
        [a],
        [l]
    ])
}
const GI = Ee(zI, [
        ["render", KI]
    ]),
    YI = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: GI
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    XI = {
        props: {
            content: {
                type: Object,
                default: () => ({})
            }
        }
    },
    JI = ["innerHTML"];

function ZI(e, t, n, r, i, s) {
    const o = pt("orphans"),
        a = pt("nl2br"),
        l = pt("links");
    return zt((Q(), pe("p", {
        class: "block-paragraph --ui-x-narrow --ui-px --type-text --type-cms",
        innerHTML: n.content.paragraph.trim()
    }, null, 8, JI)), [
        [o],
        [a],
        [l]
    ])
}
const QI = Ee(XI, [
        ["render", ZI]
    ]),
    e4 = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: QI
    }, Symbol.toStringTag, {
        value: "Module"
    }));
const t4 = {
        props: {
            content: {
                type: Object,
                default: () => ({})
            }
        }
    },
    n4 = {
        class: "block-spacer"
    };

function r4(e, t, n, r, i, s) {
    return Q(), pe("div", n4)
}
const i4 = Ee(t4, [
        ["render", r4]
    ]),
    s4 = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: i4
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    o4 = "modulepreload",
    a4 = function(e) {
        return "/" + e
    },
    qp = {},
    yn = function(t, n, r) {
        if (!n || n.length === 0) return t();
        const i = document.getElementsByTagName("link");
        return Promise.all(n.map(s => {
            if (s = a4(s), s in qp) return;
            qp[s] = !0;
            const o = s.endsWith(".css"),
                a = o ? '[rel="stylesheet"]' : "";
            if (!!r)
                for (let f = i.length - 1; f >= 0; f--) {
                    const h = i[f];
                    if (h.href === s && (!o || h.rel === "stylesheet")) return
                } else if (document.querySelector(`link[href="${s}"]${a}`)) return;
            const u = document.createElement("link");
            if (u.rel = o ? "stylesheet" : o4, o || (u.as = "script", u.crossOrigin = ""), u.href = s, document.head.appendChild(u), o) return new Promise((f, h) => {
                u.addEventListener("load", f), u.addEventListener("error", () => h(new Error(`Unable to preload CSS for ${s}`)))
            })
        })).then(() => t()).catch(s => {
            const o = new Event("vite:preloadError", {
                cancelable: !0
            });
            if (o.payload = s, window.dispatchEvent(o), !o.defaultPrevented) throw s
        })
    },
    l4 = {
        components: {
            "ui-table": Za(() => yn(() =>
                import ("./table-4bd1dceb.js"), ["assets/table-4bd1dceb.js", "assets/table-17926526.css"]))
        },
        props: {
            content: {
                type: Object,
                default: () => ({})
            }
        },
        computed: {
            rows() {
                return this.content.rows || []
            },
            cols() {
                return gt(this.rows, "[0]", []).length
            }
        }
    };

function c4(e, t, n, r, i, s) {
    const o = vt("ui-table");
    return Q(), pe("div", {
        class: Ot(["block-table --type-caption --type-cms --ui-px", {
            "--ui-x": s.cols >= 4,
            "--ui-x-narrow": s.cols < 4
        }])
    }, [Pe(o, {
        items: s.rows
    }, null, 8, ["items"])], 2)
}
const u4 = Ee(l4, [
        ["render", c4]
    ]),
    f4 = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: u4
    }, Symbol.toStringTag, {
        value: "Module"
    }));
const d4 = {
        props: {
            content: {
                type: Object,
                default: () => ({})
            }
        },
        computed: {
            thumb() {
                return ["image-block", {
                    md: "image-block-md"
                }, {
                    lg: "image-block-lg"
                }]
            }
        }
    },
    h4 = {
        class: "block-video --ui-x --ui-px"
    };

function p4(e, t, n, r, i, s) {
    const o = vt("ui-video");
    return Q(), pe("div", h4, [Pe(o, {
        media: n.content.video,
        thumb: s.thumb,
        class: "--ui-card"
    }, null, 8, ["media", "thumb"])])
}
const m4 = Ee(d4, [
        ["render", p4]
    ]),
    g4 = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: m4
    }, Symbol.toStringTag, {
        value: "Module"
    }));
const _4 = {
        props: {
            content: {
                type: Object,
                default: () => ({})
            }
        },
        data() {
            return {
                show: !1
            }
        },
        computed: {
            component() {
                return this.show ? "div" : "button"
            },
            youtubeID() {
                var e = this;
                if (e.content.url) {
                    var t = e.content.url.split(/(vi\/|v=|\/v\/|youtu\.be\/|\/embed\/)/);
                    return t[2] !== void 0 ? t[2].split(/[^0-9a-z_-]/i)[0] : t[0]
                }
                return !1
            },
            posterSrc() {
                var e = this;
                return e.youtubeID ? location.protocol + "//img.youtube.com/vi/" + e.youtubeID + "/maxresdefault.jpg" : !1
            }
        },
        methods: {
            clickVideo() {
                this.component === "button" && (this.show = !0)
            }
        }
    },
    v4 = {
        class: "block-youtube --ui-x --ui-px"
    },
    y4 = ["src"],
    b4 = {
        key: 0
    },
    w4 = {
        class: "ui-video_paused"
    },
    S4 = {
        class: "ui-video_tl"
    };

function T4(e, t, n, r, i, s) {
    const o = vt("media"),
        a = vt("icon");
    return Q(), pe("div", v4, [(Q(), Et(kr(s.component), {
        onClick: s.clickVideo,
        class: "block-youtube_aspect ui-video --ui-card"
    }, {
        default: Ct(() => [s.youtubeID && i.show ? (Q(), pe("iframe", {
            key: 0,
            src: "https://www.youtube.com/embed/" + s.youtubeID + "?autoplay=1&cc_load_policy=1&modestbranding=1&color=white",
            frameborder: "0",
            allow: "accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture",
            allowFullScreen: ""
        }, null, 8, y4)) : dt("", !0), s.posterSrc && !i.show ? (Q(), Et(o, {
            key: 1,
            media: s.posterSrc
        }, null, 8, ["media"])) : dt("", !0), Pe(Mr, {
            name: "ui-video_fade"
        }, {
            default: Ct(() => [i.show ? dt("", !0) : (Q(), pe("div", b4, [qe("div", w4, [Pe(a, {
                name: "media-play"
            })]), qe("div", S4, [Pe(a, {
                name: "logo-youtube"
            })])]))]),
            _: 1
        })]),
        _: 1
    }, 8, ["onClick"]))])
}
const C4 = Ee(_4, [
        ["render", T4]
    ]),
    E4 = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: C4
    }, Symbol.toStringTag, {
        value: "Module"
    }));
const A4 = {
        components: {
            "part-menu": Za(() => yn(() =>
                import ("./menu-55fc2a9b.js"), ["assets/menu-55fc2a9b.js", "assets/menu-4425be58.css"])),
            "part-header": Za(() => yn(() =>
                import ("./header-34b9fd1a.js"), ["assets/header-34b9fd1a.js", "assets/header-31ef58cc.css"])),
            "ui-toaster": Za(() => yn(() =>
                import ("./toaster-439c10c3.js"), ["assets/toaster-439c10c3.js", "assets/uniqueId-d6099c84.js", "assets/toaster-4c677d03.css"]))
        },
        computed: {
            go() {
                return this.$app.go && this.$api.go
            },
            show() {
                return this.$routing.go && this.$window.go
            }
        }
    },
    x4 = {
        key: 0,
        class: "app-loading"
    };

function O4(e, t, n, r, i, s) {
    const o = vt("part-header"),
        a = vt("app-routing"),
        l = vt("part-menu"),
        u = vt("ui-toaster");
    return Q(), pe(nt, null, [s.go ? (Q(), pe("div", {
        key: 0,
        class: Ot(["app-go", {
            "--show": s.show
        }])
    }, [Pe(o, {
        fixed: ""
    }), Pe(a)], 2)) : dt("", !0), Pe(l), Pe(u), Pe(Mr, {
        name: "app-loading"
    }, {
        default: Ct(() => [s.show ? dt("", !0) : (Q(), pe("div", x4))]),
        _: 1
    })], 64)
}
const P4 = Ee(A4, [
    ["render", O4]
]);
/*!
 * vue-router v4.3.2
 * (c) 2024 Eduardo San Martin Morote
 * @license MIT
 */
const gs = typeof document < "u";

function M4(e) {
    return e.__esModule || e[Symbol.toStringTag] === "Module"
}
const _t = Object.assign;

function Hc(e, t) {
    const n = {};
    for (const r in t) {
        const i = t[r];
        n[r] = Yn(i) ? i.map(e) : e(i)
    }
    return n
}
const _o = () => {},
    Yn = Array.isArray,
    Iy = /#/g,
    R4 = /&/g,
    I4 = /\//g,
    $4 = /=/g,
    k4 = /\?/g,
    $y = /\+/g,
    L4 = /%5B/g,
    N4 = /%5D/g,
    ky = /%5E/g,
    F4 = /%60/g,
    Ly = /%7B/g,
    D4 = /%7C/g,
    Ny = /%7D/g,
    j4 = /%20/g;

function md(e) {
    return encodeURI("" + e).replace(D4, "|").replace(L4, "[").replace(N4, "]")
}

function B4(e) {
    return md(e).replace(Ly, "{").replace(Ny, "}").replace(ky, "^")
}

function Vu(e) {
    return md(e).replace($y, "%2B").replace(j4, "+").replace(Iy, "%23").replace(R4, "%26").replace(F4, "`").replace(Ly, "{").replace(Ny, "}").replace(ky, "^")
}

function V4(e) {
    return Vu(e).replace($4, "%3D")
}

function H4(e) {
    return md(e).replace(Iy, "%23").replace(k4, "%3F")
}

function U4(e) {
    return e == null ? "" : H4(e).replace(I4, "%2F")
}

function Do(e) {
    try {
        return decodeURIComponent("" + e)
    } catch {}
    return "" + e
}
const W4 = /\/$/,
    z4 = e => e.replace(W4, "");

function Uc(e, t, n = "/") {
    let r, i = {},
        s = "",
        o = "";
    const a = t.indexOf("#");
    let l = t.indexOf("?");
    return a < l && a >= 0 && (l = -1), l > -1 && (r = t.slice(0, l), s = t.slice(l + 1, a > -1 ? a : t.length), i = e(s)), a > -1 && (r = r || t.slice(0, a), o = t.slice(a, t.length)), r = Y4(r ? ? t, n), {
        fullPath: r + (s && "?") + s + o,
        path: r,
        query: i,
        hash: Do(o)
    }
}

function q4(e, t) {
    const n = t.query ? e(t.query) : "";
    return t.path + (n && "?") + n + (t.hash || "")
}

function Kp(e, t) {
    return !t || !e.toLowerCase().startsWith(t.toLowerCase()) ? e : e.slice(t.length) || "/"
}

function K4(e, t, n) {
    const r = t.matched.length - 1,
        i = n.matched.length - 1;
    return r > -1 && r === i && Vs(t.matched[r], n.matched[i]) && Fy(t.params, n.params) && e(t.query) === e(n.query) && t.hash === n.hash
}

function Vs(e, t) {
    return (e.aliasOf || e) === (t.aliasOf || t)
}

function Fy(e, t) {
    if (Object.keys(e).length !== Object.keys(t).length) return !1;
    for (const n in e)
        if (!G4(e[n], t[n])) return !1;
    return !0
}

function G4(e, t) {
    return Yn(e) ? Gp(e, t) : Yn(t) ? Gp(t, e) : e === t
}

function Gp(e, t) {
    return Yn(t) ? e.length === t.length && e.every((n, r) => n === t[r]) : e.length === 1 && e[0] === t
}

function Y4(e, t) {
    if (e.startsWith("/")) return e;
    if (!e) return t;
    const n = t.split("/"),
        r = e.split("/"),
        i = r[r.length - 1];
    (i === ".." || i === ".") && r.push("");
    let s = n.length - 1,
        o, a;
    for (o = 0; o < r.length; o++)
        if (a = r[o], a !== ".")
            if (a === "..") s > 1 && s--;
            else break;
    return n.slice(0, s).join("/") + "/" + r.slice(o).join("/")
}
var jo;
(function(e) {
    e.pop = "pop", e.push = "push"
})(jo || (jo = {}));
var vo;
(function(e) {
    e.back = "back", e.forward = "forward", e.unknown = ""
})(vo || (vo = {}));

function X4(e) {
    if (!e)
        if (gs) {
            const t = document.querySelector("base");
            e = t && t.getAttribute("href") || "/", e = e.replace(/^\w+:\/\/[^\/]+/, "")
        } else e = "/";
    return e[0] !== "/" && e[0] !== "#" && (e = "/" + e), z4(e)
}
const J4 = /^[^#]+#/;

function Z4(e, t) {
    return e.replace(J4, "#") + t
}

function Q4(e, t) {
    const n = document.documentElement.getBoundingClientRect(),
        r = e.getBoundingClientRect();
    return {
        behavior: t.behavior,
        left: r.left - n.left - (t.left || 0),
        top: r.top - n.top - (t.top || 0)
    }
}
const uc = () => ({
    left: window.scrollX,
    top: window.scrollY
});

function e$(e) {
    let t;
    if ("el" in e) {
        const n = e.el,
            r = typeof n == "string" && n.startsWith("#"),
            i = typeof n == "string" ? r ? document.getElementById(n.slice(1)) : document.querySelector(n) : n;
        if (!i) return;
        t = Q4(i, e)
    } else t = e;
    "scrollBehavior" in document.documentElement.style ? window.scrollTo(t) : window.scrollTo(t.left != null ? t.left : window.scrollX, t.top != null ? t.top : window.scrollY)
}

function Yp(e, t) {
    return (history.state ? history.state.position - t : -1) + e
}
const Hu = new Map;

function t$(e, t) {
    Hu.set(e, t)
}

function n$(e) {
    const t = Hu.get(e);
    return Hu.delete(e), t
}
let r$ = () => location.protocol + "//" + location.host;

function Dy(e, t) {
    const {
        pathname: n,
        search: r,
        hash: i
    } = t, s = e.indexOf("#");
    if (s > -1) {
        let a = i.includes(e.slice(s)) ? e.slice(s).length : 1,
            l = i.slice(a);
        return l[0] !== "/" && (l = "/" + l), Kp(l, "")
    }
    return Kp(n, e) + r + i
}

function i$(e, t, n, r) {
    let i = [],
        s = [],
        o = null;
    const a = ({
        state: _
    }) => {
        const m = Dy(e, location),
            T = n.value,
            R = t.value;
        let B = 0;
        if (_) {
            if (n.value = m, t.value = _, o && o === T) {
                o = null;
                return
            }
            B = R ? _.position - R.position : 0
        } else r(m);
        i.forEach(I => {
            I(n.value, T, {
                delta: B,
                type: jo.pop,
                direction: B ? B > 0 ? vo.forward : vo.back : vo.unknown
            })
        })
    };

    function l() {
        o = n.value
    }

    function u(_) {
        i.push(_);
        const m = () => {
            const T = i.indexOf(_);
            T > -1 && i.splice(T, 1)
        };
        return s.push(m), m
    }

    function f() {
        const {
            history: _
        } = window;
        _.state && _.replaceState(_t({}, _.state, {
            scroll: uc()
        }), "")
    }

    function h() {
        for (const _ of s) _();
        s = [], window.removeEventListener("popstate", a), window.removeEventListener("beforeunload", f)
    }
    return window.addEventListener("popstate", a), window.addEventListener("beforeunload", f, {
        passive: !0
    }), {
        pauseListeners: l,
        listen: u,
        destroy: h
    }
}

function Xp(e, t, n, r = !1, i = !1) {
    return {
        back: e,
        current: t,
        forward: n,
        replaced: r,
        position: window.history.length,
        scroll: i ? uc() : null
    }
}

function s$(e) {
    const {
        history: t,
        location: n
    } = window, r = {
        value: Dy(e, n)
    }, i = {
        value: t.state
    };
    i.value || s(r.value, {
        back: null,
        current: r.value,
        forward: null,
        position: t.length - 1,
        replaced: !0,
        scroll: null
    }, !0);

    function s(l, u, f) {
        const h = e.indexOf("#"),
            _ = h > -1 ? (n.host && document.querySelector("base") ? e : e.slice(h)) + l : r$() + e + l;
        try {
            t[f ? "replaceState" : "pushState"](u, "", _), i.value = u
        } catch (m) {
            console.error(m), n[f ? "replace" : "assign"](_)
        }
    }

    function o(l, u) {
        const f = _t({}, t.state, Xp(i.value.back, l, i.value.forward, !0), u, {
            position: i.value.position
        });
        s(l, f, !0), r.value = l
    }

    function a(l, u) {
        const f = _t({}, i.value, t.state, {
            forward: l,
            scroll: uc()
        });
        s(f.current, f, !0);
        const h = _t({}, Xp(r.value, l, null), {
            position: f.position + 1
        }, u);
        s(l, h, !1), r.value = l
    }
    return {
        location: r,
        state: i,
        push: a,
        replace: o
    }
}

function o$(e) {
    e = X4(e);
    const t = s$(e),
        n = i$(e, t.state, t.location, t.replace);

    function r(s, o = !0) {
        o || n.pauseListeners(), history.go(s)
    }
    const i = _t({
        location: "",
        base: e,
        go: r,
        createHref: Z4.bind(null, e)
    }, t, n);
    return Object.defineProperty(i, "location", {
        enumerable: !0,
        get: () => t.location.value
    }), Object.defineProperty(i, "state", {
        enumerable: !0,
        get: () => t.state.value
    }), i
}

function a$(e) {
    return typeof e == "string" || e && typeof e == "object"
}

function jy(e) {
    return typeof e == "string" || typeof e == "symbol"
}
const Wr = {
        path: "/",
        name: void 0,
        params: {},
        query: {},
        hash: "",
        fullPath: "/",
        matched: [],
        meta: {},
        redirectedFrom: void 0
    },
    By = Symbol("");
var Jp;
(function(e) {
    e[e.aborted = 4] = "aborted", e[e.cancelled = 8] = "cancelled", e[e.duplicated = 16] = "duplicated"
})(Jp || (Jp = {}));

function Hs(e, t) {
    return _t(new Error, {
        type: e,
        [By]: !0
    }, t)
}

function yr(e, t) {
    return e instanceof Error && By in e && (t == null || !!(e.type & t))
}
const Zp = "[^/]+?",
    l$ = {
        sensitive: !1,
        strict: !1,
        start: !0,
        end: !0
    },
    c$ = /[.+*?^${}()[\]/\\]/g;

function u$(e, t) {
    const n = _t({}, l$, t),
        r = [];
    let i = n.start ? "^" : "";
    const s = [];
    for (const u of e) {
        const f = u.length ? [] : [90];
        n.strict && !u.length && (i += "/");
        for (let h = 0; h < u.length; h++) {
            const _ = u[h];
            let m = 40 + (n.sensitive ? .25 : 0);
            if (_.type === 0) h || (i += "/"), i += _.value.replace(c$, "\\$&"), m += 40;
            else if (_.type === 1) {
                const {
                    value: T,
                    repeatable: R,
                    optional: B,
                    regexp: I
                } = _;
                s.push({
                    name: T,
                    repeatable: R,
                    optional: B
                });
                const A = I || Zp;
                if (A !== Zp) {
                    m += 10;
                    try {
                        new RegExp(`(${A})`)
                    } catch (O) {
                        throw new Error(`Invalid custom RegExp for param "${T}" (${A}): ` + O.message)
                    }
                }
                let E = R ? `((?:${A})(?:/(?:${A}))*)` : `(${A})`;
                h || (E = B && u.length < 2 ? `(?:/${E})` : "/" + E), B && (E += "?"), i += E, m += 20, B && (m += -8), R && (m += -20), A === ".*" && (m += -50)
            }
            f.push(m)
        }
        r.push(f)
    }
    if (n.strict && n.end) {
        const u = r.length - 1;
        r[u][r[u].length - 1] += .7000000000000001
    }
    n.strict || (i += "/?"), n.end ? i += "$" : n.strict && (i += "(?:/|$)");
    const o = new RegExp(i, n.sensitive ? "" : "i");

    function a(u) {
        const f = u.match(o),
            h = {};
        if (!f) return null;
        for (let _ = 1; _ < f.length; _++) {
            const m = f[_] || "",
                T = s[_ - 1];
            h[T.name] = m && T.repeatable ? m.split("/") : m
        }
        return h
    }

    function l(u) {
        let f = "",
            h = !1;
        for (const _ of e) {
            (!h || !f.endsWith("/")) && (f += "/"), h = !1;
            for (const m of _)
                if (m.type === 0) f += m.value;
                else if (m.type === 1) {
                const {
                    value: T,
                    repeatable: R,
                    optional: B
                } = m, I = T in u ? u[T] : "";
                if (Yn(I) && !R) throw new Error(`Provided param "${T}" is an array but it is not repeatable (* or + modifiers)`);
                const A = Yn(I) ? I.join("/") : I;
                if (!A)
                    if (B) _.length < 2 && (f.endsWith("/") ? f = f.slice(0, -1) : h = !0);
                    else throw new Error(`Missing required param "${T}"`);
                f += A
            }
        }
        return f || "/"
    }
    return {
        re: o,
        score: r,
        keys: s,
        parse: a,
        stringify: l
    }
}

function f$(e, t) {
    let n = 0;
    for (; n < e.length && n < t.length;) {
        const r = t[n] - e[n];
        if (r) return r;
        n++
    }
    return e.length < t.length ? e.length === 1 && e[0] === 40 + 40 ? -1 : 1 : e.length > t.length ? t.length === 1 && t[0] === 40 + 40 ? 1 : -1 : 0
}

function d$(e, t) {
    let n = 0;
    const r = e.score,
        i = t.score;
    for (; n < r.length && n < i.length;) {
        const s = f$(r[n], i[n]);
        if (s) return s;
        n++
    }
    if (Math.abs(i.length - r.length) === 1) {
        if (Qp(r)) return 1;
        if (Qp(i)) return -1
    }
    return i.length - r.length
}

function Qp(e) {
    const t = e[e.length - 1];
    return e.length > 0 && t[t.length - 1] < 0
}
const h$ = {
        type: 0,
        value: ""
    },
    p$ = /[a-zA-Z0-9_]/;

function m$(e) {
    if (!e) return [
        []
    ];
    if (e === "/") return [
        [h$]
    ];
    if (!e.startsWith("/")) throw new Error(`Invalid path "${e}"`);

    function t(m) {
        throw new Error(`ERR (${n})/"${u}": ${m}`)
    }
    let n = 0,
        r = n;
    const i = [];
    let s;

    function o() {
        s && i.push(s), s = []
    }
    let a = 0,
        l, u = "",
        f = "";

    function h() {
        u && (n === 0 ? s.push({
            type: 0,
            value: u
        }) : n === 1 || n === 2 || n === 3 ? (s.length > 1 && (l === "*" || l === "+") && t(`A repeatable param (${u}) must be alone in its segment. eg: '/:ids+.`), s.push({
            type: 1,
            value: u,
            regexp: f,
            repeatable: l === "*" || l === "+",
            optional: l === "*" || l === "?"
        })) : t("Invalid state to consume buffer"), u = "")
    }

    function _() {
        u += l
    }
    for (; a < e.length;) {
        if (l = e[a++], l === "\\" && n !== 2) {
            r = n, n = 4;
            continue
        }
        switch (n) {
            case 0:
                l === "/" ? (u && h(), o()) : l === ":" ? (h(), n = 1) : _();
                break;
            case 4:
                _(), n = r;
                break;
            case 1:
                l === "(" ? n = 2 : p$.test(l) ? _() : (h(), n = 0, l !== "*" && l !== "?" && l !== "+" && a--);
                break;
            case 2:
                l === ")" ? f[f.length - 1] == "\\" ? f = f.slice(0, -1) + l : n = 3 : f += l;
                break;
            case 3:
                h(), n = 0, l !== "*" && l !== "?" && l !== "+" && a--, f = "";
                break;
            default:
                t("Unknown state");
                break
        }
    }
    return n === 2 && t(`Unfinished custom RegExp for param "${u}"`), h(), o(), i
}

function g$(e, t, n) {
    const r = u$(m$(e.path), n),
        i = _t(r, {
            record: e,
            parent: t,
            children: [],
            alias: []
        });
    return t && !i.record.aliasOf == !t.record.aliasOf && t.children.push(i), i
}

function _$(e, t) {
    const n = [],
        r = new Map;
    t = nm({
        strict: !1,
        end: !0,
        sensitive: !1
    }, t);

    function i(f) {
        return r.get(f)
    }

    function s(f, h, _) {
        const m = !_,
            T = v$(f);
        T.aliasOf = _ && _.record;
        const R = nm(t, f),
            B = [T];
        if ("alias" in f) {
            const E = typeof f.alias == "string" ? [f.alias] : f.alias;
            for (const O of E) B.push(_t({}, T, {
                components: _ ? _.record.components : T.components,
                path: O,
                aliasOf: _ ? _.record : T
            }))
        }
        let I, A;
        for (const E of B) {
            const {
                path: O
            } = E;
            if (h && O[0] !== "/") {
                const P = h.record.path,
                    $ = P[P.length - 1] === "/" ? "" : "/";
                E.path = h.record.path + (O && $ + O)
            }
            if (I = g$(E, h, R), _ ? _.alias.push(I) : (A = A || I, A !== I && A.alias.push(I), m && f.name && !tm(I) && o(f.name)), T.children) {
                const P = T.children;
                for (let $ = 0; $ < P.length; $++) s(P[$], I, _ && _.children[$])
            }
            _ = _ || I, (I.record.components && Object.keys(I.record.components).length || I.record.name || I.record.redirect) && l(I)
        }
        return A ? () => {
            o(A)
        } : _o
    }

    function o(f) {
        if (jy(f)) {
            const h = r.get(f);
            h && (r.delete(f), n.splice(n.indexOf(h), 1), h.children.forEach(o), h.alias.forEach(o))
        } else {
            const h = n.indexOf(f);
            h > -1 && (n.splice(h, 1), f.record.name && r.delete(f.record.name), f.children.forEach(o), f.alias.forEach(o))
        }
    }

    function a() {
        return n
    }

    function l(f) {
        let h = 0;
        for (; h < n.length && d$(f, n[h]) >= 0 && (f.record.path !== n[h].record.path || !Vy(f, n[h]));) h++;
        n.splice(h, 0, f), f.record.name && !tm(f) && r.set(f.record.name, f)
    }

    function u(f, h) {
        let _, m = {},
            T, R;
        if ("name" in f && f.name) {
            if (_ = r.get(f.name), !_) throw Hs(1, {
                location: f
            });
            R = _.record.name, m = _t(em(h.params, _.keys.filter(A => !A.optional).concat(_.parent ? _.parent.keys.filter(A => A.optional) : []).map(A => A.name)), f.params && em(f.params, _.keys.map(A => A.name))), T = _.stringify(m)
        } else if (f.path != null) T = f.path, _ = n.find(A => A.re.test(T)), _ && (m = _.parse(T), R = _.record.name);
        else {
            if (_ = h.name ? r.get(h.name) : n.find(A => A.re.test(h.path)), !_) throw Hs(1, {
                location: f,
                currentLocation: h
            });
            R = _.record.name, m = _t({}, h.params, f.params), T = _.stringify(m)
        }
        const B = [];
        let I = _;
        for (; I;) B.unshift(I.record), I = I.parent;
        return {
            name: R,
            path: T,
            params: m,
            matched: B,
            meta: b$(B)
        }
    }
    return e.forEach(f => s(f)), {
        addRoute: s,
        resolve: u,
        removeRoute: o,
        getRoutes: a,
        getRecordMatcher: i
    }
}

function em(e, t) {
    const n = {};
    for (const r of t) r in e && (n[r] = e[r]);
    return n
}

function v$(e) {
    return {
        path: e.path,
        redirect: e.redirect,
        name: e.name,
        meta: e.meta || {},
        aliasOf: void 0,
        beforeEnter: e.beforeEnter,
        props: y$(e),
        children: e.children || [],
        instances: {},
        leaveGuards: new Set,
        updateGuards: new Set,
        enterCallbacks: {},
        components: "components" in e ? e.components || null : e.component && {
            default: e.component
        }
    }
}

function y$(e) {
    const t = {},
        n = e.props || !1;
    if ("component" in e) t.default = n;
    else
        for (const r in e.components) t[r] = typeof n == "object" ? n[r] : n;
    return t
}

function tm(e) {
    for (; e;) {
        if (e.record.aliasOf) return !0;
        e = e.parent
    }
    return !1
}

function b$(e) {
    return e.reduce((t, n) => _t(t, n.meta), {})
}

function nm(e, t) {
    const n = {};
    for (const r in e) n[r] = r in t ? t[r] : e[r];
    return n
}

function Vy(e, t) {
    return t.children.some(n => n === e || Vy(e, n))
}

function w$(e) {
    const t = {};
    if (e === "" || e === "?") return t;
    const r = (e[0] === "?" ? e.slice(1) : e).split("&");
    for (let i = 0; i < r.length; ++i) {
        const s = r[i].replace($y, " "),
            o = s.indexOf("="),
            a = Do(o < 0 ? s : s.slice(0, o)),
            l = o < 0 ? null : Do(s.slice(o + 1));
        if (a in t) {
            let u = t[a];
            Yn(u) || (u = t[a] = [u]), u.push(l)
        } else t[a] = l
    }
    return t
}

function rm(e) {
    let t = "";
    for (let n in e) {
        const r = e[n];
        if (n = V4(n), r == null) {
            r !== void 0 && (t += (t.length ? "&" : "") + n);
            continue
        }(Yn(r) ? r.map(s => s && Vu(s)) : [r && Vu(r)]).forEach(s => {
            s !== void 0 && (t += (t.length ? "&" : "") + n, s != null && (t += "=" + s))
        })
    }
    return t
}

function S$(e) {
    const t = {};
    for (const n in e) {
        const r = e[n];
        r !== void 0 && (t[n] = Yn(r) ? r.map(i => i == null ? null : "" + i) : r == null ? r : "" + r)
    }
    return t
}
const T$ = Symbol(""),
    im = Symbol(""),
    gd = Symbol(""),
    Hy = Symbol(""),
    Uu = Symbol("");

function to() {
    let e = [];

    function t(r) {
        return e.push(r), () => {
            const i = e.indexOf(r);
            i > -1 && e.splice(i, 1)
        }
    }

    function n() {
        e = []
    }
    return {
        add: t,
        list: () => e.slice(),
        reset: n
    }
}

function Zr(e, t, n, r, i, s = o => o()) {
    const o = r && (r.enterCallbacks[i] = r.enterCallbacks[i] || []);
    return () => new Promise((a, l) => {
        const u = _ => {
                _ === !1 ? l(Hs(4, {
                    from: n,
                    to: t
                })) : _ instanceof Error ? l(_) : a$(_) ? l(Hs(2, {
                    from: t,
                    to: _
                })) : (o && r.enterCallbacks[i] === o && typeof _ == "function" && o.push(_), a())
            },
            f = s(() => e.call(r && r.instances[i], t, n, u));
        let h = Promise.resolve(f);
        e.length < 3 && (h = h.then(u)), h.catch(_ => l(_))
    })
}

function Wc(e, t, n, r, i = s => s()) {
    const s = [];
    for (const o of e)
        for (const a in o.components) {
            let l = o.components[a];
            if (!(t !== "beforeRouteEnter" && !o.instances[a]))
                if (C$(l)) {
                    const f = (l.__vccOpts || l)[t];
                    f && s.push(Zr(f, n, r, o, a, i))
                } else {
                    let u = l();
                    s.push(() => u.then(f => {
                        if (!f) return Promise.reject(new Error(`Couldn't resolve component "${a}" at "${o.path}"`));
                        const h = M4(f) ? f.default : f;
                        o.components[a] = h;
                        const m = (h.__vccOpts || h)[t];
                        return m && Zr(m, n, r, o, a, i)()
                    }))
                }
        }
    return s
}

function C$(e) {
    return typeof e == "object" || "displayName" in e || "props" in e || "__vccOpts" in e
}

function sm(e) {
    const t = fr(gd),
        n = fr(Hy),
        r = Ht(() => {
            const l = Ar(e.to);
            return t.resolve(l)
        }),
        i = Ht(() => {
            const {
                matched: l
            } = r.value, {
                length: u
            } = l, f = l[u - 1], h = n.matched;
            if (!f || !h.length) return -1;
            const _ = h.findIndex(Vs.bind(null, f));
            if (_ > -1) return _;
            const m = om(l[u - 2]);
            return u > 1 && om(f) === m && h[h.length - 1].path !== m ? h.findIndex(Vs.bind(null, l[u - 2])) : _
        }),
        s = Ht(() => i.value > -1 && O$(n.params, r.value.params)),
        o = Ht(() => i.value > -1 && i.value === n.matched.length - 1 && Fy(n.params, r.value.params));

    function a(l = {}) {
        return x$(l) ? t[Ar(e.replace) ? "replace" : "push"](Ar(e.to)).catch(_o) : Promise.resolve()
    }
    return {
        route: r,
        href: Ht(() => r.value.href),
        isActive: s,
        isExactActive: o,
        navigate: a
    }
}
const E$ = qo({
        name: "RouterLink",
        compatConfig: {
            MODE: 3
        },
        props: {
            to: {
                type: [String, Object],
                required: !0
            },
            replace: Boolean,
            activeClass: String,
            exactActiveClass: String,
            custom: Boolean,
            ariaCurrentValue: {
                type: String,
                default: "page"
            }
        },
        useLink: sm,
        setup(e, {
            slots: t
        }) {
            const n = li(sm(e)),
                {
                    options: r
                } = fr(gd),
                i = Ht(() => ({
                    [am(e.activeClass, r.linkActiveClass, "router-link-active")]: n.isActive,
                    [am(e.exactActiveClass, r.linkExactActiveClass, "router-link-exact-active")]: n.isExactActive
                }));
            return () => {
                const s = t.default && t.default(n);
                return e.custom ? s : ec("a", {
                    "aria-current": n.isExactActive ? e.ariaCurrentValue : null,
                    href: n.href,
                    onClick: n.navigate,
                    class: i.value
                }, s)
            }
        }
    }),
    A$ = E$;

function x$(e) {
    if (!(e.metaKey || e.altKey || e.ctrlKey || e.shiftKey) && !e.defaultPrevented && !(e.button !== void 0 && e.button !== 0)) {
        if (e.currentTarget && e.currentTarget.getAttribute) {
            const t = e.currentTarget.getAttribute("target");
            if (/\b_blank\b/i.test(t)) return
        }
        return e.preventDefault && e.preventDefault(), !0
    }
}

function O$(e, t) {
    for (const n in t) {
        const r = t[n],
            i = e[n];
        if (typeof r == "string") {
            if (r !== i) return !1
        } else if (!Yn(i) || i.length !== r.length || r.some((s, o) => s !== i[o])) return !1
    }
    return !0
}

function om(e) {
    return e ? e.aliasOf ? e.aliasOf.path : e.path : ""
}
const am = (e, t, n) => e ? ? t ? ? n,
    P$ = qo({
        name: "RouterView",
        inheritAttrs: !1,
        props: {
            name: {
                type: String,
                default: "default"
            },
            route: Object
        },
        compatConfig: {
            MODE: 3
        },
        setup(e, {
            attrs: t,
            slots: n
        }) {
            const r = fr(Uu),
                i = Ht(() => e.route || r.value),
                s = fr(im, 0),
                o = Ht(() => {
                    let u = Ar(s);
                    const {
                        matched: f
                    } = i.value;
                    let h;
                    for (;
                        (h = f[u]) && !h.components;) u++;
                    return u
                }),
                a = Ht(() => i.value.matched[o.value]);
            oo(im, Ht(() => o.value + 1)), oo(T$, a), oo(Uu, i);
            const l = Tn();
            return zn(() => [l.value, a.value, e.name], ([u, f, h], [_, m, T]) => {
                f && (f.instances[h] = u, m && m !== f && u && u === _ && (f.leaveGuards.size || (f.leaveGuards = m.leaveGuards), f.updateGuards.size || (f.updateGuards = m.updateGuards))), u && f && (!m || !Vs(f, m) || !_) && (f.enterCallbacks[h] || []).forEach(R => R(u))
            }, {
                flush: "post"
            }), () => {
                const u = i.value,
                    f = e.name,
                    h = a.value,
                    _ = h && h.components[f];
                if (!_) return lm(n.default, {
                    Component: _,
                    route: u
                });
                const m = h.props[f],
                    T = m ? m === !0 ? u.params : typeof m == "function" ? m(u) : m : null,
                    B = ec(_, _t({}, T, t, {
                        onVnodeUnmounted: I => {
                            I.component.isUnmounted && (h.instances[f] = null)
                        },
                        ref: l
                    }));
                return lm(n.default, {
                    Component: B,
                    route: u
                }) || B
            }
        }
    });

function lm(e, t) {
    if (!e) return null;
    const n = e(t);
    return n.length === 1 ? n[0] : n
}
const M$ = P$;

function R$(e) {
    const t = _$(e.routes, e),
        n = e.parseQuery || w$,
        r = e.stringifyQuery || rm,
        i = e.history,
        s = to(),
        o = to(),
        a = to(),
        l = xg(Wr);
    let u = Wr;
    gs && e.scrollBehavior && "scrollRestoration" in history && (history.scrollRestoration = "manual");
    const f = Hc.bind(null, W => "" + W),
        h = Hc.bind(null, U4),
        _ = Hc.bind(null, Do);

    function m(W, ge) {
        let fe, ye;
        return jy(W) ? (fe = t.getRecordMatcher(W), ye = ge) : ye = W, t.addRoute(ye, fe)
    }

    function T(W) {
        const ge = t.getRecordMatcher(W);
        ge && t.removeRoute(ge)
    }

    function R() {
        return t.getRoutes().map(W => W.record)
    }

    function B(W) {
        return !!t.getRecordMatcher(W)
    }

    function I(W, ge) {
        if (ge = _t({}, ge || l.value), typeof W == "string") {
            const C = Uc(n, W, ge.path),
                U = t.resolve({
                    path: C.path
                }, ge),
                K = i.createHref(C.fullPath);
            return _t(C, U, {
                params: _(U.params),
                hash: Do(C.hash),
                redirectedFrom: void 0,
                href: K
            })
        }
        let fe;
        if (W.path != null) fe = _t({}, W, {
            path: Uc(n, W.path, ge.path).path
        });
        else {
            const C = _t({}, W.params);
            for (const U in C) C[U] == null && delete C[U];
            fe = _t({}, W, {
                params: h(C)
            }), ge.params = h(ge.params)
        }
        const ye = t.resolve(fe, ge),
            Me = W.hash || "";
        ye.params = f(_(ye.params));
        const Be = q4(r, _t({}, W, {
                hash: B4(Me),
                path: ye.path
            })),
            S = i.createHref(Be);
        return _t({
            fullPath: Be,
            hash: Me,
            query: r === rm ? S$(W.query) : W.query || {}
        }, ye, {
            redirectedFrom: void 0,
            href: S
        })
    }

    function A(W) {
        return typeof W == "string" ? Uc(n, W, l.value.path) : _t({}, W)
    }

    function E(W, ge) {
        if (u !== W) return Hs(8, {
            from: ge,
            to: W
        })
    }

    function O(W) {
        return H(W)
    }

    function P(W) {
        return O(_t(A(W), {
            replace: !0
        }))
    }

    function $(W) {
        const ge = W.matched[W.matched.length - 1];
        if (ge && ge.redirect) {
            const {
                redirect: fe
            } = ge;
            let ye = typeof fe == "function" ? fe(W) : fe;
            return typeof ye == "string" && (ye = ye.includes("?") || ye.includes("#") ? ye = A(ye) : {
                path: ye
            }, ye.params = {}), _t({
                query: W.query,
                hash: W.hash,
                params: ye.path != null ? {} : W.params
            }, ye)
        }
    }

    function H(W, ge) {
        const fe = u = I(W),
            ye = l.value,
            Me = W.state,
            Be = W.force,
            S = W.replace === !0,
            C = $(fe);
        if (C) return H(_t(A(C), {
            state: typeof C == "object" ? _t({}, Me, C.state) : Me,
            force: Be,
            replace: S
        }), ge || fe);
        const U = fe;
        U.redirectedFrom = ge;
        let K;
        return !Be && K4(r, ye, fe) && (K = Hs(16, {
            to: U,
            from: ye
        }), ke(ye, ye, !0, !1)), (K ? Promise.resolve(K) : k(U, ye)).catch(z => yr(z) ? yr(z, 2) ? z : Oe(z) : ce(z, U, ye)).then(z => {
            if (z) {
                if (yr(z, 2)) return H(_t({
                    replace: S
                }, A(z.to), {
                    state: typeof z.to == "object" ? _t({}, Me, z.to.state) : Me,
                    force: Be
                }), ge || U)
            } else z = L(U, ye, !0, S, Me);
            return Y(U, ye, z), z
        })
    }

    function F(W, ge) {
        const fe = E(W, ge);
        return fe ? Promise.reject(fe) : Promise.resolve()
    }

    function V(W) {
        const ge = Ie.values().next().value;
        return ge && typeof ge.runWithContext == "function" ? ge.runWithContext(W) : W()
    }

    function k(W, ge) {
        let fe;
        const [ye, Me, Be] = I$(W, ge);
        fe = Wc(ye.reverse(), "beforeRouteLeave", W, ge);
        for (const C of ye) C.leaveGuards.forEach(U => {
            fe.push(Zr(U, W, ge))
        });
        const S = F.bind(null, W, ge);
        return fe.push(S), Ne(fe).then(() => {
            fe = [];
            for (const C of s.list()) fe.push(Zr(C, W, ge));
            return fe.push(S), Ne(fe)
        }).then(() => {
            fe = Wc(Me, "beforeRouteUpdate", W, ge);
            for (const C of Me) C.updateGuards.forEach(U => {
                fe.push(Zr(U, W, ge))
            });
            return fe.push(S), Ne(fe)
        }).then(() => {
            fe = [];
            for (const C of Be)
                if (C.beforeEnter)
                    if (Yn(C.beforeEnter))
                        for (const U of C.beforeEnter) fe.push(Zr(U, W, ge));
                    else fe.push(Zr(C.beforeEnter, W, ge));
            return fe.push(S), Ne(fe)
        }).then(() => (W.matched.forEach(C => C.enterCallbacks = {}), fe = Wc(Be, "beforeRouteEnter", W, ge, V), fe.push(S), Ne(fe))).then(() => {
            fe = [];
            for (const C of o.list()) fe.push(Zr(C, W, ge));
            return fe.push(S), Ne(fe)
        }).catch(C => yr(C, 8) ? C : Promise.reject(C))
    }

    function Y(W, ge, fe) {
        a.list().forEach(ye => V(() => ye(W, ge, fe)))
    }

    function L(W, ge, fe, ye, Me) {
        const Be = E(W, ge);
        if (Be) return Be;
        const S = ge === Wr,
            C = gs ? history.state : {};
        fe && (ye || S ? i.replace(W.fullPath, _t({
            scroll: S && C && C.scroll
        }, Me)) : i.push(W.fullPath, Me)), l.value = W, ke(W, ge, fe, S), Oe()
    }
    let te;

    function ie() {
        te || (te = i.listen((W, ge, fe) => {
            if (!Le.listening) return;
            const ye = I(W),
                Me = $(ye);
            if (Me) {
                H(_t(Me, {
                    replace: !0
                }), ye).catch(_o);
                return
            }
            u = ye;
            const Be = l.value;
            gs && t$(Yp(Be.fullPath, fe.delta), uc()), k(ye, Be).catch(S => yr(S, 12) ? S : yr(S, 2) ? (H(S.to, ye).then(C => {
                yr(C, 20) && !fe.delta && fe.type === jo.pop && i.go(-1, !1)
            }).catch(_o), Promise.reject()) : (fe.delta && i.go(-fe.delta, !1), ce(S, ye, Be))).then(S => {
                S = S || L(ye, Be, !1), S && (fe.delta && !yr(S, 8) ? i.go(-fe.delta, !1) : fe.type === jo.pop && yr(S, 20) && i.go(-1, !1)), Y(ye, Be, S)
            }).catch(_o)
        }))
    }
    let _e = to(),
        X = to(),
        le;

    function ce(W, ge, fe) {
        Oe(W);
        const ye = X.list();
        return ye.length ? ye.forEach(Me => Me(W, ge, fe)) : console.error(W), Promise.reject(W)
    }

    function ue() {
        return le && l.value !== Wr ? Promise.resolve() : new Promise((W, ge) => {
            _e.add([W, ge])
        })
    }

    function Oe(W) {
        return le || (le = !W, ie(), _e.list().forEach(([ge, fe]) => W ? fe(W) : ge()), _e.reset()), W
    }

    function ke(W, ge, fe, ye) {
        const {
            scrollBehavior: Me
        } = e;
        if (!gs || !Me) return Promise.resolve();
        const Be = !fe && n$(Yp(W.fullPath, 0)) || (ye || !fe) && history.state && history.state.scroll || null;
        return Ws().then(() => Me(W, ge, Be)).then(S => S && e$(S)).catch(S => ce(S, W, ge))
    }
    const Ze = W => i.go(W);
    let Fe;
    const Ie = new Set,
        Le = {
            currentRoute: l,
            listening: !0,
            addRoute: m,
            removeRoute: T,
            hasRoute: B,
            getRoutes: R,
            resolve: I,
            options: e,
            push: O,
            replace: P,
            go: Ze,
            back: () => Ze(-1),
            forward: () => Ze(1),
            beforeEach: s.add,
            beforeResolve: o.add,
            afterEach: a.add,
            onError: X.add,
            isReady: ue,
            install(W) {
                const ge = this;
                W.component("RouterLink", A$), W.component("RouterView", M$), W.config.globalProperties.$router = ge, Object.defineProperty(W.config.globalProperties, "$route", {
                    enumerable: !0,
                    get: () => Ar(l)
                }), gs && !Fe && l.value === Wr && (Fe = !0, O(i.location).catch(Me => {}));
                const fe = {};
                for (const Me in Wr) Object.defineProperty(fe, Me, {
                    get: () => l.value[Me],
                    enumerable: !0
                });
                W.provide(gd, ge), W.provide(Hy, vf(fe)), W.provide(Uu, l);
                const ye = W.unmount;
                Ie.add(W), W.unmount = function() {
                    Ie.delete(W), Ie.size < 1 && (u = Wr, te && te(), te = null, l.value = Wr, Fe = !1, le = !1), ye()
                }
            }
        };

    function Ne(W) {
        return W.reduce((ge, fe) => ge.then(() => V(fe)), Promise.resolve())
    }
    return Le
}

function I$(e, t) {
    const n = [],
        r = [],
        i = [],
        s = Math.max(t.matched.length, e.matched.length);
    for (let o = 0; o < s; o++) {
        const a = t.matched[o];
        a && (e.matched.find(u => Vs(u, a)) ? r.push(a) : n.push(a));
        const l = e.matched[o];
        l && (t.matched.find(u => Vs(u, l)) || i.push(l))
    }
    return [n, r, i]
}
const $$ = "/assets/default-b4ddd046.svg",
    k$ = "/assets/pointer-45e3a2ec.svg",
    L$ = "/assets/active-76e7d58c.svg",
    N$ = "/assets/not-allowed-195bcc15.svg",
    F$ = "/assets/help-6b152726.svg",
    D$ = "/assets/grab-edda1ac6.svg",
    j$ = "/assets/grabbing-5e813e4c.svg",
    B$ = {
        install: e => {
            const t = zs({
                    go: !1,
                    menu: !1
                }),
                n = {};
            let r;
            const i = {
                init(s) {
                    r = s, i.customCursor(), t.go = !0, r.$router.beforeEach((o, a) => {
                        r.$routing.go && a && o.path !== a.path && Bs(() => {
                            i.toggleMenu(!1)
                        }, 24)
                    })
                },
                customCursor() {
                    const s = document.createElement("style");
                    s.innerHTML = `
        @layer base {
          :root {
            --app-cursor-default: url(` + $$ + `) 23 16, default;
            --app-cursor-pointer: url(` + k$ + `) 30 20, pointer;
            --app-cursor-active: url(` + L$ + `) 30 20, pointer;
            --app-cursor-not-allowed: url(` + N$ + `) 23 16, not-allowed;
            --app-cursor-help: url(` + F$ + `) 23 16, help;
            --app-cursor-grab: url(` + D$ + `) 36 36, grab;
            --app-cursor-grabbing: url(` + j$ + `) 36 36, grabbing;
          }
        }
        `, document.head.appendChild(s)
                },
                toggleMenu(s) {
                    t.menu = s === void 0 ? !t.menu : s, t.menu ? document.body.classList.add("--app-menu-open") : document.body.classList.remove("--app-menu-open"), r._window.lock(t.menu)
                }
            };
            Rt.global.$app = t, Rt.global._app = {
                data: s => gt(n, s),
                ...i
            }
        }
    },
    V$ = {
        install: e => {
            const t = zs({
                    go: !1,
                    menus: {},
                    options: {}
                }),
                n = {
                    cached: {}
                };
            let r;
            const i = {
                init(s) {
                    r = s, Sr && !Oy ? (Mn(Sr, "Server-side rendering: "), t.menus = Sr.menus, t.options = Sr.options, t.go = !0, Sr.error ? r._routing.addError(Sr.error.error, Sr.error.status) : r._routing.routePost(Sr.post), r._routing.loadPost()) : Promise.all([i.call({
                        url: "/api/menus"
                    }), i.call({
                        url: "/api/options"
                    })]).then(async ([o, a]) => {
                        t.menus = o, t.options = a, t.go = !0, r._routing.loadPost()
                    }).catch(o => {
                        r._routing.addError(o.message, o.status), t.go = !0, r._routing.loadPost()
                    })
                },
                headers() {
                    const s = {
                        "Content-Type": "application/json",
                        Pragma: "no-cache",
                        "Cache-Control": "no-cache"
                    }; {
                        const o = localStorage.getItem("user");
                        o && (s.Authorization = "Bearer " + JSON.parse(o).jwt, s["hextail-cms"] = "true")
                    }
                    return s
                },
                call(s) {
                    const a = { ...{
                            url: "/api",
                            method: "GET",
                            cached: !1,
                            version: Date.now(),
                            headers: i.headers(),
                            body: void 0,
                            delay: 0,
                            format: null
                        },
                        ...s
                    };
                    let l;
                    const u = typeof a.cached == "string" ? a.cached : a.method === "GET" ? a.url : JSON.stringify({
                        url: a.url,
                        body: a.body
                    });
                    return a.cached && n.cached[u] ? (Mn({
                        key: u
                    }, "API (cached)"), new Promise(f => setTimeout(() => {
                        f(n.cached[u])
                    }, a.delay))) : new Promise(f => setTimeout(() => {
                        f()
                    }, a.delay)).then(() => {
                        l = Date.now();
                        const f = a.version ? a.url + "?v=" + a.version : a.url;
                        return fetch(f, {
                            method: a.method,
                            headers: a.headers,
                            body: a.body
                        })
                    }).then(f => f.text().then(h => {
                        let _;
                        try {
                            let m = JSON.parse(h);
                            m && typeof m == "object" && (_ = m)
                        } catch {
                            return Promise.reject({
                                message: h,
                                status: 500
                            })
                        }
                        return f.ok ? (Mn({
                            call: a,
                            api: _,
                            response: f,
                            time: Date.now() - l + "ms"
                        }, "API (new)"), _.data ? { ..._.data
                        } : { ..._
                        }) : Promise.reject({
                            message: gt(_, "data.error") || f.statusText || "Error",
                            status: gt(_, "data.status") || f.status || 500
                        })
                    })).then(f => (a.format && (f = a.format(f)), a.cached && i.cache(u, f), f)).catch(f => {
                        const h = f.message || f.statusText || "Error",
                            _ = f.status || 500;
                        return Mn(h, _), Promise.reject({
                            message: h,
                            status: _
                        })
                    })
                },
                cache(s, o) {
                    n.cached[s] = o
                },
                block(s) {
                    const o = {};
                    return lr(s || {}, (a, l) => {
                        mh(a, "field_type") || mh(a, "value") ? o[l] = a.value : o[l] = a
                    }), o
                },
                content(s) {
                    const o = {};
                    return lr(s || {}, (a, l) => {
                        on(a) ? o[l] = af(a, u => i.block(u)) : XS(a) === 1 ? o[l] = i.block(Km(a)) : o[l] = AS(a, u => i.block(u))
                    }), o
                },
                get(s, o, a) {
                    return a = a || r.$routing.post, gt(a, "content." + s) || gt(a, "content." + s.split(".")[0]) || o
                },
                query(s, o) {
                    const a = {
                        cached: !0,
                        method: "POST",
                        body: JSON.stringify({
                            action: "query",
                            data: s
                        }),
                        format: l => (lr(l.posts || [], u => {
                            const f = u.content || {};
                            lr(u, (h, _) => {
                                _.includes("content.") && (KS(f, _.replace("content.", ""), h), delete u[_])
                            }), u.content = r._api.content(f)
                        }), l),
                        ...o
                    };
                    return i.call(a)
                }
            };
            Rt.global.$api = t, Rt.global._api = {
                data: s => gt(n, s),
                ...i
            }
        }
    },
    cm = (e, t) => {
        const n = e[t];
        return n ? typeof n == "function" ? n() : Promise.resolve(n) : new Promise((r, i) => {
            (typeof queueMicrotask == "function" ? queueMicrotask : setTimeout)(i.bind(null, new Error("Unknown variable dynamic import: " + t)))
        })
    },
    H$ = {
        install: e => {
            const t = {
                    custom: []
                },
                n = zs({
                    go: !1,
                    post: null
                }),
                r = {
                    last: sessionStorage.last || "",
                    previous: {},
                    active: {}
                };
            let i;
            const s = {
                init(o) {
                    i = o;
                    const a = window.location.pathname;
                    r.last !== a && (r.last = a, sessionStorage.last = a, i._window.scrollTo({
                        target: 0,
                        user: !0
                    })), i.$router.beforeEach((l, u) => {
                        n.go && u && l.path !== u.path && (r.last = l.path, sessionStorage.last = l.path)
                    }), lr(t.custom, l => {
                        i.$router.addRoute({
                            name: l.__id,
                            path: l.path,
                            component: () => cm(Object.assign({
                                "../templates/default.vue": () => yn(() =>
                                    import ("./default-076d02d9.js"), ["assets/default-076d02d9.js", "assets/default-c03cb230.css"]),
                                "../templates/error.vue": () => yn(() =>
                                    import ("./error-3db613fa.js"), ["assets/error-3db613fa.js", "assets/error-8fb2318f.css"]),
                                "../templates/home.vue": () => yn(() =>
                                    import ("./home-9c42f712.js"), ["assets/home-9c42f712.js", "assets/home-1bfae47c.css"]),
                                "../templates/info.vue": () => yn(() =>
                                    import ("./info-9ee35912.js"), ["assets/info-9ee35912.js", "assets/info-49c0b2d9.css"]),
                                "../templates/ui.vue": () => yn(() =>
                                    import ("./ui-05acea74.js").then(u => u.u), ["assets/ui-05acea74.js", "assets/ui-8f48893a.css"])
                            }), `../templates/${l.template}.vue`),
                            meta: RS({
                                custom: !0,
                                key: l.key,
                                __id: l.__id,
                                canonical: l.canonical
                            })
                        })
                    }), i.$router.beforeEach((l, u) => {
                        n.go && u && l.path !== u.path && (r.previous = { ...u
                        }, s.loadPost(l.fullPath))
                    })
                },
                getActive(o) {
                    const a = window.location;
                    o = o || a.pathname;
                    const l = i.$router.resolve(o + a.hash + a.search),
                        u = gt(l, "meta.__id") || yh(l.path, "/").replace(/\//g, "_") || "_",
                        f = "/api/" + (Oy ? "preview/" + u + "/" : "posts/" + u),
                        h = { ...l.params
                        },
                        _ = { ...l.query
                        },
                        m = l.hash;
                    return {
                        __id: u,
                        __api: f,
                        params: h,
                        query: _,
                        hash: m,
                        path: o,
                        ...l.meta
                    }
                },
                routePost(o, a) {
                    if (r.active = s.getActive(a), o.content = i._api.content(o.content), o.key = r.active.key || o.id, i._api.cache(r.active.__api, o), !r.active.custom) {
                        const l = o.template.replace("_", "-");
                        i.$router.addRoute({
                            name: r.active.__id,
                            path: o.permalink.path,
                            component: () => cm(Object.assign({
                                "../templates/default.vue": () => yn(() =>
                                    import ("./default-076d02d9.js"), ["assets/default-076d02d9.js", "assets/default-c03cb230.css"]),
                                "../templates/error.vue": () => yn(() =>
                                    import ("./error-3db613fa.js"), ["assets/error-3db613fa.js", "assets/error-8fb2318f.css"]),
                                "../templates/home.vue": () => yn(() =>
                                    import ("./home-9c42f712.js"), ["assets/home-9c42f712.js", "assets/home-1bfae47c.css"]),
                                "../templates/info.vue": () => yn(() =>
                                    import ("./info-9ee35912.js"), ["assets/info-9ee35912.js", "assets/info-49c0b2d9.css"]),
                                "../templates/ui.vue": () => yn(() =>
                                    import ("./ui-05acea74.js").then(u => u.u), ["assets/ui-05acea74.js", "assets/ui-8f48893a.css"])
                            }), `../templates/${l}.vue`).catch(u => {
                                Mn('"templates/' + l + '.vue" file is missing', 404)
                            })
                        })
                    }
                    i.$router.replace({
                        name: r.active.__id,
                        path: r.active.path,
                        params: r.active.params,
                        hash: r.active.hash,
                        query: r.active.query
                    })
                },
                addError(o, a) {
                    r.active = s.getActive();
                    const l = {
                        title: o + " " + a,
                        id: "error-" + Date.now(),
                        post_type: "page",
                        template: "error",
                        error: {
                            message: o,
                            status: a
                        },
                        permalink: {
                            path: r.active.path
                        }
                    };
                    s.routePost(l), s.setPost(l)
                },
                loadPost(o) {
                    n.post = null, r.active = s.getActive(o);
                    const a = r.active.__api,
                        l = i._api.data("cached[" + a + "]");
                    l ? (Mn(r.active, "Routing (cached)"), s.setPost(l)) : (Mn(r.active, "Routing (new)"), i._api.call({
                        url: a
                    }).then(u => {
                        s.routePost(u, u.permalink.path), s.setPost(u)
                    }, ({
                        message: u,
                        status: f
                    }) => {
                        s.addError(u, f)
                    }))
                },
                setPost(o) {
                    const a = i.$api.options;
                    let l = "";
                    const u = a.site_title || "";
                    o.permalink.frontpage ? l = o.seo_title ? o.seo_title : u : (l = o.seo_title ? o.seo_title : o.title, u && (l += " | " + u)), document.title = l;
                    const f = o.seo_desc || a.site_desc || "";
                    document.head.querySelector('meta[name="description"]').setAttribute("content", f);
                    const _ = yh(a.site_url || window.location.origin, "/");
                    document.head.querySelector('link[rel="canonical"]').setAttribute("href", _ + (r.active.canonical || o.permalink.path));
                    const T = o.seo_no_index || Fo || Rl ? "noindex, nofollow" : "index, follow";
                    document.head.querySelector('meta[name="robots"]').setAttribute("content", T), Bs(() => {
                        n.post = o, Mn(o, "Post")
                    }, 250)
                },
                addParam(o, a, l) {
                    const u = a || "",
                        f = { ...r.active
                        };
                    f.__id && String(f.query[o]) !== String(u) && (f.query[o] = u, l ? i.$router.push({
                        name: f.name,
                        query: f.query
                    }) : i.$router.replace({
                        name: f.name,
                        query: f.query
                    }))
                },
                removeParam(o, a) {
                    const l = { ...r.active
                    };
                    l.__id && l.query[o] !== void 0 && (delete l.query[o], a ? i.$router.push({
                        name: l.name,
                        query: l.query
                    }) : i.$router.replace({
                        name: l.name,
                        query: l.query
                    }))
                }
            };
            e.component("app-routing", {
                template: `
      <router-view v-slot="{ Component, route }">
        <transition 
          @before-leave="onBeforeLeave"
          @after-leave="onAfterLeave"
          :name="transition"
          mode="out-in"
        >
          <component
            v-if="post"
            :is="Component"
            :key="post.key"
            class="app-routing"
            @vue:mounted="mounted"
          />
        </transition>
      </router-view>
      `,
                computed: {
                    post() {
                        return n.post
                    },
                    transition() {
                        return n.go ? "app-routing" : null
                    }
                },
                methods: {
                    mounted() {
                        n.go || (n.go = !0, i.$nextTick(() => {
                            i._window.restoreScroll()
                        })), Bs(() => {
                            document.body.classList.remove("--app-routing")
                        }, 24)
                    },
                    onBeforeLeave() {
                        document.body.classList.add("--app-routing")
                    },
                    onAfterLeave() {
                        i._window.scrollTo({
                            target: 0,
                            user: !0
                        })
                    }
                }
            }), Rt.global.$routing = n, Rt.global._routing = {
                data: o => gt(r, o),
                ...s
            }
        }
    },
    U$ = {
        install: e => {
            const t = zs({
                    go: !1,
                    width: 0,
                    height: 0,
                    size: null,
                    scroll: parseInt(sessionStorage.scroll) || 0,
                    scrolled: !1,
                    locked: dP(document.body)
                }),
                n = JSON.parse('{"xs":362,"sm":640,"md":768,"lg":1024,"xl":1280,"2xl":1537,"3xl":1740}'),
                r = JSON.parse('{"body":"#FFFAF0","type":"#3A001D","raised":"#FFFFFF","spot":{"1":"#FECB66","2":"#FF6F89"},"soft":{"1":"#F7EFDF","2":"#FAE3B7","3":"#F9D1CB","4":"#E5D9CA"},"pom":{"1":"#EA3D5B","2":"#C21937","3":"#9A1436","4":"#730F34"}}'),
                i = {
                    observer: null,
                    retina: !1,
                    touch: !1,
                    scrollbar: 0,
                    browser: "",
                    ios: !1,
                    screens: n,
                    colors: r
                };
            let s;
            const o = {
                init(a) {
                    s = a, i.retina = o.checkRetina(), i.retina && document.body.classList.add("--retina-screen"), i.touch = o.checkTouch(), i.touch && document.body.classList.add("--touch-screen"), i.browser = o.checkBrowser(), document.body.classList.add("--browser-" + i.browser), i.ios = o.checkiOS(), i.ios && document.body.classList.add("--ios"), window.addEventListener("resize", vh(() => {
                        o.updateSize()
                    }, 10)), o.updateSize(), document.addEventListener("scroll", vh(() => {
                        o.updateScroll()
                    }, 10)), o.restoreScrollObserve(), document.addEventListener("pointerdown", o.userScrolled, {
                        once: !0
                    }), document.addEventListener("wheel", o.userScrolled, {
                        once: !0
                    }), document.addEventListener("touchstart", o.userScrolled, {
                        once: !0
                    }), o.cssVars(), document.readyState === "complete" ? t.go = !0 : window.addEventListener("load", () => {
                        t.go = !0
                    }, {
                        once: !0
                    })
                },
                updateSize() {
                    const a = Math.max(document.documentElement.clientWidth, window.innerWidth || 0),
                        l = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);
                    t.width = a, t.height = l;
                    const u = Km(Object.values(n).reverse(), f => window.matchMedia("(min-width: " + f + "px)").matches);
                    t.size = pS(n, f => f === u) || "-"
                },
                updateScroll(a) {
                    if (t.scrolled || a) {
                        const l = parseInt(window.scrollY || document.documentElement.scrollTop);
                        sessionStorage.scroll = a || l, t.scroll = a || l
                    }
                },
                restoreScrollObserve() {
                    i.observer = new MutationObserver(o.restoreScroll), i.observer.observe(e._container, {
                        childList: !0,
                        subtree: !0
                    })
                },
                restoreScroll() {
                    if (!t.scroll && window.location.hash) {
                        const a = window.location.hash.substring(1),
                            l = document.getElementById(a);
                        l && o.scrollTo({
                            target: l
                        });
                        return
                    }
                    o.scrollTo({
                        target: t.scroll
                    })
                },
                userScrolled() {
                    t.scrolled = !0, i.observer && i.observer.disconnect()
                },
                scrollTo(a) {
                    const u = { ...{
                            target: 0,
                            centered: !1,
                            smooth: !1,
                            user: !1
                        },
                        ...a
                    };
                    if (u.user && o.userScrolled(), Wo(u.target) && (u.target = document.querySelector(u.target)), ES(u.target)) {
                        const f = parseInt(window.scrollY || document.documentElement.scrollTop),
                            h = u.target.getBoundingClientRect();
                        u.target = h.top + f, u.centered && (u.target += h.height * .5)
                    }
                    u.centered && (u.target -= t.height * .5), window.scrollTo({
                        top: u.target,
                        behavior: u.smooth ? "smooth" : "instant"
                    }), o.updateScroll(u.target)
                },
                checkRetina() {
                    return window.matchMedia("(-webkit-min-device-pixel-ratio: 2)").matches || window.devicePixelRatio >= 2
                },
                checkTouch() {
                    return window.matchMedia("(pointer: coarse)").matches
                },
                checkBrowser() {
                    return /^((?!chrome|android).)*safari/i.test(navigator.userAgent) ? "safari" : /Edge/.test(navigator.userAgent) ? "edge" : /firefox/i.test(navigator.userAgent) ? "firefox" : /Chrome/.test(navigator.userAgent) && /Google Inc/.test(navigator.vendor) ? "chrome" : ""
                },
                checkiOS() {
                    return ["iPad Simulator", "iPhone Simulator", "iPod Simulator", "iPad", "iPhone", "iPod"].includes(navigator.platform) || navigator.userAgent.includes("Mac") && "ontouchend" in document
                },
                lock(a) {
                    const l = document.body;
                    a ? s.$nextTick(() => {
                        t.locked = !0, i.scrollbar && (l.style.setProperty("--scrollbar-width", i.scrollbar + "px"), l.style.setProperty("padding-right", i.scrollbar + "px"), l.style.setProperty("margin-right", "0px"))
                    }) : (t.locked = !1, l.style.removeProperty("--scrollbar-width"), l.style.removeProperty("padding-right"), l.style.removeProperty("margin-right"))
                },
                cssVars() {
                    const a = document.body;
                    i.scrollbar = window.innerWidth - a.offsetWidth, a.style.setProperty("--app-scrollbar", i.scrollbar + "px")
                }
            };
            Rt.global._is = a => (t.width, window.matchMedia("(min-width: " + n[a] + "px)").matches), Rt.global._isBelow = a => (t.width, window.matchMedia("(max-width: " + (n[a] - 1) + "px)").matches), Rt.global._isPortrait = () => (t.width, window.matchMedia("(orientation: portrait)").matches), Rt.global._isLandscape = () => (t.width, window.matchMedia("(orientation: landscape)").matches), Rt.global.$window = t, Rt.global._window = {
                data: a => gt(i, a),
                ...o
            }
        }
    },
    W$ = {
        install: e => {
            const t = zs({
                    go: !1
                }),
                n = {
                    init(r) {
                        t.go = !0
                    },
                    animateType(r) {
                        const s = gh({
                            heading: null,
                            text: null,
                            scroll: null
                        }, r);
                        s.heading && (hP.create(s.heading, {
                            types: "words",
                            wordClass: "--type-word"
                        }), ji(s.heading.querySelectorAll(".--type-word"), {
                            scaleY: {
                                from: .8
                            },
                            opacity: {
                                from: 0,
                                duration: 75,
                                ease: "linear"
                            },
                            duration: 1800,
                            ease: "outElastic(1.3, 0.4)",
                            autoplay: s.scroll ? Bi({
                                enter: "center+=3em top",
                                target: s.scroll
                            }) : !0,
                            delay: Nu(60, {
                                start: s.scroll ? 0 : 500
                            })
                        })), s.text && ji(s.text, {
                            opacity: {
                                from: 0
                            },
                            delay: Nu(250, {
                                start: s.scroll ? 200 : 800
                            }),
                            duration: 300,
                            ease: "linear",
                            autoplay: s.scroll ? Bi({
                                enter: "center+=3em top",
                                target: s.scroll
                            }) : !0
                        })
                    },
                    animateMedia(r) {
                        const s = gh({
                            el: null
                        }, r);
                        s.el && ji(s.el, {
                            y: {
                                from: "20%"
                            },
                            opacity: {
                                from: 0,
                                duration: 200,
                                ease: "linear"
                            },
                            duration: 1500,
                            ease: "outElastic(1, 0.8)",
                            autoplay: Bi({
                                enter: "center+=8em top"
                            })
                        })
                    }
                };
            Rt.global.$motion = t, Rt.global._motion = {
                data: r => gt(data, r),
                ...n
            }
        }
    },
    z$ = "/assets/active-76e7d58c.svg",
    q$ = "/assets/crosshair-5335bdbc.svg",
    K$ = "/assets/default-b4ddd046.svg",
    G$ = "/assets/grab-edda1ac6.svg",
    Y$ = "/assets/grabbing-5e813e4c.svg",
    X$ = "/assets/help-6b152726.svg",
    J$ = "/assets/not-allowed-195bcc15.svg",
    Z$ = "/assets/pointer-45e3a2ec.svg",
    Q$ = "/assets/text-370fe426.svg",
    ek = "/assets/phone-mask-f191834c.svg",
    tk = "/assets/pomegranate-icon-dfadad6d.svg",
    nk = "/assets/pomegranate-logo-71304675.svg",
    rk = "/assets/embla-291e4361.svg",
    ik = "/assets/hextail-234386cc.svg",
    sk = "/assets/radix-6f10e69e.svg",
    ok = "/assets/uno-1ec078ba.svg",
    ak = "/assets/vite-a298ef45.svg",
    lk = "/assets/vue-9dc71870.svg",
    ck = {
        install: e => {
            let t;
            const n = {
                    init(a) {
                        t = a
                    },
                    time(a, l) {
                        if (!a || !Number.isInteger(a)) return "";
                        const u = new Date(a * 1e3),
                            f = u.getFullYear(),
                            h = u.getMonth() + 1,
                            _ = u.getDate();
                        switch (l) {
                            case "datetime":
                                return f + "-" + h + _;
                            default:
                                return _ + "/" + h + "/" + f
                        }
                    },
                    formatNumber(a, l) {
                        switch (l) {
                            case "commas":
                                return a.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                            case "abbreviate":
                                const u = ["", "k", "M", "G", "T", "P", "E"],
                                    f = Math.log10(Math.abs(a)) / 3 | 0;
                                if (f == 0) return a;
                                const h = u[f],
                                    _ = Math.pow(10, f * 3);
                                return (a / _).toFixed(1) + h;
                            default:
                                return a
                        }
                    }
                },
                r = (a, l) => {
                    const h = a.innerHTML.replaceAll(`

`, "<br><br>").replaceAll(`
`, '<br class="--type-nl2br">');
                    a.innerHTML = h
                };
            e.directive("nl2br", {
                beforeMount: r
            });
            const i = (a, l) => {
                const f = { ...{
                            minWords: 4,
                            bigWord: 9
                        },
                        ...l.value || {}
                    },
                    h = a.innerHTML.trim().replace(/&nbsp;/g, " ").split(/ (?=[^>]*(?:<|$))/);
                if (h.length < f.minWords || h[h.length - 1].length >= f.bigWord) return;
                const _ = h[h.length - 2];
                h[h.length - 2] = _ + "&nbsp;";
                let m = h.join(" ");
                m = m.replace(/&nbsp; /g, "&nbsp;"), a.innerHTML = m
            };
            e.directive("orphans", {
                beforeMount: i
            });
            const s = a => {
                let {
                    target: l
                } = a;
                for (; l && l.tagName !== "A";) l = l.parentNode;
                if (l && l.matches("a:not([href*='://']):not([href*='tel:']):not([href*='mailto:'])") && l.href) {
                    const {
                        altKey: u,
                        ctrlKey: f,
                        metaKey: h,
                        shiftKey: _,
                        button: m,
                        defaultPrevented: T
                    } = a;
                    if (h || u || f || _ || T || m !== void 0 && m !== 0) return;
                    if (l && l.getAttribute) {
                        const I = l.getAttribute("target");
                        if (/\b_blank\b/i.test(I)) return
                    }
                    const B = new URL(l.href).pathname;
                    a.preventDefault(), window.location.pathname !== B && t.$router.push(B)
                } else if (l && l.matches("a[href*='://']") && l.href) {
                    const u = new URL(l.href);
                    a.preventDefault(), window.open(u, "_blank")
                }
            };
            e.directive("links", {
                beforeMount: a => {
                    a.addEventListener("click", s), lr(a.querySelectorAll("a[href*='://'], a[target='_blank']"), l => {
                        l.innerHTML += '<svg class="--type-external" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M21 9V3m0 0h-6m6 0-8 8m-3-6H5L3 7v12l2 2h12l2-2v-5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>'
                    })
                },
                unmounted: a => {
                    a.removeEventListener("click", s)
                }
            });
            const o = (a, l) => {
                const f = { ...{
                            once: !1,
                            threshold: 0
                        },
                        ...l.value || {}
                    },
                    h = Py(a, {
                        threshold: f.threshold
                    }),
                    _ = zn(h, m => {
                        m ? (a.setAttribute("data-visible", !0), a.dispatchEvent(new CustomEvent("isVisible")), f.once && _()) : (a.removeAttribute("data-visible"), a.dispatchEvent(new CustomEvent("isHidden")))
                    })
            };
            e.directive("visible", {
                beforeMount: o
            }), Rt.global._image = a => new URL(Object.assign({
                "/src/assets/images/cursor/active.svg": z$,
                "/src/assets/images/cursor/crosshair.svg": q$,
                "/src/assets/images/cursor/default.svg": K$,
                "/src/assets/images/cursor/grab.svg": G$,
                "/src/assets/images/cursor/grabbing.svg": Y$,
                "/src/assets/images/cursor/help.svg": X$,
                "/src/assets/images/cursor/not-allowed.svg": J$,
                "/src/assets/images/cursor/pointer.svg": Z$,
                "/src/assets/images/cursor/text.svg": Q$,
                "/src/assets/images/phone-mask.svg": ek,
                "/src/assets/images/pomegranate-icon.svg": tk,
                "/src/assets/images/pomegranate-logo.svg": nk,
                "/src/assets/images/stack/embla.svg": rk,
                "/src/assets/images/stack/hextail.svg": ik,
                "/src/assets/images/stack/radix.svg": sk,
                "/src/assets/images/stack/uno.svg": ok,
                "/src/assets/images/stack/vite.svg": ak,
                "/src/assets/images/stack/vue.svg": lk
            })[`/src/assets/images/${a}`], self.location).href, Rt.global._utils = { ...n
            }
        }
    },
    uk = {
        install: e => {
            const t = zs({
                    go: !1
                }),
                n = {
                    site_id: gt(Sr, "options.fathom_site_id")
                };
            let r;
            const i = {
                init(s) {
                    if (r = s, !n.site_id) return;
                    const o = document.createElement("script");
                    o.onload = () => {
                        window.fathom && (t.go = !0, Mn({
                            url: window.location.pathname
                        }, "Analytics"), !Fo && !Rl && window.fathom.trackPageview(), r.$router.afterEach((a, l, u) => {
                            const f = gt(a, "fullPath", void 0),
                                h = gt(l, "fullPath", void 0);
                            !u && f !== h && (!Fo && !Rl && window.fathom.trackPageview({
                                url: f,
                                referrer: h
                            }), Mn({
                                url: f,
                                referrer: h
                            }, "Analytics"))
                        }))
                    }, o.setAttribute("data-site", n.site_id), o.setAttribute("data-auto", !1), o.setAttribute("defer", ""), o.src = "https://cdn.usefathom.com/script.js", document.head.appendChild(o)
                },
                track(s, o) {
                    const a = {
                        _site_id: n.site_id,
                        _value: o
                    };
                    Mn({
                        name: s,
                        payload: a
                    }, "Analytics"), t.go && window.fathom.trackEvent(s, a)
                }
            };
            Rt.global.$analytics = t, Rt.global._analytics = {
                data: s => gt(n, s),
                ...i
            }
        }
    },
    Zn = cP(P4);
Rt.global = Zn.config.globalProperties;
const Uy = R$({
    history: o$("/"),
    scrollBehavior() {
        return !1
    },
    routes: []
});
Zn.use(Uy);
Rt.router = Uy;
Zn.use(B$);
Zn.use(V$);
Zn.use(H$);
Zn.use(U$);
Zn.use(W$);
Zn.use(ck);
Zn.use(uk);
lr([{
    files: Object.assign({
        "/src/components/core/block.vue": _P,
        "/src/components/core/group.vue": wP,
        "/src/components/core/icon.vue": EP,
        "/src/components/core/media.vue": PP,
        "/src/components/core/posts.vue": $P,
        "/src/components/core/rive.vue": jP,
        "/src/components/core/route.vue": UP
    }),
    prefix: ""
}, {
    files: Object.assign({
        "/src/components/icons/action-alert.vue": GP,
        "/src/components/icons/action-check.vue": QP,
        "/src/components/icons/action-close.vue": iM,
        "/src/components/icons/action-external.vue": cM,
        "/src/components/icons/action-health.vue": pM,
        "/src/components/icons/action-help.vue": yM,
        "/src/components/icons/action-info.vue": EM,
        "/src/components/icons/action-money.vue": RM,
        "/src/components/icons/action-open.vue": NM,
        "/src/components/icons/action-search.vue": VM,
        "/src/components/icons/action-spark.vue": KM,
        "/src/components/icons/action-team.vue": QM,
        "/src/components/icons/action-user.vue": sR,
        "/src/components/icons/arrow-down.vue": uR,
        "/src/components/icons/arrow-left.vue": mR,
        "/src/components/icons/arrow-right.vue": bR,
        "/src/components/icons/arrow-up.vue": ER,
        "/src/components/icons/chevron-down.vue": MR,
        "/src/components/icons/chevron-left.vue": LR,
        "/src/components/icons/chevron-right.vue": BR,
        "/src/components/icons/chevron-up.vue": zR,
        "/src/components/icons/chevron-y.vue": XR,
        "/src/components/icons/math-minus.vue": t5,
        "/src/components/icons/math-plus.vue": o5,
        "/src/components/icons/media-muted.vue": f5,
        "/src/components/icons/media-play.vue": g5,
        "/src/components/icons/media-unmuted.vue": w5
    }),
    prefix: "icon-"
}, {
    files: Object.assign({
        "/src/components/ui/button.vue": A5,
        "/src/components/ui/card.vue": I5,
        "/src/components/ui/expand.vue": D5,
        "/src/components/ui/gradient.vue": W5,
        "/src/components/ui/image.vue": Z5,
        "/src/components/ui/rive.vue": r6,
        "/src/components/ui/scroll.vue": a6,
        "/src/components/ui/skeleton.vue": m6,
        "/src/components/ui/tag.vue": b6,
        "/src/components/ui/video.vue": O6
    }),
    prefix: "ui-"
}, {
    files: Object.assign({
        "/src/components/blocks/accordion.vue": z6,
        "/src/components/blocks/blockquote.vue": J6,
        "/src/components/blocks/button.vue": nI,
        "/src/components/blocks/caption.vue": aI,
        "/src/components/blocks/columns.vue": pI,
        "/src/components/blocks/feature.vue": AI,
        "/src/components/blocks/grid.vue": MI,
        "/src/components/blocks/heading.vue": LI,
        "/src/components/blocks/image.vue": jI,
        "/src/components/blocks/list.vue": WI,
        "/src/components/blocks/opening.vue": YI,
        "/src/components/blocks/paragraph.vue": e4,
        "/src/components/blocks/spacer.vue": s4,
        "/src/components/blocks/table.vue": f4,
        "/src/components/blocks/video.vue": g4,
        "/src/components/blocks/youtube.vue": E4
    }),
    prefix: "block-"
}, {
    files: Object.assign({}),
    prefix: "part-"
}], e => {
    lr(e.files, (t, n) => {
        const r = e.prefix + n.split("/").at(-1).split(".")[0];
        Zn.component(r, t.default), Rt.components.push(r)
    })
});
const Wu = Zn.mount("#app");
Rt.v = Wu;
lr(["routing", "window", "motion", "utils", "api", "app", "analytics"], e => {
    Wu["_" + e].init(Wu)
});
Fo || console.log(`

███████████████████████████████████████████████
███████████████████████████████████████████████
███████████████████████████████████████████████
███████████████████████████████████████████████
█████████▓    ████      ▓███▒      ▓███████████
██████████    ▓██▓      ▒███       ▒███████████
██████████    ▒██▒       ███       ▒███████████
██████████▒    ██    ▒   ██▓   ▒    ███████████
██████████▓    ██   ▒▒   ██▒   █    ███████████
██████████▓    █▓   ▓▓   ▓█   ▒█    ▓██████████
███████████    ▓▒   ██   ▒▓   ▒█    ▒██████████
███████████    ▓    ██    ▓   ▓█▒    ██████████
███████████▒       ▒██▒       ██▓    ██████████
███████████▓       ▓██▓       ██▓    ██████████
████████████       ███▓      ▒███    ▓█████████
████████████▒    ▒▓████▒    ▒████▒   ▓█████████
███████████████████████████████████████████████
███████████████████████████████████████████████
███████████████████████████████████████████████
███████████████████████████████████████████████
  
                    v` + lP + `

--------- by https://wondermake.xyz ---------

`);
export {
    lr as $, U_ as A, Fo as B, fk as C, dk as D, on as E, nt as F, el as G, Tm as H, ef as I, zu as J, $l as K, af as L, lS as M, Km as N, yA as O, qt as P, Bi as Q, eT as R, oi as S, Mr as T, pi as U, Tn as V, an as W, is as X, Jl as Y, zn as Z, Ee as _, Wi as a, Wo as a0, Py as a1, kr as a2, Ku as a3, Il as a4, lb as a5, il as a6, fw as a7, Jc as a8, mw as a9, WC as aA, LC as aB, ET as aC, Cr as aD, ws as aE, kt as aF, Eg as aG, W_ as aH, fr as aI, oo as aJ, Tf as aK, Jn as aL, Zg as aM, Xl as aN, Pg as aO, sn as aP, hr as aQ, qC as aR, vh as aS, pk as aT, C1 as aa, Lm as ab, iS as ac, lf as ad, gl as ae, q_ as af, Mn as ag, Ht as ah, Ar as ai, xg as aj, pf as ak, fg as al, GT as am, qo as an, tC as ao, ag as ap, C_ as aq, li as ar, wA as as, Ws as at, Oo as au, Jg as av, Zl as aw, gE as ax, ec as ay, OC as az, Mt as b, pe as c, qe as d, yn as e, ji as f, gt as g, vt as h, Et as i, Ct as j, Pe as k, Za as l, ui as m, Ot as n, Q as o, dt as p, Pr as q, pt as r, Nu as s, Hi as t, Rt as u, zs as v, zt as w, hk as x, Bs as y, ns as z
};