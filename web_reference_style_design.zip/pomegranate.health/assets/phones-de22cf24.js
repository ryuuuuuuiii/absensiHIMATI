import {
    _ as p,
    R as c,
    g as i,
    f as l,
    Q as m,
    s as _,
    h as u,
    o as t,
    c as s,
    F as d,
    a as h,
    k as f
} from "./index-1cb91aca.js";
const g = {
        props: {
            content: {
                type: Object,
                default: () => ({})
            }
        },
        computed: {
            items() {
                const e = this;
                return c(3, n => i(e.content, "media_" + (n + 1), {}))
            }
        },
        mounted() {
            this.animeInit()
        },
        methods: {
            animeInit() {
                const e = this;
                l(e.$refs.phones.querySelectorAll(".part-phones_item"), {
                    y: ["100%", "0%"],
                    autoplay: m({
                        target: e.$refs.phones,
                        sync: .5
                    }),
                    ease: "outExpo",
                    delay: _(50)
                })
            }
        }
    },
    v = {
        class: "part-phones",
        ref: "phones"
    },
    y = {
        class: "part-phones_item"
    };

function x(e, n, $, k, b, a) {
    const r = u("media");
    return t(), s("div", v, [(t(!0), s(d, null, h(a.items, o => (t(), s("div", y, [f(r, {
        media: o,
        thumb: "phone",
        alt: "Pomegranate app preview",
        loop: o.extention === "mp4" ? !1 : null
    }, null, 8, ["media", "loop"])]))), 256))], 512)
}
const E = p(g, [
    ["render", x]
]);
export {
    E as
    default
};